package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.Image;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class sql_Image {
	private sql_DataBase data;
	private int PICKER_ID;
	private String PICKER_NAME;
	
	public static final String TABLE_IMAGE = "Image";
	public static final String COLUMN0_ID = "ID";
	public static final String COLUMN1_LOAD_ID = "LoadId";
	public static final String COLUMN2_LOAD_CODE = "LoadCode";
	public static final String COLUMN3_ORDER_REF = "OrderRef";
	public static final String COLUMN4_ORDER_ITEM_ID = "OrderItemId";
	public static final String COLUMN5_PICKER_ID = "PickerId";
	public static final String COLUMN6_PICKER_NAME = "PickerName";
	public static final String COLUMN7_IMAGE_DATA = "ImageData";
	public static final String COLUMN8_IMAGE_NAME = "ImageName";
	public static final String COLUMN9_IMAGE_TYPE = "ImageType";
	
	public static final String CREATE_TABLE_IMAGE = "CREATE TABLE " 
			+ TABLE_IMAGE +"("
			+ COLUMN0_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ COLUMN1_LOAD_ID +" INTEGER, "
			+ COLUMN2_LOAD_CODE +" TEXT, "
			+ COLUMN3_ORDER_REF +" TEXT, "
			+ COLUMN4_ORDER_ITEM_ID +" TEXT, "
			+ COLUMN5_PICKER_ID +" INTEGER, "
			+ COLUMN6_PICKER_NAME +" TEXT, "
			+ COLUMN7_IMAGE_DATA +" TEXT, "
			+ COLUMN8_IMAGE_NAME +" TEXT, "
			+ COLUMN9_IMAGE_TYPE +" INTEGER)";
	
	public sql_Image(Context context){
		data = new sql_DataBase(context);
		FileSave fileSave = new FileSave(context, Constants.GET);
		PICKER_ID = fileSave.getPickerID();
		PICKER_NAME = fileSave.getPickerName();
	}
	
	public void insert(Image image){
		SQLiteDatabase db = data.getWritableDatabase();
		ContentValues values = new ContentValues();		
		values.put(COLUMN1_LOAD_ID, image.getLoadId());
		values.put(COLUMN2_LOAD_CODE, image.getLoadCode());
		values.put(COLUMN3_ORDER_REF, image.getOrderRef());
		values.put(COLUMN4_ORDER_ITEM_ID, image.getOrderItemId());
		values.put(COLUMN5_PICKER_ID, PICKER_ID);
		values.put(COLUMN6_PICKER_NAME, PICKER_NAME);
		values.put(COLUMN7_IMAGE_DATA, image.getImageData());
		values.put(COLUMN8_IMAGE_NAME, image.getImageName());
		values.put(COLUMN9_IMAGE_TYPE, image.getImageType());
		
		if(db.insert(TABLE_IMAGE, null, values) > 0){
			Log.e("Insert Image:", "LUU IMAGE THANH CONG");
		}
		db.close();
	}
	
	public List<Image> selectTop() {
		List<Image> list = null;
		Image image = null;
		SQLiteDatabase db = data.getReadableDatabase();
		String sql = "SELECT * FROM " + TABLE_IMAGE + "";
		Cursor cursor = db.rawQuery(sql, null);
		if (cursor.getCount() > 0) {
			list = new ArrayList<Image>();
			cursor.moveToFirst();
			do {
				image = new Image();
				image.setId(cursor.getInt(0));
				image.setLoadId(cursor.getInt(1));
				image.setLoadCode(cursor.getString(2));
				image.setOrderRef(cursor.getString(3));
				image.setOrderItemId(cursor.getString(4));
				image.setPickerId(cursor.getInt(5));
				image.setPickerName(cursor.getString(6));
				image.setImageData(cursor.getString(7));
				image.setImageName(cursor.getString(8));
				image.setImageType(cursor.getInt(9));
				
				list.add(image);
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}
	
	public boolean delete(Image obj){
		boolean output = false;
		SQLiteDatabase db = data.getWritableDatabase();
		int sodong = db.delete(TABLE_IMAGE,
				COLUMN0_ID + " = " + obj.getId(), null);
		if (sodong > 0) {
			output = true;
		}
		db.close();
		return output;
	}
}
