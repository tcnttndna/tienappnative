package vcn.kybotech.model;

public class PickPart {

	int id;
	int PartID;
	boolean IsScanned;
	boolean IsQA;
	boolean IsQC;
	String PartName;
	int Quantity;
	String Barcode;
	String OrderRef;
	int OrderItemID;
	int TotalPack;
	String DateScanned;
	String LocationName;
	String PickedBy;
	int PickTypeID;
	String PickType;
	String ProductName;
	String ProductOption;
	int DropNumber;
	int LoadCode;
	int Package;
	String SpecialInstructions;
	int Swipe;
	int FreeStock;
	int SwipeQA;
	int SwipeQC;
	boolean IsStacked;
	int SwipeStack;
	String StackedBy;
	boolean IsChecked;
	int SwipeCheck;
	String CheckedBy;
	String PickingNotes;
	boolean IsLoaded;
	private String PartGroup;
	private int PartGroupID;
	private boolean NeedScan;

	public boolean isQC() {
		return IsQC;
	}

	public void setQC(boolean QC) {
		IsQC = QC;
	}

	public int getSwipeQC() {
		return SwipeQC;
	}

	public void setSwipeQC(int swipeQC) {
		SwipeQC = swipeQC;
	}

	public int getPartGroupID() {
		return PartGroupID;
	}

	public void setPartGroupID(int partGroupID) {
		PartGroupID = partGroupID;
	}

	public boolean isNeedScan() {
		return NeedScan;
	}

	public void setNeedScan(boolean needScan) {
		NeedScan = needScan;
	}

	public String getPartGroup() {
		return PartGroup;
	}

	public void setPartGroup(String partGroup) {
		PartGroup = partGroup;
	}

	public boolean isIsLoaded() {
		return IsLoaded;
	}

	public void setIsLoaded(boolean isLoaded) {
		IsLoaded = isLoaded;
	}

	public int getSwipeLoading() {
		return SwipeLoading;
	}

	public void setSwipeLoading(int swipeLoading) {
		SwipeLoading = swipeLoading;
	}

	public String getLoadedBy() {
		return LoadedBy;
	}

	public void setLoadedBy(String loadedBy) {
		LoadedBy = loadedBy;
	}

	int SwipeLoading;
	String LoadedBy;

	public String getPickingNotes() {
		return PickingNotes;
	}

	public void setPickingNotes(String pickingNotes) {
		PickingNotes = pickingNotes;
	}

	public boolean isIsChecked() {
		return IsChecked;
	}

	public void setIsChecked(boolean isChecked) {
		IsChecked = isChecked;
	}

	public int getSwipeCheck() {
		return SwipeCheck;
	}

	public void setSwipeCheck(int swipeCheck) {
		SwipeCheck = swipeCheck;
	}

	public String getCheckedBy() {
		return CheckedBy;
	}

	public void setCheckedBy(String checkedBy) {
		CheckedBy = checkedBy;
	}

	public boolean isIsStacked() {
		return IsStacked;
	}

	public void setIsStacked(boolean isStacked) {
		IsStacked = isStacked;
	}

	public int getSwipeStack() {
		return SwipeStack;
	}

	public void setSwipeStack(int swipeStack) {
		SwipeStack = swipeStack;
	}

	public String getStackedBy() {
		return StackedBy;
	}

	public void setStackedBy(String stackedBy) {
		StackedBy = stackedBy;
	}

	public PickPart() {
		super();
	}

	public PickPart(int id, int partID, boolean isScanned, boolean isQA, String partName, int quantity, String orderRef,
			int orderItemID, int totalPack, String locationName, String pickedBy, int picktypeid, int package1,
			String specialInstructions, int swipe, int freeStock, int swipeQA, boolean isStacked, int swipeStack,
			String stackedBy, boolean isChecked, int swipeCheck, String checkedBy, String pickingNotes,
			boolean isLoaded, int swipeLoading, String loadedBy, String partGroup, boolean NeedScan, int partGroupID, boolean isQC, int swipeQC) {
		super();
		this.id = id;
		PartID = partID;
		IsScanned = isScanned;
		IsQA = isQA;
		IsQC = isQC;
		PartName = partName;
		Quantity = quantity;
		OrderRef = orderRef;
		OrderItemID = orderItemID;
		TotalPack = totalPack;
		LocationName = locationName;
		PickedBy = pickedBy;
		PickTypeID = picktypeid;
		Package = package1;
		SpecialInstructions = specialInstructions;
		Swipe = swipe;
		FreeStock = freeStock;
		SwipeQA = swipeQA;
		SwipeQC = swipeQC;
		IsStacked = isStacked;
		SwipeStack = swipeStack;
		StackedBy = stackedBy;
		IsChecked = isChecked;
		SwipeCheck = swipeCheck;
		CheckedBy = checkedBy;
		PickingNotes = pickingNotes;
		IsLoaded = isLoaded;
		SwipeLoading = swipeLoading;
		LoadedBy = loadedBy;
		PartGroup = partGroup;
		PartGroupID = partGroupID;
		this.NeedScan = NeedScan;
	}

	public PickPart(int id, int partID, boolean isScanned, boolean isQA, String partName, int quantity, String orderRef,
			int orderItemID, int totalPack, String locationName, String pickedBy, int picktypeid, int package1,
			String specialInstructions, int swipe, int freeStock, int swipeQA, String pickingNotes, boolean isQC, int swipeQC) {
		super();
		this.id = id;
		PartID = partID;
		IsScanned = isScanned;
		IsQA = isQA;
		IsQC = isQC;
		PartName = partName;
		Quantity = quantity;
		OrderRef = orderRef;
		OrderItemID = orderItemID;
		TotalPack = totalPack;
		LocationName = locationName;
		PickedBy = pickedBy;
		PickTypeID = picktypeid;
		Package = package1;
		SpecialInstructions = specialInstructions;
		Swipe = swipe;
		FreeStock = freeStock;
		SwipeQA = swipeQA;
		SwipeQC = swipeQC;
		PickingNotes = pickingNotes;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public boolean isIsScanned() {
		return IsScanned;
	}

	public void setIsScanned(boolean isScanned) {
		IsScanned = isScanned;
	}

	public boolean isIsQA() {
		return IsQA;
	}

	public void setIsQA(boolean isQA) {
		IsQA = isQA;
	}

	public String getPartName() {
		return PartName;
	}

	public void setPartName(String partName) {
		PartName = partName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public String getBarcode() {
		return Barcode;
	}

	public void setBarcode(String barcode) {
		Barcode = barcode;
	}

	public String getOrderRef() {
		return OrderRef;
	}

	public void setOrderRef(String orderRef) {
		OrderRef = orderRef;
	}

	public int getOrderItemID() {
		return OrderItemID;
	}

	public void setOrderItemID(int orderItemID) {
		OrderItemID = orderItemID;
	}

	public int getTotalPack() {
		return TotalPack;
	}

	public void setTotalPack(int totalPack) {
		TotalPack = totalPack;
	}

	public String getDateScanned() {
		return DateScanned;
	}

	public void setDateScanned(String dateScanned) {
		DateScanned = dateScanned;
	}

	public String getLocationName() {
		return LocationName;
	}

	public void setLocationName(String locationName) {
		LocationName = locationName;
	}

	public String getPickedBy() {
		return PickedBy;
	}

	public void setPickedBy(String pickedBy) {
		PickedBy = pickedBy;
	}

	public int getPickTypeID() {
		return PickTypeID;
	}

	public void setPickTypeID(int pickTypeID) {
		PickTypeID = pickTypeID;
	}

	public String getPickType() {
		return PickType;
	}

	public void setPickType(String pickType) {
		PickType = pickType;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public String getProductOption() {
		return ProductOption;
	}

	public void setProductOption(String productOption) {
		ProductOption = productOption;
	}

	public int getiDropNumber() {
		return DropNumber;
	}

	public void setiDropNumber(int iDropNumber) {
		this.DropNumber = iDropNumber;
	}

	public int getLoadCode() {
		return LoadCode;
	}

	public void setLoadCode(int loadCode) {
		LoadCode = loadCode;
	}

	public int getPackage() {
		return Package;
	}

	public void setPackage(int package1) {
		Package = package1;
	}

	public String getSpecialInstructions() {
		return SpecialInstructions;
	}

	public void setSpecialInstructions(String specialInstructions) {
		SpecialInstructions = specialInstructions;
	}

	public int getSwipe() {
		return Swipe;
	}

	public void setSwipe(int swipe) {
		Swipe = swipe;
	}

	public int getDropNumber() {
		return DropNumber;
	}

	public void setDropNumber(int dropNumber) {
		DropNumber = dropNumber;
	}

	public int getFreeStock() {
		return FreeStock;
	}

	public void setFreeStock(int freeStock) {
		FreeStock = freeStock;
	}

	public int getSwipeQA() {
		return SwipeQA;
	}

	public void setSwipeQA(int swipeQA) {
		SwipeQA = swipeQA;
	}

}
