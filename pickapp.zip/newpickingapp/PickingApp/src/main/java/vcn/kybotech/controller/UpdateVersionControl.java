package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;

public class UpdateVersionControl {
	private JSONParser jsonParser;

	public UpdateVersionControl() {
		this.jsonParser = new JSONParser();
	}
	
	public JSONObject requestServer(int curVersion){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "checkversion"));
		params.add(new BasicNameValuePair("softType", "newpickingapp"));
		params.add(new BasicNameValuePair("curVersion", String.valueOf(curVersion)));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
}
