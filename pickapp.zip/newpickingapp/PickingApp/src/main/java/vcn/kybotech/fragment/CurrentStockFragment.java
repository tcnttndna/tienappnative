package vcn.kybotech.fragment;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import vcn.kybotech.adapter.CurrentStockAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.controller.CurrentStockControl;
import vcn.kybotech.model.CurrentStock;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class CurrentStockFragment extends Fragment {
	private TextView tvPartId;
	private TextView tvPartName;
	public static EditText etTapToScan;
	private ImageView imgTapToScan;
	private ProgressBar proLoad;
	public static ListView lvCurrentStock;
	private Button btnViewCurrentStock;
	private ImageButton btnTakePhoto;
	public static CurrentStockAdapter adapter;
	public static ArrayList<CurrentStock> listCurrentStock;
	private JSONArray arrJSON = null;
	private int VIEW_CURRENT_STOCK = 3;
	private Dialog dialog;
	private Button btnGTIN;
	private TextView tv3,tv4,tv5,tv6;
	public static int SCAN_ADD = 1;
	public static int SCAN_REDUCE = 2;
	public static int SCAN_TRANSFER = 3;
	public static int SCAN_CURRENT = 4;
	public static int SCAN_PRIORITY = 5;
	public static int SCAN_ADD_PALLET = 6;

	public CurrentStockFragment callHamTao() {
		CurrentStockFragment mFragment = new CurrentStockFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_current_stock, container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		HamKhoiTao(rootView);
		BatSuKien();
		return rootView;
	}

	public void HamKhoiTao(View v) {
		// KHAI BAO GIAO DIEN
		tvPartId = (TextView) v.findViewById(R.id.fragment_current_stock_textview_part_id);
		tvPartName = (TextView) v.findViewById(R.id.fragment_current_stock_textview_part_name);
		etTapToScan = (EditText) v.findViewById(R.id.fragment_current_stock_taptoscan);
		imgTapToScan = (ImageView) v.findViewById(R.id.fragment_current_stock_taptoscan_img);
		proLoad = (ProgressBar) v.findViewById(R.id.fragment_current_stock_progressbar_load);
		lvCurrentStock = (ListView) v.findViewById(R.id.fragment_current_stock_listview_current_stock);
		btnViewCurrentStock = (Button) v.findViewById(R.id.fragment_current_stock_button_view_current_stock);
		btnTakePhoto = (ImageButton) v.findViewById(R.id.fragment_current_stock_button_take_photo_current);
		btnGTIN = (Button) v.findViewById(R.id.btnGTIN);
		tv3  = (TextView)v.findViewById(R.id.textView3);
		tv4  = (TextView)v.findViewById(R.id.textView4);
		tv5  = (TextView)v.findViewById(R.id.textView5);
		tv6  = (TextView)v.findViewById(R.id.textView6);

		// ==================

		// KHAI BAO KHOI TAO LISTVIEW
		listCurrentStock = new ArrayList<CurrentStock>();
		adapter = new CurrentStockAdapter(getActivity(), R.layout.custom_listview_current_stock, listCurrentStock);
		lvCurrentStock.setAdapter(adapter);
		// ==========================
	}

	public void BatSuKien() {
		etTapToScan.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				if (etTapToScan.getText().toString().length() > 0) {
					imgTapToScan.setVisibility(View.VISIBLE);
					if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {
						if (etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN) {
							getCurrentStock();
						}
					} else {
						if (etTapToScan.getText().toString().length() >= Constants.LENGTH_TAP_TO_SCAN_BARCODE) {
							getCurrentStockByBarcode();
						}
					}
				} else {
					imgTapToScan.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});

		imgTapToScan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etTapToScan.setText(null);
				etTapToScan.requestFocus();
			}
		});

		tv3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

			}
		});
		tv4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

			}
		});
		tv5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

			}
		});
		tv6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

			}
		});
		btnViewCurrentStock.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (etTapToScan.getText().toString().length() > 0) {
					if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {
						if (etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN) {
							getCurrentStock();
						}
					} else {
						if (etTapToScan.getText().toString().length() >= Constants.LENGTH_TAP_TO_SCAN_BARCODE) {
							getCurrentStockByBarcode();
						}
					}
				} else {
					etTapToScan.requestFocus();
					OpenKeyBoard(CurrentStockFragment.this.getActivity());
				}
			}
		});

		btnTakePhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				onSCanBarCode(SCAN_CURRENT);
			}
		});


		btnGTIN.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {
					btnGTIN.setText("GTIN");
				} else {
					btnGTIN.setText("QR");
				}

			}
		});
	}

	public void onSCanBarCode(int types) {
		try {
			Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
			intent.putExtra("SCAN_FORMATS",
					"QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
			startActivityForResult(intent, types);
		} catch (Exception e) {
			Log.e("NOT SCAN", e.toString());
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SCAN_CURRENT && resultCode == RESULT_OK) {
			try {

				String qrcode = (data.getStringExtra("SCAN_RESULT"));
				BarcodeSubString barcodeSubString = new BarcodeSubString();
				qrcode = barcodeSubString.CutBarcode(qrcode, "");
				etTapToScan.setText(qrcode);
			} catch (Exception e) {
				//dialogPartIDFail();
			}
		}
	}


	public void getCurrentStock() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				try {
					CurrentStockControl ctrCurrentStock = new CurrentStockControl(getActivity());
					int partid = Integer.parseInt(etTapToScan.getText().toString().trim());
					objJSON = ctrCurrentStock.getCurrentStock(partid);
					return objJSON;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {
								tvPartId.setVisibility(View.VISIBLE);
								tvPartName.setVisibility(View.VISIBLE);
								listCurrentStock.clear();
								arrJSON = objJSON.getJSONArray("data");
								if (arrJSON.length() == 0) {
									tvPartId.setVisibility(View.GONE);
									tvPartName.setVisibility(View.GONE);
									Toast.makeText(getActivity(), "No items available", Toast.LENGTH_SHORT).show();
								}
								for (int i = 0; i < arrJSON.length(); i++) {
									JSONObject obj = arrJSON.getJSONObject(i);
									CurrentStock objCurrentStock = new CurrentStock();
									objCurrentStock.setPartID(obj.getInt(CurrentStock.COLUMN_PART_ID));
									objCurrentStock.setPartName(obj.getString(CurrentStock.COLUMN_PART_NAME));
									objCurrentStock.setWarehouseID(obj.getInt(CurrentStock.COLUMN_WARE_HOUSE_ID));
									objCurrentStock
											.setWarehouseName(obj.getString(CurrentStock.COLUMN_WARE_HOUSE_NAME));
									objCurrentStock.setFreeStock(obj.getInt(CurrentStock.COLUMN_FREE_STOCK));
									objCurrentStock.setAllocatedStock(obj.getInt(CurrentStock.COLUMN_ALLOCATED_STOCK));
									objCurrentStock.setPickedNotLoadedStock(
											obj.getInt(CurrentStock.COLUMN_PICKED_NOT_LOADED_STOCK));
									objCurrentStock
											.setShippingPriority(obj.getInt(CurrentStock.COLUMN_SHIPPING_PRIORITY));
									listCurrentStock.add(objCurrentStock);
									tvPartId.setText(obj.getString(CurrentStock.COLUMN_PART_ID));
									tvPartName.setText(obj.getString(CurrentStock.COLUMN_PART_NAME));
								}
								adapter.notifyDataSetChanged();
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_FALSE)) {
									dialogAddLocation(VIEW_CURRENT_STOCK);
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void getCurrentStockByBarcode() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				try {
					CurrentStockControl ctrCurrentStock = new CurrentStockControl(getActivity());
					objJSON = ctrCurrentStock.getCurrentStockByBarcode(etTapToScan.getText().toString().trim());
					return objJSON;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {
								tvPartId.setVisibility(View.VISIBLE);
								tvPartName.setVisibility(View.VISIBLE);
								listCurrentStock.clear();
								arrJSON = objJSON.getJSONArray("data");
								if (arrJSON.length() == 0) {
									tvPartId.setVisibility(View.GONE);
									tvPartName.setVisibility(View.GONE);
									Toast.makeText(getActivity(), "No items available", Toast.LENGTH_SHORT).show();
								}
								for (int i = 0; i < arrJSON.length(); i++) {
									JSONObject obj = arrJSON.getJSONObject(i);
									CurrentStock objCurrentStock = new CurrentStock();
									objCurrentStock.setPartID(obj.getInt(CurrentStock.COLUMN_PART_ID));
									objCurrentStock.setPartName(obj.getString(CurrentStock.COLUMN_PART_NAME));
									objCurrentStock.setWarehouseID(obj.getInt(CurrentStock.COLUMN_WARE_HOUSE_ID));
									objCurrentStock
											.setWarehouseName(obj.getString(CurrentStock.COLUMN_WARE_HOUSE_NAME));
									objCurrentStock.setFreeStock(obj.getInt(CurrentStock.COLUMN_FREE_STOCK));
									objCurrentStock.setAllocatedStock(obj.getInt(CurrentStock.COLUMN_ALLOCATED_STOCK));
									objCurrentStock.setPickedNotLoadedStock(
											obj.getInt(CurrentStock.COLUMN_PICKED_NOT_LOADED_STOCK));
									objCurrentStock
											.setShippingPriority(obj.getInt(CurrentStock.COLUMN_SHIPPING_PRIORITY));
									listCurrentStock.add(objCurrentStock);
									tvPartId.setText(obj.getString(CurrentStock.COLUMN_PART_ID));
									tvPartName.setText(obj.getString(CurrentStock.COLUMN_PART_NAME));
								}
								adapter.notifyDataSetChanged();
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_FALSE)) {
									dialogAddLocation(VIEW_CURRENT_STOCK);
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void dialogAddLocation(final int type) {
		dialog = new Dialog(getActivity());
		dialog.setContentView(R.layout.custom_dialog);
		TextView tvnoidung = (TextView) dialog.findViewById(R.id.custom_dialog_textview_noidung);
		final EditText etlocation = (EditText) dialog.findViewById(R.id.custom_dialog_edittext_location);
		final ImageView imglocation = (ImageView) dialog.findViewById(R.id.custom_dialog_edittext_location_img);
		Button btncancel = (Button) dialog.findViewById(R.id.custom_dialog_button_cancel);
		Button btnok = (Button) dialog.findViewById(R.id.custom_dialog_button_ok);

		if (type == VIEW_CURRENT_STOCK) {
			dialog.setTitle(Constants.INFO);
			tvnoidung.setText(Constants.PART_NOT_FOUND);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}

		etlocation.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				if (etlocation.getText().toString().length() > 0) {
					imglocation.setVisibility(View.VISIBLE);
				} else {
					imglocation.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		imglocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etlocation.setText(null);
			}
		});
		btncancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});

		btnok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (type == VIEW_CURRENT_STOCK) {
					etTapToScan.setText(null);
					tvPartId.setVisibility(View.GONE);
					tvPartName.setVisibility(View.GONE);
					listCurrentStock.clear();

					etTapToScan.requestFocus();
				}
				dialog.dismiss();
			}
		});

		dialog.show();
	}

	public void DialogDisconnectToServer() {
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new AlertDialog.Builder(CurrentStockFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {

				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}
}
