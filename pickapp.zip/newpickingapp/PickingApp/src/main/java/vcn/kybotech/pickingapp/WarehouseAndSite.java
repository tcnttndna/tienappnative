package vcn.kybotech.pickingapp;

import org.json.JSONArray;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.WareHouseControl;
import vcn.kybotech.sqlite.sql_Site;
import vcn.kybotech.sqlite.sql_WareHouse;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

public class WarehouseAndSite extends AsyncTask<String, String, JSONObject> {
	JSONObject objJSON;
	Context context;
	
	public Context getContext() {
		return context;
	}
	public void setContext(Context context) {
		this.context = context;
	}
	public WarehouseAndSite(Context context){
		setContext(context);
	} 
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	}

	@Override
	protected JSONObject doInBackground(String... params) {
		WareHouseControl ctrWareHouse = new WareHouseControl();
		objJSON = ctrWareHouse.getWasehouseAndSite();
		return objJSON;
	}

	@Override
	protected void onPostExecute(JSONObject objJSON) {
		if (objJSON != null) {
			try {
				if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
					if (objJSON.getString(Constants.KEY_SUCCESS).equals(
							Constants.KEY_TRUE)) {
//						JSONArray arrWarehouse = objJSON.getJSONArray("warehouse");
//						JSONArray arrSite = objJSON.getJSONArray("site");
						JSONArray arrWarehouse = objJSON.getJSONArray("data");
						JSONArray arrSite = objJSON.getJSONArray("packdetails");
						sql_WareHouse sqlWareHouse = new sql_WareHouse(getContext());
						sql_Site sqlSite = new sql_Site(getContext());
						if(!sqlSite.checkData() || !sqlWareHouse.checkData()){
							sqlWareHouse.inser(arrWarehouse);
							sqlSite.inser(arrSite);
						}
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Log.e("Error", Constants.ERR_SERVICE_NETWORK);
		}
	}
}
