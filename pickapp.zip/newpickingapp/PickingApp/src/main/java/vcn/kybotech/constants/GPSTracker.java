package vcn.kybotech.constants;

import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;

public class GPSTracker extends Service implements LocationListener{

	private final Context context;
	public static boolean isShowDialog = false;
	boolean isGPSEnabled = false;
	boolean isNetworkEnabled = false;
	boolean isPassiveProvider = false;
	boolean canGetLocation = false;
	
	Location location;
	
	double latitude;
	double longitude;
	
	private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
	private static final long MIN_TIME_BW_UPDATES = 1000 * 60 * 1;
	
	protected LocationManager locationManager;
	
	public GPSTracker(Context context) {
		this.context = context;
		getLocation();
	}
	
	public Location getLocation() {
		try {
			locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);
			
			isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
			
			isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
			
			isPassiveProvider = locationManager.isProviderEnabled(LocationManager.PASSIVE_PROVIDER);
			
			if (isGPSEnabled && isNetworkEnabled) {
				locationManager.requestLocationUpdates(	
						LocationManager.GPS_PROVIDER, 
						MIN_TIME_BW_UPDATES, 
						MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
				locationManager.requestLocationUpdates(
						LocationManager.NETWORK_PROVIDER,
						MIN_TIME_BW_UPDATES,
						MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
				
				if(locationManager != null) {
					location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
					if (location == null) {
						location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
					}
					if(location != null) {
						latitude = location.getLatitude();
						longitude = location.getLongitude();
					}
				}
			}else{
				
				if (isGPSEnabled) {
					
					locationManager.requestLocationUpdates(	
							LocationManager.GPS_PROVIDER, 
							MIN_TIME_BW_UPDATES, 
							MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
					
					if(locationManager != null) {
						location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
						
						if(location != null) {
							latitude = location.getLatitude();
							longitude = location.getLongitude();
						}
					}
					
					
				}
					
				if (isNetworkEnabled) {
					
					
					locationManager.requestLocationUpdates(
							LocationManager.NETWORK_PROVIDER,
							MIN_TIME_BW_UPDATES,
							MIN_DISTANCE_CHANGE_FOR_UPDATES, this);

					if (locationManager != null && location == null) {
						location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

						if (location != null) {
							
							latitude = location.getLatitude();
							longitude = location.getLongitude();
						}
					}
				}
					
				if (isPassiveProvider) {
					locationManager.requestLocationUpdates(
							LocationManager.PASSIVE_PROVIDER,
							MIN_TIME_BW_UPDATES,
							MIN_DISTANCE_CHANGE_FOR_UPDATES, this);

					if (locationManager != null && location == null) {
						location = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

						if (location != null) {
							
							latitude = location.getLatitude();
							longitude = location.getLongitude();
						}
					}
				}
				
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return location;
	}
	
	
	public void stopUsingGPS() {
		if(locationManager != null) {
			locationManager.removeUpdates(GPSTracker.this);
		}
	}
	
	public double getLatitude() {
		if (canGetLocation()) {
			if(location != null) {
				return latitude = location.getLatitude();
			}else{
				return latitude = -1;
			}
		}else{
			return latitude = 0.0;
		}
	}
	
	public double getLongitude() {
		if (canGetLocation()) {
			if(location != null) {
				return longitude = location.getLongitude();
			}else{
				return longitude = -1;
			}
		}else{
			return longitude = 0.0;
		}
	}
	
//	public boolean canGetLocation() {
//		@SuppressWarnings("deprecation")
//		String provider = Settings.Secure.getString( context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
////		Log.e("checkGPS  - providers ", provider);
//		return !provider.equalsIgnoreCase("");
//	}
	
	
	public boolean canGetLocation() {
//		Log.e("checkGPS  - providers ", provider);
		isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
		boolean isGPSEnabledNetWork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
		return isGPSEnabled||isGPSEnabledNetWork;
	}
	
	
	
	public void showSettingsAlert() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
		
		alertDialog.setTitle("GPS is settings");
		
		alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?");
		
		alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				isShowDialog = false;
				Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				context.startActivity(intent);
			}
		});
		
		alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				isShowDialog = false;
				dialog.cancel();
			}
		});
		
		alertDialog.setCancelable(false);
		isShowDialog = true;
//		if(alertDialog.create().isShowing()){
			alertDialog.show();
//		}
	}
	
	@Override
	public void onLocationChanged(Location arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

}
