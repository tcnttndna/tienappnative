package vcn.kybotech.model;

import java.io.Serializable;

public class PartLocation implements Serializable {
	private int Id;

	public PartLocation(int id, int partID, String location) {
		super();
		Id = id;
		PartID = partID;
		Location = location;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	private int PartID;
	private String Location;

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

}
