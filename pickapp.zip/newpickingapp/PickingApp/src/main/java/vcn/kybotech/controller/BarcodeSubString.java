package vcn.kybotech.controller;

import android.app.Dialog;
import android.widget.Toast;

/**
 * Created by cuong.nv on 2017-07-07.
 */

public class BarcodeSubString {

    public String CutBarcode(String barcode, String format) {
        if (format.length() > 0) {
            if (format.equalsIgnoreCase("QR_CODE")) {
                if (barcode.toLowerCase().startsWith("part id ") && barcode.length() >= 13) {
                    barcode = barcode.substring(8, 13);
                } else if (barcode.length() > 5) {
                    String[] s = barcode.split(",");
                    if (s.length > 1) {
                        barcode = s[0];
                        if (s[0].toLowerCase().contains("k")) {
                            barcode = s[1].substring(0, 5);
                        }
                    }
                } else if (barcode.length() > 5) {
                    barcode = barcode.substring(0, 5);
                }
            }

        } else {
            if (barcode.toLowerCase().startsWith("part id ") && barcode.length() >= 13) {
                barcode = barcode.substring(8, 13);
            } else if (barcode.length() > 5) {
                String[] s = barcode.split(",");
                if (s.length > 1) {
                    barcode = s[0];
                    if (s[0].toLowerCase().contains("k")) {
                        barcode = s[1].substring(0, 5);
                    }
                }
            } else if (barcode.length() > 5) {
                barcode = barcode.substring(0, 5);
            }
        }
        if (barcode.length() > 5) {
            barcode = barcode.substring(0, 5);
        }
        return barcode.trim();
    }
}