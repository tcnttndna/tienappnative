package vcn.kybotech.controller;

//import java.io.UnsupportedEncodingException;
//import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;
import android.content.Context;

public class ReduceStockControl {
	private JSONParser jsonParser;
	private int userid;
	private String username;

	public ReduceStockControl(Context context) {
		jsonParser = new JSONParser();
		FileSave file = new FileSave(context, Constants.GET);
		userid = file.getPickerID();
		username = file.getPickerName();
		if(!file.getName().equals("")){
			username = username + " - " + file.getName();
		}
	}
	
	public JSONObject uploadReducePart(int partid, String reason,
			int warehouseid, String quantity) {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "reduce"));
		params.add(new BasicNameValuePair("partid", String.valueOf(partid)));
		params.add(new BasicNameValuePair("reason", reason));
		params.add(new BasicNameValuePair("warehouseid", String.valueOf(warehouseid)));
		params.add(new BasicNameValuePair("userid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("quan", quantity));
		params.add(new BasicNameValuePair("username", username));
		params.add(new BasicNameValuePair("appname", "Load Mobile New"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		
		//KHONG REQUEST DUOC LEN SERVER WEB
//		String LINK = "";
//		try {
//			LINK = Constants.link + "type=reduce&partid="
//					+ URLEncoder.encode(String.valueOf(partid), "UTF-8")
//					+ "&reason="
//					+ URLEncoder.encode(reason, "UTF-8")
//					+ "&warehouseid="
//					+ URLEncoder.encode(String.valueOf(warehouseid), "UTF-8")
//					+ "&userid="
//					+ URLEncoder.encode(String.valueOf(userid), "UTF-8")
//					+ "&quan="
//					+ URLEncoder.encode(quantity, "UTF-8")
//					+ "&username=" 
//					+ URLEncoder.encode(username, "UTF-8") 
//					+ "&appname="
//					+ URLEncoder.encode("Load Mobile New", "UTF-8") + "";
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		}
//		JSONObject objJSON = jsonParser.getJsonTuUrl(LINK, params);
		//===================================
		return objJSON;
	}
}
