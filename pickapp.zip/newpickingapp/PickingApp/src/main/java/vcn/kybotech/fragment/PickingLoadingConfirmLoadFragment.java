package vcn.kybotech.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.R;

public class PickingLoadingConfirmLoadFragment extends android.app.Fragment{

	private String LoadID;
	private Button confirmLoad;
	private Button cancel;
	private TextView tvLoadID;
	private GPSTracker gpsTracker;
	private CommunicatingFragments communicatingFragments;
	private final static String Tag = "RequesConfirm";
	RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
	FileSave fileSave;
	
	@Override
	public void onAttach(Activity activity) {
		
		super.onAttach(activity);
		try {
			communicatingFragments = (CommunicatingFragments)getActivity();
		} catch (Exception e) {
			throw new ClassCastException(activity.toString() + " must implement CommunicatingFragments");
		}

	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_picking_load_confirm_loading,container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));

		confirmLoad = (Button)rootView.findViewById(R.id.fragment_picking_load_completion_confirm);
		cancel = (Button)rootView.findViewById(R.id.fragment_picking_load_completion_decline);
		tvLoadID = (TextView)rootView.findViewById(R.id.fragment_picking_load_completion_loadassigned_id);
		
		return rootView;
	}
	
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		
		requestQueue = Volley.newRequestQueue(getActivity());
		gpsTracker = new  GPSTracker(getActivity());
		fileSave = new FileSave(getActivity(), Constants.GET);
		LoadID = getArguments().getString(Constants.key_bundle_loadid);
		tvLoadID.setText(LoadID);
		
		confirmLoad.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						
						final ProgressDialog progressDialog;
						progressDialog = new ProgressDialog(getActivity());
						progressDialog.setMessage(getString(R.string.fragment_login_waiting));
						progressDialog.setCancelable(false);
						progressDialog.show();
						Log.e("hehe", "111");
						Response.Listener<String> listener = new Response.Listener<String>() {
		
							@Override
							public void onResponse(String response) {
								try {
									
									JSONObject jsonObject = new JSONObject(response);
									Log.e("hehe", jsonObject.toString());
									if (jsonObject.getBoolean("success")) {
										/*Bat dau xu ly cap nhat du lieu trong sqlite cua Load*/
										communicatingFragments.onConfirmLoadPicked(LoadID);
									}else{
										
										AlertDialog.Builder dialog = new Builder(getActivity());
										dialog.setTitle("Notification")
										.setMessage("Confirm error.\nServer is problem! ")
										.setPositiveButton("OK", null)
										.show();
									}
									
								} catch (JSONException e) {
									DialogServerProblem();
									e.printStackTrace();
								} catch(Exception e2){
									
								}
								
								if (progressDialog!=null) {
									progressDialog.dismiss();
								}
							}
							
							
						};
						
						Response.ErrorListener errorListener = new Response.ErrorListener() {
		
							@Override
							public void onErrorResponse(VolleyError arg0) {
								if (progressDialog!=null) {
									progressDialog.dismiss();
								}
								
								AlertDialog.Builder dialog = new Builder(getActivity());
								dialog.setTitle("Notification")
								.setMessage("Confirm Load fail, Connect to server timeout!")
								.setPositiveButton("OK", null)
								.show();
							}
						};
						
						
						StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener){
							
							@Override
							protected Map<String,String> getParams(){
								String latitude = String.valueOf(gpsTracker.getLatitude());
							    String longtitude = String.valueOf(gpsTracker.getLongitude());
								
								Map<String, String> params = new HashMap<String, String>();
								
								params = onCreateParams(latitude, longtitude);
		
								return params;
							}
		
							private Map<String, String> onCreateParams(String latitude, String longtitude) {
								Map<String, String> params = new HashMap<String, String>();
								SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								Log.e("reques ConfirmOrderItem", "Toa Do: "+ latitude + " ; " + longtitude);
								
								
								String date = "";
								String version ="";
								
								try {
									date =  formatngay.format(new Date());
									version = android.os.Build.MODEL + " | " +android.os.Build.VERSION.RELEASE + " | " + getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionCode;
		
								} catch (Exception e) {
									e.printStackTrace();
								}
		
								
								params.put("type", "newconfirmloadloaded");
								params.put("pickerid", String.valueOf(fileSave.getPickerID()));
								params.put("pickername",fileSave.getPickerName());
								params.put("InApp","NewPickingApp");
								params.put("loadid", LoadID);
								params.put("lat",latitude);
								params.put("lng",longtitude);
								params.put("version",version);
								params.put("phonedate",date);	
								
								return params;
							};
						};
						
		//				RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
						postRequest.setTag(Tag);
						postRequest.setShouldCache(false);
						requestQueue.add(postRequest);
						
					}
		});
		
		cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				android.app.Fragment fragment = getActivity().getFragmentManager().findFragmentById(R.id.container);
				android.app.FragmentTransaction ft = getActivity().getFragmentManager().beginTransaction();
				ft.remove(fragment);
				ft.commit(); 
				Log.e("remove", fragment.toString());
				getActivity().getFragmentManager().popBackStack();
			}
		});
		
	}
	
	public void DialogServerProblem(){
		Log.e("LoginFramgment", "server is problem");
		if (getActivity()==null) {
			return;
		}
		Builder dialog = new  AlertDialog.Builder(getActivity());
		dialog.setTitle("Message");
		dialog.setMessage("Server is problem");
		dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				
			}
		});
		dialog.show();
	}
	
	@Override
	public void onDetach() {
		requestQueue.cancelAll(Tag);
		gpsTracker.stopUsingGPS();
		super.onDetach();
	}
	
}
