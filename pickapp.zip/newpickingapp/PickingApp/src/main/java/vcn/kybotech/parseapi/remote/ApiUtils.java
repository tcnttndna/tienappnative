package vcn.kybotech.parseapi.remote;

/**
 * Created by Admin-PC on 1/13/2018.
 */

public class ApiUtils {

    public static final String BASE_URL = "http://pickingservice.vcncorp.net/";

    public static SOService getSOService() {
        return RetrofitClient.getClient(BASE_URL).create(SOService.class);
    }
}