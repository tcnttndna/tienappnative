package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.model.PickType;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class sql_PickPartType {

	private sql_DataBase data;
	public static final String TABLE_PARTS_WITH_TYPE = "PickPartsWithType";
	
	public static final String COLUMN0_ID = "Id";
	public static final String COLUMN1_ORDER_REF = "OrderRef";
	public static final String COLUMN2_ORDER_ITEM_ID = "OrderItemID";
	public static final String COLUMN3_PART_ID = "PartID";
	public static final String COLUMN4_PART_NAME = "PartName";	
	public static final String COLUMN5_LOCATION_NAME = "LocationName";
	public static final String COLUMN6_PICKED_BY = "PickedBy";
	
	public static final String COLUMN7_PICK_TYPE = "PickType";	
	public static final String COLUMN8_PICK_TYPE_ID = "PickTypeID";
	public static final String COLUMN9_PRODUCT_NAME = "ProductName";
	public static final String COLUMN10_PRODUCT_OPTION = "ProductOption";	
	public static final String COLUMN11_DROP_NUMBER = "DropNumber";
	
	public static final String COLUMN12_TOTAL_PACK = "TotalPack";
	public static final String COLUMN13_QUANTITY = "Quantity";
	public static final String COLUMN14_SPECIAL_INSTRUCTIONS = "SpecialInstructions";
	

	public static final String CREATE_TABLE_PICK_TYPE = "CREATE TABLE "
			+TABLE_PARTS_WITH_TYPE + " (" 
			    +COLUMN0_ID + " INTEGER PRIMARY KEY, "
				+COLUMN1_ORDER_REF + " TEXT, "
				+COLUMN2_ORDER_ITEM_ID + " INTEGER, "
				+COLUMN3_PART_ID + " INTEGER, "

				+COLUMN4_PART_NAME + " TEXT, "
				+COLUMN5_LOCATION_NAME + " TEXT, "
				+COLUMN6_PICKED_BY + " TEXT, "
				
				+COLUMN7_PICK_TYPE + " TEXT, "
				+COLUMN8_PICK_TYPE_ID + " INTEGER, "
				+COLUMN9_PRODUCT_NAME + " TEXT, "
				+COLUMN10_PRODUCT_OPTION + " TEXT, "
				+COLUMN11_DROP_NUMBER + " INTEGER, "
				
				+COLUMN12_TOTAL_PACK + " INTEGER, "
				+COLUMN13_QUANTITY + " INTEGER, "
				+COLUMN14_SPECIAL_INSTRUCTIONS + " TEXT "
		
			+ " )";
	


	public sql_PickPartType(Context context) {
		data = new sql_DataBase(context);
	}

	
	/* Kiem tra su ton tai cua du lieu*/
	public boolean checkExistsData() {
		boolean output = false;
		String sqlSelect = "SELECT * FROM " + TABLE_PARTS_WITH_TYPE;
		SQLiteDatabase db = data.getReadableDatabase();
		Cursor cursor = db.rawQuery(sqlSelect, null);
		if (cursor.getCount() > 0) {
			output = true;
		}
		cursor.close();
		db.close();
		return output;
	}
	
	/* Kiem tra xem co bao nhieu ban ghi*/
	public int getCountParts() {
		int c = 0;
		String sqlSelect = "SELECT * FROM " + TABLE_PARTS_WITH_TYPE;
		SQLiteDatabase db = data.getReadableDatabase();
		Cursor cursor = db.rawQuery(sqlSelect, null);
		c = cursor.getCount();
		cursor.close();
		db.close();
		return c;
	}
	
	

	
//	public List<PickPart> getAllPickParts() {
//		SQLiteDatabase db = data.getWritableDatabase();
//		Cursor cursor = db.query(TABLE_PARTS, null, null, null, null, null, null);
//		List<PickPart> list = new ArrayList<PickPart>();
//		if (cursor.getCount() > 0) {
//			cursor.moveToFirst();
//			do {
//				list.add(new PickPart(
//						
//						cursor.getInt(cursor.getColumnIndex(COLUMN0_PART_ID)),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN1_IS_SCANNED))),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_QA))),
//						cursor.getString(cursor.getColumnIndex(COLUMN3_PART_NAME)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN4_QUANTITY)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN6_ORDER_REF)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN7_ORDER_ITEM_ID)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN8_TOTAL_PACK)),
//						cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
//						cursor.getString(cursor.getColumnIndex(COLUMN10_LOCATION_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN11_PICKED_BY)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN12_PICK_TYPE_ID)),
//						cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN18_PACKAGE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN19_SPECIAL_INSTRUCTIONS))
//						)
//				);
//				
//			} while (cursor.moveToNext());
//		}
//		cursor.close();
//		db.close();
//		return list;
//	}

	/*Clear du lieu*/
	public void clearData() {
		SQLiteDatabase db = data.getWritableDatabase();
		try {
			db.delete(TABLE_PARTS_WITH_TYPE, null, null);
			db.close();
			Log.e("sql_PickPartsWithType", " Clear Data succes");
		} catch (Exception e) {
			if (db!=null) {
				db.close();
			}
//			new LogCrashActivity().inserException(e);
		}
	}

	
	/*Insert du lieu su dung transaction*/
	public void insertPickPartWithTypeTransaciton(JSONArray jsonArr) {
		
		/*Chuoi JSONArray truyen vao la mot mang cac doi tuong */
		
		
		String sql = "INSERT INTO " + TABLE_PARTS_WITH_TYPE + " (" 
				
				+COLUMN1_ORDER_REF + ", "
				+COLUMN2_ORDER_ITEM_ID + ", "
				+COLUMN3_PART_ID + ", "
				+COLUMN4_PART_NAME + ", "
				+COLUMN5_LOCATION_NAME + ", "
				+COLUMN6_PICKED_BY + ", "
				+COLUMN7_PICK_TYPE + ", "
				+COLUMN8_PICK_TYPE_ID + ", "
				+COLUMN9_PRODUCT_NAME + ", "
				+COLUMN10_PRODUCT_OPTION + ", "
				+COLUMN11_DROP_NUMBER + ", "
				+COLUMN12_TOTAL_PACK + ", "
				+COLUMN13_QUANTITY + ", "
				+COLUMN14_SPECIAL_INSTRUCTIONS + " "
				
							
				+ ") VALUES (?, ?, ?, ?, ?, " +
							"?, ?, ?, ?, ?, " +
							"?, ?, ?, ? )";
		
		

		
		SQLiteDatabase db = data.getWritableDatabase();
		db.beginTransactionNonExclusive();
		SQLiteStatement sqlSTMT = db.compileStatement(sql);
		Log.e("sql_PickPartsWithType ","so ban ghi PickType can duoc insert vao sqlite = "+jsonArr.length());
		try {
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject jsonParts = jsonArr.getJSONObject(i);
				
				sqlSTMT.bindString(1, jsonParts.getString("OrderRef"));
				sqlSTMT.bindLong(2,jsonParts.getLong("OrderItemID"));
				sqlSTMT.bindLong(3,jsonParts.getLong("PartID"));
				sqlSTMT.bindString(4, jsonParts.getString("PartName"));
				sqlSTMT.bindString(5, jsonParts.getString("LocationName"));
				sqlSTMT.bindString(6, jsonParts.getString("PickedBy") );
	
				sqlSTMT.bindString(7, jsonParts.getString("PickType"));
				sqlSTMT.bindLong(8, jsonParts.getLong("PickTypeID"));
				sqlSTMT.bindString(9, jsonParts.getString("ProductName"));
				sqlSTMT.bindString(10, jsonParts.getString("ProductOption") );
				sqlSTMT.bindLong(11, jsonParts.getLong("DropNumber") );
	   
				sqlSTMT.bindLong(12, jsonParts.getLong("TotalPack") );
				sqlSTMT.bindLong(13, jsonParts.getLong("Quantity") );
				sqlSTMT.bindString(14, jsonParts.getString("SpecialInstructions") );

				sqlSTMT.execute();
				sqlSTMT.clearBindings();
			}
			db.setTransactionSuccessful();
			db.endTransaction();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.e("sql_PickPartsWithType"," insertTransaction jsonParts to sqlite error ");
		}
		db.close();
		Log.e("sql_PickPartsWithType"," so ban ghi duoc qickly insert  =  " + getCountParts());
	}

	
	public List<PickType> getListType() {
		List<PickType> list = new ArrayList<PickType>();
		String sqlType = "SELECT DISTINCT " + COLUMN8_PICK_TYPE_ID + ", " + COLUMN7_PICK_TYPE + " FROM " + TABLE_PARTS_WITH_TYPE + " ORDER BY " + COLUMN8_PICK_TYPE_ID + " ASC ";
		
		SQLiteDatabase db = data.getReadableDatabase();
		Cursor cursor = db.rawQuery(sqlType, null);
		if (cursor.getCount() > 0) {
			cursor.moveToFirst();
			do {
				list.add(new PickType(						
						cursor.getString(cursor.getColumnIndex(COLUMN7_PICK_TYPE)),
						cursor.getInt(cursor.getColumnIndex(COLUMN8_PICK_TYPE_ID))
						)
				);
				
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}


}
