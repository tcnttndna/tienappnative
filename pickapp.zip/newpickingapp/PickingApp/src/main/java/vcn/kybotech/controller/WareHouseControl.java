package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;

public class WareHouseControl {
	private JSONParser jsonParser;
	
	public WareHouseControl(){
		jsonParser = new JSONParser();
	} 
	
	public JSONObject upload(){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "warehouse"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
	
	public JSONObject getWasehouseAndSite(){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "listwasehouseandsite"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
