package vcn.kybotech.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.model.PickReturnPart;

public class sql_PickReturnParts {

    private sql_DataBase data;
    public static final String TABLE_PICK_RETURN_PART = "PickReturnPart";

    public static final String COLUMN0_ID = "Id";
    public static final String COLUMN1_LOADID = "LoadID";
    public static final String COLUMN2_ORDERITEMPARTID = "OrderItemPartID";
    public static final String COLUMN3_ORDERREF = "OrderRef";
    public static final String COLUMN4_PARTID = "PartID";
    public static final String COLUMN5_PARTNAME = "PartName";

    public static final String COLUMN6_PARTQUANTITY = "PartQuantity";
    public static final String COLUMN7_CONFIRMED = "Confirmed";


    public static final String CREATE_TABLE_RETURN_PART = "CREATE TABLE "
            + TABLE_PICK_RETURN_PART + " ("
            + COLUMN0_ID + " INTEGER PRIMARY KEY, "
            + COLUMN1_LOADID + " TEXT, "
            + COLUMN2_ORDERITEMPARTID + " TEXT, "
            + COLUMN3_ORDERREF + " TEXT, "
            + COLUMN4_PARTID + " TEXT, "
            + COLUMN5_PARTNAME + " TEXT, "
            + COLUMN6_PARTQUANTITY + " TEXT, "
            + COLUMN7_CONFIRMED + " TEXT"
            + " )";

    public sql_PickReturnParts(Context context) {
        data = new sql_DataBase(context);
    }


    /* Kiem tra su ton tai cua du lieu*/
    public boolean checkExistsData() {
        boolean output = false;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PICK_RETURN_PART;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            if (cursor.getInt(0) > 0) {
                output = true;
            }
        }

        cursor.close();
        db.close();
        return output;
    }

    /* Kiem tra xem co bao nhieu ban ghi*/
    public int getCountLoadAssigned() {
        int c = 0;
        String sqlSelect = "SELECT * FROM " + TABLE_PICK_RETURN_PART;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        c = cursor.getCount();
        cursor.close();
        db.close();
        return c;
    }

    public int getSumPartByOrder(int loadId, String orderref) {
        int c = 0;
        String sqlSelect = "SELECT SUM(" + COLUMN6_PARTQUANTITY + ") AS COUNTPART FROM " + TABLE_PICK_RETURN_PART + " WHERE " + COLUMN1_LOADID +" ='"+loadId+"'"+" AND "+COLUMN3_ORDERREF+" = '"+orderref+"'";
//        String sqlSelect = "SELECT SUM(" + COLUMN6_PARTQUANTITY + ") AS COUNTPART FROM " + TABLE_PICK_RETURN_PART + " WHERE " + COLUMN0_ID + " =" + loadId +"GROUP BY "+COLUMN3_ORDERREF;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        try {
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    c = cursor.getInt(cursor.getColumnIndex("COUNTPART"));
                } while (cursor.moveToNext());
            }

        } catch (Exception ex) {
            String str = ex.getMessage();
        } finally {
            cursor.close();
            db.close();
        }

        return c;
    }

    public int getSumPartByLoad(int loadId) {
        int c = 0;
        String sqlSelect = "SELECT SUM(" + COLUMN6_PARTQUANTITY + ") AS COUNTPART FROM " + TABLE_PICK_RETURN_PART + " WHERE " + COLUMN1_LOADID +" ='"+loadId+"'";
//        String sqlSelect = "SELECT SUM(" + COLUMN6_PARTQUANTITY + ") AS COUNTPART FROM " + TABLE_PICK_RETURN_PART + " WHERE " + COLUMN0_ID + " =" + loadId +"GROUP BY "+COLUMN3_ORDERREF;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        try {
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    c = cursor.getInt(cursor.getColumnIndex("COUNTPART"));
                } while (cursor.moveToNext());
            }

        } catch (Exception ex) {
            String str = ex.getMessage();
        } finally {
            cursor.close();
            db.close();
        }

        return c;
    }

    public int getCountOrderOfLoad(String LoadId) {

        List<PickReturnPart> list = new ArrayList<>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN1_LOADID + " = ?";
        String[] args = new String[]{LoadId};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, COLUMN3_ORDERREF, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list.size();
    }

    public int getCountPartOfLoad(String LoadId) {

        List<PickReturnPart> list = new ArrayList<>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN1_LOADID + " = ?";
        String[] args = new String[]{LoadId};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, COLUMN3_ORDERREF, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list.size();
    }

    public List<PickReturnPart> getListOrderOfLoad(String LoadId) {

        List<PickReturnPart> list = new ArrayList<>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN1_LOADID + " = ?";
        String[] args = new String[]{LoadId};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, COLUMN3_ORDERREF, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list;
    }

//    public int getCountAllPart() {
//        int c = 0;
//        String sqlSelect = "SELECT SUM("+COLUMN6_PARTQUANTITY+") FROM " + TABLE_PICK_RETURN_PART;
//        SQLiteDatabase db = data.getReadableDatabase();
//        Cursor cursor = db.rawQuery(sqlSelect, null);
//        c = cursor.getCount();
//        cursor.close();
//        db.close();
//        return c;
//    }

    public void insertPickReturnLoad(JSONArray jsonArr) {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonLoadAssigned = jsonArr.getJSONObject(i);
                ContentValues values = new ContentValues();

                values.put(COLUMN1_LOADID, jsonLoadAssigned.getLong("LoadID"));
                values.put(COLUMN2_ORDERITEMPARTID, jsonLoadAssigned.getDouble("OrderItemPartID"));
                values.put(COLUMN3_ORDERREF, jsonLoadAssigned.getString("OrderRef"));
                values.put(COLUMN4_PARTID, jsonLoadAssigned.getString("PartID"));
                values.put(COLUMN5_PARTNAME, jsonLoadAssigned.getString("PartName"));

                values.put(COLUMN6_PARTQUANTITY, jsonLoadAssigned.getInt("PartQuantity"));
                values.put(COLUMN7_CONFIRMED, jsonLoadAssigned.getBoolean("Confirmed"));
                db.insert(TABLE_PICK_RETURN_PART, null, values);

            }
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.e("sql_PickLoadAssign", " insert jsonLoadAssigned to sqlite error ");
        } finally {
            db.close();
        }
    }


    /*Clear du lieu*/
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            db.delete(TABLE_PICK_RETURN_PART, null, null);
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }
    }

    /*Insert du lieu su dung transaction*/
    public void insertPickReturnLoadTransaciton(JSONArray jsonArr) {

		/*Chuoi JSONArray truyen vao la mot mang cac doi tuong */


        String sql = "INSERT INTO " + TABLE_PICK_RETURN_PART + " ("

                + COLUMN1_LOADID + ", "
                + COLUMN2_ORDERITEMPARTID + ", "
                + COLUMN3_ORDERREF + ", "
                + COLUMN4_PARTID + ", "
                + COLUMN5_PARTNAME + ", "
                + COLUMN6_PARTQUANTITY + ", "
                + COLUMN7_CONFIRMED + " "
                + ") VALUES (?, ?, ?, ?, ?, ?, ?)";

        SQLiteDatabase db = data.getWritableDatabase();
        db.beginTransactionNonExclusive();
        try {

            SQLiteStatement sqlSTMT = db.compileStatement(sql);
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonLoadAssigned = jsonArr.getJSONObject(i);

				/*Tam thoi chi insert cac cot can su dung con cac cot khong su dung tam thoi comment*/
                sqlSTMT.bindLong(1, jsonLoadAssigned.getInt("LoadID"));
                sqlSTMT.bindString(2, jsonLoadAssigned.getString("OrderItemPartID"));
                sqlSTMT.bindString(3, jsonLoadAssigned.getString("OrderRef"));
                sqlSTMT.bindString(4, jsonLoadAssigned.getString("PartID"));
                sqlSTMT.bindString(5, jsonLoadAssigned.getString("PartName"));
                sqlSTMT.bindString(6, jsonLoadAssigned.getString("PartQuantity"));
                sqlSTMT.bindString(7, jsonLoadAssigned.getString("Confirmed"));

                sqlSTMT.execute();
                sqlSTMT.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            db.close();
        }

    }

    /* PickByType - Lay ra cac part theo type */
    public List<PickReturnPart> getListPartsByLoadId(String LoadId) {

        List<PickReturnPart> list = new ArrayList<PickReturnPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN1_LOADID + " = ? ";
        String[] args = new String[]{LoadId};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, null, null, COLUMN4_PARTID + " ASC ");
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list;
    }

    public List<PickReturnPart> getListOrderRef(String LoadId) {

        List<PickReturnPart> list = new ArrayList<PickReturnPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN1_LOADID + " = ? ";
        String[] args = new String[]{LoadId};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, COLUMN3_ORDERREF, null, COLUMN4_PARTID + " ASC ");
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list;
    }

    public List<PickReturnPart> getAllPartOfLoad(String loadId) {

        List<PickReturnPart> list = new ArrayList<PickReturnPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN1_LOADID + " = ? ";
        String[] args = new String[]{loadId};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, null, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list;
    }


    public List<PickReturnPart> getListLoad() {

        List<PickReturnPart> list = new ArrayList<PickReturnPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, null, null, COLUMN1_LOADID, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            db.close();
        }

        return list;
    }


    public List<PickReturnPart> getListPartsByOrderRef(String OrderRef) {

        List<PickReturnPart> list = new ArrayList<PickReturnPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN3_ORDERREF + " = ? ";
        String[] args = new String[]{OrderRef};
        try {
            cursor = db.query(TABLE_PICK_RETURN_PART, null, where, args, null, null, COLUMN7_CONFIRMED + " ASC ");
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOADID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDERITEMPARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN3_ORDERREF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN4_PARTID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN5_PARTNAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN6_PARTQUANTITY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN7_CONFIRMED)))));

                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        } finally {
            cursor.close();
            db.close();
        }
        return list;
    }

//
//    public int updateConfirmedAddToStock(String LoadID, String OrderItemPartID, String PartId) {
//
//        SQLiteDatabase db = data.getReadableDatabase();
//        String sql = "Update " + TABLE_PICK_RETURN_PART + " set " + COLUMN7_CONFIRMED + " = '" + "true" + "' WHERE "
//                + COLUMN0_LOADID + " = '" + LoadID + "' AND "
//                + COLUMN2_ORDERITEMPARTID + " = '" + OrderItemPartID + "' AND "
//                + COLUMN4_PARTID + " = '" + PartId + "'";
//        int c = 0;
//        try {
//            c = db.update(sql, null);
//            db.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//            if (db != null) {
//                db.close();
//            }
//        }
//        return c;
//    }

    public int updateConfirmedAddToStock(String LoadID, String OrderItemPartID, String PartId) {

        SQLiteDatabase db = data.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN7_CONFIRMED, "true");
        int c = 0;
        try {
            c = db.update(TABLE_PICK_RETURN_PART, values, COLUMN1_LOADID + " = ? AND "
                    + COLUMN2_ORDERITEMPARTID + " = ? AND "
                    + COLUMN4_PARTID + " = ? ", new String[]{LoadID, OrderItemPartID, PartId});

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
        return c;
    }

//
//
//    public int deleteLoad(String LoadID) {
//        SQLiteDatabase db = data.getWritableDatabase();
//        int c = 0;
//        try {
//            c = db.delete(TABLE_LOAD_ASSIGNED, COLUMN0_LOADID + " = ?", new String[]{LoadID});
//
//            db.close();
//            Log.e("Delete Load Depatched " + LoadID, "success!");
//        } catch (Exception e) {
//            e.printStackTrace();
//            if (db != null) {
//                db.close();
//            }
//        }
//
//        return c;
//    }
//

    //	public String[] getSearchUsername(String search) {
//	String[] username;
//	String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
//	SQLiteDatabase db = data.getReadableDatabase();
//	Cursor cursor = db.rawQuery(sqlSelect, null);
//	username = new String[cursor.getCount()];
//	cursor.moveToFirst();
//	for (int i = 0; i < cursor.getCount(); i++) {
//		username[i] = cursor.getString(0);
//		cursor.moveToNext();
//	}
//	cursor.close();
//	db.close();
//	return username;
//}
//
//public int getCountSearch(String search) {
//	int count = 0;
//	String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
//	SQLiteDatabase db = data.getReadableDatabase();
//	Cursor cursor = db.rawQuery(sqlSelect, null);
//	count = cursor.getCount();
//	cursor.close();
//	db.close();
//	return count;
//}

}
