package vcn.kybotech.sqlite;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import vcn.kybotech.model.LogCrash;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class sql_LogCrash {
	private sql_DataBase data;
	private String DEVICE_MODEL;
	private String ANDROID_VERSION;
	private int APP_VERSION_CODE;
	private String APP_VERSION_NAME;
	private String DATE_TIME;
	
	public static final String TABLE_LOG_CRASH = "LogCrash";
	public static final String COLUMN0_ID = "ID";
	public static final String COLUMN1_PICKER_ID = "PickerId";
	public static final String COLUMN2_MESSAGE = "Message";
	public static final String COLUMN3_STACK_TRACE = "StackTrace";
	public static final String COLUMN4_DEVICE_MODEL = "DeviceModel";
	public static final String COLUMN5_ANDROID_VERSION = "AndroidVersion";
	public static final String COLUMN6_APP_VERSION_CODE = "AppVersionCode";
	public static final String COLUMN7_APP_VERSION_NAME = "AppVersionName";
	public static final String COLUMN8_ISCRASH = "IsCrashed";
	public static final String COLUMN9_DATE_TIME = "DateTime";
	
	public static final String CREATE_TABLE_LOG_CRASH = "CREATE TABLE "
				+ TABLE_LOG_CRASH +"("
				+ COLUMN0_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "
				+ COLUMN1_PICKER_ID +" INTEGER, "
				+ COLUMN2_MESSAGE +" TEXT, "
				+ COLUMN3_STACK_TRACE +" TEXT, "
				+ COLUMN4_DEVICE_MODEL +" TEXT NOT NULL, "
				+ COLUMN5_ANDROID_VERSION +" TEXT NOT NULL, "
				+ COLUMN6_APP_VERSION_CODE +" INTEGER NOT NULL, "
				+ COLUMN7_APP_VERSION_NAME +" TEXT NOT NULL, "
				+ COLUMN8_ISCRASH +" INTEGER NOT NULL, "
				+ COLUMN9_DATE_TIME +" NUMERIC NOT NULL)";
	
	public sql_LogCrash(Context context){
		data = new sql_DataBase(context);
		try {
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DATE_TIME = dateFormat.format(calendar.getTime());
			DEVICE_MODEL = android.os.Build.MODEL;
			ANDROID_VERSION = android.os.Build.VERSION.RELEASE;
			APP_VERSION_CODE = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
			APP_VERSION_NAME = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void insert(LogCrash crash){
		SQLiteDatabase db = data.getWritableDatabase();
		ContentValues values = new ContentValues();		
		values.put(COLUMN1_PICKER_ID, crash.getPickerId());
		values.put(COLUMN2_MESSAGE, crash.getMessage());
		values.put(COLUMN3_STACK_TRACE, crash.getStackTrace());
		values.put(COLUMN4_DEVICE_MODEL, DEVICE_MODEL);
		values.put(COLUMN5_ANDROID_VERSION, ANDROID_VERSION);
		values.put(COLUMN6_APP_VERSION_CODE, APP_VERSION_CODE);
		values.put(COLUMN7_APP_VERSION_NAME, APP_VERSION_NAME);
		values.put(COLUMN8_ISCRASH, crash.getIsCrashed());
		values.put(COLUMN9_DATE_TIME, DATE_TIME);
		
		if(db.insert(TABLE_LOG_CRASH, null, values) > 0){
			Log.e("Insert Error:" , "LUU ERROR THANH CONG");
			Log.e("Insert Error: " + crash.getMessage() ,"" + crash.getStackTrace());
		}
		db.close();
	}
	
	public List<LogCrash> selectTop() {
		List<LogCrash> list = null;
		LogCrash crash = null;
		SQLiteDatabase db = data.getReadableDatabase();
		String sql = "SELECT * FROM " + TABLE_LOG_CRASH + "";
		Cursor cursor = db.rawQuery(sql, null);
		if (cursor.getCount() > 0) {
			list = new ArrayList<LogCrash>();
			cursor.moveToFirst();
			do {
				crash = new LogCrash();

				crash.setID(cursor.getInt(0));
				crash.setPickerId(cursor.getInt(1));
				crash.setMessage(cursor.getString(2));
				crash.setStackTrace(cursor.getString(3));
				crash.setDeviceModel(cursor.getString(4));
				crash.setAndroidVersion(cursor.getString(5));
				crash.setAppVersionCode(cursor.getInt(6));
				crash.setAppVersionName(cursor.getString(7));
				crash.setIsCrashed(cursor.getInt(8));
				crash.setDateTime(cursor.getString(9));
				
				list.add(crash);
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}
	
	public boolean delete(LogCrash obj) {
		boolean output = false;
		SQLiteDatabase db = data.getWritableDatabase();
		int sodong = db.delete(TABLE_LOG_CRASH,
				COLUMN0_ID + " = " + obj.getID(), null);
		if (sodong == 1) {
			output = true;
		}
		db.close();
		return output;
	}
}
