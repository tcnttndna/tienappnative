package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.LogCrash;

public class LogCrashControl {
	private JSONParser jsonParser;
	
	public LogCrashControl(){
		jsonParser = new JSONParser();
	}
		
	public JSONObject upload(LogCrash obj){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "savelogcrash"));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(obj.getPickerId())));
		params.add(new BasicNameValuePair("message", obj.getMessage()));
		params.add(new BasicNameValuePair("stacktrace", obj.getStackTrace()));
		params.add(new BasicNameValuePair("devicemodel", obj.getDeviceModel()));
		params.add(new BasicNameValuePair("androidversion", obj.getAndroidVersion()));
		params.add(new BasicNameValuePair("appversioncode", String.valueOf(obj.getAppVersionCode())));
		params.add(new BasicNameValuePair("appversionname", obj.getAppVersionName()));
		params.add(new BasicNameValuePair("iscrashed", String.valueOf(obj.getIsCrashed())));
		params.add(new BasicNameValuePair("actiontime", obj.getDateTime()));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
}
