package vcn.kybotech.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.List;

import vcn.kybotech.adapter.OrderInPreviewAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.PickOrder;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickOrders;

public class PickingPreviewLoadFragment extends android.app.Fragment{
	private RelativeLayout layoutFrame;
	private ListView lvOrder;
	private String StrLoadID;
	


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_picking_load_preview,container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
		
		layoutFrame = (RelativeLayout)rootView.findViewById(R.id.fragment_picking_load_preview_xml);
		lvOrder = (ListView)rootView.findViewById(R.id.lvOrderInPreView);
		return rootView;
	}
	
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		layoutFrame.setOnClickListener(null);
		
		StrLoadID = getArguments().getString(Constants.key_bundle_loadid);
		
		sql_PickOrders pickOrders = new sql_PickOrders(getActivity());
		List<PickOrder> listOrders = pickOrders.getListOrders(StrLoadID);
		//ADD HEADER
		listOrders.add(0, new PickOrder());
		
		OrderInPreviewAdapter adapter = new OrderInPreviewAdapter(getActivity(), R.layout.item_order_in_preview, listOrders, StrLoadID);
		lvOrder.setAdapter(adapter);
		
	}
}
