package vcn.kybotech.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.crash.FirebaseCrash;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class ScanTimberPackFragment extends android.app.Fragment {

    private int SCAN_STP = 6;
    private final static String Tag = "cancelAll";
    RequestQueue requestQueue;
    private ImageButton btnScan;
    private Button btnTakePhoto;
    private TextView txtQRCode, txtTryAgain;
    private ArrayList<String> listImgUri = new ArrayList<>();
    private ArrayList<String> listImgBase64;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_scan_timber_pack,container,false);

        requestQueue = Volley.newRequestQueue(getActivity());
        initView(view);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        if (isOnline()) {
            setActionBarBlue();
        } else {
            setActionBarRed();
        }
        ((AppCompatActivity)getActivity()).getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(false);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);
        eventOnView();

        return view;
    }



    private void eventOnView() {
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSCanBarCode(SCAN_STP);
            }
        });

        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTakePhoto();
            }
        });

        txtTryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtQRCode.setText("");
                btnScan.setVisibility(View.VISIBLE);
                btnTakePhoto.setVisibility(View.GONE);
                txtTryAgain.setVisibility(View.GONE);
            }
        });
    }

    private void initView(View v) {
        btnScan = (ImageButton) v.findViewById(R.id.btn_STP_QrCode);
        btnTakePhoto = (Button) v.findViewById(R.id.btn_STP_TakePhoto);
        txtQRCode = (TextView) v.findViewById(R.id.txt_STP_scanbarcode);
        txtTryAgain = (TextView) v.findViewById(R.id.txt_tryagain_scanQRCode);
        btnScan.setVisibility(View.VISIBLE);
        btnTakePhoto.setVisibility(View.GONE);
        txtTryAgain.setVisibility(View.GONE);

    }

    public void onSCanBarCode(int types) {
        try {
            Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
            intent.putExtra("SCAN_FORMATS", "QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
            startActivityForResult(intent, types);
        } catch (Exception e) {
            Log.e("NOT SCAN", e.toString());
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SCAN_STP && resultCode == RESULT_OK) {
            try {
                String qrcode = (data.getStringExtra("SCAN_RESULT"));
               if (qrcode.startsWith("QR")) {
                    qrcode = qrcode.substring(0, 10);
                    txtQRCode.setText(qrcode);
                    btnScan.setVisibility(View.GONE);
                    btnTakePhoto.setVisibility(View.VISIBLE);
                    txtTryAgain.setVisibility(View.VISIBLE);
                } else {
                    txtQRCode.setText(qrcode);
                }

            } catch (Exception e) {
                txtQRCode.setText("");
                btnScan.setVisibility(View.VISIBLE);
                btnTakePhoto.setVisibility(View.GONE);
                txtTryAgain.setVisibility(View.GONE);
                dialogQRCodeFail();
            }
        }
        if (requestCode == Constants.RESULT_CONFIRMSTP_UPLOAD_IMAGE
                && resultCode == Constants.RESULT_CONFIRMSTP_UPLOAD_IMAGE) {
            listImgUri = data.getExtras().getStringArrayList("ListImageUriBase64");
            if (listImgUri.size() > 0) {
                listImgBase64 = new ArrayList<>();
                for (String image : listImgUri) {
                    try {
                        byte byteAnh[] = null;
                        String path = image;
                        FileInputStream inputStream = new FileInputStream(path);

                        BufferedInputStream buffInputStream = new BufferedInputStream(inputStream);
                        byteAnh = new byte[buffInputStream.available()];
                        buffInputStream.read(byteAnh);
                        buffInputStream.close();
                        String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
                        listImgBase64.add(encodedString);
                    } catch (Exception ex) {
                        Toast.makeText(getActivity(), "Try again.", Toast.LENGTH_SHORT).show();
                    }
                }

                showDialogConfirm();
            }

        }
    }


    protected void openTakePhoto() {
        Bundle bundle = new Bundle();
        bundle.putString("key_imagetype", Constants.image_ScanTimberPack);
//        bundle.putString("key_pickerid", String.valueOf(fileSave.getPickerID()));
//        bundle.putString("key_pickername", fileSave.getPickerName());

        Intent intent = new Intent(getActivity(), PickingNormalUploadImagesActivity.class);
        intent.putExtra(Constants.key_bundle_upload_image, bundle);
        startActivityForResult(intent, Constants.RESULT_CONFIRMSTP_UPLOAD_IMAGE);
    }

    protected void showDialogConfirm() {
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
        View mview = getActivity().getLayoutInflater().inflate(R.layout.custom_dialog_yesno, null);
        Button btnNo = (Button) mview.findViewById(R.id.btnSTPNo);
        Button btnYes = (Button) mview.findViewById(R.id.btnSTPYes);
        mBuilder.setView(mview);
        final AlertDialog dialog = mBuilder.create();
        dialog.setCancelable(false);
        dialog.show();
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

            }
        });
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (txtQRCode.getText().length() == 0) {
                        dialogQRCodeFail();
                    } else {
                        processConfirmSTP();
                    }
                    dialog.dismiss();
                } catch (Exception ex) {
                    FirebaseCrash.report(ex);
                }
            }
        });
    }

    private void processConfirmSTP() {
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();
        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    if (jsonObject.getBoolean("success")) {

                        if (listImgUri.size() > 0){
                            for (String image : listImgUri){
                                File f = new File(image);
                                f.delete();
                            }
                        }

                        txtQRCode.setText("");
                        btnScan.setVisibility(View.VISIBLE);
                        btnTakePhoto.setVisibility(View.GONE);
                        txtTryAgain.setVisibility(View.GONE);
                        Toast.makeText(getActivity(), "Confirmed!",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Confirm failure!",
                                Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e2) {

                } finally {
                    progressDialog.dismiss();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                try {

                    Toast.makeText(getActivity(), "Connection to your server disconnected!", Toast.LENGTH_SHORT)
                            .show();
                } catch (Exception ex) {
                } finally {
                    progressDialog.dismiss();
                }
            }
        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                final FileSave fileSave = new FileSave(getActivity(), Constants.GET);
                params.put("type", Constants.type_confirmscantimberpack);
                params.put("qrCode", String.valueOf(txtQRCode.getText()));
                params.put("imageIrl", listImgBase64.get(0));
                params.put("imageIrl2", listImgBase64.get(1));
                params.put("pickerId", String.valueOf(fileSave.getPickerID()));
                return params;
            }
        };

        // RequestQueue requestQueue = Volley.newRequestQueue(this);
        int socketTimeout = 30000;// 30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest.setRetryPolicy(policy);
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);
    }

    public void dialogQRCodeFail() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.QRCODE_FAIL);
        dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dialog.show();
    }

    public void setActionBarBlue() {
        if (((AppCompatActivity)getActivity()).getSupportActionBar() != null) {
            ((AppCompatActivity)getActivity()).getSupportActionBar()
                    .setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
        }

    }

    public void setActionBarRed() {
        if (((AppCompatActivity)getActivity()).getSupportActionBar() != null) {
            ((AppCompatActivity)getActivity()).getSupportActionBar()
                    .setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
    }

    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

//    @SuppressLint("NewApi")
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_load_picking, menu);
//
//        int version_in_manifest = 0;
//        try {
//            version_in_manifest = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (Constants.LINK_DONE.equals(Constants.LINK_COMPARE_VIEW_VERSION)) {
//            menu.findItem(R.id.menu_order_picking_test)
//                    .setTitle(Constants.VERSION_TYPE + String.valueOf(version_in_manifest));
//        } else {
//            menu.findItem(R.id.menu_order_picking_test).setTitle(R.string.Test);
//        }
//        return true;
//    }

    @SuppressLint("NewApi")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                getActivity().finish();
                break;
            case R.id.menu_order_picking_user:
                dialogLogout();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogLogout() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.LOGOUT);
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent returnIntent = new Intent();
                getActivity().setResult(RESULT_OK, returnIntent);
                getActivity().finish();
            }
        });
        dialog.setNegativeButton("No", null);
        dialog.show();
    }


}
