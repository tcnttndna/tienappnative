package vcn.kybotech.controller;

/**
 * Created by User on 1/30/2018.
 */

public interface RequestFirebaseListener {
    //    void onRequestFirebaseStart();
    void onRequestFirebaseSuccess(boolean kq);
//    void onRequestCheckDidStatic(boolean result);
}

