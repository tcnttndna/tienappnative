package vcn.kybotech.services;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.ImageControl;
import vcn.kybotech.controller.LogCrashControl;
import vcn.kybotech.controller.LogDataControl;
import vcn.kybotech.model.Image;
import vcn.kybotech.model.LogCrash;
import vcn.kybotech.model.LogData;
import vcn.kybotech.sqlite.sql_Image;
import vcn.kybotech.sqlite.sql_LogCrash;
import vcn.kybotech.sqlite.sql_LogData;
import android.app.Activity;
import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Base64;
import android.util.Log;

public class ServiceUpload extends IntentService{
	public static final String ACTION = "vcn.kybotech.services.ServiceUpload";
	public ServiceUpload() {
		super("Service Upload");
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		Intent in = new Intent(ACTION);
	    in.putExtra("resultCode", Activity.RESULT_OK);
	    if (pingNetWork()) {
	    	Log.e("Check Internet", "Success True");
	    	in.putExtra("getResponseCode", 200);
	    	callCrash();
	    	callImage();
	    	callLogData();
	    }else{
	    	Log.e("Check Internet", "Success False");
	    	in.putExtra("getResponseCode", 404);
	    }
	    LocalBroadcastManager.getInstance(this).sendBroadcast(in);
	}

//	public boolean pingNetWork() {
//		try {
//			SocketAddress addr = new InetSocketAddress("www.google.com", 80);
//			Socket socket = new Socket();
//			socket.connect(addr, 2000);
//			socket.close();
//			return true;
//		} catch (UnknownHostException e) {
//			e.printStackTrace();
//			return false;
//		} catch (IOException e) {
//			return false;
//		}
//	}
	
	public boolean pingNetWork() {
		try {
			
			
//			URL url = new URL("http://192.168.1.121:85");
//		    URL url = new URL("http://kybotech.co.uk");
//			URL url = new URL("http://pickingapp.kybotech.co.uk");
			URL url = new URL(Constants.LINK_DONE);
			HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();
			httpUrlConn.setConnectTimeout(3000);
			httpUrlConn.connect();

			if (httpUrlConn.getResponseCode() == 200) {
				Log.e("ServiceUpload.java","getResponseCode = " + httpUrlConn.getResponseCode());
				return true;
			}else{
				return true;
			}
		} catch (MalformedURLException e) {
			return false;
		} catch (IOException e) {
			return false;
		} catch (Exception e) {
			return false;
		}
}
	
	
	
	public void callCrash(){
		sql_LogCrash sql_crash = new sql_LogCrash(getApplicationContext());
		List<LogCrash> list = new ArrayList<LogCrash>();
		list = sql_crash.selectTop();
		if(list != null){
			for (LogCrash obj : list) {
				if(!UploadCrash(obj)){
					Log.e("Upload table Log Crash", "FALSE");
				} else{
					Log.e("Upload table Log Crash", "TRUE");
				}
			}
		}
		Log.e("Stop Upload table Log Crash", "Upload Log Crash Done");
	}
	
	public boolean UploadCrash(LogCrash obj){
		boolean output = false;
		LogCrashControl ctr_crash = new LogCrashControl();
		JSONObject objJSON = ctr_crash.upload(obj);
		if (objJSON != null) {
			try {
				if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
					if (objJSON.getString(Constants.KEY_SUCCESS).equals("true")) {
						sql_LogCrash sql_Crash = new sql_LogCrash(getApplicationContext());
						if(sql_Crash.delete(obj)){
							System.out.println(">>>>>>>>>>>>DELETE: "+ obj.getID());
							output = true;
						}
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Log.e("Error", Constants.ERR_SERVICE_NETWORK);
		}
		return output;
	}
	
	public void callImage(){
		sql_Image sqlImage = new sql_Image(getApplicationContext());
		List<Image> list = new ArrayList<Image>();
		list = sqlImage.selectTop();
		if(list != null){
			for (Image obj : list) {
				if (!uploadImage(obj)) {
					Log.e("Upload Table Image", "FALSE");
				} else{
					Log.e("Upload Table Images", "TRUE");
				}
			}
		}
		Log.e("Stop Upload Table Image", "Upload Image Done");
	}
	
	public boolean uploadImage(Image image) {
		BufferedInputStream buffInputStream = null;
		boolean output = false;
		try {
			/**MA HOA ANH*/
			byte byteAnh[] = null;
			String path = image.getImageData();
			File file = new File(path);
			FileInputStream inputStream = new FileInputStream(path);
			buffInputStream = new BufferedInputStream(inputStream);
			byteAnh = new byte[buffInputStream.available()];
			buffInputStream.read(byteAnh);
			String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
			image.setImageData(encodedString);
			
			/**GUI ANH VUA MA HOA LEN SERVICE*/
			ImageControl ctrImage = new ImageControl(getApplicationContext());
			JSONObject objJSON = ctrImage.upload(image);
			if (objJSON != null) {
				try {
					if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
						if (objJSON.getString(Constants.KEY_SUCCESS).equals("true")) {
							sql_Image sqlImages = new sql_Image(getApplicationContext());
							if (sqlImages.delete(image)) {
								System.out.println(">>>>>>>>>>>>DELETE DATA BASE: " + image.getId());
								if(file.delete()){
									System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
								}
								output = true;
								buffInputStream.close();
							}
						}else{
							if (objJSON.getString(Constants.KEY_SUCCESS).equals("false")) {
								output = false;
							}
						}
					} else {
						Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				Log.e("Error", Constants.ERR_SERVICE_NETWORK);
			}
		} catch (FileNotFoundException e){
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}
	
	public void callLogData(){
		sql_LogData sql_LogData = new sql_LogData(getApplicationContext());
		List<LogData> list = new ArrayList<LogData>();
		list = sql_LogData.selectTop();
		if(list != null){
			for (LogData obj : list) {
				if(!UploadLogData(obj)){
					Log.e("Upload table Log Data", "FALSE");
				} else{
					Log.e("Upload table Log Data", "TRUE");
				}
			}
		}
		Log.e("Stop Upload table Log Data", "Upload Log Data Done");
	}
	
	public boolean UploadLogData(LogData obj){
		boolean output = false;
		LogDataControl ctr_LogData = new LogDataControl();
		JSONObject objJSON = ctr_LogData.upload(obj);
		if (objJSON != null) {
			try {
				if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
					if (objJSON.getString(Constants.KEY_SUCCESS).equals("true")) {
						sql_LogData sql_LogData = new sql_LogData(getApplicationContext());
						if(sql_LogData.delete(obj)){
							System.out.println(">>>>>>>>>>>>DELETE: "+ obj.getId());
							output = true;
						}
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Log.e("Error", Constants.ERR_SERVICE_NETWORK);
		}
		return output;
	}
}
