package vcn.kybotech.model;

import java.util.List;

public class WareHouseItem {
	public static String COLUMN_WARE_HOUSE_ID = "WarehouseID";
	public static String COLUMN_WARE_HOUSE_NAME = "WarehouseName";
	private int WarehouseID;
	private String WarehouseName;
	private List<SiteItem> site;
	
	public WareHouseItem() {
		super();
	}

	public WareHouseItem(int warehouseID, String warehouseName) {
		super();
		WarehouseID = warehouseID;
		WarehouseName = warehouseName;
	}
	
	public WareHouseItem(int warehouseID, String warehouseName,
			List<SiteItem> site) {
		super();
		WarehouseID = warehouseID;
		WarehouseName = warehouseName;
		this.site = site;
	}

	public int getWarehouseID() {
		return WarehouseID;
	}

	public void setWarehouseID(int warehouseID) {
		WarehouseID = warehouseID;
	}

	public String getWarehouseName() {
		return WarehouseName;
	}

	public void setWarehouseName(String warehouseName) {
		WarehouseName = warehouseName;
	}

	public List<SiteItem> getSite() {
		return site;
	}

	public void setSite(List<SiteItem> site) {
		this.site = site;
	}
}
