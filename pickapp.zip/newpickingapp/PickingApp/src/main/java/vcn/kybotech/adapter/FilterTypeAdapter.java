package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.PickType;
import vcn.kybotech.pickingapp.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

@SuppressLint({ "SimpleDateFormat", "ViewHolder" })
public class FilterTypeAdapter extends ArrayAdapter<PickType> {

	Context context;
	int ResID;
	List<PickType> listObj;

	public FilterTypeAdapter(Context context, int resource,
			List<PickType> objects) {
		super(context, resource, objects);
		this.context = context;
		this.listObj = objects;
		this.ResID = resource;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {


		TypeHolder typeHolder;

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			typeHolder = new TypeHolder();
			convertView = inflater.inflate(R.layout.item_listview_filter_type, parent, false);

			typeHolder.TypeName = (TextView) convertView.findViewById(R.id.item_filter_type_name);

			convertView.setTag(typeHolder);
		} else {
			typeHolder = (TypeHolder) convertView.getTag();
		}
		PickType type = listObj.get(position);
		typeHolder.TypeName.setText(type.getPickType());

		return convertView;
	}

	public static class TypeHolder {
		TextView TypeName;
	}

}
