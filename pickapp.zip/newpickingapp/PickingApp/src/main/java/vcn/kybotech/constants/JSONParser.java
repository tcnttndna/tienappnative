package vcn.kybotech.constants;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class JSONParser {
	private static InputStream input = null;
	static JSONObject objJSON;
	static String json = "";

	public JSONParser() {
	}

	public JSONObject getJsonTuUrl(String url, List<NameValuePair> params) {
		try {
			Log.e("hehe zzz", "zzz");
			objJSON = null;
			HttpParams my_httpParams = new BasicHttpParams();
	        HttpConnectionParams.setConnectionTimeout(my_httpParams, Constants.TIME_OUT * 1000);
	        HttpConnectionParams.setSoTimeout(my_httpParams, 15000);
	        DefaultHttpClient httpClient = new DefaultHttpClient(my_httpParams);

//			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(url);

			httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));

			HttpResponse httpResponse = httpClient.execute(httpPost);
			HttpEntity httpEntity = httpResponse.getEntity();

			input = httpEntity.getContent();
			
			
			BufferedReader bf = new BufferedReader(new InputStreamReader(input,	"UTF-8"), 8);
			StringBuilder sb = new StringBuilder();
			String dong = null;
			while ((dong = bf.readLine()) != null) {
				sb.append(dong + "\n");
			}
			input.close();
			json = sb.toString();
			Log.e("JSON", json);
			objJSON = new JSONObject(json);
		}catch (SocketTimeoutException e){
		    e.printStackTrace();
		}  catch (JSONException e) {
			Log.e("JSON Parser", "LOI COVERT JSONObject " + e.toString());
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objJSON;
	}

}
