package vcn.kybotech.constants;

import java.util.ArrayList;
import java.util.List;

public class Constants {
	/* Link picking */

	/* Server test may Dung */
	// public static final String LINK_DONE = "http://192.168.1.121:85/";

	/* Server test may Linh */
	// public static final String LINK_DONE = "http://192.168.1.123:83/";

	/* Server test may Huyen */
	// public static final String LINK_DONE = "http://192.168.1.125:84/";

	/* Server test */
	public static final String LINK_DONE = "http://pickingservice.vcncorp.net/";

	/* Service release */
//	 public static final String LINK_DONE ="http://pickingapp.kybotech.co.uk/";

	public static final String LINK_PICK_ACCOUNT = Constants.LINK_DONE + "ajax/PickAccount.ashx?";
	public static final String link = Constants.LINK_DONE + "ajax/Stock.ashx?";
	public static final String LINK_PROCESS = Constants.LINK_DONE + "ajax/Process.ashx?";

	/* Luu thong tin tam thoi khi xu ly */
	public static final String TEMP_PICKING_APP = "temp_picking_app.dat";
	public static final String key_boolean_app_installed = "isAppInstalled";
	public static final String key_boolean_remember_login = "isRememberLogin";
	public static final String key_boolean_islogin = "isLogin";
	public static final String key_boolean_isadmin = "isAdmin";
	public static final String key_boolean_isDevicelogin = "isDeviceLogin";

	public static final String key_bundle_pickload = "key_bundle_pickload";
	public static final String key_bundle_loadid = "key_bundle_loadid";
	public static final String key_bundle_loadcode = "key_bundle_loadcode";
	public static final String key_bundle_pickreturnload = "key_bundle_pickreturnload";

	public static final String key_int_UserID = "UserID";
	public static final String key_String_UserName = "UserName";
	public static final String key_int_PickerID = "PickerID";
	public static final String key_String_PickerName = "PickerName";
	public static final String key_int_WarehouseLocationID = "key_int_WarehouseLocationID";
	public static final String key_String_LoadCode = "key_string_loadcode";
	public static final String key_int_CountPhoto = "key_int_countphoto";
	public static final String key_int_CountPhotoAD = "key_int_countphotoad";
	public static final String key_int_PhotoType = "key_int_phototype";
	public static final String key_int_LoadId = "key_int_loadid";
	public static final String key_bundle_upload_image = "upload_imgage";
	public static final String key_bundle_qa_upload_image = "qa_upload_imgage";
	public static final String key_bundle_stack_upload_image = "stack_upload_imgage";
	public static final String key_bundle_confirmloadqa_upload_image = "confirmloadqa_upload_imgage";
	public static final String key_bundle_confirmloadloading_upload_image = "confirmloadloading_upload_imgage";
	public static final String key_String_Name = "Name";
	public static final String key_String_DeviceID = "Name";

	public static final String appname = "appname";
	public static final String type = "type";
	public static final String type_LoginPicker = "LoginPicker";
	public static final String type_ListPickers = "listpickers";
	public static final String type_Loadassigned = "loadassigned";
	public static final String type_loadorders = "loadorders";
	public static final String type_loadid = "loadid";
	public static final String type_checkdevice = "checkdevice";
	public static final String type_returnload = "returningloads";
	public static final String type_returnstock = "returningstock";
	public static final String type_addtostock = "addreturningstock";
	public static final String type_confirmreturnload = "confirmreturnload";
	public static final String type_confirmscantimberpack = "confirmscantimberpack";


	public static final int type_pick_normalpick = 1;
	public static final int type_pick_newpick = 2;
	public static final int type_pick_pickbytype = 3;
	public static final int type_pick_qa = 4;
	public static final int type_pick_stack = 5;
	public static final int type_pick_check = 6;
	public static final int type_pick_loaded = 7;
	public static final int type_pick_qc = 20;

	public static final String pickerid = "pickerid";
	public static final String password = "password";
	public static final String devicename = "devicename";
	public static final String deviceid = "deviceid";
	public static final String deviceversion = "deviceversion";

	public static final String ERR_SERVICE_NETWORK = "NOT INTERNET";
	public static final String ERR_SERVICE_NOT_SUCCESS = "NOT SUCCESS";
	public static final String KEY_SUCCESS = "success";
	public static final String KEY_TRUE = "true";
	public static final String KEY_FALSE = "false";
	public static final String KEY_MESSAGE = "message";
	public static final String KEY_LOAD_CODE = "LoadCode";
	public static final String KEY_COUNT_PHOTO = "CountPhoto";
	public static final String KEY_COUNT_PHOTOAD = "CountPhotoAd";
	public static final String KEY_NONE = "none";

	public static final String NEW_LOCATION = "New Location";
	public static final String INPUT_LOCATION_TO_ADD_STOCK = "Input Location To Add Stock";
	public static final String NOTIFICATION = "Notice";
	public static final String QUANTITY_IS_NOT_NUMBER = "Quantity is not valid, please input a number between 1-400";
	public static final String QUANTITY_IS_NOT_VALUES = "Please input reason!";
	public static final String PRIORITY_ORDER_DO_NOT_OVERLAP = "Priority order do not overlap or null!";
	public static final String QUANTITY_PART_CONFIRM = "Quantity part confirm";
	public static final String NOT_ADD_PART = "SUCCESS FALSE: NOT ADD PART";
	public static final String INFO = "Info";
	public static final String PART_NOT_FOUND = "Part not found!";
	public static final String ADJUST_STOCK_SUCCESSFUL = "Adjust stock successful!";
	public static final String WAREHOUSE_ERROR = "Warehouse error";
	public static final String WAREHOUSE_ERROR_MESS = "Can't not move to the same warehouse";
	public static final String NOTICE = "Notice";
	public static final String MESSAGE_CANT_FIND_LOAD = "Can't find load have ID null, please input correct LoadID and try again!";

	/*
	 * Trang thai cua OrderItem thuong co 3 trang thai 1-None; 2-IsItemPicked;
	 * 3- Remove;
	 */
	public static final String StatusOrderItem_None = "None";// Trang thai chua
																// Picked
	public static final String StatusOrderItem_Picked = "Picked";// Trang thai
																	// da
																	// picked;
	public static final String StatusOrderItem_Loaded = "Loaded";// Trang thai
																	// da
																	// picked;
	public static final String StatusOrderItem_Remove = "Remove";// Trang thai
																	// da xoa
																	// khoi Load

	/* Trang thai LoadMobileStatus cua LoadAssigned de Filter */
	public static final String LoadMobileStatus_All_Status = "All Status";
	public static final String LoadMobileStatus_Ready_To_Pick = "Ready To Pick";
	public static final String LoadMobileStatus_Picking = "Picking";
	public static final String LoadMobileStatus_Picked = "PICKED";
	public static final String LoadMobileStatus_QA_Confirmed = "QA Confirmed";
	public static final String LoadMobileStatus_Stacked = "STACKED";
	public static final String LoadMobileStatus_Checked = "CHECKED";
	public static final String LoadMobileStatus_Loaded = "LOADED";

	public static final String key_int_send_data_from_listloadassigned_to_PickingLoadAssignedFragment = "send_LoadID_from_listloadassigned_to_PickingLoadAssignedFragment";
	public static final String key_int_send_jsonObject_from_listloadassigned_to_PickingLoadAssignedFragment = "send_JsonObject_from_listloadassigned_to_PickingLoadAssignedFragment";

	public static final int ANIMATION = 7;

	public static final int ORDER_PICK_INTENT_MAIN = 9;
	public static final int STOCK_INTENT_MAIN = 10;
	public static final int ADJUST_INTENT_MAIN = 11;
	public static final int VAN_PHOTO_INTENT_MAIN = 12;
	public static final int TAKE_VANS_PHOTO = 13;
	public static final int UPLOAD_IMAGE_MAIN = 14;
	public static final int TAKE_UNPACK_PHOTO = 15;
	public static final int TAKE_TIMBER_DELIVERED_PHOTO = 16;
	public static final int RETURN_LOAD_INTENT_MAIN = 17;
	public static final int SCAN_TIMBER_PACK = 18;
	public static final String PUT = "put";
	public static final String GET = "get";
	public static final String LOGOUT = "Do you want to logout?";
	public static final String PARTID_FAIL = "PartId is not valid, please enter again";
	public static final String QRCODE_FAIL = "QR Code is not valid, please enter again";
	public static final String NOT_DRIVER_CONFIRM = "You did not choose the driver";
	public static final int LENGTH_TAP_TO_SCAN = 5;
	public static final int LENGTH_TAP_TO_SCAN_BARCODE = 10;
	public static final int LENGTH_TAP_TO_SCAN_PALLET = 6;
	public static final String FOLDER_NAME = "PickingApp";
	public static final String FOLDER_NAME_VANS = "Vans Photo";
	public static final String FOLDER_NAME_UNPACK = "Unpack";
	public static final String FOLDER_NAME_QA = "QA";
	public static final String FOLDER_NAME_PICK = "Picker";

	public static final String NAME_VANS_PHOTO = "VansPhoto";
	public static final int TYPE_VANS_PHOTO = 2;

	public static final int TYPE_UNPACK_PHOTO = 5;

	public static final int TYPE_AFTER_DELIVERY_PHOTO = 6;

	public static final int TYPE_LOADED_PHOTO = 8;

	public static final String image_PickingOrderImage = "1";
	public static final String image_VanImage = "2";
	public static final String image_QaOrderImage = "3";
	public static final String image_QaLoadImage = "4";
	public static final String image_StackOrderImage = "7";
	public static final String image_LoadingOrderImage = "9";
	public static final String image_LoadingLoadImage = "10";
	public static final String image_QcOrderImage = "20";
	public static final String image_ReturnLoad = "30";
	public static final String image_ScanTimberPack = "31";

	public static final String LOG_LOGIN_STRING = "Login";

	/* Result Scanner in Load Accept Picking */
	public static int SCAN_ACCEPT_LOAD_PICKING = 111;

	public static int SCAN_PART_BY_QA = 112;

	public static int SCAN_ACCEPT_LOAD_LOADING = 113;

	public static int SCAN_PART_BY_QC = 114;

	/* Take picture confirm load accept */
	public static int REQUEST_TAKE_PHOTO_FROM_PICKING_UPLOAD_IMAGES_FRAGMENT = 15343;
	public static int REQUEST_TAKE_PHOTO_QA_CONFIRM_ORDER = 15344;
	public static int REQUEST_NORMAL_UPLOAD_IMAGE = 15345;
	public static int RESULT_NORMAL_UPLOAD_IMAGE = 15346;

	public static int REQUEST_QA_UPLOAD_IMAGE = 15347;
	public static int RESULT_QA_UPLOAD_IMAGE = 15348;

	public static int REQUEST_STACK_UPLOAD_IMAGE = 15349;
	public static int RESULT_STACK_UPLOAD_IMAGE = 15350;

	public static int REQUEST_CONFIRMLOADQA_UPLOAD_IMAGE = 15351;
	public static int RESULT_CONFIRMLOADQA_UPLOAD_IMAGE = 15352;
	public static int RESULT_CONFIRMRETURNLOAD_UPLOAD_IMAGE = 15353;
	public static int RESULT_CONFIRMSTP_UPLOAD_IMAGE = 15354;
	public static int RESULT_UPDATERETURNLOAD = 22222;

	public static int RESULT_SERVICE_LOGOUT = 1123;

	// public static int REQUEST_TAKE_PHOTO_FROM_PICKING_UPLOAD_IMAGES_FRAGMENT
	// = 15343;

	public static final int LOG_LOGIN_INT = 1;
	public static final String LOG_AUTO_LOGIN_STRING = "Auto Login";
	public static final int LOG_AUTO_LOGIN_INT = 2;

	public static final String LINK_COMPARE_VIEW_VERSION = "http://pickingapp.kybotech.co.uk/";
	public static final String VERSION_TYPE = "Beta ";

	public static int TIMER = 60;
	public static String GOOGLE_LINK = "http://www.google.com";
	public static int TIME_OUT = 30;

//	public static String[] listCarrierName = {"BILLYOH VAN DELIVERY"};

	/**
	 * Key firebase
	 */
	public static final String firebase_key_main = "StateLogin";
	public static final String firebase_key_pickerId = "pickerid";
	public static final String firebase_key_deviceId = "deviceid";
	public static final String firebase_key_pickername = "PickerName";

}
