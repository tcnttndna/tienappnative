package vcn.kybotech.activity;

/**
 * Created by User on 1/24/2018.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.adapter.LoadAssignedAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.fragment.PickingConfirmLoadFragment;
import vcn.kybotech.fragment.PickingLoadingConfirmLoadFragment;
import vcn.kybotech.fragment.PickingLoadingFragment;
import vcn.kybotech.fragment.PickingNormalPickFragment;
import vcn.kybotech.fragment.PickingQAConfirmLoadFragment;
import vcn.kybotech.fragment.PickingQAFragment;
import vcn.kybotech.fragment.PickingQCFragment;
import vcn.kybotech.fragment.PickingSelectTypePickFragment;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickLoad;
import vcn.kybotech.mycustom.LoggingExceptionHandler;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.services.ServiceUpload;
import vcn.kybotech.sqlite.sql_PickLoads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources.NotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SlidingDrawer;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.crash.FirebaseCrash;

import static android.app.Activity.RESULT_OK;

@SuppressLint("SimpleDateFormat")
@SuppressWarnings("deprecation")
public class PickingMainLoadFragment extends android.app.Fragment{

    static RequestQueue requestQueue;
    private final static String Tag = "cancelAll";
    public static List<PickLoad> listLoadAssigned;
    SharedPreferences file_Preferences;
    int pickerID;
    // TODO thÃƒÂªm public static
    public static ListView lvLoadAssigned;
    public static LoadAssignedAdapter adapter;
    public static ProgressBar progressBar;
    public static ImageButton btnRefresh;
    public static ImageButton btnSearchAssigned;
    public static SlidingDrawer slidingDrawer;
    Spinner comboxLoadMobileStatus;
    EditText edtFilterLoadID;
    RadioGroup radioGroup;
    ArrayAdapter<String> adapterSpinner;
    Button btnOK;
    LinearLayout contentSlidingBottomToUp;
    public static TextView tvSearchResult;
//    private int min = 0;
//    private int sec = 59;
//    private Handler mDemnguocHandler;
//    private DemNguocRunnable mDemnguocRun;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_main_load_picking,container,false);

        new LoggingExceptionHandler(getActivity());

        try {
            // GPSTracker gps = new GPSTracker(this);
//            mDemnguocHandler = new Handler();
//            mDemnguocRun = new DemNguocRunnable();
//            showDemNguoc();

            requestQueue = Volley.newRequestQueue(getActivity());
        /* Create ActionBar */
            ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            if (isOnline()) {
                setActionBarBlue((AppCompatActivity) getActivity());
                // pingConnectionSerVer();
            } else {
                // checkConnect = false;
                setActionBarRed((AppCompatActivity) getActivity());
            }
            ((AppCompatActivity)getActivity()).getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
            ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(false);
            ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);

            listLoadAssigned = new ArrayList<PickLoad>();
            file_Preferences = getActivity().getSharedPreferences(Constants.TEMP_PICKING_APP, 0);
            pickerID = file_Preferences.getInt(Constants.key_int_PickerID, -1);
            tvSearchResult = (TextView) view.findViewById(R.id.tvSearchResutl);
            contentSlidingBottomToUp = (LinearLayout) view.findViewById(R.id.content);
            btnOK = (Button) view.findViewById(R.id.btnSearchOK);
            radioGroup = (RadioGroup) view.findViewById(R.id.myRadioGroupWeightSort);
            edtFilterLoadID = (EditText) view.findViewById(R.id.activity_order_picking_filter_loadID);
            comboxLoadMobileStatus = (Spinner) view.findViewById(R.id.activity_order_picking_comboxLoadMobileStatus);
            slidingDrawer = (SlidingDrawer) view.findViewById(R.id.sliding_Search);
            btnSearchAssigned = (ImageButton) view.findViewById(R.id.search_loadAssigned);
            btnRefresh = (ImageButton) view.findViewById(R.id.activity_order_picking_button_refresh);
            progressBar = (ProgressBar) view.findViewById(R.id.activity_order_picking_progressbar);
            lvLoadAssigned = (ListView) view.findViewById(R.id.activity_order_picking_lvLoadAssigned);
            adapter = new LoadAssignedAdapter(getActivity(), R.layout.item_load_assigned, listLoadAssigned);
            lvLoadAssigned.setAdapter(adapter);

		/* Co the xu ly ham nay o onStart() cua Activity nay */
            // TODO (!!) thÃƒÂªm getActivity() vÃƒÂ o onLoadAssigned
            onLoadAssigned(pickerID, (AppCompatActivity) getActivity());

            btnRefresh.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View arg0) {
                    btnRefresh.setVisibility(View.INVISIBLE);
                    // TODO (!!) thÃƒÂªm getActivity() vÃƒÂ o onLoadAssigned
                    onLoadAssigned(pickerID,(AppCompatActivity) getActivity());
                }
            });

            btnSearchAssigned.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View arg0) {
                    if (slidingDrawer.isOpened()) {
                        btnSearchAssigned.setImageResource(R.drawable.abc_ic_search_api_mtrl_alpha);
                        slidingDrawer.close();
                        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(btnSearchAssigned.getWindowToken(), 0);
                    } else {

                        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                        radioGroup.clearCheck();
                        edtFilterLoadID.setText("");
                        comboxLoadMobileStatus.setSelection(0);
                        btnSearchAssigned.setImageResource(R.drawable.ic_close_filter);
                        slidingDrawer.open();
                        edtFilterLoadID.requestFocus();
                    }
                }
            });

            /** SET GIA TRI CHO SPINNER */
            final List<String> listLoadMobileStatus = new ArrayList<String>();
            listLoadMobileStatus.add(Constants.LoadMobileStatus_All_Status);
            listLoadMobileStatus.add(Constants.LoadMobileStatus_Ready_To_Pick);
            listLoadMobileStatus.add(Constants.LoadMobileStatus_Picking);
            listLoadMobileStatus.add(Constants.LoadMobileStatus_Picked);
            listLoadMobileStatus.add(Constants.LoadMobileStatus_QA_Confirmed);

            adapterSpinner = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, listLoadMobileStatus);
            adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            comboxLoadMobileStatus.setAdapter(adapterSpinner);
            comboxLoadMobileStatus.setOnItemSelectedListener(new OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                    String status = listLoadMobileStatus.get(position).toString();

                    /* 1. Loc theo filter */
                    adapter.filter(edtFilterLoadID.getText().toString());

                    /* 2. Loc theo LoadMobileStatus */
                    adapter.filterLoadMobileStatus(status);

                    /* 3. Xet truong tang giam Weight */
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    if (selectedId == R.id.rad_ASC) {
                        onSortWeightASC();
                    } else if (selectedId == R.id.rad_DESC) {
                        onSortWeightDESC();
                    }

                    adapter.notifyDataSetChanged();
                    if (listLoadAssigned.size() == 0) {
                        tvSearchResult.setVisibility(View.VISIBLE);
                    } else {
                        tvSearchResult.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {

                }
            });

            radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(RadioGroup arg0, int checkedID) {
                    // TODO Auto-generated method stub
                    if (checkedID == R.id.rad_ASC) {
                        // Toast.makeText(getApplicationContext(), "Sort Asc",
                        // Toast.LENGTH_SHORT).show();
                        onSortWeightASC();
                    } else if (checkedID == R.id.rad_DESC) {
                        // Toast.makeText(getApplicationContext(), "Sort Desc",
                        // Toast.LENGTH_SHORT).show();
                        onSortWeightDESC();
                    }
                    adapter.notifyDataSetChanged();

                }
            });

            edtFilterLoadID.addTextChangedListener(new TextWatcher() {

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                    /* 1.Loc theo LoadID */
                    adapter.filter(edtFilterLoadID.getText().toString());

                    String status = (String) comboxLoadMobileStatus.getSelectedItem();
                    // long status2 = comboxLoadMobileStatus.getSelectedItemId();
                    // int status3 =
                    // comboxLoadMobileStatus.getSelectedItemPosition();

                    /* 2. Loc theo LoadMobileStatus */
                    adapter.filterLoadMobileStatus(status);

                    /* 3. Xet truong tang giam Weight */
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    if (selectedId == R.id.rad_ASC) {
                        onSortWeightASC();
                    } else if (selectedId == R.id.rad_DESC) {
                        onSortWeightDESC();
                    }

                    adapter.notifyDataSetChanged();
                    if (listLoadAssigned.size() == 0) {
                        tvSearchResult.setVisibility(View.VISIBLE);
                    } else {
                        tvSearchResult.setVisibility(View.GONE);
                    }

                }

                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void afterTextChanged(Editable s) {
                    // TODO Auto-generated method stub

                }
            });

            btnOK.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    slidingDrawer.close();
                    btnSearchAssigned.setImageResource(R.drawable.abc_ic_search_api_mtrl_alpha);
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(btnSearchAssigned.getWindowToken(), 0);
                }
            });

            lvLoadAssigned.setOnItemClickListener(new OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                    android.app.Fragment fragment = new PickingSelectTypePickFragment();
                    Bundle bundlePickLoad = new Bundle();
                    bundlePickLoad.putSerializable(Constants.key_bundle_pickload, listLoadAssigned.get(position));
                    fragment.setArguments(bundlePickLoad);

                    if (fragment != null) {
                        getActivity().getFragmentManager().beginTransaction()
                                .add(R.id.container, fragment, "PickingSelectTypePickFragment")
                                .addToBackStack("PickingSelectTypePickFragment").commit();
                        Log.e("addToBackStack", "PickingSelectTypePickFragment");
                    }
                }
            });
        } catch (Exception e) {
            FirebaseCrash.report(e);
        }


        return view;
    }

    protected void onSortWeightDESC() {
        Collections.sort(listLoadAssigned, new Comparator<PickLoad>() {

            @Override
            public int compare(PickLoad arg0, PickLoad arg1) {

                return (arg1.getWeight() > arg0.getWeight()) ? 1 : -1;
            }
        });
    }

    protected void onSortWeightASC() {
        Collections.sort(listLoadAssigned, new Comparator<PickLoad>() {

            @Override
            public int compare(PickLoad arg0, PickLoad arg1) {

                return (arg1.getWeight() < arg0.getWeight()) ? 1 : -1;
            }
        });
    }

    // TODO thÃƒÂªm para AppCompatActivity vÃƒÂ o hÃƒÂ m, do static k nhÃ¡ÂºÂ­n getActivity()
    public static void onLoadAssigned(final int pickerId, final AppCompatActivity act) {

        progressBar.setVisibility(View.VISIBLE);

        listLoadAssigned.clear();
        tvSearchResult.setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        adapter.notifyDataSetChangedCustom();
        lvLoadAssigned.setSelectionAfterHeaderView();

        final sql_PickLoads loadAssigned = new sql_PickLoads(act.getApplicationContext());
        loadAssigned.clearData();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Log.d("Response", response.toString());
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
                if (btnRefresh != null) {
                    btnRefresh.setVisibility(View.VISIBLE);
                }
                try {

                    JSONObject jsonObject = new JSONObject(response.toString());
                    if (jsonObject.getBoolean("success")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        // listLoadAssigned.clear();
                        // adapter.notifyDataSetChanged();
                        // adapter.notifyDataSetChangedCustom();
                        // lvLoadAssigned.setSelectionAfterHeaderView();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonLoadAssigned = jsonArray.getJSONObject(i);

							/*
                             * Tam thoi comment mot so cot khong su dung den de
							 * dam bao hieu suat cho phan mem
							 */
                            PickLoad loadAssigned = new PickLoad();

                            loadAssigned.setLoadID(jsonLoadAssigned.getInt("LoadID"));
                            loadAssigned.setLoadCode(jsonLoadAssigned.getString("LoadCode"));
                            loadAssigned.setLoadStatus(jsonLoadAssigned.getString("LoadStatus"));
                            // loadAssigned.setCreatedByUserID(
                            // jsonPickAccount.getInt("CreatedByUserID") );
                            // loadAssigned.setCreatedDate(
                            // jsonPickAccount.getString("CreatedDate") );
                            // loadAssigned.setUsername(
                            // jsonPickAccount.getString("Username") );
                            loadAssigned.setPlannedDeliveryDate(jsonLoadAssigned.getString("PlannedDeliveryDate"));
                            // loadAssigned.setCarrierName(
//                             jsonPickAccount.getString("carrierName") );
                            loadAssigned.setCarrierName(jsonLoadAssigned.getString("carrierName"));
                            // loadAssigned.setDriverName(
                            // jsonPickAccount.getString("DriverName") );
                            // loadAssigned.setName(
                            // jsonPickAccount.getString("Name") );
                            // loadAssigned.setVehicleMaxWeight(
                            // jsonPickAccount.getInt("VehicleMaxWeight") );
                            loadAssigned.setBayNumber(jsonLoadAssigned.getInt("BayNumber"));
                            loadAssigned.setLoadMobileStatus(jsonLoadAssigned.getString("LoadMobileStatus"));
                            // loadAssigned.setIsLocked(
                            // jsonPickAccount.getBoolean("IsLocked") );
                            // loadAssigned.setPickerID(
                            // jsonPickAccount.getInt("PickerID") );
                            // loadAssigned.setDriverID(
                            // jsonPickAccount.getInt("DriverID") );
                            loadAssigned.setWeight(jsonLoadAssigned.getDouble("Weight"));
                            // loadAssigned.setIsLoadComplete(
                            // jsonPickAccount.getBoolean("IsLoadComplete") );
                            // loadAssigned.setIsLoadComplete(
                            // jsonPickAccount.getBoolean("IsLocalModified") );
                            // loadAssigned.setOrderRefs(
                            // jsonPickAccount.getString("OrderRefs") );
                            // loadAssigned.setPartItems(
                            // jsonPickAccount.getString("PartItems") );

                            listLoadAssigned.add(loadAssigned);
                            // Log.e("LoginFragment",
                            // jsonLoadAssigned.toString());

                        }

                        adapter.notifyDataSetChanged();
                        adapter.notifyDataSetChangedCustom();
                        lvLoadAssigned.setSelectionAfterHeaderView();

                        if (listLoadAssigned.size() == 0) {
                            AlertDialog.Builder dialog = new Builder(act);
                            dialog.setTitle("Message").setMessage("Not found Load!").setPositiveButton("OK", null)
                                    .show();
                        } else {
                            tvSearchResult.setVisibility(View.GONE);
                        }

                        loadAssigned.insertPickLoadAssignedTransaciton(jsonArray);
                        // TODO (!) thÃƒÂªm PickingFragment vÃƒÂ  setACtionBAr static
                        PickingMainLoadFragment.setActionBarBlue(act);
                    } else {
                        // TODO (!) thÃƒÂªm PickingFragment vÃƒÂ  setACtionBAr static
                        PickingMainLoadFragment.setActionBarRed(act);

                        Toast.makeText(act.getApplicationContext(), "Success: false, server is problem!",
                                Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e2) {
                    // TODO (!) thÃƒÂªm PickingFragment vÃƒÂ  setACtionBAr static
                    PickingMainLoadFragment.DialogServerProblem(act);
                    e2.printStackTrace();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {

                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
                if (btnRefresh != null) {
                    btnRefresh.setVisibility(View.VISIBLE);
                }
                setActionBarRed(act);

                Toast.makeText(act.getApplicationContext(), "Connection to your server disconnected!", Toast.LENGTH_SHORT)
                        .show();
                Log.e("OrderPickingActivity.java", "Load Data AccountPicker disconnect");
                Log.e("OrderPickingActivity.java", volleyError.toString());
            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "loadassigned");
                params.put("pickerid", String.valueOf(pickerId));
                return params;
            }
        };

        // RequestQueue requestQueue = Volley.newRequestQueue(this);
        int socketTimeout = 30000;// 30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest.setRetryPolicy(policy);
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);
    }

    // TODO (!!) thÃƒÂªm para ACtivity
    public static void DialogServerProblem(Activity act) {
        Log.e("LoginFramgment", "server is problem");
        // TODO (!!) thay Ã„â€˜Ã¡Â»â€¢i Picking.this
        if (act == null) {
            return;
        }
        Builder dialog = new AlertDialog.Builder(act);
        dialog.setTitle("Message");
        dialog.setMessage("Server is problem");
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

//    public void onSCanBarCode(int types) {
//        try {
//            Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
//            intent.putExtra("SCAN_FORMATS",
//                    "QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
//            startActivityForResult(intent, types);
//        } catch (Exception e) {
//            Log.e("NOT SCAN", e.toString());
//        }
//    }

//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        /* Scan part in NormalPick */
//        if (requestCode == Constants.SCAN_ACCEPT_LOAD_PICKING && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
//            try {
//                PickingNormalPickFragment.istyped = false;
//                PickingNormalPickFragment.IsManuallyScan = false;
//                PickingNormalPickFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
//            } catch (Exception e) {
//                PickingNormalPickFragment.textScanBarcode.setText("");
//                e.printStackTrace();
//                AlertDialog.Builder dialog = new Builder(getActivity());
//                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
//                        .show();
//            }
//
//        } else if (requestCode == Constants.SCAN_PART_BY_QA && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
//            try {
//                PickingQAFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
//                PickingQAFragment.IsManuallyScan = false;
//            } catch (Exception e) {
//                PickingQAFragment.textScanBarcode.setText("");
//                e.printStackTrace();
//                AlertDialog.Builder dialog = new Builder(getActivity());
//                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
//                        .show();
//            }
//        } else if (requestCode == Constants.SCAN_PART_BY_QC && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
//            Toast.makeText(getActivity(), "23534", Toast.LENGTH_SHORT).show();
//            try {
//                PickingQCFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
//                PickingQCFragment.IsManuallyScan = false;
//            } catch (Exception e) {
//                PickingQCFragment.textScanBarcode.setText("");
//                e.printStackTrace();
//                AlertDialog.Builder dialog = new Builder(getActivity());
//                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
//                        .show();
//            }
//        } else if (requestCode == Constants.SCAN_ACCEPT_LOAD_LOADING && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
//            try {
//                PickingLoadingFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
//                PickingLoadingFragment.IsManuallyScan = false;
//            } catch (Exception e) {
//                PickingLoadingFragment.textScanBarcode.setText("");
//                e.printStackTrace();
//                AlertDialog.Builder dialog = new Builder(getActivity());
//                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
//                        .show();
//            }
//        }
//    }


    @SuppressLint("NewApi")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                getActivity().finish();
                break;
            case R.id.menu_order_picking_user:
                dialogLogout();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogLogout() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.LOGOUT);
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent returnIntent = new Intent();
                getActivity().setResult(RESULT_OK, returnIntent);
                getActivity().finish();
            }
        });
        dialog.setNegativeButton("No", null);
        dialog.show();
    }

    //    /* giao tiep */
//    @Override
//    public void onNormalPickMoveConfirmLoad(String LoadID) {
//
//        PickingConfirmLoadFragment fragmentConfirmLoad = new PickingConfirmLoadFragment();
//
//        Bundle bundle = new Bundle();
//        bundle.putString(Constants.key_bundle_loadid, LoadID);
//        fragmentConfirmLoad.setArguments(bundle);
//
//        getActivity().getFragmentManager().beginTransaction()
//                .add(R.id.container_main_picking_xml, fragmentConfirmLoad, "PickingConfirmLoadFragment")
//                .addToBackStack("PickingConfirmLoadFragment").commit();
//        Log.e("addToBackStack", "PickingConfirmLoadFragment");
//    }
//
//    @Override
//    public void onQAConfirmLoad(String LoadID) {
//
//        PickingQAConfirmLoadFragment fragmentQAConfirmLoad = new PickingQAConfirmLoadFragment();
//        Bundle bundle = new Bundle();
//        bundle.putString(Constants.key_bundle_loadid, LoadID);
//        fragmentQAConfirmLoad.setArguments(bundle);
//
//        getActivity().getFragmentManager().beginTransaction()
//                .add(R.id.container_main_picking_xml, fragmentQAConfirmLoad, "PickingQAConfirmLoadFragment")
//                .addToBackStack("PickingQAConfirmLoadFragment").commit();
//        Log.e("addToBackStack", "PickingQAConfirmLoadFragment");
//    }
//
//    public void onLoadingConfirmLoad(String LoadID) {
//
//        PickingLoadingConfirmLoadFragment fragmentLoadingConfirmLoad = new PickingLoadingConfirmLoadFragment();
//        Bundle bundle = new Bundle();
//        bundle.putString(Constants.key_bundle_loadid, LoadID);
//        fragmentLoadingConfirmLoad.setArguments(bundle);
//
//        getActivity().getFragmentManager().beginTransaction()
//                .add(R.id.container_main_picking_xml, fragmentLoadingConfirmLoad, "PickingLoadingConfirmLoadFragment")
//                .addToBackStack("PickingLoadingConfirmLoadFragment").commit();
//        Log.e("addToBackStack", "PickingLoadingConfirmLoadFragment");
//    }
//
//    @Override
//    public void onDespatchedLoad(String LoadID) {
//        android.app.Fragment fragment = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        getActivity().getFragmentManager().beginTransaction().remove(fragment).commit();
//        getActivity().getFragmentManager().popBackStack();
//        Log.e("remove", fragment.toString());
//
//        sql_PickLoads sqlLoad = new sql_PickLoads(getActivity());
//
//        listLoadAssigned.clear();
//        sqlLoad.deleteLoad(LoadID);
//        listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//        adapter.notifyDataSetChanged();
//        adapter.notifyDataSetChangedCustom();
//        lvLoadAssigned.setSelectionAfterHeaderView();
//    }
//
//    @Override
//    public void onConfirmLoadPicked(String LoadID) {
//
//        android.app.Fragment fragment1 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft1 = getActivity().getFragmentManager().beginTransaction();
//        ft1.remove(fragment1);
//        ft1.commit();
//        Log.e("remove", fragment1.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//        android.app.Fragment fragment2 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft2 = getActivity().getFragmentManager().beginTransaction();
//        ft2.remove(fragment2);
//        ft2.commit();
//        Log.e("remove", fragment2.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//		/* DOAN NAY UPDATE OFFLINE */
//        sql_PickLoads sqlLoad = new sql_PickLoads(getActivity());
//        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picked);
//        Log.e("PickingOrderActivity", "LoadAssigned load in Sqlite");
//        listLoadAssigned.clear();
//        listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//        adapter.notifyDataSetChanged();
//        adapter.notifyDataSetChangedCustom();
//        lvLoadAssigned.setSelectionAfterHeaderView();
//		/*-----------------DOAN NAY UPDATE OFFLINE */
//
//		/* DOAN NAY UPDATE ONLINE */
//        onLoadAssigned(new FileSave(getActivity(), Constants.GET).getPickerID());
//
//    }
//
//    @Override
//    public void onConfirmLoadQA(String LoadID) {
//
//        android.app.Fragment fragment1 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft1 = getActivity().getFragmentManager().beginTransaction();
//        ft1.remove(fragment1);
//        ft1.commit();
//        Log.e("remove", fragment1.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//        android.app.Fragment fragment2 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft2 = getActivity().getFragmentManager().beginTransaction();
//        ft2.remove(fragment2);
//        ft2.commit();
//        Log.e("remove", fragment2.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//		/* DOAN NAY UPDATE OFFLINE */
//        sql_PickLoads sqlLoad = new sql_PickLoads(getActivity());
//        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_QA_Confirmed);
//        listLoadAssigned.clear();
//        listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//        adapter.notifyDataSetChanged();
//        adapter.notifyDataSetChangedCustom();
//        lvLoadAssigned.setSelectionAfterHeaderView();
//		/*-----------------DOAN NAY UPDATE OFFLINE */
//
//		/* DOAN NAY UPDATE ONLINE */
//        onLoadAssigned(new FileSave(getActivity(), Constants.GET).getPickerID());
//
//    }
//
//    @Override
//    public void onConfirmLoadLoading(String LoadID) {
//
//        android.app.Fragment fragment1 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft1 = getActivity().getFragmentManager().beginTransaction();
//        ft1.remove(fragment1);
//        ft1.commit();
//        Log.e("remove", fragment1.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//        android.app.Fragment fragment2 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft2 = getActivity().getFragmentManager().beginTransaction();
//        ft2.remove(fragment2);
//        ft2.commit();
//        Log.e("remove", fragment2.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//		/* DOAN NAY UPDATE OFFLINE */
//        sql_PickLoads sqlLoad = new sql_PickLoads(getActivity());
//        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Loaded);
//        listLoadAssigned.clear();
//        listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//        adapter.notifyDataSetChanged();
//        adapter.notifyDataSetChangedCustom();
//        lvLoadAssigned.setSelectionAfterHeaderView();
//		/*-----------------DOAN NAY UPDATE OFFLINE */
//
//		/* DOAN NAY UPDATE ONLINE */
//        onLoadAssigned(new FileSave(getActivity(), Constants.GET).getPickerID());
//
//    }
//
//    @Override
//    public void onConfirmLoadStacked(String LoadID) {
//
//        android.app.Fragment fragment1 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft1 = getActivity().getFragmentManager().beginTransaction();
//        ft1.remove(fragment1);
//        ft1.commit();
//        Log.e("remove", fragment1.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//        android.app.Fragment fragment2 = getActivity().getFragmentManager().findFragmentById(R.id.container_main_picking_xml);
//        android.app.FragmentTransaction ft2 = getActivity().getFragmentManager().beginTransaction();
//        ft2.remove(fragment2);
//        ft2.commit();
//        Log.e("remove", fragment2.toString());
//        getActivity().getFragmentManager().popBackStack();
//
//		/* DOAN NAY UPDATE OFFLINE */
//        sql_PickLoads sqlLoad = new sql_PickLoads(getActivity());
//        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picked);
//        listLoadAssigned.clear();
//        listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//        adapter.notifyDataSetChanged();
//        adapter.notifyDataSetChangedCustom();
//        lvLoadAssigned.setSelectionAfterHeaderView();
//		/*-----------------DOAN NAY UPDATE OFFLINE */
//
//		/* DOAN NAY UPDATE ONLINE */
//        onLoadAssigned(new FileSave(getActivity(), Constants.GET).getPickerID());
//
//    }
//
//    @Override
//    public void onRefeshAllLoad() {
//
//        // sql_PickLoadAssigneds sqlLoad = new sql_PickLoadAssigneds(this);
//        // sqlLoad.updateLoadMobileStatus(LoadID,
//        // Constants.LoadMobileStatus_Picked);
//        // Log.e("PickingOrderActivity", "LoadAssigned load in Sqlite");
//        // listLoadAssigned.clear();
//        // listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//        // adapter.notifyDataSetChanged();
//        // adapter.notifyDataSetChangedCustom();
//        // lvLoadAssigned.setSelectionAfterHeaderView();
//
//        onLoadAssigned(new FileSave(getActivity(), Constants.GET).getPickerID());
//    }
    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        try {
            IntentFilter filter = new IntentFilter(ServiceUpload.ACTION);
            LocalBroadcastManager.getInstance(getActivity()).registerReceiver(testReceiver, filter);
            pingConnectionSerVer();
        } catch (Exception e) {
        }

//        slidingDrawer.setFocusableInTouchMode(true);
//        slidingDrawer.requestFocus();
//        slidingDrawer.setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//
//                if (keyCode == KeyEvent.KEYCODE_BACK){
//                    Toast.makeText(getActivity(),"Key back",Toast.LENGTH_SHORT).show();
//                    if(slidingDrawer.isOpened()){
//                        slidingDrawer.close();
//                        btnSearchAssigned.setImageResource(R.drawable.abc_ic_search_api_mtrl_alpha);
//                        return true;
//                    }
//                }
//
//                return false;
//            }
//        });

        // mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(testReceiver);
            requestQueue.cancelAll(Tag);
        } catch (Exception e) {
        }
        // mHandler.removeCallbacks(setTitleColor);
    }

    private BroadcastReceiver testReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            try {
                if (intent != null) {
                    int getResponseCode = intent.getIntExtra("getResponseCode", 404);
					/* trang thai cua server */
                    if (getResponseCode == 200) {
                        setActionBarBlue((AppCompatActivity)getActivity());
                    } else {
                        setActionBarRed((AppCompatActivity)getActivity());
                    }
                }
            } catch (Exception e) {
                Log.e("tag", e.toString());
            }
        }
    };

    private void pingConnectionSerVer() {

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    Log.e("pingConnectionSerVer", jsonObject.toString());
                    // if (jsonObject.getBoolean("success")) {
                    // TODO (!!) thÃƒÂªm para (AppCompatActivity)getActivity()
                    setActionBarBlue((AppCompatActivity)getActivity());

                    // }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError arg0) {

                try {
                    setActionBarRed((AppCompatActivity)getActivity());
                } catch (NotFoundException e) {
                }
            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "checkversion");
                params.put("softType", "newpickingapp");
                params.put("curVersion", "1");
                return params;
            }
        };

        try {

            postRequest.setTag(Tag);
            postRequest.setShouldCache(false);
            requestQueue.add(postRequest);
        } catch (Exception e) {
        }
    }

    // TODO (!!) thÃƒÂªm para AppCompatActivity setActionBarBlue thay AppCompatActivity = act
    public static void setActionBarBlue(AppCompatActivity act) {
        if (act.getSupportActionBar() != null) {
            act.getSupportActionBar()
                    .setBackgroundDrawable(act.getResources().getDrawable(R.drawable.background_color_actionbar));
        }

    }

    public static void setActionBarRed(AppCompatActivity act) {
        if (act.getSupportActionBar() != null) {
            act.getSupportActionBar()
                    .setBackgroundDrawable(act.getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        try {
//            mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        } catch (Exception ex) {
//        }
    }

//    public class DemNguocRunnable implements Runnable {
//        @Override
//        public void run() {
//            handleDemnguoc();
//        }
//    }
//
//    private void showDemNguoc() {
//        mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//    }
//
//    private void handleDemnguoc() {
//        try {
//            sec--;
//            if (sec < 0) {
//                min--;
//                sec = 59;
//            }
////        Toast.makeText(this, min + ":" + sec, Toast.LENGTH_SHORT).show();
//            mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//            if (min == 0 && sec == 29) {
////                Toast.makeText(getActivity(), "Gá»­i Request", Toast.LENGTH_SHORT).show();
//                FileSave file = new FileSave(getActivity(), Constants.GET);
//                if (!file.getIsDeviceLogin()) {
//                    Intent intent = new Intent();
//                    file = new FileSave(getActivity(), Constants.PUT);
//                    file.putIsDeviceLogin(true);
//                    getActivity().setResult(Constants.RESULT_SERVICE_LOGOUT, intent);
//                    getActivity().finish();
//                }
//                min = 0;
//                sec = 59;
//                showDemNguoc();
//            }
//        } catch (Exception ex) {
//            Log.e("Service Handle", ex.getMessage());
//        }
//    }

}
