package vcn.kybotech.adapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.PickLoad;
import vcn.kybotech.pickingapp.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("SimpleDateFormat")
public class LoadAssignedAdapter extends ArrayAdapter<PickLoad> {

    Context context;
    int ResID;
    List<PickLoad> listLoadAssigned;
    List<PickLoad> listLoadAssignedFilter;

    public LoadAssignedAdapter(Context context, int resource, List<PickLoad> objects) {
        super(context, resource, objects);
        this.context = context;
        this.ResID = resource;
        listLoadAssignedFilter = objects;

        listLoadAssigned = new ArrayList<PickLoad>();
        // listLoadAssigned.addAll(objects);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LoadAssignedHolder loadAssignedHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            loadAssignedHolder = new LoadAssignedHolder();
            convertView = inflater.inflate(R.layout.item_load_assigned, parent, false);

//			loadAssignedHolder.LoadID = (TextView) convertView.findViewById(R.id.item_load_assigned_LoadID);
            loadAssignedHolder.LoadCode = (TextView) convertView.findViewById(R.id.item_load_assigned_LoadID);
            loadAssignedHolder.BayNumber = (TextView) convertView.findViewById(R.id.item_load_assigned_BayNumber);
            loadAssignedHolder.LoadStatus = (TextView) convertView.findViewById(R.id.item_load_assigned_LoadStatus);
            loadAssignedHolder.Weight = (TextView) convertView.findViewById(R.id.item_load_assigned_Weight);
            loadAssignedHolder.PlannedDeliveryDate = (TextView) convertView
                    .findViewById(R.id.item_load_assigned_PlannedDeliveryDate);

            convertView.setTag(loadAssignedHolder);
        } else {
            loadAssignedHolder = (LoadAssignedHolder) convertView.getTag();
        }

        String dateCovert = "";

        try {
            PickLoad loadAssigned = listLoadAssignedFilter.get(position);
            String dateString = listLoadAssignedFilter.get(position).getPlannedDeliveryDate();
            Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(dateString);
            dateCovert = new SimpleDateFormat("MMM d, yyyy").format(date);
            String ldCode = loadAssigned.getLoadCode().toString();
            int size = ldCode.length();
            String number = ldCode.substring(size - 6);
            String chara = ldCode.substring(0, size - 6);
//			loadAssignedHolder.LoadID.setText(loadAssigned.getLoadID() + "");
            loadAssignedHolder.LoadCode.setText(chara + "\n" + number);
            loadAssignedHolder.BayNumber.setText(loadAssigned.getBayNumber() + "");
            loadAssignedHolder.LoadStatus.setText(loadAssigned.getLoadStatus() + "");
            loadAssignedHolder.Weight.setText(loadAssigned.getWeight() + "");
            loadAssignedHolder.PlannedDeliveryDate.setText(dateCovert);

            String LoadMobileStatus = loadAssigned.getLoadMobileStatus();
            if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_Picked)) {
//				loadAssignedHolder.LoadID.setTextColor(Color.BLUE);
                loadAssignedHolder.LoadCode.setTextColor(Color.BLUE);
                loadAssignedHolder.BayNumber.setTextColor(Color.BLUE);
                loadAssignedHolder.LoadStatus.setTextColor(Color.BLUE);
                loadAssignedHolder.Weight.setTextColor(Color.BLUE);
                loadAssignedHolder.PlannedDeliveryDate.setTextColor(Color.BLUE);
            } else if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_QA_Confirmed)) {
//				loadAssignedHolder.LoadID.setTextColor(Color.parseColor("#009900"));
                loadAssignedHolder.LoadCode.setTextColor(Color.parseColor("#009900"));
                loadAssignedHolder.BayNumber.setTextColor(Color.parseColor("#009900"));
                loadAssignedHolder.LoadStatus.setTextColor(Color.parseColor("#009900"));
                loadAssignedHolder.Weight.setTextColor(Color.parseColor("#009900"));
                loadAssignedHolder.PlannedDeliveryDate.setTextColor(Color.parseColor("#009900"));
            } else if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_Loaded)) {
//				loadAssignedHolder.LoadID.setTextColor(Color.parseColor("#A24E00"));
                loadAssignedHolder.LoadCode.setTextColor(Color.parseColor("#A24E00"));
                loadAssignedHolder.BayNumber.setTextColor(Color.parseColor("#A24E00"));
                loadAssignedHolder.LoadStatus.setTextColor(Color.parseColor("#A24E00"));
                loadAssignedHolder.Weight.setTextColor(Color.parseColor("#A24E00"));
                loadAssignedHolder.PlannedDeliveryDate.setTextColor(Color.parseColor("#A24E00"));
            } else if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_Checked)) {
//				loadAssignedHolder.LoadID.setTextColor(Color.RED);
                loadAssignedHolder.LoadCode.setTextColor(Color.RED);
                loadAssignedHolder.BayNumber.setTextColor(Color.RED);
                loadAssignedHolder.LoadStatus.setTextColor(Color.RED);
                loadAssignedHolder.Weight.setTextColor(Color.RED);
                loadAssignedHolder.PlannedDeliveryDate.setTextColor(Color.RED);
            } else {
//				loadAssignedHolder.LoadID.setTextColor(Color.BLACK);
                loadAssignedHolder.LoadCode.setTextColor(Color.BLACK);
                loadAssignedHolder.BayNumber.setTextColor(Color.BLACK);
                loadAssignedHolder.LoadStatus.setTextColor(Color.BLACK);
                loadAssignedHolder.Weight.setTextColor(Color.BLACK);
                loadAssignedHolder.PlannedDeliveryDate.setTextColor(Color.BLACK);
            }

        } catch (Exception e) {
            Log.e("LoadAssignedAdatper", "error conver time");
            e.printStackTrace();
        }
        return convertView;
    }

    public void filter(String charText) {

        listLoadAssignedFilter.clear();

        for (PickLoad loadAssigned : listLoadAssigned) {
            int i = String.valueOf(loadAssigned.getLoadID()).indexOf(charText);
            if (i == 0) {
                listLoadAssignedFilter.add(loadAssigned);
            }

        }
        notifyDataSetChanged();

    }

    public void filterLoadMobileStatus(String charText) {

        if (charText.equals(Constants.LoadMobileStatus_All_Status)) {
            return;
        }
        List<PickLoad> listIsFilterID = new ArrayList<PickLoad>();
        listIsFilterID.addAll(listLoadAssignedFilter);
        listLoadAssignedFilter.clear();
        for (PickLoad loadAssigned : listIsFilterID) {
            /*
             * Filter theo LoadMoblieStatus neu chon trang thai == Ready to Pick
			 * thi loc ra cac LoadAssign co LoadMobileStatus = "null" hoac =
			 * "Ready to Pick"
			 */
            // boolean check1 =
            // (loadAssigned.getLoadMobileStatus().equals("null") &&
            // Constants.LoadMobileStatus_Ready_To_Pick.equals(charText));
            // boolean check2 =
            // charText.equals(loadAssigned.getLoadMobileStatus());
            // boolean check = check1||check2;
            // Log.e("check = ", check+"");
            // if (check) {
            // listLoadAssignedFilter.add(loadAssigned);
            // }
            // Log.e("check = ", check+"");
            if (((loadAssigned.getLoadMobileStatus().equals("null")
                    && Constants.LoadMobileStatus_Ready_To_Pick.equals(charText)))
                    || (charText.equals(loadAssigned.getLoadMobileStatus()))) {
                listLoadAssignedFilter.add(loadAssigned);
            }
        }
        notifyDataSetChanged();

    }

    public void notifyDataSetChangedCustom() {
        listLoadAssigned.clear();
        listLoadAssigned.addAll(listLoadAssignedFilter);
        notifyDataSetChanged();
    }

    public static class LoadAssignedHolder {
        //		TextView LoadID;
        TextView LoadCode;
        TextView LoadStatus;
        TextView PlannedDeliveryDate;
        TextView BayNumber;
        TextView Weight;
    }
}
