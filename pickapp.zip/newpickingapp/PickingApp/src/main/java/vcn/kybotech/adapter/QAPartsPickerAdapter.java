package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

@SuppressLint("SimpleDateFormat")
public class QAPartsPickerAdapter extends ArrayAdapter<PickPart> {

    Context context;
    int ResID;
    List<PickPart> listLoadAssigned;

    //	List<PickPart> listLoadAssignedFilter;
    public QAPartsPickerAdapter(Context context, int resource, List<PickPart> objects) {
        super(context, resource, objects);
        this.context = context;
        this.ResID = resource;
//		listLoadAssignedFilter = objects;

        listLoadAssigned = objects;
//		listLoadAssigned.addAll(objects);

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        PartHolder partHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            partHolder = new PartHolder();
            convertView = inflater.inflate(R.layout.item_part, parent, false);

            partHolder.soThuTu = (TextView) convertView.findViewById(R.id.item_part_soThuTu);
            partHolder.PartID = (TextView) convertView.findViewById(R.id.item_part_partID);
            partHolder.PartName = (TextView) convertView.findViewById(R.id.item_part_partName);
            partHolder.PartQTy = (TextView) convertView.findViewById(R.id.item_part_QTy);
            partHolder.PartTotalPack = (TextView) convertView.findViewById(R.id.item_part_TotalPack);
            partHolder.PartLoc = (TextView) convertView.findViewById(R.id.item_part_Loc);
            partHolder.PartFreeStock = (TextView) convertView.findViewById(R.id.item_part_FreeStock);

            convertView.setTag(partHolder);
        } else {
            partHolder = (PartHolder) convertView.getTag();
        }

//		String dateCovert = "";

        try {
//			String dateString = listLoadAssignedFilter.get(position).getPlannedDeliveryDate();
//			Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(dateString);
//			dateCovert = new SimpleDateFormat("MMM d, yyyy").format(date);

            partHolder.soThuTu.setText((position + 1) + ".   ");
            partHolder.PartID.setText(String.format("%05d", listLoadAssigned.get(position).getPartID()));
            partHolder.PartName.setText(listLoadAssigned.get(position).getPartName());
            partHolder.PartQTy.setText("QTYScan: " + listLoadAssigned.get(position).getSwipeQA() + "/" + listLoadAssigned.get(position).getQuantity() + "");
            partHolder.PartTotalPack.setText("| Total Pack: " + listLoadAssigned.get(position).getTotalPack() + "");
            partHolder.PartLoc.setText("| Location: " + listLoadAssigned.get(position).getLocationName());
            partHolder.PartFreeStock.setText("| FreeStock: " + listLoadAssigned.get(position).getFreeStock());


            if (listLoadAssigned.get(position).isIsQA()) {
                partHolder.PartID.setTextColor(Color.RED);
                partHolder.PartName.setTextColor(Color.RED);
                partHolder.PartQTy.setTextColor(Color.RED);
                partHolder.PartTotalPack.setTextColor(Color.RED);
                partHolder.PartLoc.setTextColor(Color.RED);
                partHolder.PartFreeStock.setTextColor(Color.RED);
            } else {
                partHolder.PartID.setTextColor(Color.parseColor("#009900"));
                partHolder.PartName.setTextColor(Color.parseColor("#404040"));
                partHolder.PartQTy.setTextColor(Color.parseColor("#404040"));
                partHolder.PartTotalPack.setTextColor(Color.parseColor("#404040"));
                partHolder.PartLoc.setTextColor(Color.parseColor("#404040"));
                partHolder.PartFreeStock.setTextColor(Color.parseColor("#404040"));
            }


        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return convertView;
    }

    public static class PartHolder {
        TextView soThuTu;
        TextView PartID;
        TextView PartName;
        TextView PartQTy;
        TextView PartTotalPack;
        TextView PartLoc;
        TextView PartFreeStock;
    }
}
