package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import vcn.kybotech.model.PickPart;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import static vcn.kybotech.sqlite.sql_PickParts.COLUMN34_PART_GROUP_NAME;
import static vcn.kybotech.sqlite.sql_PickParts.COLUMN35_IS_NEED_SCAN;
import static vcn.kybotech.sqlite.sql_PickParts.COLUMN36_PART_GROUP_ID;
import static vcn.kybotech.sqlite.sql_PickParts.COLUMN37_SWIPE_QC;
import static vcn.kybotech.sqlite.sql_PickParts.COLUMN38_IS_QC;

public class sql_PickPartStack {

    private sql_DataBase data;
    public static final String TABLE_PARTS = "PickPartStack";

    public static final String COLUMN0_ID = "Id";
    public static final String COLUMN1_PART_ID = "PartID";
    public static final String COLUMN2_IS_SCANNED = "IsScanned";
    public static final String COLUMN3_IS_QA = "IsQA";
    public static final String COLUMN4_PART_NAME = "PartName";
    public static final String COLUMN5_QUANTITY = "Quantity";

    public static final String COLUMN6_BAR_CODE = "Barcode";
    public static final String COLUMN7_ORDER_REF = "OrderRef";
    public static final String COLUMN8_ORDER_ITEM_ID = "OrderItemID";
    public static final String COLUMN9_TOTAL_PACK = "TotalPack";
    public static final String COLUMN10_DATE_SCANNED = "DateScanned";

    public static final String COLUMN11_LOCATION_NAME = "LocationName";
    public static final String COLUMN12_PICKED_BY = "PickedBy";
    public static final String COLUMN13_PICK_TYPE_ID = "PickTypeID";
    public static final String COLUMN14_PICK_TYPE = "PickType";
    public static final String COLUMN15_PRODUCT_NAME = "ProductName";

    public static final String COLUMN16_PRODUCT_OPTION = "ProductOption";
    public static final String COLUMN17_DROP_NUMBER = "DropNumber";
    public static final String COLUMN18_LOAD_CODE = "LoadCode";
    public static final String COLUMN19_PACKAGE = "Package";
    public static final String COLUMN20_SPECIAL_INSTRUCTIONS = "SpecialInstructions";
    public static final String COLUMN21_SWIPE = "Swipe";
    public static final String COLUMN22_FREE_STOCK = "FreeStock";
    public static final String COLUMN23_SWIPE_QA = "SwipeQA";
    public static final String COLUMN24_IS_STACKED = "IsStacked";
    public static final String COLUMN25_SWIPE_STACK = "SwipeStack";
    public static final String COLUMN26_STACKED_BY = "StackedBy";

    public static final String CREATE_TABLE_PART = "CREATE TABLE "
            + TABLE_PARTS + " ("
            + COLUMN0_ID + " INTEGER PRIMARY KEY, "
            + COLUMN1_PART_ID + " INTEGER, "
            + COLUMN2_IS_SCANNED + " TEXT, "
            + COLUMN3_IS_QA + " TEXT, "
            + COLUMN4_PART_NAME + " TEXT, "
            + COLUMN5_QUANTITY + " INTEGER, "

            + COLUMN6_BAR_CODE + " TEXT, "
            + COLUMN7_ORDER_REF + " TEXT, "
            + COLUMN8_ORDER_ITEM_ID + " INTEGER, "
            + COLUMN9_TOTAL_PACK + " INTEGER, "
            + COLUMN10_DATE_SCANNED + " TEXT, "

            + COLUMN11_LOCATION_NAME + " TEXT, "
            + COLUMN12_PICKED_BY + " TEXT, "
            + COLUMN13_PICK_TYPE_ID + " INTEGER, "
            + COLUMN14_PICK_TYPE + " TEXT, "
            + COLUMN15_PRODUCT_NAME + " TEXT, "

            + COLUMN16_PRODUCT_OPTION + " TEXT, "
            + COLUMN17_DROP_NUMBER + " INTEGER, "
            + COLUMN18_LOAD_CODE + " TEXT, "
            + COLUMN19_PACKAGE + " INTEGER, "
            + COLUMN20_SPECIAL_INSTRUCTIONS + " TEXT, "
            + COLUMN21_SWIPE + " INTEGER, "
            + COLUMN22_FREE_STOCK + " INTEGER, "
            + COLUMN23_SWIPE_QA + " INTEGER, "
            + COLUMN24_IS_STACKED + " TEXT, "
            + COLUMN25_SWIPE_STACK + " INTEGER, "
            + COLUMN26_STACKED_BY + " TEXT "
            + " )";


    public sql_PickPartStack(Context context) {
        data = new sql_DataBase(context);
    }

    /* Kiem tra xem co bao nhieu ban ghi*/
    public int getCountParts() {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {

            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return c;
    }

    /*NewPickApp NormalPicking - Dem so Part in OrderItem*/
    public int getCountParts(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = " + OrderItemID;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /*NewPickApp Stack - Dem so Part scanned in OrderItem*/
    public int getCountPartScannedStack(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = " + OrderItemID + " AND " + COLUMN24_IS_STACKED + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /*Clear du lieu*/
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            db.delete(TABLE_PARTS, null, null);
            db.close();
            Log.e("sql_PickPartStack", " Clear Data succes");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
    }

    /*Insert du lieu su dung transaction*/
    public void insertPickLoadAssignedTransaciton(JSONArray jsonArr) {

		/*Chuoi JSONArray truyen vao la mot mang cac doi tuong */


        String sql = "INSERT INTO " + TABLE_PARTS + " ("

                + COLUMN1_PART_ID + ", "
                + COLUMN2_IS_SCANNED + ", "
                + COLUMN3_IS_QA + ", "
                + COLUMN4_PART_NAME + ", "
                + COLUMN5_QUANTITY + ", "
                + COLUMN6_BAR_CODE + ", "
                + COLUMN7_ORDER_REF + ", "
                + COLUMN8_ORDER_ITEM_ID + ", "
                + COLUMN9_TOTAL_PACK + ", "
                + COLUMN10_DATE_SCANNED + ", "
                + COLUMN11_LOCATION_NAME + ", "
                + COLUMN12_PICKED_BY + ", "
                + COLUMN13_PICK_TYPE_ID + ", "
                + COLUMN14_PICK_TYPE + ", "
                + COLUMN15_PRODUCT_NAME + ", "
                + COLUMN16_PRODUCT_OPTION + ", "
                + COLUMN17_DROP_NUMBER + ", "
                + COLUMN18_LOAD_CODE + ", "
                + COLUMN19_PACKAGE + ", "
                + COLUMN20_SPECIAL_INSTRUCTIONS + ", "
                + COLUMN21_SWIPE + ", "
                + COLUMN22_FREE_STOCK + ", "
                + COLUMN23_SWIPE_QA + ", "
                + COLUMN24_IS_STACKED + ", "
                + COLUMN25_SWIPE_STACK + ", "
                + COLUMN26_STACKED_BY + " "
                + ") VALUES (?, ?, ?, ?, ?, " +
                "?, ?, ?, ?, ?, " +
                "?, ?, ?, ?, ?, " +
                "?, ?, ?, ?, ?, " +
                "?, ?, ?, ?, ?, ?)";


        SQLiteDatabase db = data.getWritableDatabase();
        db.beginTransactionNonExclusive();
        SQLiteStatement sqlSTMT = db.compileStatement(sql);
        Log.e("sql_PickPartStack ", "so ban ghi sql_PickPartStack can duoc insert vao sqlite = " + jsonArr.length());
        try {
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonParts = jsonArr.getJSONObject(i);
				
				/*Tam thoi chi insert cac cot can su dung con cac cot khong su dung tam thoi comment*/
                sqlSTMT.bindLong(1, jsonParts.getLong("PartID"));
				
				
				/* Neu da scanned thi phai co ten nguoi da pickedby, neu chua scanned thi pickedby=null*/
                String pickby = jsonParts.getString("PickedBy");
                String iscanned = "true";
                if (pickby.equalsIgnoreCase("null")) {
                    iscanned = "false";
                }
                Log.e("sql insert part", " isScanned: " + iscanned);
                sqlSTMT.bindString(2, iscanned);
                sqlSTMT.bindString(3, jsonParts.getString("IsQA"));
                sqlSTMT.bindString(4, jsonParts.getString("PartName"));
                sqlSTMT.bindLong(5, jsonParts.getLong("Quantity"));
//	
                sqlSTMT.bindString(6, jsonParts.getString("Barcode"));
                sqlSTMT.bindString(7, jsonParts.getString("OrderRef"));
                sqlSTMT.bindLong(8, jsonParts.getLong("OrderItemID"));
                sqlSTMT.bindLong(9, jsonParts.getLong("TotalPack"));
//				sqlSTMT.bindString(10, jsonParts.getString("DateScanned") );
//	   
                sqlSTMT.bindString(11, jsonParts.getString("LocationName"));
                sqlSTMT.bindString(12, jsonParts.getString("PickedBy"));
                sqlSTMT.bindLong(13, jsonParts.getLong("PickTypeID"));
                sqlSTMT.bindString(14, jsonParts.getString("PickType"));
//				sqlSTMT.bindString(15, jsonParts.getString("ProductName") );
//				
//				sqlSTMT.bindString(16, jsonParts.getString("ProductOption"));
//				sqlSTMT.bindLong(17, jsonParts.getLong("DropNumber"));
//				sqlSTMT.bindString(18, jsonParts.getString("LoadCode") );			
                sqlSTMT.bindLong(19, jsonParts.getInt("Package"));
                sqlSTMT.bindString(20, jsonParts.getString("SpecialInstructions"));
				
				/*Neu da swipe het roi thi set swipe = Quantity, else = 0*/
                if (Boolean.parseBoolean(iscanned)) {
                    sqlSTMT.bindLong(21, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(21, 0);
                }
                sqlSTMT.bindLong(22, jsonParts.getInt("FreeStock"));
				
				/*Neu da swipe QA het roi thi set swipe = Quantity, else = 0*/
                if (jsonParts.getBoolean("IsQA")) {
                    sqlSTMT.bindLong(23, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(23, 0);
                }
									
				/* Neu da stacked thi phai co ten nguoi da stackedby, neu chua stacked thi stackedby=null*/
                String stackedby = jsonParts.getString("StackedBy");
                String isstacked = "true";
                if (stackedby.equalsIgnoreCase("null")) {
                    isstacked = "false";
                }
				
				/*Neu da swipe het roi thi set swipe = Quantity, else = 0*/
                if (Boolean.parseBoolean(isstacked)) {
                    sqlSTMT.bindLong(25, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(25, 0);
                }

                Log.e("sql insert part", " isstacked: " + isstacked);
                sqlSTMT.bindString(24, isstacked);
                sqlSTMT.bindString(26, stackedby);

                sqlSTMT.execute();
                sqlSTMT.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (Exception e) {
            if (db != null) {
                db.close();
            }

            e.printStackTrace();
            Log.e("sql_PickPartStack", " insertTransaction jsonParts to sqlite error ");
        }
        db.close();
        Log.e("sql_PickPartStack", " so ban ghi duoc qickly insert  =  " + getCountParts());
    }

    /*UPDATE SCAN FOR STACK*/
    public int updateSwipeStack(int OrderItemID, int PartID, int id, String pickedBy) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickPartStack set SwipeStack = (SwipeStack +1) where OrderItemID = " + OrderItemID + " and PartID = " + PartID + " and " + COLUMN24_IS_STACKED + " = 'false' and " + COLUMN0_ID + "  = " + id;
		
		/*Neu swipe full cua tung part thi no se update PickedBy nguoi swipe*/
        ContentValues values = new ContentValues();
        values.put(COLUMN24_IS_STACKED, "true");
        values.put(COLUMN26_STACKED_BY, pickedBy);

        String whereClause = COLUMN25_SWIPE_STACK + " = " + COLUMN5_QUANTITY +
                "  AND " +
                COLUMN8_ORDER_ITEM_ID + " = " + OrderItemID +
                "  AND " +
                COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan Stack part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned Stack 	part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return output;

    }

    /* 	Stack - kiem tra xem tat ca cac part da stacked chua*/
    public boolean isAllPartScannedStacked(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartScannedStack(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    /*Check swipe confirm - Stack*/
    public boolean checkSwipeConfirmStack(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN25_SWIPE_STACK};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /*NewPick dem so part con lai chua scanned*/
    public int getCountPartNotScan(String OrderRef) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN7_ORDER_REF + " = '" + OrderRef + "' AND " + COLUMN24_IS_STACKED + " = 'false'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /*CHECK SCANNED FOR STACK*/
    public boolean checkPartScannedStack(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN24_IS_STACKED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*Trong bang Part co the co 2 Part co cung PartID giong nhau va cung trong mot OrderItemID */
		/*Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung dowhile de loc ra*/
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPartStack", "check stacked part full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /*NewPickApp*/
    public boolean checkPartScannedStack(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN24_IS_STACKED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN0_ID + " = ?";
        Cursor cursor = null;
		/*Trong bang Part co the co 2 Part co cung PartID giong nhau va cung trong mot OrderItemID */
		/*Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung dowhile de loc ra*/
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID), String.valueOf(id)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPartStack", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /*NewPickApp trong class Stack - Clear part */
    public int clearScanPartStack(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();

        int output = -1;

        ContentValues values = new ContentValues();
        values.put(COLUMN25_SWIPE_STACK, 0);
        values.put(COLUMN24_IS_STACKED, "false");
        values.put(COLUMN26_STACKED_BY, "null");
        output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ? ", new String[]{String.valueOf(OrderItemID), String.valueOf(PartID), String.valueOf(id)});
        db.close();
        Log.e("sql_PickPartStack", "clearScanPartStack thanh cong swipe");
        db.close();
        return output;

    }

    /*NewPickapp NormalPicking - Lay ra cac part co the chon scanned hoac not scanned*/
    public List<PickPart> getListParts(String OrderItemID, String isScanned) {

        List<PickPart> list = new ArrayList<PickPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? " + " AND " + COLUMN2_IS_SCANNED + " = ? ";
        String[] args = new String[]{OrderItemID, isScanned};
        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
//						cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
//						cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            "", false, 0, "",
                            cursor.getString(cursor.getColumnIndex(COLUMN34_PART_GROUP_NAME)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN35_IS_NEED_SCAN))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN36_PART_GROUP_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                    ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /*NewPickApp: NormalPick -- NewPick - QA*/
    public List<PickPart> getListParts(String OrderItemID) {
        List<PickPart> list = new ArrayList<PickPart>();

        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_PARTS, null, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID}, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(
                            cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
//						cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
//						cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            "", false, 0, "",
                            cursor.getString(cursor.getColumnIndex(COLUMN34_PART_GROUP_NAME)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN35_IS_NEED_SCAN))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN36_PART_GROUP_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                    ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
//			new LogCrashActivity().inserException(e);
        }
        return list;
    }

}
