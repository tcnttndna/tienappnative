package vcn.kybotech.fragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.adapter.ListDriverAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.controller.DespathchedControl;
import vcn.kybotech.model.Driver;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickLoad;
import vcn.kybotech.model.PickOrder;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.pickingapp.SaveLogTryCatch;
import vcn.kybotech.sqlite.sql_PickAccount;
import vcn.kybotech.sqlite.sql_PickOrderType;
import vcn.kybotech.sqlite.sql_PickOrders;
import vcn.kybotech.sqlite.sql_PickPartStack;
import vcn.kybotech.sqlite.sql_PickPartType;
import vcn.kybotech.sqlite.sql_PickParts;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class PickingSelectTypePickFragment extends android.app.Fragment implements OnClickListener {

    private RelativeLayout noAction;
    private CommunicatingFragments communicatingFragments;
    private Button buttonDoubleCheck;
    private Button buttonStack;
    private Button buttonQA;
    private Button buttonQC;
    private Button buttonDespatched;
    private TextView textViewDespatched;
    private Button buttonNormalPick;
    private Button buttonPreView;
    private Button buttonNewPick;
    private Button buttonPickByType;
    private Button buttonLoading;
    private TextView loadAssingID;
    private Button buttonReTry;
    private RelativeLayout uiReTryRequesServer;
    private TextView messageReTryRequesServer;
    private PickLoad LoadAssigned;
    private android.app.Fragment fragment;
    private String tagNameFragment;
    private ProgressBar processBar;
    private Dialog dialog;
    private List<Driver> listDriver;
    private int chisochon;
    private GPSTracker gps;
    private double LAT;
    private double LNG;
    private final static String Tag = "tagRequesLoadData";
    RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
    FileSave fileSave;
    private JSONParser jsonParser;
    sql_PickAccount sql_pickAccount;
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            communicatingFragments = (CommunicatingFragments) getActivity();
        } catch (Exception e) {
            throw new ClassCastException(activity.toString() + " must implement CommunicatingFragments");
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d("hehe", "start");
        View rootView = inflater.inflate(R.layout.fragment_picking_option_type_pick_, container, false);
        rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        requestQueue = Volley.newRequestQueue(getActivity());
        noAction = (RelativeLayout) rootView.findViewById(R.id.fragment_load_acceptance_xml);
        uiReTryRequesServer = (RelativeLayout) rootView.findViewById(R.id.UI_NotConnectServer);

        processBar = (ProgressBar) rootView.findViewById(R.id.progressbar);
        buttonDoubleCheck = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_DoubleCheck);
        buttonStack = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_Stack);
        buttonQA = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_QuanlityAssurance);
        buttonQC = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_QuanlityControl);
        //change buttonDespatched to text
        buttonDespatched = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_ConfirmDespatched);
        textViewDespatched = (TextView) rootView.findViewById(R.id.fragment_load_acceptance_text_ConfirmDespatched);
        buttonNormalPick = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_NormalPick);
        buttonPreView = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_PreView);
        buttonNewPick = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_NewPick);
        buttonPickByType = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_PickByType);
        buttonLoading = (Button) rootView.findViewById(R.id.fragment_load_acceptance_button_Loading);
        buttonReTry = (Button) rootView.findViewById(R.id.btnReTry);
        messageReTryRequesServer = (TextView) rootView.findViewById(R.id.messgeReTry);
        loadAssingID = (TextView) rootView.findViewById(R.id.fragment_picking_load_acceptance_loadassigned_id);

        buttonDoubleCheck.setVisibility(View.GONE);
        buttonStack.setVisibility(View.VISIBLE);
        buttonQA.setVisibility(View.GONE);
        buttonQC.setVisibility(View.GONE);
        //change buttonDespatched to text
        buttonDespatched.setVisibility(View.GONE);
        textViewDespatched.setVisibility(View.GONE);
        buttonNormalPick.setVisibility(View.GONE);
        buttonPreView.setVisibility(View.GONE);
        buttonNewPick.setVisibility(View.GONE);
        buttonPickByType.setVisibility(View.GONE);
        buttonLoading.setVisibility(View.GONE);
        uiReTryRequesServer.setVisibility(View.GONE);

        noAction.setOnClickListener(this);

        buttonDoubleCheck.setOnClickListener(this);
        buttonStack.setOnClickListener(this);
        buttonQA.setOnClickListener(this);
        buttonQC.setOnClickListener(this);
        buttonDespatched.setOnClickListener(this);
        buttonNormalPick.setOnClickListener(this);
        buttonPreView.setOnClickListener(this);
        buttonNewPick.setOnClickListener(this);
        buttonPickByType.setOnClickListener(this);
        buttonLoading.setOnClickListener(this);
        buttonReTry.setOnClickListener(this);

        Log.d("hehe", "done");

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        fileSave = new FileSave(getActivity(), Constants.GET);
        LoadAssigned = (PickLoad) getArguments().getSerializable(Constants.key_bundle_pickload);

        loadAssingID.setText(String.valueOf(LoadAssigned.getLoadID()));
        try {
            gps = new GPSTracker(PickingSelectTypePickFragment.this.getActivity());
            if (gps.canGetLocation()) {
                LAT = gps.getLatitude();
                LNG = gps.getLongitude();
            }
            gps.stopUsingGPS();
        } catch (Exception e) {
            e.printStackTrace();
        }
        sql_pickAccount = new sql_PickAccount(getActivity());
        onLoadData();
    }

    public void setActionBarRed() {
        if (((AppCompatActivity)getActivity()).getSupportActionBar() != null) {
            ((AppCompatActivity)getActivity()).getSupportActionBar()
                    .setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
    }
    public void setActionBarBlue() {
        if (((AppCompatActivity)getActivity()).getSupportActionBar() != null) {
            ((AppCompatActivity)getActivity()).getSupportActionBar()
                    .setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
        }

    }

    private void onLoadData() {

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(final String reponse) {

                try {
                    setActionBarBlue();
                } catch (Exception e4) {
                }
                new AsyncTask<Void, Void, Void>() {

                    sql_PickParts parts;
                    sql_PickOrders orders;
                    sql_PickPartType partType;
                    sql_PickOrderType ordersWithType;
                    sql_PickPartStack partStack;

                    @Override
                    protected void onPreExecute() {
                        super.onPreExecute();
                        try {
                            parts = new sql_PickParts(getActivity());
                            orders = new sql_PickOrders(getActivity());
                            partType = new sql_PickPartType(getActivity());
                            ordersWithType = new sql_PickOrderType(getActivity());
                            partStack = new sql_PickPartStack(getActivity());
                        } catch (Exception e) {
                        }
                    }

                    @Override
                    protected Void doInBackground(Void... params) {
                        try {
                            parts.clearData();
                            orders.clearData();
                            partType.clearData();
                            ordersWithType.clearData();
                            partStack.clearData();
                        } catch (Exception e1) {
                        }

                        try {
                            JSONObject jsonObject = new JSONObject(reponse.toString());
                            if (jsonObject.getBoolean("success")) {

                                try {

                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss.SSS");
                                    Date date = new Date();
                                    String time = dateFormat.format(date);
                                    Log.e("start insert data", time);

									/* Luu Orders vao SQLite */
                                    try {
                                        JSONArray jsonArray = jsonObject.getJSONArray("orders");
                                        orders.insertPickOrdersTransaciton(jsonArray);
                                    } catch (JSONException e) {
                                        // processBar.setVisibility(View.GONE);
                                        e.printStackTrace();
                                        Log.e("loi~ loi~", e.getMessage());
                                    }

									/* Luu Parts vao SQLite */
                                    try {
                                        JSONArray jsonArray = jsonObject.getJSONArray("parts");
                                        parts.insertPickLoadAssignedTransaciton(jsonArray);
                                    } catch (JSONException e) {
                                        // processBar.setVisibility(View.GONE);
                                        e.printStackTrace();
                                    }

                                    try {
                                        JSONArray jsonArray = jsonObject.getJSONArray("listproductname");
                                        ordersWithType.insertPickOrdersWithTypeTransaciton(jsonArray);
                                    } catch (JSONException e) {
                                        // processBar.setVisibility(View.GONE);
                                        e.printStackTrace();
                                    }

                                    try {
                                        JSONArray jsonArray = jsonObject.getJSONArray("partwithtypes");
                                        partType.insertPickPartWithTypeTransaciton(jsonArray);
                                    } catch (JSONException e) {
                                        // processBar.setVisibility(View.GONE);
                                        e.printStackTrace();
                                    }

                                    // Luu part stack
                                    try {
                                        JSONArray jsonArray = jsonObject.getJSONArray("partstack");
                                        partStack.insertPickLoadAssignedTransaciton(jsonArray);
                                    } catch (JSONException e) {
                                        // processBar.setVisibility(View.GONE);
                                        e.printStackTrace();
                                    }

                                    SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss.SSS");
                                    Date date1 = new Date();
                                    String time1 = dateFormat1.format(date1);
                                    Log.e(" insert data finish", time1);

                                } catch (Exception e) {
                                    Log.e("/* Luu Parts vao SQLite */", "");
                                    Log.e("/* Luu Orders vao SQLite */", "");
                                    Log.e("/* Luu PartWithType vao SQLite */", "");
                                    Log.e("/* Luu OrdersWithType vao SQLite */", "");
                                    e.printStackTrace();
                                    // processBar.setVisibility(View.GONE);
                                }

                            }

                        } catch (Exception e) {

                        }
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void result) {
                        super.onPostExecute(result);
                        try {
                            JSONObject jsonObject = new JSONObject(reponse.toString());
                            if (jsonObject.getBoolean("success")) {

								/* Set visibility cho cac nut */
                                String LoadMobileStatus = LoadAssigned.getLoadMobileStatus();
                                if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_Picked)) {
                                    // buttonStack.setVisibility(View.VISIBLE);

                                    buttonQA.setVisibility(View.VISIBLE);
                                    buttonDespatched.setVisibility(View.GONE);
                                    buttonNormalPick.setVisibility(View.GONE);
                                    buttonPreView.setVisibility(View.VISIBLE);
                                    // buttonNewPick.setVisibility(View.GONE);
                                    // buttonPickByType.setVisibility(View.GONE);
                                    uiReTryRequesServer.setVisibility(View.GONE);
                                    buttonDoubleCheck.setVisibility(View.GONE);

                                } else if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_QA_Confirmed)) {
                                    buttonQA.setVisibility(View.GONE);
                                    buttonDespatched.setVisibility(View.GONE);
                                    buttonNormalPick.setVisibility(View.GONE);
                                    buttonPreView.setVisibility(View.VISIBLE);
                                    // buttonNewPick.setVisibility(View.GONE);
                                    // buttonPickByType.setVisibility(View.GONE);
                                    uiReTryRequesServer.setVisibility(View.GONE);
                                    buttonDoubleCheck.setVisibility(View.GONE);
                                    buttonLoading.setVisibility(View.VISIBLE);
                                    CheckPermissionQC();

                                } else if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_Loaded)) {
                                    buttonQA.setVisibility(View.GONE);
                                    //change buttonDespatched to text
//									buttonDespatched.setVisibility(View.VISIBLE);
                                    textViewDespatched.setVisibility(View.VISIBLE);
                                    buttonNormalPick.setVisibility(View.GONE);
                                    buttonPreView.setVisibility(View.VISIBLE);
                                    // buttonNewPick.setVisibility(View.GONE);
                                    // buttonPickByType.setVisibility(View.GONE);
                                    uiReTryRequesServer.setVisibility(View.GONE);
                                    buttonDoubleCheck.setVisibility(View.GONE);
                                    buttonLoading.setVisibility(View.GONE);
                                    CheckPermissionQC();

                                } else if (LoadMobileStatus.equalsIgnoreCase(Constants.LoadMobileStatus_Checked)) {
                                    buttonQA.setVisibility(View.GONE);
                                    //change buttonDespatched to text
//									buttonDespatched.setVisibility(View.VISIBLE);
                                    textViewDespatched.setVisibility(View.VISIBLE);
                                    buttonNormalPick.setVisibility(View.GONE);
                                    buttonPreView.setVisibility(View.VISIBLE);
                                    // buttonNewPick.setVisibility(View.GONE);
                                    // buttonPickByType.setVisibility(View.GONE);
                                    uiReTryRequesServer.setVisibility(View.GONE);
                                    buttonDoubleCheck.setVisibility(View.GONE);
                                    buttonLoading.setVisibility(View.GONE);
                                } else {
                                    CheckPermissionQC();
                                    // buttonStack.setVisibility(View.GONE);
                                    buttonQA.setVisibility(View.GONE);
                                    buttonDespatched.setVisibility(View.GONE);
                                    buttonNormalPick.setVisibility(View.VISIBLE);
                                    buttonPreView.setVisibility(View.VISIBLE);
                                    // buttonNewPick.setVisibility(View.VISIBLE);
                                    // buttonPickByType.setVisibility(View.VISIBLE);
                                    uiReTryRequesServer.setVisibility(View.GONE);
                                    buttonDoubleCheck.setVisibility(View.GONE);
                                }

                            } else {// result.getBoolean("success")==fasel;
                                // buttonStack.setVisibility(View.GONE);
                                buttonQC.setVisibility(View.GONE);
                                buttonQA.setVisibility(View.GONE);
                                buttonDespatched.setVisibility(View.GONE);
                                buttonNormalPick.setVisibility(View.GONE);
                                buttonPreView.setVisibility(View.GONE);
                                // buttonNewPick.setVisibility(View.GONE);
                                // buttonPickByType.setVisibility(View.GONE);
                                uiReTryRequesServer.setVisibility(View.VISIBLE);
                                messageReTryRequesServer.setText("Not data from server.");
                            }

                        } catch (JSONException e) {
                            DialogServerProblem();
                            try {
                                // buttonStack.setVisibility(View.GONE);
                                buttonQA.setVisibility(View.GONE);
                                buttonDespatched.setVisibility(View.GONE);
                                buttonNormalPick.setVisibility(View.GONE);
                                buttonPreView.setVisibility(View.GONE);
                                // buttonNewPick.setVisibility(View.GONE);
                                // buttonPickByType.setVisibility(View.GONE);
                                uiReTryRequesServer.setVisibility(View.VISIBLE);
                                messageReTryRequesServer.setText("Check your connection and try again.");
                                processBar.setVisibility(View.GONE);
                            } catch (Exception e3) {
                                // processBar.setVisibility(View.GONE);
                                e3.printStackTrace();
                            }
                        } catch (Exception e2) {
                            new SaveLogTryCatch(getActivity()).inserException(e2);
                        }

                        if (processBar != null) {
                            processBar.setVisibility(View.GONE);
                        }
                    }
                }.execute();

            }

        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {

                if (processBar != null) {
                    processBar.setVisibility(View.GONE);

                }
                try {
                    setActionBarRed();
                } catch (Exception e1) {
                }

                Toast.makeText(getActivity(), "Connection to your server disconnected!", Toast.LENGTH_SHORT).show();
                Log.e("PickingSelectType.java", volleyError.toString());

                try {
                    buttonQA.setVisibility(View.GONE);
                    buttonDespatched.setVisibility(View.GONE);
                    buttonNormalPick.setVisibility(View.GONE);
                    buttonPreView.setVisibility(View.GONE);
                    // buttonNewPick.setVisibility(View.GONE);
                    // buttonPickByType.setVisibility(View.GONE);
                    uiReTryRequesServer.setVisibility(View.VISIBLE);
                    messageReTryRequesServer.setText("Check your connection and try again.");
                    processBar.setVisibility(View.GONE);
                } catch (Exception e) {
                    // processBar.setVisibility(View.GONE);
                    e.printStackTrace();
                }
            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "loadorders");
                params.put("loadid", String.valueOf(LoadAssigned.getLoadID()));

                return params;

            }

            ;
        };

        // RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        int socketTimeout = 30000;// 30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest.setRetryPolicy(policy);
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.fragment_load_acceptance_button_DoubleCheck:
                onButtonCheck();
                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_Stack:
                onButtonStack();
                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_QuanlityAssurance:
                onButtonQA();
//                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_QuanlityControl:
                onButtonQC();
//                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_ConfirmDespatched:
                getDriver();
                break;
            case R.id.fragment_load_acceptance_button_NormalPick:
                onButtonNormalPick();
                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_PreView:
                onButtonPreview();
                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_NewPick:
                onButtonNewPick();
                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_PickByType:
                onButtonPickByType();
                onAddToBackStack();
                break;
            case R.id.fragment_load_acceptance_button_Loading:
                onButtonLoading();
                onAddToBackStack();
                break;
            case R.id.btnReTry:
                uiReTryRequesServer.setVisibility(View.GONE);
                processBar.setVisibility(View.VISIBLE);
                onLoadData();

        }

    }

    private void onAddToBackStack() {
        if (fragment != null) {
            getActivity().getFragmentManager().beginTransaction()
                    .add(R.id.container, fragment, tagNameFragment).addToBackStack(tagNameFragment)
                    .commit();
            Log.e("addToBackStack", tagNameFragment);
        }
    }

    private void onButtonCheck() {
        try {
            // Check if this user is also picked or not
            new AsyncTask<String, String, JSONObject>() {
                JSONObject objJSON;
                ProgressDialog progressDialog;

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    progressDialog = new ProgressDialog(getActivity());
                    progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                protected JSONObject doInBackground(String... params) {
                    DespathchedControl ctrDriver = new DespathchedControl(
                            PickingSelectTypePickFragment.this.getActivity());
                    objJSON = ctrDriver.checkUser("2", String.valueOf(fileSave.getPickerID()),
                            String.valueOf(LoadAssigned.getLoadID()));
                    return objJSON;
                }

                @Override
                protected void onPostExecute(JSONObject objJSON) {
                    if (objJSON != null) {
                        try {
                            if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                                if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                                    String mess = objJSON.getString("message");
                                    if (!mess.equals("OK")) {
                                        AlertDialog.Builder dialog = new Builder(getActivity());
                                        dialog.setTitle("Notification").setMessage(mess).setPositiveButton("OK", null)
                                                .show();
                                    } else {
                                        sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                                        List<PickOrder> listOrder = sqlOrders.getListOrdersQA();

                                        fragment = new PickingCheckFragment();

                                        Bundle bundle = new Bundle();
                                        bundle.putString(Constants.key_bundle_loadid,
                                                String.valueOf(LoadAssigned.getLoadID()));
                                        bundle.putString(Constants.key_bundle_loadcode,
                                                String.valueOf(LoadAssigned.getLoadCode()));
                                        fragment.setArguments(bundle);

                                        tagNameFragment = "PickingCheckFragment";
                                    }
                                } else {
                                    DialogDisconnectToServer();
                                }
                            } else {
                                Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                        DialogDisconnectToServer();
                    }
                    progressDialog.dismiss();
                }
            }.execute();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onButtonStack() {
        try {
            sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
            List<PickOrder> listOrder = sqlOrders.getListOrdersStack();

            fragment = new PickingStackFragment();

            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            bundle.putString(Constants.key_bundle_loadcode, String.valueOf(LoadAssigned.getLoadCode()));
            fragment.setArguments(bundle);

            tagNameFragment = "PickingStackFragment";

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void onButtonQA() {
        try {
            // Check if this user is also picked or not
            new AsyncTask<String, String, JSONObject>() {
                JSONObject objJSON;
                ProgressDialog progressDialog;

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    progressDialog = new ProgressDialog(getActivity());
                    progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                protected JSONObject doInBackground(String... params) {
                    DespathchedControl ctrDriver = new DespathchedControl(
                            PickingSelectTypePickFragment.this.getActivity());
                    objJSON = ctrDriver.checkUser("1", String.valueOf(fileSave.getPickerID()),
                            String.valueOf(LoadAssigned.getLoadID()));
                    return objJSON;
                }

                @Override
                protected void onPostExecute(JSONObject objJSON) {
                    if (objJSON != null) {
                        try {
                            if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                                if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                                    String mess = objJSON.getString("message");
                                    if (!mess.equals("OK")) {
                                        Log.d("dau do", "xanh xanh");
                                        AlertDialog.Builder dialog = new Builder(getActivity());
                                        dialog.setTitle("Notification").setMessage(mess).setPositiveButton("OK", null)
                                                .show();
                                    } else {
                                        Log.d("dau xanh", "xanh xanh");
                                        sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                                        List<PickOrder> listOrder = sqlOrders.getListOrdersQA();

                                        if (listOrder.size() > 0) {
                                            fragment = new PickingQAFragment();

                                            Bundle bundle = new Bundle();
                                            bundle.putString(Constants.key_bundle_loadid,
                                                    String.valueOf(LoadAssigned.getLoadID()));
                                            bundle.putString(Constants.key_bundle_loadcode,
                                                    String.valueOf(LoadAssigned.getLoadCode()));
                                            fragment.setArguments(bundle);

                                            tagNameFragment = "PickingQAFragment";
                                            onAddToBackStack();
                                        } else {
                                            /*
                                             * Neu Load khong con OrderItem nao
											 * de xu ly thi chuyen sang giao
											 * dien confirm Neu Load trong thi
											 * chuyen sang giao dien thong bao
											 * khong co OrderItem
											 */
                                            if (sqlOrders.getCountOrdersNotRemove(
                                                    String.valueOf(LoadAssigned.getLoadID())) > 0) {
                                                /*
                                                 * Chuyen sang giao dien confirm
												 * Load
												 */
                                                fragment = new PickingQAConfirmLoadFragment();

                                                Bundle bundle = new Bundle();
                                                bundle.putString(Constants.key_bundle_loadid,
                                                        String.valueOf(LoadAssigned.getLoadID()));
                                                fragment.setArguments(bundle);

                                                tagNameFragment = "PickingQAConfirmLoadFragment";
                                                onAddToBackStack();

                                            } else {
                                                /*
                                                 * Chuyen sang giao dien bao
												 * Order khong ton tai trong
												 * Load
												 */
                                                fragment = new PickingLoadEmptyFragment();
                                                Bundle bundle = new Bundle();
                                                bundle.putString(Constants.key_bundle_loadid,
                                                        String.valueOf(LoadAssigned.getLoadID()));
                                                fragment.setArguments(bundle);
                                                tagNameFragment = "PickingLoadEmptyFragment";
                                                onAddToBackStack();
                                            }
                                        }
                                    }
                                } else {
                                    DialogDisconnectToServer();
                                }
                            } else {
                                Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                        DialogDisconnectToServer();
                    }
                    progressDialog.dismiss();
                }
            }.execute();

        } catch (Exception e) {
            Log.d("hehe haha 6", "");
            e.printStackTrace();
        }

    }

    private void onButtonQC() {
        try {
            fragment = new PickingQCFragment();

            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid,
                    String.valueOf(LoadAssigned.getLoadID()));
            bundle.putString(Constants.key_bundle_loadcode,
                    String.valueOf(LoadAssigned.getLoadCode()));
            fragment.setArguments(bundle);
            tagNameFragment = "PickingQCFragment";
            getActivity().getFragmentManager().beginTransaction()
                    .add(R.id.container, fragment, tagNameFragment).addToBackStack(tagNameFragment)
                    .commit();
        } catch (Exception e) {
            Log.d("hehe haha 6", "");
            e.printStackTrace();
        }

    }

    private void onButtonNormalPick() {
        try {
            sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
            List<PickOrder> listOrder = sqlOrders.getListOrdersAccept(String.valueOf(LoadAssigned.getLoadID()));

            if (listOrder.size() > 0) {
                fragment = new PickingNormalPickFragment();

                Bundle bundle = new Bundle();
                bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
                bundle.putString(Constants.key_bundle_loadcode, String.valueOf(LoadAssigned.getLoadCode()));
                fragment.setArguments(bundle);

                tagNameFragment = "PickingNormalPickFragment";
            } else {
                if (sqlOrders.getCountOrders(String.valueOf(LoadAssigned.getLoadID())) > 0) {
					/* Chuyen sang giao dien confirm Load */
                    // fragment = new PickingConfirmLoadFragment();
                    //
                    // Bundle bundle = new Bundle();
                    // bundle.putString(Constants.key_bundle_loadid,
                    // String.valueOf(LoadAssigned.getLoadID()));
                    // fragment.setArguments(bundle);
                    //
                    // tagNameFragment = "PickingConfirmLoadFragment";

                    fragment = new PickingQAConfirmLoadFragment();

                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
                    fragment.setArguments(bundle);

                    tagNameFragment = "PickingQAConfirmLoadFragment";

                } else {
					/*
					 * Chuyen sang giao dien bao Order khong ton tai trong Load
					 */
                    fragment = new PickingLoadEmptyFragment();

                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
                    fragment.setArguments(bundle);

                    tagNameFragment = "PickingLoadEmptyFragment";

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void onButtonLoading() {
        try {
            sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
            List<PickOrder> listOrder = sqlOrders.getListOrdersLoading(String.valueOf(LoadAssigned.getLoadID()));

            if (listOrder.size() > 0) {
                fragment = new PickingLoadingFragment();

                Bundle bundle = new Bundle();
                bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
                bundle.putString(Constants.key_bundle_loadcode, String.valueOf(LoadAssigned.getLoadCode()));
                fragment.setArguments(bundle);

                tagNameFragment = "PickingNormalPickFragment";
            } else {
                if (sqlOrders.getCountOrders(String.valueOf(LoadAssigned.getLoadID())) > 0) {

                    fragment = new PickingLoadingConfirmLoadFragment();

                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
                    fragment.setArguments(bundle);

                    tagNameFragment = "PickingLoadingConfirmLoadFragment";

                } else {
					/*
					 * Chuyen sang giao dien bao Order khong ton tai trong Load
					 */
                    fragment = new PickingLoadEmptyFragment();

                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
                    fragment.setArguments(bundle);

                    tagNameFragment = "PickingLoadEmptyFragment";
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void onButtonNewPick() {

        sql_PickOrders sqlPickOrders = new sql_PickOrders(getActivity());
        int countOrder = sqlPickOrders.getCountOrdersNotRemove(String.valueOf(LoadAssigned.getLoadID()));
        if (countOrder > 0) {

            fragment = new PickingNewPickFragment();
            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            fragment.setArguments(bundle);
            tagNameFragment = "PickingNewPickFragment";

        } else {
			/* Chuyen sang giao dien bao Order khong ton tai trong Load */
            fragment = new PickingLoadEmptyFragment();

            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            fragment.setArguments(bundle);

            tagNameFragment = "PickingLoadEmptyFragment";
        }
    }

    private void onButtonPickByType() {

        sql_PickOrderType sqlOrdersWithType = new sql_PickOrderType(getActivity());
        int countOrder = sqlOrdersWithType.getCountOrdersWithType();

        if (countOrder > 0) {

            fragment = new PickingPickByTypeFragment();
            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            fragment.setArguments(bundle);
            tagNameFragment = "PickingPickByTypeFragment";
        } else {
			/* Chuyen sang giao dien bao Order khong ton tai trong Load */
            fragment = new PickingLoadEmptyFragment();

            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            fragment.setArguments(bundle);

            tagNameFragment = "PickingLoadEmptyFragment";
        }

    }

    private void onButtonPreview() {

        sql_PickOrders sqlPickOrders = new sql_PickOrders(getActivity());
        int countOrder = sqlPickOrders.getCountOrdersNotRemove(String.valueOf(LoadAssigned.getLoadID()));
        if (countOrder > 0) {

            fragment = new PickingPreviewLoadFragment();

            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            fragment.setArguments(bundle);

            tagNameFragment = "PickingPreviewLoadFragment";
        } else {
			/* Chuyen sang giao dien bao Order khong ton tai trong Load */
            fragment = new PickingLoadEmptyFragment();

            Bundle bundle = new Bundle();
            bundle.putString(Constants.key_bundle_loadid, String.valueOf(LoadAssigned.getLoadID()));
            fragment.setArguments(bundle);

            tagNameFragment = "PickingLoadEmptyFragment";
        }

    }

    public void dialogConfirmDespatched() {
        chisochon = -1;
        dialog = new Dialog(PickingSelectTypePickFragment.this.getActivity());
        dialog.setContentView(R.layout.custom_dialog_despatched);
        dialog.setTitle("Confirm Despatched");
        final ListDriverAdapter adapter;
        ListView lvDriver = (ListView) dialog.findViewById(R.id.custom_dialog_despatched_listview);
        Button btnCancel = (Button) dialog.findViewById(R.id.custom_dialog_despatched_listview_button_cancel);
        Button btnConfirm = (Button) dialog.findViewById(R.id.custom_dialog_despatched_listview_button_confirm);
        adapter = new ListDriverAdapter(PickingSelectTypePickFragment.this.getActivity(),
                R.layout.item_listview_dialog_despatched, listDriver);
        lvDriver.setAdapter(adapter);

        lvDriver.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                chisochon = arg2;
                listDriver.get(arg2).setChecked(true);
                for (int i = 0; i < listDriver.size(); i++) {
                    if (i != arg2) {
                        listDriver.get(i).setChecked(false);
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });
        btnCancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnConfirm.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chisochon != -1) {
                    ConfirmDespatched();
                    dialog.dismiss();
                } else {
                    Toast.makeText(PickingSelectTypePickFragment.this.getActivity(), Constants.NOT_DRIVER_CONFIRM,
                            Toast.LENGTH_LONG).show();
                }

            }
        });
        dialog.show();
    }

    public void getDriver() {
        new AsyncTask<String, String, JSONObject>() {
            JSONObject objJSON;
            ProgressDialog progressDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                progressDialog.setCancelable(false);
                progressDialog.show();
            }

            @Override
            protected JSONObject doInBackground(String... params) {
                DespathchedControl ctrDriver = new DespathchedControl(PickingSelectTypePickFragment.this.getActivity());
                objJSON = ctrDriver.getDriver();
                return objJSON;
            }

            @Override
            protected void onPostExecute(JSONObject objJSON) {
                if (objJSON != null) {
                    try {
                        if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                            if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                                JSONArray jsonArray = objJSON.getJSONArray("data");
                                listDriver = new ArrayList<Driver>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject json = jsonArray.getJSONObject(i);
                                    Driver obj = new Driver();
                                    obj.setDriverId(json.getInt("UserID"));
                                    obj.setDriverName(json.getString("Username"));
                                    obj.setPassword(json.getString("UserPassword"));
                                    obj.setChecked(false);
                                    listDriver.add(obj);
                                }

                                dialogConfirmDespatched();
                            } else {
                                DialogDisconnectToServer();
                            }
                        } else {
                            Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                    DialogDisconnectToServer();
                }
                progressDialog.dismiss();
            }
        }.execute();
    }

    public Boolean CheckUser(final String action) {

        return true;
    }

    public void DialogDisconnectToServer() {
        Log.e("LoginFramgment", "disconnect to server");
        Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

    public void DialogServerProblem() {
        Log.e("LoginFramgment", "server is problem");
        if (getActivity() == null) {
            return;
        }
        Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage("Server is problem");
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

    public void ConfirmDespatched() {
        new AsyncTask<String, String, JSONObject>() {
            JSONObject objJSON;
            ProgressDialog progressDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                progressDialog.setCancelable(false);
                progressDialog.show();
            }

            @Override
            protected JSONObject doInBackground(String... params) {
                DespathchedControl ctrDriver = new DespathchedControl(PickingSelectTypePickFragment.this.getActivity());
                objJSON = ctrDriver.confirmDespatched(String.valueOf(LoadAssigned.getLoadID()),
                        listDriver.get(chisochon).getDriverId(), LAT, LNG);
                return objJSON;
            }

            @Override
            protected void onPostExecute(JSONObject objJSON) {
                if (objJSON != null) {
                    try {
                        if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                            if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                                String s = objJSON.getString("message");
                                if (s.equals("success")) {
                                    communicatingFragments.onDespatchedLoad(String.valueOf(LoadAssigned.getLoadID()));
                                } else {
                                    Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                                }

                            } else {
                                DialogDisconnectToServer();
                            }
                        } else {
                            Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                    DialogDisconnectToServer();
                }
                progressDialog.dismiss();
            }
        }.execute();
    }

    @Override
    public void onDetach() {
        requestQueue.cancelAll(Tag);
        super.onDetach();
    }

    private void CheckPermissionQC(){
        String canQC = sql_pickAccount.getPickerCanQcById(String.valueOf(fileSave.getPickerID())).isCanQC();
        if (canQC.toLowerCase().equals("true") && canQC != null) {
            buttonQC.setVisibility(View.VISIBLE);
        }
    }
}
