package vcn.kybotech.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Cuong.nv on 12/12/2017.
 */

public class PickReturnPart implements Serializable {

    private int loadID;

    private int orderItemPartID;

    private String orderRef;

    private int partID;

    private String partName;

    private int partQuantity;

    private boolean confirmed;

    public PickReturnPart(int loadID, int orderItemPartID, String orderRef, int partID, String partName, int partQuantity, boolean confirmed) {
        this.loadID = loadID;
        this.orderItemPartID = orderItemPartID;
        this.orderRef = orderRef;
        this.partID = partID;
        this.partName = partName;
        this.partQuantity = partQuantity;
        this.confirmed = confirmed;
    }

    public PickReturnPart() {
        super();
    }


    public int getLoadID() {
        return loadID;
    }

    public void setLoadID(int loadID) {
        this.loadID = loadID;
    }

    public int getOrderItemPartID() {
        return orderItemPartID;
    }

    public void setOrderItemPartID(int orderItemPartID) {
        this.orderItemPartID = orderItemPartID;
    }

    public String getOrderRef() {
        return orderRef;
    }

    public void setOrderRef(String orderRef) {
        this.orderRef = orderRef;
    }

    public int getPartID() {
        return partID;
    }

    public void setPartID(int partID) {
        this.partID = partID;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public int getPartQuantity() {
        return partQuantity;
    }

    public void setPartQuantity(int partQuantity) {
        this.partQuantity = partQuantity;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public void setConfirmed(boolean confirmed) {
        this.confirmed = confirmed;
    }

}
