package vcn.kybotech.fragment;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.adapter.SipnnerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.AddStockControl;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.model.PartPallet;
import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.model.WareHouseItem;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class AddPalletFragment extends Fragment {
	public static EditText etTapToScan;
	private ImageView imgTapToScan;
	private int intPallet = 0;
	private Button btnAppPart;
	private ProgressBar proLoad;
	private ImageButton btnTakePhoto;
	private List<SpinnerItem> itemSpinnerPallet;
	private ArrayAdapter<String> adapterpallet;
	private List<PartPallet> listPartPallet;
	private int ADD_LOCATION = 1;
	private int CHECK_QTY = 2;
	private int ADD_PART = 3;
	private int CHECK_REASON = 4;
	private TextView etPallet;
	private ImageView iconComboPallet;
	private Dialog dialog;
	private TextView etPartID;
	private TextView etQtyOnPallet;
	private TextView etJigCode;
	private TextView etPackDim;
	private EditText etReason;
	private Spinner spinWarehose;
	private int intWarehose = 0;
	private List<WareHouseItem> itemWareHouse;
	private List<SpinnerItem> itemSpinnerWareHouse;
	private SipnnerAdapter adapter;
	public static int SCAN_ADD = 1;
	public static int SCAN_REDUCE = 2;
	public static int SCAN_TRANSFER = 3;
	public static int SCAN_CURRENT = 4;
	public static int SCAN_PRIORITY = 5;
	public static int SCAN_ADD_PALLET = 6;

	public AddPalletFragment callHamTao() {
		AddPalletFragment mFragment = new AddPalletFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_add_pallet, container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		HamKhoiTao(rootView);
		BatSuKien();
		return rootView;
	}

	public void HamKhoiTao(View v) {
		// KHAI BAO GIAO DIEN

		etTapToScan = (EditText) v.findViewById(R.id.fragment_add_stock_taptoscan);
		imgTapToScan = (ImageView) v.findViewById(R.id.fragment_add_stock_taptoscan_img);

		proLoad = (ProgressBar) v.findViewById(R.id.fragment_add_stock_progressbar_load);

		btnAppPart = (Button) v.findViewById(R.id.fragment_add_stock_button_add_part);
		btnTakePhoto = (ImageButton) v.findViewById(R.id.fragment_add_stock_button_take_photo_add);

		etPallet = (TextView) v.findViewById(R.id.fragment_add_pallet_edPallet);
		etPartID = (TextView) v.findViewById(R.id.fragment_add_pallet_etPartID);
		etQtyOnPallet = (TextView) v.findViewById(R.id.fragment_add_pallet_etQtyOnPallet);
		etJigCode = (TextView) v.findViewById(R.id.fragment_add_pallet_Parts_LJigCode);
		etPackDim = (TextView) v.findViewById(R.id.fragment_add_pallet_package_dimension);
		etReason = (EditText) v.findViewById(R.id.fragment_add_pallet_reason);
		spinWarehose = (Spinner) v.findViewById(R.id.fragment_add_pallet_spinner_warehouse);

		// ==================
		// SET COMBOBOX WHARE HOUSE
		getWareHouse();
		// ========================
	}

	public void BatSuKien() {

		etTapToScan.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				if (etTapToScan.getText().toString().length() > 0) {
					imgTapToScan.setVisibility(View.VISIBLE);
					if (etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN_PALLET) {
						getPalletDetails();
					}
				} else {
					imgTapToScan.setVisibility(View.GONE);
				}
				if (etTapToScan.getText().toString().length() != Constants.LENGTH_TAP_TO_SCAN_PALLET) {
					etPallet.setText("");
					etPartID.setText("");
					etQtyOnPallet.setText("");
					etJigCode.setText("");
					etPackDim.setText("");
					etReason.setText("");
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});

		imgTapToScan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etTapToScan.setText(null);
				etTapToScan.requestFocus();
			}
		});

		btnAppPart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (etTapToScan.getText().toString().trim().length() == Constants.LENGTH_TAP_TO_SCAN_PALLET) {
					if (etPartID.getText().toString().trim().length() != 5
							|| Integer.parseInt(etQtyOnPallet.getText().toString().trim()) <= 0) {
						dialogAddLocation(CHECK_QTY);
					} else {
						dialogAddLocation(ADD_PART);
					}
				} else {
					etTapToScan.requestFocus();
					OpenKeyBoard(AddPalletFragment.this.getActivity());
				}
			}
		});

		btnTakePhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				onSCanBarCode(SCAN_ADD_PALLET);
			}
		});
		spinWarehose.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				intWarehose = arg2;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});
	}

	public void onSCanBarCode(int types) {
		try {
			Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
			intent.putExtra("SCAN_FORMATS",
					"QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
			startActivityForResult(intent, types);
		} catch (Exception e) {
			Log.e("NOT SCAN", e.toString());
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SCAN_ADD_PALLET && resultCode == RESULT_OK) {
			try {

				String qrcode = (data.getStringExtra("SCAN_RESULT"));
				BarcodeSubString barcodeSubString = new BarcodeSubString();
				qrcode = barcodeSubString.CutBarcode(qrcode, "");
				etTapToScan.setText(qrcode);
			} catch (Exception e) {
				//dialogPartIDFail();
			}
		}
	}


	public void getWareHouse() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				AddStockControl ctrAddStock = new AddStockControl(getActivity());
				objJSON = ctrAddStock.getWareHouse();
				return objJSON;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {
								itemSpinnerWareHouse = new ArrayList<SpinnerItem>();
								itemWareHouse = new ArrayList<WareHouseItem>();
								JSONArray obj = objJSON.getJSONArray("data");
								for (int i = 0; i < obj.length(); i++) {
									JSONObject objItem = obj.getJSONObject(i);
									itemSpinnerWareHouse.add(
											new SpinnerItem(objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
									itemWareHouse
											.add(new WareHouseItem(objItem.getInt(WareHouseItem.COLUMN_WARE_HOUSE_ID),
													objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
								}
								SipnnerAdapter adapter = new SipnnerAdapter(getActivity(), R.layout.custom_spinner,
										itemSpinnerWareHouse);
								spinWarehose.setAdapter(adapter);

								// Mặc định cho hiện warehouse worksop
								for (int i = 0; i < itemWareHouse.size(); i++) {
									if (itemWareHouse.get(i).getWarehouseID() == 19) {
										spinWarehose.setSelection(i);
										break;
									}
								}
								// ======================================
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void getPallet() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				AddStockControl ctrAddStock = new AddStockControl(getActivity());
				objJSON = ctrAddStock.getPallet();
				return objJSON;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						Log.e("hehe", "hehe");

						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {
								itemSpinnerPallet = new ArrayList<SpinnerItem>();
								listPartPallet = new ArrayList<PartPallet>();
								JSONArray obj = objJSON.getJSONArray("data");
								String[] palletcode = new String[obj.length()];
								for (int i = 0; i < obj.length(); i++) {
									JSONObject objItem = obj.getJSONObject(i);
									Log.e("hehe", objItem.getString(PartPallet.COLUMN_PALLET_CODE));
									itemSpinnerPallet
											.add(new SpinnerItem(objItem.getString(PartPallet.COLUMN_PALLET_CODE)));
									Log.e("hihi", objItem.getString(PartPallet.COLUMN_PALLET_CODE));
									listPartPallet.add(new PartPallet(objItem.getInt(PartPallet.COLUMN_PART_PALLET_ID),
											objItem.getInt(PartPallet.COLUMN_PARTID),
											objItem.getInt(PartPallet.COLUMN_QTY_IN_PALLET),
											objItem.getString(PartPallet.COLUMN_PALLET_CODE),
											objItem.getString(PartPallet.COLUMN_BARCODE),
											objItem.getBoolean(PartPallet.COLUMN_ACTIVE)));
									palletcode[i] = objItem.getString(PartPallet.COLUMN_PALLET_CODE);
									Log.e("hehe ad ad", objItem.getString(PartPallet.COLUMN_PALLET_CODE));
								}
								adapterpallet = new ArrayAdapter<String>(getActivity(),
										android.R.layout.simple_dropdown_item_1line, palletcode);
								// etPallet.setThreshold(1);
								// etPallet.setAdapter(adapter);
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void getPalletDetails() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				AddStockControl ctrAddStock = new AddStockControl(getActivity());
				objJSON = ctrAddStock.getPalletDetails(etTapToScan.getText().toString().trim());
				return objJSON;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							etPallet.setText("");
							etPartID.setText("");
							etQtyOnPallet.setText("");
							etJigCode.setText("");
							etPackDim.setText("");
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)
									&& objJSON.getString("data") != null) {
								JSONObject objItem = objJSON.getJSONObject("data");
								etPallet.setText(objItem.getString("PalletCode"));
								etPartID.setText(objItem.getString("PartID"));
								etQtyOnPallet.setText(objItem.getString("QtyInPallet"));
								etJigCode.setText(objItem.getString("PartsLJigCode") == "null" ? ""
										: objItem.getString("PartsLJigCode"));
								etPackDim.setText(objItem.getString("PackageDimension") == "null" ? ""
										: objItem.getString("PackageDimension"));
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_FALSE)) {
									// itemSpinnerLocation.clear();
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void uploadAddPart() {
		btnAppPart.setVisibility(View.GONE);
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				try {
					AddStockControl ctrAddStock = new AddStockControl(getActivity());
					String palletcode = etPallet.getText().toString().trim();
					String partid = etPartID.getText().toString().trim();
					String qtyonpallet = etQtyOnPallet.getText().toString().trim();
					String reason = etReason.getText().toString().trim();
					int warehouseid = itemWareHouse.get(intWarehose).getWarehouseID();	
					objJSON = ctrAddStock.uploadAddPallet(warehouseid, palletcode, partid, qtyonpallet, reason);
					return objJSON;
				} catch (Exception e) {
					e.printStackTrace();
					btnAppPart.setVisibility(View.VISIBLE);
					return null;
				}
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {
								String mess = objJSON.getString("message");
								Toast.makeText(getActivity(), mess, Toast.LENGTH_LONG).show();
								btnAppPart.setVisibility(View.VISIBLE);
								etPallet.setText("");
								etPartID.setText("");
								etQtyOnPallet.setText("");
								etJigCode.setText("");
								etPackDim.setText("");
								etReason.setText("");
								etTapToScan.setText(null);
								etTapToScan.requestFocus();
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(), objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_LONG).show();
									etTapToScan.requestFocus();
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void dialogAddLocation(final int type) {
		dialog = new Dialog(getActivity());
		dialog.setContentView(R.layout.custom_dialog);
		TextView tvnoidung = (TextView) dialog.findViewById(R.id.custom_dialog_textview_noidung);
		final EditText etlocation = (EditText) dialog.findViewById(R.id.custom_dialog_edittext_location);
		final ImageView imglocation = (ImageView) dialog.findViewById(R.id.custom_dialog_edittext_location_img);
		Button btncancel = (Button) dialog.findViewById(R.id.custom_dialog_button_cancel);
		Button btnok = (Button) dialog.findViewById(R.id.custom_dialog_button_ok);

		if (type == ADD_LOCATION) {
			dialog.setTitle(Constants.NEW_LOCATION);
			tvnoidung.setText(Constants.INPUT_LOCATION_TO_ADD_STOCK);
			etlocation.setVisibility(View.VISIBLE);
		}
		if (type == CHECK_QTY) {
			// dialog.setTitle(Constants.NOTIFICATION);
			tvnoidung.setText("PartID or Qty On Pallet is not valid, please check again !");
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		if (type == CHECK_REASON) {
			dialog.setTitle(Constants.NOTIFICATION);
			tvnoidung.setText(Constants.QUANTITY_IS_NOT_VALUES);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		if (type == ADD_PART) {
			tvnoidung.setText("Are you sure you want to add a pallet of partID " + etPartID.getText().toString()
					+ " (Qty in pallet: " + etQtyOnPallet.getText().toString() + ") to the system?");
			etlocation.setVisibility(View.GONE);
			btncancel.setText("No");
		}

		btncancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});

		btnok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (type == ADD_LOCATION) {
					if (etlocation.getText().toString().length() > 0) {
						// itemSpinnerLocation.add(new
						// SpinnerItem(etlocation.getText().toString().trim()));
						// adapter.notifyDataSetChanged();
						//
						// spinLocation.setSelection(itemSpinnerLocation.size()
						// - 1);
					}
				}
				if (type == CHECK_QTY) {
					etTapToScan.requestFocus();
				}
				if (type == CHECK_REASON) {
					// etReason.requestFocus();
				}
				if (type == ADD_PART) {
					 uploadAddPart();
//					Toast.makeText(getActivity(), "hehe", Toast.LENGTH_SHORT).show();
				}

				dialog.dismiss();
			}
		});

		dialog.show();
	}

	public void DialogDisconnectToServer() {
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new AlertDialog.Builder(AddPalletFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {

				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}
}
