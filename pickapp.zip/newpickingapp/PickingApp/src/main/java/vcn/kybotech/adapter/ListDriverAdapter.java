package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.Driver;
import vcn.kybotech.pickingapp.R;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListDriverAdapter extends ArrayAdapter<Driver>{
	private Context context;
	private int layoutId;
	private List<Driver> listDriver;
	
	public ListDriverAdapter(Context context, int layoutId, List<Driver> listDriver) {
		super(context, layoutId, listDriver);
		this.context = context;
		this.layoutId = layoutId;
		this.listDriver = listDriver;
	}

	public static class Holder{
		TextView tvDriverName;
		ImageView imgIsChecked;
	}
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		View view = convertView;
		Holder holder;
		if(view == null){
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			view = inflater.inflate(layoutId, parent, false);
			holder = new Holder();
			
			holder.tvDriverName = (TextView) view.findViewById(R.id.item_listview_dialog_despatched_tvDriver);
			holder.imgIsChecked = (ImageView) view.findViewById(R.id.item_listview_dialog_despatched_imgCheck);
			view.setTag(holder);
		}else{
			holder = (Holder) view.getTag();
		}
		
		holder.tvDriverName.setText(listDriver.get(position).getDriverName());
		if(listDriver.get(position).isChecked()){
			holder.imgIsChecked.setBackgroundResource(R.drawable.ic_checked_true);
		}else{
			holder.imgIsChecked.setBackgroundResource(R.drawable.ic_checked_false);
		}
		return view;
	}
}
