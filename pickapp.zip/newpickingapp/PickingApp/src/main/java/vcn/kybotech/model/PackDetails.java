package vcn.kybotech.model;

public class PackDetails {
	private int PartId;
	private int Length;
	private int NumOfPieces;
	private String DateCreate;
	private double VolumeItem;
	public PackDetails() {
		super();
	}
	public PackDetails(int partId, int length, int numOfPieces,
			String dateCreate, double volumeItem) {
		super();
		PartId = partId;
		Length = length;
		NumOfPieces = numOfPieces;
		DateCreate = dateCreate;
		VolumeItem = volumeItem;
	}
	public int getPartId() {
		return PartId;
	}
	public void setPartId(int partId) {
		PartId = partId;
	}
	public int getLength() {
		return Length;
	}
	public void setLength(int length) {
		Length = length;
	}
	public int getNumOfPieces() {
		return NumOfPieces;
	}
	public void setNumOfPieces(int numOfPieces) {
		NumOfPieces = numOfPieces;
	}
	public String getDateCreate() {
		return DateCreate;
	}
	public void setDateCreate(String dateCreate) {
		DateCreate = dateCreate;
	}
	public double getVolumeItem() {
		return VolumeItem;
	}
	public void setVolumeItem(double volumeItem) {
		VolumeItem = volumeItem;
	}
}

