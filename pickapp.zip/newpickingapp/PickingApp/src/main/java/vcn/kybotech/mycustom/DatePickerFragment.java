package vcn.kybotech.mycustom;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import vcn.kybotech.fragment.UnpackFragment;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.TextView;

@SuppressWarnings("unused")
@SuppressLint("ValidFragment")
public class DatePickerFragment extends DialogFragment implements
        DatePickerDialog.OnDateSetListener {
    TextView tvDateUse;

    public DatePickerFragment(TextView tvDateUse) {
        DatePickerFragment.this.tvDateUse = tvDateUse;
    }

    public DatePickerFragment() {
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        DatePickerFragment.this.tvDateUse.setText(day + "/" + (month + 1) + "/" + year);
        UnpackFragment.dateused = (year + "-" + (month + 1) + "-" + day);
    }
}