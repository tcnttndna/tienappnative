package vcn.kybotech.fragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.adapter.ListPartLocationAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.PartLocation;
import vcn.kybotech.pickingapp.R;

public class SLSSearchFragment extends android.app.Fragment {

	private Button btnSearch;
	private ListView lvData;
	private List<PartLocation> listData;
	private JSONParser jsonParser;
	private EditText etPartid;
	private EditText etLocation;
	private ProgressBar pbLoading;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_sls_search, container, false);

		btnSearch = (Button) rootView.findViewById(R.id.fragment_sls_search_btnSearch);
		lvData = (ListView) rootView.findViewById(R.id.fragment_sls_search_lvData);
		etPartid = (EditText) rootView.findViewById(R.id.fragment_sls_search_etpartid);
		etLocation = (EditText) rootView.findViewById(R.id.fragment_sls_search_etlocation);
		pbLoading = (ProgressBar) rootView.findViewById(R.id.fragment_sls_search_pbLoading);
		
		listData = new ArrayList<PartLocation>();

		jsonParser = new JSONParser();

		return rootView;
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		btnSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Seach();				
			}
		});
	}

	private void Seach(){
		listData = new ArrayList<PartLocation>();
		final String partid = etPartid.getText().toString();
		final String location = etLocation.getText().toString();
		
		new AsyncTask<String, Void, JSONObject>() {
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				pbLoading.setVisibility(View.VISIBLE);
				lvData.setVisibility(View.INVISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... arg0) {
				List<NameValuePair> params = new ArrayList<NameValuePair>();
				params.add(new BasicNameValuePair(Constants.type, "slsgetpartlocation"));
				params.add(new BasicNameValuePair("partid", partid));
				params.add(new BasicNameValuePair("location", location));
				JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
				return objJSON;
			}

			protected void onPostExecute(JSONObject jsonObject) {
				try {
					if (jsonObject == null) {
						Toast.makeText(getActivity(), "Can not get data, please try again !",
								Toast.LENGTH_SHORT).show();
					} else {
						if (jsonObject.getBoolean("success")) {
							JSONArray jsonArray = jsonObject.getJSONArray("data");

							/* Hien thi khi click vao */
							listData.clear();
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject object = jsonArray.getJSONObject(i);
								listData.add(new PartLocation(object.getInt("Id"), object.getInt("PartID"),
										object.getString("LocationName")));
							}

							ListPartLocationAdapter adapter = new ListPartLocationAdapter(getActivity(),
									R.layout.item_sls, listData);
							lvData.setAdapter(adapter);
							adapter.notifyDataSetChanged();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					pbLoading.setVisibility(View.GONE);
					lvData.setVisibility(View.VISIBLE);
					Toast.makeText(getActivity(), "Error: " + e.getMessage(),
							Toast.LENGTH_SHORT).show();
				}
				pbLoading.setVisibility(View.GONE);
				lvData.setVisibility(View.VISIBLE);
			};
		}.execute();
	}
	
	public boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		return netInfo != null && netInfo.isConnectedOrConnecting();
	}

}
