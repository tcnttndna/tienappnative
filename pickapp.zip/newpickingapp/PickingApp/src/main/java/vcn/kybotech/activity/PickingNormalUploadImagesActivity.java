package vcn.kybotech.activity;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.adapter.PickImageGridViewAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.fragment.PickingNormalPickFragment;
import vcn.kybotech.model.ImageItem;
import vcn.kybotech.mycustom.LoggingExceptionHandler;
import vcn.kybotech.mycustom.ScalingUtilities;
import vcn.kybotech.mycustom.ScalingUtilities.ScalingLogic;
import vcn.kybotech.pickingapp.R;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources.NotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.crash.FirebaseCrash;

public class PickingNormalUploadImagesActivity extends ActionBarActivity {

    RequestQueue requestQueue;// = Volley.newRequestQueue(PickingNormalUploadImagesActivity.this);
    private final static String Tag = "cancelAll";
    private Button btnTakePhoto;
    private Button btnUpload;
    private GridView grdImagesUpload;
    public PickImageGridViewAdapter adapter;
    public ArrayList<ImageItem> data;
    private Bundle bundleData;
    private TextView orderRef;
    private TextView countImageUploaded;
    private static int countSelected;
    private static String mCurrentPhotoPath;
    ProgressDialog dialogUpload;
    private String imagetype;
    ArrayList<String> listImgUri = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new LoggingExceptionHandler(PickingNormalUploadImagesActivity.this);
        requestQueue = Volley.newRequestQueue(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        if (isOnline()) {
            getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
        } else {
            getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
        getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setContentView(R.layout.activity_picking_upload_images);
        btnTakePhoto = (Button) findViewById(R.id.btnTakePhoto);
        btnUpload = (Button) findViewById(R.id.btnUpload);
        grdImagesUpload = (GridView) findViewById(R.id.grdListImagesUpload);
        countImageUploaded = (TextView) findViewById(R.id.countImageUploaded);
        orderRef = (TextView) findViewById(R.id.orderRef_in_form_upload_images);

        dialogUpload = new ProgressDialog(PickingNormalUploadImagesActivity.this);
        dialogUpload.setTitle(getString(R.string.fragment_picking_upload_images));
        dialogUpload.setMessage(getString(R.string.fragment_login_waiting));

        bundleData = getIntent().getBundleExtra(Constants.key_bundle_upload_image);
        String orderref = bundleData.getString("key_orderref");
        imagetype = bundleData.getString("key_imagetype");
        orderRef.setText(orderref);

        if (imagetype.equals(Constants.image_ScanTimberPack)) {
            countImageUploaded.setText("Please select 2 photos best!");
        } else {
            countImageUploaded.setText(PickingNormalPickFragment.countImageUpLoaded + " image(s) uploaded");
        }

        btnUpload.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                try {
                    if (data != null) {
                        int cImageSelected = 0;
                        /*doan nay chi la check xem co image nao chon chua thoi*/
                        for (ImageItem imageItem : data) {
                            if (imageItem.isChecked()) {
                                ++cImageSelected;
                                //                            break;
                            }
                        }
                        if (imagetype.equals(Constants.image_ReturnLoad)) {
                            if (cImageSelected >= 3) {
                                onUploadImages();
                            } else {
                                Builder dialog = new Builder(PickingNormalUploadImagesActivity.this);
                                dialog.setTitle("Message")
                                        .setMessage("Please select at least 3 image upload to server.")
                                        .setNegativeButton("Cancel", null)
                                        .show();
                            }
                        } else if (imagetype.equals(Constants.image_ScanTimberPack)) {
                            if (cImageSelected == 2) {
                                onUploadImages();
                            } else {
                                Builder dialog = new Builder(PickingNormalUploadImagesActivity.this);
                                dialog.setTitle("Message")
                                        .setMessage("Please select 2 photos best!.")
                                        .setNegativeButton("Cancel", null)
                                        .show();
                            }
                        } else {
                            if (cImageSelected > 0) {
                                onUploadImages();
                            } else {
                                Builder dialog = new Builder(PickingNormalUploadImagesActivity.this);
                                dialog.setTitle("Message")
                                        .setMessage("Please select image upload to server.")
                                        .setNegativeButton("Cancel", null)
                                        .show();
                            }
                        }

                    }
                } catch (Exception e) {
                    FirebaseCrash.report(e);
                }
            }
        });

        btnTakePhoto.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                onTakePhoto();
            }
        });

        data = new ArrayList<ImageItem>();
        adapter = new PickImageGridViewAdapter(PickingNormalUploadImagesActivity.this, data);
        grdImagesUpload.setAdapter(adapter);

        Log.e("hehe", "3333");

        showImages();
        onTakePhoto();

    }

    private void showImages() {
        new AsyncTask<String, Void, Void>() {

            @Override
            protected Void doInBackground(String... params) {
                try {
                    File targetDirector = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_PICK);
                    File[] files = targetDirector.listFiles();
                    data.clear();
                    if (files != null) {
                        if (imagetype.equals(Constants.image_ScanTimberPack)) {
                            for (File file : files) {
                                ImageItem imageItem = new ImageItem(file.getAbsolutePath(), false);
                                data.add(0, imageItem);
                            }
                        } else {
                            for (File file : files) {
                                ImageItem imageItem = new ImageItem(file.getAbsolutePath(), true);
                                data.add(0, imageItem);
                            }
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(Void result) {
                adapter.notifyDataSetChanged();
            }
        }.execute();

    }

    protected void onUploadImages() {
//		final ProgressDialog progressDialog = new ProgressDialog(PickingNormalUploadImagesActivity.this);
//		progressDialog.setTitle(getString(R.string.fragment_picking_upload_images));
//		progressDialog.setMessage(getString(R.string.fragment_login_waiting));
//        progressDialog.show();
        PickingNormalUploadImagesActivity.this.dialogUpload.setCancelable(false);
        PickingNormalUploadImagesActivity.this.dialogUpload.show();

        countSelected = 0;

        for (final ImageItem image : data) {
            if (image.isChecked()) {
                ++countSelected;
            }
        }
        /*Moi lan up anh chi cho toi da 10 anh*/
//		if (countSelected>10) {
//			countSelected =10;
//		}

        if (imagetype.equals(Constants.image_ScanTimberPack)) {
            try {
                for (ImageItem image : data) {
                    if (image.isChecked()) {
                        listImgUri.add(image.getPathImage());
                    }
                }

//                PickingNormalUploadImagesActivity.this.dialogUpload.dismiss();
                PickingNormalUploadImagesActivity.this.dialogUpload.dismiss();
                Intent data = new Intent();
                data.putStringArrayListExtra("ListImageUriBase64", listImgUri);
                PickingNormalUploadImagesActivity.this.setResult(Constants.RESULT_CONFIRMSTP_UPLOAD_IMAGE, data);
                PickingNormalUploadImagesActivity.this.finish();

            } catch (Exception e) {
                Toast.makeText(PickingNormalUploadImagesActivity.this, "Upload fail,Try again.", Toast.LENGTH_SHORT).show();
                PickingNormalUploadImagesActivity.this.dialogUpload.dismiss();
                FirebaseCrash.report(e);
            }
        } else {
            for (final ImageItem image : data) {
                if (image.isChecked()) {

				/*Moi lan up anh chi cho toi da 10 anh*/
//				++ maxQTy;
//				if (maxQTy>10) 	break;

                    try {
                        byte byteAnh[] = null;
                        String path = image.getPathImage();
                        FileInputStream inputStream = new FileInputStream(path);

                        BufferedInputStream buffInputStream = new BufferedInputStream(inputStream);
                        byteAnh = new byte[buffInputStream.available()];
                        buffInputStream.read(byteAnh);
                        buffInputStream.close();
                        String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
                        if (imagetype.equals(Constants.image_ReturnLoad)) {

                            String loadid = bundleData.getString("key_loadid");
                            String loadcode = bundleData.getString("key_loadcode");
                            String pickerid = bundleData.getString("key_pickerid");
                            String pickername = bundleData.getString("key_pickername");
                            image.setImageType(imagetype);
                            image.setLoadid(loadid);
                            image.setLoadcode(loadcode);
                            image.setPickerid(pickerid);
                            image.setPickername(pickername);
                            image.setImageuri(encodedString);

                        } else {

                            String loadid = bundleData.getString("key_loadid");
                            String loadcode = bundleData.getString("key_loadcode");
                            String pickerid = bundleData.getString("key_pickerid");
                            String pickername = bundleData.getString("key_pickername");
                            String orderid = bundleData.getString("key_orderid");
                            String orderref = bundleData.getString("key_orderref");
                            String orderitemid = bundleData.getString("key_orderitemid");
                            image.setImageType(imagetype);
                            image.setLoadid(loadid);
                            image.setLoadcode(loadcode);
                            image.setPickerid(pickerid);
                            image.setPickername(pickername);
                            image.setImageuri(encodedString);
                            image.setOrderid(orderid);
                            image.setOrderref(orderref);
                            image.setOrderitemid(orderitemid);
                        }

                        Response.Listener<String> listener = new Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {

                                --countSelected;
                                if ((PickingNormalUploadImagesActivity.this.dialogUpload != null) && (countSelected == 0)) {
                                    PickingNormalUploadImagesActivity.this.dialogUpload.dismiss();
                                    adapter.notifyDataSetChanged();
                                }

                                try {
                                    JSONObject jsonObject = new JSONObject(response.toString());
                                    if (jsonObject.getBoolean("success")) {

                                        Log.e("Upload Images success", "");
                                        File f = new File(image.getPathImage());
                                        f.delete();
                                        data.remove(image);
                                        adapter.notifyDataSetChanged();

                                        PickingNormalPickFragment.countImageUpLoaded += 1;
                                        if (PickingNormalPickFragment.countImageUpLoaded > 1) {
                                            countImageUploaded.setText(PickingNormalPickFragment.countImageUpLoaded + " images uploaded");
                                        } else if (PickingNormalPickFragment.countImageUpLoaded > 0) {
                                            countImageUploaded.setText(PickingNormalPickFragment.countImageUpLoaded + " image uploaded");
                                        }

									/* CHECK UPLOAD ALL DISSMIS DIALOG */
                                        boolean checkedAll = true;
                                        for (ImageItem image : data) {
                                            if (image.isChecked()) {
                                                checkedAll = false;
                                            }
                                        }
                                        if (checkedAll && dialogUpload != null) {
                                            PickingNormalUploadImagesActivity.this.dialogUpload.dismiss();
                                            new CountDownTimer(1000, 10) {

                                                public void onTick(long millisUntilFinished) {
                                                }

                                                public void onFinish() {
                                                    if (imagetype.equals(Constants.image_ReturnLoad)) {
                                                        PickingNormalUploadImagesActivity.this.setResult(Constants.RESULT_CONFIRMRETURNLOAD_UPLOAD_IMAGE);
                                                    } else {
                                                        PickingNormalUploadImagesActivity.this.setResult(Constants.RESULT_NORMAL_UPLOAD_IMAGE);
                                                    }
                                                    PickingNormalUploadImagesActivity.this.finish();
                                                }
                                            }.start();

                                        }
                                    } else {
                                        if (adapter != null) {
                                            adapter.notifyDataSetChanged();
                                        }
                                        Toast.makeText(PickingNormalUploadImagesActivity.this, "upload fail, server is problem!", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    DialogServerProblem();
                                    if (adapter != null) {
                                        adapter.notifyDataSetChanged();
                                    }
                                } catch (Exception e) {
                                    if (adapter != null) {
                                        adapter.notifyDataSetChanged();
                                    }
                                    e.printStackTrace();
                                }


                            }

                        };

                        Response.ErrorListener errorListener = new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError volleyError) {
                                try {
                                    --countSelected;
                                    if ((PickingNormalUploadImagesActivity.this.dialogUpload != null) && (countSelected == 0)) {
                                        PickingNormalUploadImagesActivity.this.dialogUpload.dismiss();
                                        if (adapter != null) {
                                            adapter.notifyDataSetChanged();
                                        }
                                    }

                                    Toast.makeText(PickingNormalUploadImagesActivity.this, "Connection to your server disconnected!", Toast.LENGTH_SHORT).show();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        };

                        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener) {
                            @Override
                            protected Map<String, String> getParams() {

                                Map<String, String> params = onCreateParams();
                                return params;
                            }

                            private Map<String, String> onCreateParams() {
                                Map<String, String> params = new HashMap<String, String>();
                                params.put("type", "uploadimagenew");

                                if (image.getImageType().equals(Constants.image_ReturnLoad)) {
                                    params.put("imagetype", image.getImageType());
                                    params.put("orderid", "-1");
                                    params.put("orderref", "Empty");
                                    params.put("orderitemid", "-1");
                                    params.put("loadid", image.getLoadid());
                                    params.put("loadcode", image.getLoadcode());
                                    params.put("pickerid", image.getPickerid());
                                    params.put("pickername", image.getPickername());
                                    params.put("imageuri", image.getImageuri());
                                } else {
                                    params.put("imagetype", image.getImageType());
                                    params.put("orderid", image.getOrderid() + "");
                                    params.put("orderref", image.getOrderref() + "");
                                    params.put("orderitemid", image.getOrderitemid() + "");
                                    params.put("loadid", image.getLoadid());
                                    params.put("loadcode", image.getLoadcode());
                                    params.put("pickerid", image.getPickerid());
                                    params.put("pickername", image.getPickername());
                                    params.put("imageuri", image.getImageuri());
                                }

                                return params;
                            }
                        };

//					RequestQueue requestQueue = Volley.newRequestQueue(PickingNormalUploadImagesActivity.this);
                        postRequest.setTag(Tag);
                        postRequest.setShouldCache(false);
                        requestQueue.add(postRequest);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

//		int maxQTy = 0;

    }

    public void DialogServerProblem() {
        Log.e("LoginFramgment", "server is problem");
        if (PickingNormalUploadImagesActivity.this == null) {
            return;
        }
        Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Message");
        dialog.setMessage("Server is problem");
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

    public void onTakePhoto() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.printStackTrace();
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(photoFile));
                startActivityForResult(takePictureIntent, Constants.REQUEST_TAKE_PHOTO_FROM_PICKING_UPLOAD_IMAGES_FRAGMENT);
            }
        }

    }

    public File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "ConfirmOrderItem_" + timeStamp;
//		File storageDir = Environment.getExternalStoragePublicDirectory("APPPICKING");
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_PICK);
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        File image = new File(storageDir, imageFileName + ".png");

        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dt) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, dt);
        if (requestCode == Constants.REQUEST_TAKE_PHOTO_FROM_PICKING_UPLOAD_IMAGES_FRAGMENT && resultCode == RESULT_OK) {
            ++countSelected;
            data.add(0, new ImageItem(mCurrentPhotoPath, true));
            adapter.notifyDataSetChanged();
            if (imagetype.equals(Constants.image_ScanTimberPack)) {
                compressImageResize(mCurrentPhotoPath);
            } else {
                compressImage(mCurrentPhotoPath, 800, 1400);
            }
            onTakePhoto();
        }
    }

    private boolean compressImage(String path, int width, int height) {
        boolean isCompress = false;
        Bitmap scaledBitmap = null;
        try {
            // Part 1: Decode image
            Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, width,
                    height, ScalingLogic.FIT);

            // if (!(unscaledBitmap.getWidth() <= width &&
            // unscaledBitmap.getHeight() <= height)) {
            // Part 2: Scale image
            scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap,
                    width, height, ScalingLogic.FIT);
            // } else {
            // unscaledBitmap.recycle();
            // return isCompress;
            // }

            FileOutputStream fos = null;
            try {
                File fichero = new File(mCurrentPhotoPath);
                if (fichero.canWrite()) {
                    fichero.createNewFile();
                    fos = new FileOutputStream(fichero);
                    isCompress = scaledBitmap.compress(
                            Bitmap.CompressFormat.JPEG, 70, fos);
                    fos.flush();
                    fos.close();
                }
            } catch (FileNotFoundException e) {

                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            scaledBitmap.recycle();
        } catch (Throwable e) {
        }
        return isCompress;
    }

    private boolean compressImageResize(String path) {
        boolean isCompress = false;
        Bitmap scaledBitmap = null;
        try {
            // Part 1: Decode image
            Bitmap bitmap = BitmapFactory.decodeFile(path);
            int w = (int) (bitmap.getWidth() * 0.50);
            int h = (int) (bitmap.getHeight() * 0.50);
            scaledBitmap = (Bitmap.createScaledBitmap(bitmap, w, h, false));
            FileOutputStream fos = null;
            try {
                File fichero = new File(mCurrentPhotoPath);
                if (fichero.canWrite()) {
                    fichero.createNewFile();
                    fos = new FileOutputStream(fichero);
                    isCompress = scaledBitmap.compress(
                            Bitmap.CompressFormat.JPEG, 70, fos);
                    fos.flush();
                    fos.close();
                }
            } catch (FileNotFoundException e) {

                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            scaledBitmap.recycle();
        } catch (Throwable e) {
        }
        return isCompress;
    }

    @Override
    protected void onResume() {
        super.onResume();
        pingConnectionSerVer();
        mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
    }

    @Override
    protected void onPause() {

        mHandler.removeCallbacks(setTitleColor);

        super.onPause();
    }

    @Override
    protected void onDestroy() {
        requestQueue.cancelAll(Tag);
        super.onDestroy();
    }

    private Handler mHandler = new Handler();

    private Runnable setTitleColor = new Runnable() {
        @Override
        public void run() {
            try {
                pingConnectionSerVer();
                mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    private void pingConnectionSerVer() {

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    Log.e("pingConnectionSerVer", jsonObject.toString());
//					if (jsonObject.getBoolean("success")) {
                    getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
//					}
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError arg0) {
                try {
                    getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
                } catch (NotFoundException e) {
                }
            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "checkversion");
                params.put("softType", "newpickingapp");
                params.put("curVersion", "1");
                return params;
            }
        };
        try {
            postRequest.setTag(Tag);
            postRequest.setShouldCache(false);
            requestQueue.add(postRequest);
        } catch (Exception e) {
        }
    }


    protected void deleteImages() {
//		String ExternalStorageDirectoryPath = Environment.getExternalStorageDirectory().getAbsolutePath();
//		String targetPath = ExternalStorageDirectoryPath + "/APPPICKING/";

        File targetDirector = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_PICK);
//		targetDirector.delete();
        File[] files = targetDirector.listFiles();
        if (files != null) {

            for (File file : files) {
                file.delete();
            }
        }
    }

    private void onQuestionDeleImages() {
        AlertDialog.Builder dialog = new Builder(this);
        dialog.setTitle("Delete images")
                .setMessage("Are you sure to delete all images?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        deleteImages();
                        showImages();

                    }
                })
                .setNegativeButton("No", null)
                .show();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_pick_upload_image, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case R.id.menu_pick_delete_images:
                onQuestionDeleImages();

                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
