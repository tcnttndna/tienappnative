package vcn.kybotech.pickingapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources.NotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.crash.FirebaseCrash;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import vcn.kybotech.activity.PickingMainLoadFragment;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.RequestFirebase;
import vcn.kybotech.controller.RequestFirebaseListener;
import vcn.kybotech.controller.UpdateVersionControl;
import vcn.kybotech.fragment.LoginFragment;
import vcn.kybotech.fragment.MainTaskFragment;
import vcn.kybotech.fragment.PickingConfirmLoadFragment;
import vcn.kybotech.fragment.PickingLoadingConfirmLoadFragment;
import vcn.kybotech.fragment.PickingLoadingFragment;
import vcn.kybotech.fragment.PickingNormalPickFragment;
import vcn.kybotech.fragment.PickingQAConfirmLoadFragment;
import vcn.kybotech.fragment.PickingQAFragment;
import vcn.kybotech.fragment.PickingQCFragment;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.LogData;
import vcn.kybotech.mycustom.LoggingExceptionHandler;
import vcn.kybotech.services.MyAlarmReceiver;
import vcn.kybotech.services.ServiceUpload;
import vcn.kybotech.sqlite.sql_LogData;
import vcn.kybotech.sqlite.sql_PickLoads;


public class MainActivity extends AppCompatActivity implements CommunicatingFragments,RequestFirebaseListener{
    private static final int PERMISSION_CONSTANT = 1;
    public static ProgressDialog mProgressDialog;
    private RequestQueue requestQueue;//= Volley.newRequestQueue(MainActivity.this);
    //    Intent serviceLogout;
//    private int min = 0;
//    private int sec = 59;
//    private Handler mDemnguocHandler;
//    private DemNguocRunnable mDemnguocRun;
    private DownloadApkTask downloadApkTask;

    // Firebase
    private DatabaseReference mDatabase;
    private String pid,did;
    private boolean canRequest;
    public static boolean isLoggedOut = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new LoggingExceptionHandler(this);
        setContentView(R.layout.activity_main);
        scheduleAlarm();
        /** ============= */
        HamKhoiTao();
        requestPermission();
        onCreateComponent();
//        serviceLogout = new Intent(this, ServiceLogout.class);
//        mDemnguocHandler = new Handler();
//        mDemnguocRun = new DemNguocRunnable();
//        showDemNguoc();
        /** ALARM SERVICE */
//        stopService();

    }

    public void HamKhoiTao() {
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Update New Version");
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        mProgressDialog.setCancelable(false);

        mDatabase = FirebaseDatabase.getInstance().getReference().child(Constants.firebase_key_main);

        FileSave file = new FileSave(MainActivity.this, Constants.GET);
        if (!file.getDeviceID().equals("") && file.getPickerID() != -1) {
            pid = String.valueOf(file.getPickerID());
            did = file.getDeviceID();
        }

    }

    private void onCreateComponent() {
        try {
            requestQueue = Volley.newRequestQueue(this);
        /* Create ActionBar */
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            if (isOnline()) {
                getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
//			pingConnectionSerVer();
            } else {
                getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
            }
            getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

		/* File luu cac thong tin */
            FileSave file = new FileSave(MainActivity.this, Constants.GET);
        /* Neu ghi nho dang nhap roi thi chuyen sang giao dien MainTask
         * Neu chua thi hien thi giao dien Login*/
            if (file.getRememberLogin()) {
//            startService();
            /* Create MainTaskFragment */
                // TODO thay getFragmentManager
                getFragmentManager().beginTransaction()
                        .add(R.id.container, new MainTaskFragment(), "MainTaskFragment")
                        .commit();
                canRequest = true;
//            startService();
                //LUU LOG DATA
                SaveLogLogin();
                Log.e("tag MainActivity", "add(R.id.container, new MainTaskFragment(),\"MainTaskFragment\")");
            } else {
                /* Create LoginFragment */
                getFragmentManager().beginTransaction()
                        .add(R.id.container, new LoginFragment(), "LoginFragment")
                        .commit();
                canRequest = false;
                Log.e("tag MainActivity", "add(R.id.container, new LoginFragment(),\"LoginFragment\")");
            }
        } catch (Exception ex) {
            FirebaseCrash.report(ex);
        }

        Log.e("MainActivity create","pid: " + pid + "\n" +
                                            "did: " + did + "\n" +
                                            "pidLogin: " + LoginFragment.pickerIdLogin + "\n" +
                                            "didLogin: " + LoginFragment.deviceIdLogin);




    }

    @SuppressLint("NewApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        int version_in_manifest = 0;
        try {
            version_in_manifest = getPackageManager()
                    .getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Constants.LINK_DONE.equals(Constants.LINK_COMPARE_VIEW_VERSION)) {
            menu.findItem(R.id.test_menu).setTitle(Constants.VERSION_TYPE + String.valueOf(version_in_manifest));
        } else {
            menu.findItem(R.id.test_menu).setTitle(R.string.Test);
//			menu.add(R.string.Test);
        }
        FileSave file = new FileSave(MainActivity.this, Constants.GET);
        if (file.getIslogin()) {
            menu.findItem(R.id.menu_main_logout).setVisible(true);
        } else {
            menu.findItem(R.id.menu_main_logout).setVisible(false);
        }
        invalidateOptionsMenu();
        return true;
    }

    @SuppressLint("NewApi")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.menu_main_logout:

                dialog();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case Constants.ORDER_PICK_INTENT_MAIN:
                case Constants.STOCK_INTENT_MAIN:
                case Constants.ADJUST_INTENT_MAIN:
                case Constants.VAN_PHOTO_INTENT_MAIN:
                case Constants.RETURN_LOAD_INTENT_MAIN:
                    logoutControl();
                    break;
                default:
                    break;
            }
        }
        /**
         *  Thá»­ Ä‘á»ƒ MainACtivity nháº­n thay PickingMainLoad
         */
        /* Scan part in NormalPick */
        if (requestCode == Constants.SCAN_ACCEPT_LOAD_PICKING && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
            try {
                PickingNormalPickFragment.istyped = false;
                PickingNormalPickFragment.IsManuallyScan = false;
                PickingNormalPickFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
            } catch (Exception e) {
                PickingNormalPickFragment.textScanBarcode.setText("");
                e.printStackTrace();
                AlertDialog.Builder dialog = new Builder(this);
                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
                        .show();
            }

        } else if (requestCode == Constants.SCAN_PART_BY_QA && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
            try {
                PickingQAFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
                PickingQAFragment.IsManuallyScan = false;
            } catch (Exception e) {
                PickingQAFragment.textScanBarcode.setText("");
                e.printStackTrace();
                AlertDialog.Builder dialog = new Builder(this);
                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
                        .show();
            }
        } else if (requestCode == Constants.SCAN_PART_BY_QC && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
//            Toast.makeText(this, "23534", Toast.LENGTH_SHORT).show();
            try {
                PickingQCFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
                PickingQCFragment.IsManuallyScan = false;
            } catch (Exception e) {
                PickingQCFragment.textScanBarcode.setText("");
                e.printStackTrace();
                AlertDialog.Builder dialog = new Builder(this);
                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
                        .show();
            }
        } else if (requestCode == Constants.SCAN_ACCEPT_LOAD_LOADING && resultCode == RESULT_OK) {
//            Log.e("scan qc: ",data.getStringExtra("SCAN_RESULT"));
            try {
                PickingLoadingFragment.textScanBarcode.setText(data.getStringExtra("SCAN_RESULT"));
                PickingLoadingFragment.IsManuallyScan = false;
            } catch (Exception e) {
                PickingLoadingFragment.textScanBarcode.setText("");
                e.printStackTrace();
                AlertDialog.Builder dialog = new Builder(this);
                dialog.setTitle("Message").setMessage("Enter format number invalid!").setPositiveButton("OK", null)
                        .show();
            }
        }

        if (resultCode == Constants.RESULT_SERVICE_LOGOUT) {
            switch (requestCode) {
                case Constants.ORDER_PICK_INTENT_MAIN:
                case Constants.STOCK_INTENT_MAIN:
                case Constants.ADJUST_INTENT_MAIN:
                case Constants.VAN_PHOTO_INTENT_MAIN:
                case Constants.RETURN_LOAD_INTENT_MAIN:
                    logoutControl();
                    break;
                default:
                    break;
            }
        }
    }

    public void dialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Message");
        dialog.setMessage(Constants.LOGOUT);
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                logoutControl();

                dialog.dismiss();
            }
        });
        dialog.setNegativeButton("No", null);
        dialog.show();
    }

    public void logoutControl() {
        /* Create LoginFragment */

        getFragmentManager().beginTransaction()
                .replace(R.id.container, new LoginFragment(), "LoginFragment")
                .commit();
        FileSave file = new FileSave(MainActivity.this, Constants.PUT);
        file.putIsRememberLogin(false);

//        stopService();
        Log.e("tag MainActivity", "replace(R.id.container, new LoginFragment(),\"LoginFragment\")");
        Log.e("tag MainActivity", "key_boolean_remember_login = false");

        invalidateOptionsMenu();

        /**
         * ThÃƒÂªm vÃƒÂ o Ã„â€˜Ã¡Â»Æ’ lÃƒÂºc ra login thÃƒÂ¬ k request firebase nÃ¡Â»Â¯a, trÃƒÂ¡nh dÃƒÂ­nh null did_static
         */
        file.putPickerID(-1);
        isLoggedOut = true;

        if (RequestFirebase.did_static == null){
//            Toast.makeText(MainActivity.this,"You have been logged in another device",
//                    Toast.LENGTH_LONG).show();

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
            alertDialog.setTitle("Warning");
            alertDialog.setMessage("Your account have been logged in another device!" +
                    "Please sign in if you continue working with this device.");
            alertDialog.show();

        }

    }

//    public void startService() {
//        this.startService(serviceLogout);
//    }
//
//    public void stopService() {
//        this.stopService(serviceLogout);
//    }

    public void checkVersion() {
        new AsyncTask<String, String, JSONObject>() {
            int version_in_manifest = 0;
            JSONObject objJSON;

            @Override
            protected JSONObject doInBackground(String... params) {
                UpdateVersionControl ctrUpdateVersion = new UpdateVersionControl();
                try {
                    version_in_manifest = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
                } catch (NameNotFoundException e) {
                    e.printStackTrace();
                }
                objJSON = ctrUpdateVersion.requestServer(version_in_manifest);
                return objJSON;
            }

            @Override
            protected void onPostExecute(JSONObject objJSON) {
                if (objJSON != null) {
                    try {
                        if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                            if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                                JSONObject obj = objJSON.getJSONObject("data");
                                if (obj.getBoolean("isUpdate")) {
                                    String url = obj.getString("url");
                                    System.out.println(url);
                                    onUpdateNewVersion(url);
                                }
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }.execute();
    }

    private boolean onUpdateNewVersion(final String url) {
        Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
        alertDialog.setCancelable(false);
        alertDialog.setTitle("Update NewVersion Now");
        alertDialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        downloadApkTask = new DownloadApkTask(
                                MainActivity.this);
                        downloadApkTask.execute(url);
                    }
                });
        alertDialog.show();
        return false;
    }

    /**
     * CHU KIM MUOI SERVICE ALARM
     **/

    public void scheduleAlarm() {
        Intent intent = new Intent(getApplicationContext(),
                MyAlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this,
                MyAlarmReceiver.REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        long firstMillis = System.currentTimeMillis();
        int intervalMillis = 120000;
        AlarmManager alarm = (AlarmManager) this
                .getSystemService(Context.ALARM_SERVICE);
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, firstMillis,
                intervalMillis, pIntent);
    }

    public void cancelAlarm() {
        Intent intent = new Intent(getApplicationContext(),
                MyAlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this,
                MyAlarmReceiver.REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) this
                .getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pingConnectionSerVer();
//		mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
        checkVersion();
        try {
            IntentFilter filter = new IntentFilter(ServiceUpload.ACTION);
            LocalBroadcastManager.getInstance(this).registerReceiver(testReceiver, filter);
        } catch (Exception e) {
        }

        FileSave file = new FileSave(MainActivity.this, Constants.GET);
        if (!file.getDeviceID().equals("") && file.getPickerID() != -1) {
            pid = String.valueOf(file.getPickerID());
            did = file.getDeviceID();
        }

//        Log.e("MainActivity resume","pid: " + pid + "\n" +
//                "did: " + did + "\n" +
//                "pidLogin: " + LoginFragment.pickerIdLogin + "\n" +
//                "didLogin: " + LoginFragment.deviceIdLogin);

        Log.e("Resume did:", did + "");
        if (did != null && RequestFirebase.did_static != null){
            if(!RequestFirebase.did_static.equals(did)){
                logoutControl();
            }
        }

//        if (!LoginFragment.requestedLogin){
        if (canRequest){

            if(pid != null && did != null){
                try {
                    Log.e("Request MainActivity","executing...");
                    new RequestFirebase(MainActivity.this,this,pid,did).execute();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }

        }

        isLoggedOut = false;

    }

    @Override
    protected void onPause() {
        super.onPause();

        try {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(testReceiver);
            requestQueue.cancelAll("cancelAll");
        } catch (Exception e) {
        }
        /*Xoa thread check internet*/
        Log.e("MainActivity", "onPause()");
//		mHandler.removeCallbacks(setTitleColor);
    }

    private BroadcastReceiver testReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            try {
                if (intent != null) {
                    int getResponseCode = intent.getIntExtra("getResponseCode", 404);
                    /*trang thai cua server*/
                    if (getResponseCode == 200) {
                        getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
                    } else {
                        getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
                    }
                }
            } catch (Exception e) {
                Log.e("tag", e.toString());
            }
        }
    };

    /**
     * ===========
     */

    public void SaveLogLogin() {
        sql_LogData sqlLogData = new sql_LogData(MainActivity.this);
        LogData logLogin = new LogData();
        logLogin.setAction(Constants.LOG_AUTO_LOGIN_INT);
        logLogin.setDescription(Constants.LOG_AUTO_LOGIN_STRING);

        sqlLogData.insert(logLogin);
    }

//	private static Handler mHandler = new Handler();
//
//	private Runnable setTitleColor = new Runnable() {
//	    @Override
//	    public void run() {
//	    	try {
//	    		pingConnectionSerVer();
//	    		mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//	    }
//	};

    public void onSCanBarCode(int types) {
        try {
            Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
            intent.putExtra("SCAN_FORMATS",
                    "QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
            startActivityForResult(intent, types);
        } catch (Exception e) {
            Log.e("NOT SCAN", e.toString());
        }
    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    private void pingConnectionSerVer() {

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    Log.e("pingConnectionSerVer", jsonObject.toString());
                    getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError arg0) {
                try {
                    getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
                } catch (NotFoundException e) {
                }
            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "checkversion");
                params.put("softType", "newpickingapp");
                params.put("curVersion", "1");
                return params;
            }
        };

        try {
            postRequest.setShouldCache(false);
            postRequest.setTag("cancelAll");
            requestQueue.add(postRequest);
        } catch (Exception e) {
        }
    }

    public void requestPermission() {
        int checkCameraPer = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int checkWiteExPer = ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int checkCoarseLocPer = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        int checkFineLocPer = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
//		int checkCameraPer = ActivityCompat.checkSelfPermission(this, Manifest.permission.WRED_EXTERNAL_STORAGE);
        int checkReadExPer = ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int checkAlert = ActivityCompat.checkSelfPermission(this, Manifest.permission.SYSTEM_ALERT_WINDOW);
        int ckeckSetting = ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_SETTINGS);
        int killApp = ActivityCompat.checkSelfPermission(this, Manifest.permission.KILL_BACKGROUND_PROCESSES);
        int permissionGranted = PackageManager.PERMISSION_GRANTED;

        String[] permissions = new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.KILL_BACKGROUND_PROCESSES,
                Manifest.permission.WRITE_SETTINGS,
                Manifest.permission.SYSTEM_ALERT_WINDOW};
        //check Android 6+
        if (Build.VERSION.SDK_INT >= 23) {
            //check permission granted
            if (checkCameraPer != permissionGranted || checkWiteExPer != permissionGranted
                    || checkCoarseLocPer != permissionGranted || checkFineLocPer != permissionGranted
                    || checkReadExPer != permissionGranted || checkAlert != permissionGranted
                    || ckeckSetting != permissionGranted || killApp != permissionGranted) {
                //request Permissions
                ActivityCompat.requestPermissions(MainActivity
                        .this, permissions, PERMISSION_CONSTANT);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LoginFragment.requestedLogin = false;
//        stopService();
//        try {
//            mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        } catch (Exception ex) {
//
//        }
    }

    /* giao tiep */
    @Override
    public void onNormalPickMoveConfirmLoad(String LoadID) {

        PickingConfirmLoadFragment fragmentConfirmLoad = new PickingConfirmLoadFragment();

        Bundle bundle = new Bundle();
        bundle.putString(Constants.key_bundle_loadid, LoadID);
        fragmentConfirmLoad.setArguments(bundle);

        getFragmentManager().beginTransaction()
                .add(R.id.container, fragmentConfirmLoad, "PickingConfirmLoadFragment")
                .addToBackStack("PickingConfirmLoadFragment").commit();
        Log.e("addToBackStack", "PickingConfirmLoadFragment");
    }

    @Override
    public void onQAConfirmLoad(String LoadID) {

        PickingQAConfirmLoadFragment fragmentQAConfirmLoad = new PickingQAConfirmLoadFragment();
        Bundle bundle = new Bundle();
        bundle.putString(Constants.key_bundle_loadid, LoadID);
        fragmentQAConfirmLoad.setArguments(bundle);

        getFragmentManager().beginTransaction()
                .add(R.id.container, fragmentQAConfirmLoad, "PickingQAConfirmLoadFragment")
                .addToBackStack("PickingQAConfirmLoadFragment").commit();
        Log.e("addToBackStack", "PickingQAConfirmLoadFragment");
    }

    public void onLoadingConfirmLoad(String LoadID) {

        PickingLoadingConfirmLoadFragment fragmentLoadingConfirmLoad = new PickingLoadingConfirmLoadFragment();
        Bundle bundle = new Bundle();
        bundle.putString(Constants.key_bundle_loadid, LoadID);
        fragmentLoadingConfirmLoad.setArguments(bundle);

        getFragmentManager().beginTransaction()
                .add(R.id.container, fragmentLoadingConfirmLoad, "PickingLoadingConfirmLoadFragment")
                .addToBackStack("PickingLoadingConfirmLoadFragment").commit();
        Log.e("addToBackStack", "PickingLoadingConfirmLoadFragment");
    }

    @Override
    public void onDespatchedLoad(String LoadID) {
        android.app.Fragment fragment = getFragmentManager().findFragmentById(R.id.container);
        getFragmentManager().beginTransaction().remove(fragment).commit();
        getFragmentManager().popBackStack();
        Log.e("remove", fragment.toString());

        sql_PickLoads sqlLoad = new sql_PickLoads(this);

        PickingMainLoadFragment.listLoadAssigned.clear();
        sqlLoad.deleteLoad(LoadID);
        PickingMainLoadFragment.listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
        PickingMainLoadFragment.adapter.notifyDataSetChanged();
        PickingMainLoadFragment.adapter.notifyDataSetChangedCustom();
        PickingMainLoadFragment.lvLoadAssigned.setSelectionAfterHeaderView();
    }

    @Override
    public void onConfirmLoadPicked(String LoadID) {

        android.app.Fragment fragment1 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft1 = getFragmentManager().beginTransaction();
        ft1.remove(fragment1);
        ft1.commit();
        Log.e("remove", fragment1.toString());
        getFragmentManager().popBackStack();

        android.app.Fragment fragment2 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft2 = getFragmentManager().beginTransaction();
        ft2.remove(fragment2);
        ft2.commit();
        Log.e("remove", fragment2.toString());
        getFragmentManager().popBackStack();

		/* DOAN NAY UPDATE OFFLINE */
        sql_PickLoads sqlLoad = new sql_PickLoads(this);
        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picked);
        Log.e("PickingOrderActivity", "LoadAssigned load in Sqlite");
        PickingMainLoadFragment.listLoadAssigned.clear();
        PickingMainLoadFragment.listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
        PickingMainLoadFragment.adapter.notifyDataSetChanged();
        PickingMainLoadFragment.adapter.notifyDataSetChangedCustom();
        PickingMainLoadFragment.lvLoadAssigned.setSelectionAfterHeaderView();
		/*-----------------DOAN NAY UPDATE OFFLINE */

		/* DOAN NAY UPDATE ONLINE */
        PickingMainLoadFragment.onLoadAssigned(new FileSave(this, Constants.GET).getPickerID(),this);

    }

    @Override
    public void onConfirmLoadQA(String LoadID) {

        android.app.Fragment fragment1 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft1 = getFragmentManager().beginTransaction();
        ft1.remove(fragment1);
        ft1.commit();
        Log.e("remove", fragment1.toString());
        getFragmentManager().popBackStack();

        android.app.Fragment fragment2 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft2 = getFragmentManager().beginTransaction();
        ft2.remove(fragment2);
        ft2.commit();
        Log.e("remove", fragment2.toString());
        getFragmentManager().popBackStack();

		/* DOAN NAY UPDATE OFFLINE */
        sql_PickLoads sqlLoad = new sql_PickLoads(this);
        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_QA_Confirmed);
        PickingMainLoadFragment.listLoadAssigned.clear();
        PickingMainLoadFragment.listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
        PickingMainLoadFragment.adapter.notifyDataSetChanged();
        PickingMainLoadFragment.adapter.notifyDataSetChangedCustom();
        PickingMainLoadFragment.lvLoadAssigned.setSelectionAfterHeaderView();
		/*-----------------DOAN NAY UPDATE OFFLINE */

		/* DOAN NAY UPDATE ONLINE */
        PickingMainLoadFragment.onLoadAssigned(new FileSave(this, Constants.GET).getPickerID(),this);

    }

    @Override
    public void onConfirmLoadLoading(String LoadID) {

        android.app.Fragment fragment1 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft1 = getFragmentManager().beginTransaction();
        ft1.remove(fragment1);
        ft1.commit();
        Log.e("remove", fragment1.toString());
        getFragmentManager().popBackStack();

        android.app.Fragment fragment2 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft2 = getFragmentManager().beginTransaction();
        ft2.remove(fragment2);
        ft2.commit();
        Log.e("remove", fragment2.toString());
        getFragmentManager().popBackStack();

		/* DOAN NAY UPDATE OFFLINE */
        sql_PickLoads sqlLoad = new sql_PickLoads(this);
        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Loaded);
        PickingMainLoadFragment.listLoadAssigned.clear();
        PickingMainLoadFragment.listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
        PickingMainLoadFragment.adapter.notifyDataSetChanged();
        PickingMainLoadFragment.adapter.notifyDataSetChangedCustom();
        PickingMainLoadFragment.lvLoadAssigned.setSelectionAfterHeaderView();
		/*-----------------DOAN NAY UPDATE OFFLINE */

		/* DOAN NAY UPDATE ONLINE */
        PickingMainLoadFragment.onLoadAssigned(new FileSave(this, Constants.GET).getPickerID(),this);

    }

    @Override
    public void onConfirmLoadStacked(String LoadID) {

        android.app.Fragment fragment1 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft1 = getFragmentManager().beginTransaction();
        ft1.remove(fragment1);
        ft1.commit();
        Log.e("remove", fragment1.toString());
        getFragmentManager().popBackStack();

        android.app.Fragment fragment2 = getFragmentManager().findFragmentById(R.id.container);
        android.app.FragmentTransaction ft2 = getFragmentManager().beginTransaction();
        ft2.remove(fragment2);
        ft2.commit();
        Log.e("remove", fragment2.toString());
        getFragmentManager().popBackStack();

		/* DOAN NAY UPDATE OFFLINE */
        sql_PickLoads sqlLoad = new sql_PickLoads(this);
        sqlLoad.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picked);
        PickingMainLoadFragment.listLoadAssigned.clear();
        PickingMainLoadFragment.listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
        PickingMainLoadFragment.adapter.notifyDataSetChanged();
        PickingMainLoadFragment.adapter.notifyDataSetChangedCustom();
        PickingMainLoadFragment.lvLoadAssigned.setSelectionAfterHeaderView();
		/*-----------------DOAN NAY UPDATE OFFLINE */

		/* DOAN NAY UPDATE ONLINE */
        PickingMainLoadFragment.onLoadAssigned(new FileSave(this, Constants.GET).getPickerID(),this);

    }

    @Override
    public void onRefeshAllLoad() {

        // sql_PickLoadAssigneds sqlLoad = new sql_PickLoadAssigneds(this);
        // sqlLoad.updateLoadMobileStatus(LoadID,
        // Constants.LoadMobileStatus_Picked);
        // Log.e("PickingOrderActivity", "LoadAssigned load in Sqlite");
        // listLoadAssigned.clear();
        // listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
        // adapter.notifyDataSetChanged();
        // adapter.notifyDataSetChangedCustom();
        // lvLoadAssigned.setSelectionAfterHeaderView();

        PickingMainLoadFragment.onLoadAssigned(new FileSave(this, Constants.GET).getPickerID(),this);
    }

//    public class DemNguocRunnable implements Runnable {
//        @Override
//        public void run() {
//            handleDemnguoc();
//        }
//    }
//
//    private void showDemNguoc() {
//        mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//    }
//
//    private void handleDemnguoc() {
//        try {
//            sec--;
//            if (sec < 0) {
//                min--;
//                sec = 59;
//            }
////        Toast.makeText(this, min + ":" + sec, Toast.LENGTH_SHORT).show();
//            mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//            if (min == 0 && sec == 29) {
////                Toast.makeText(getActivity(), "GÃ¡Â»Â­i Request", Toast.LENGTH_SHORT).show();
//                FileSave file = new FileSave(MainActivity.this, Constants.GET);
//                if (!file.getIsDeviceLogin()) {
//                    file = new FileSave(this, Constants.PUT);
//                    file.putIsDeviceLogin(true);
//                    this.getFragmentManager().beginTransaction()
//                            .replace(R.id.container, new LoginFragment(), "LoginFragment")
//                            .commit();
////                    stopService();
//                }
//                min = 0;
//                sec = 59;
//                showDemNguoc();
//            }
//        } catch (Exception ex) {
//            Log.e("Service Handle", ex.getMessage());
//        }
//    }

    @Override
    public void onBackPressed() {
//        turnOffFlash();
        if (PickingMainLoadFragment.slidingDrawer != null){
            // TODO thÃƒÂªm back pressed khi slidingDrawer Ã„â€˜ang mÃ¡Â»Å¸
            if(PickingMainLoadFragment.slidingDrawer.isOpened()){
                PickingMainLoadFragment.btnSearchAssigned.setImageResource(R.drawable.abc_ic_search_api_mtrl_alpha);
                PickingMainLoadFragment.slidingDrawer.close();
                InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(PickingMainLoadFragment.btnSearchAssigned.getWindowToken(), 0);
            }else {
                super.onBackPressed();
            }
        }else
            super.onBackPressed();

    }

    @Override
    public void onRequestFirebaseSuccess(boolean kq) {

//        Toast.makeText(MainActivity.this,"kq = " + kq + "\n"
//                        + "did_static:" + RequestFirebase.did_static + "\n"
//                        + "did:" + did ,
//                Toast.LENGTH_LONG).show();
//        Log.e("MainActivity nhận",kq+"");
//        Log.e("MainActivity request","pidLogin: " + LoginFragment.pickerIdLogin);
//        Log.e("MainActivity request","pid: " + pid);
//        if (LoginFragment.pickerIdLogin != null && LoginFragment.deviceIdLogin != null){
//            try {
//                new RequestFirebase(MainActivity.this,this,LoginFragment.pickerIdLogin,LoginFragment.deviceIdLogin).execute();
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//            }
//        }
        FileSave fileSave = new FileSave(MainActivity.this,Constants.GET);
        if (fileSave.getPickerID() != -1){
            if (!kq){
                try{
                    FileSave file = new FileSave(MainActivity.this, Constants.GET);
                    if (!file.getIsDeviceLogin()) {
                        file = new FileSave(MainActivity.this, Constants.PUT);
                        file.putIsDeviceLogin(true);
                        logoutControl();
                    }
                }catch (Exception e){
                    Log.e("Fragment null",e.toString());
                }
            }

        }



    }




}

