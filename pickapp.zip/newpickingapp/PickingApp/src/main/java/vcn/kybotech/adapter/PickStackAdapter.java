package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.PickOrder;
import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.R;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PickStackAdapter extends ArrayAdapter<Object> {
	Context context;
	int	ResID;
	List<Object> listObj;
	boolean hide;
	
	public PickStackAdapter(Context context, int resource, List<Object> objects) {
		super(context, resource, objects);
		this.context = context;
		this.listObj = objects;
//		this.ResID = resource;
		hide = false;
		
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		Object object = null;
		try {
			object = listObj.get(position);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (object == null) {
			
		}else if (object instanceof PickOrder) {
			OrderItemHolder orderItemHolder ;
			PickOrder pickOrder = (PickOrder) object;
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			orderItemHolder = new OrderItemHolder();
			convertView = inflater.inflate(R.layout.item_newpick_order, parent, false);
			
			orderItemHolder.OrderRef = (TextView) convertView.findViewById(R.id.newPick_ItemOrder_OrderRef);
			orderItemHolder.ProducName = (TextView) convertView.findViewById(R.id.newPick_ItemOrder_ProductName);
			orderItemHolder.SpecialInstructions = (TextView) convertView.findViewById(R.id.newPick_ItemOrder_SpecialInstructions);
			
			convertView.setTag(orderItemHolder);
			
			String stOrderRef = pickOrder.getOrderRef();
			
			if (stOrderRef.indexOf("KTC")>=0) {
				stOrderRef = "TESCO - " + stOrderRef;
				orderItemHolder.OrderRef.setTextColor(Color.RED);
				orderItemHolder.ProducName.setTextColor(Color.RED);
			}else{
				orderItemHolder.OrderRef.setTextColor(Color.parseColor("#0000E5"));
				orderItemHolder.ProducName.setTextColor(Color.parseColor("#0000E5"));
			}
			orderItemHolder.OrderRef.setText(pickOrder.getDropNumber() + " - " + stOrderRef);
			orderItemHolder.ProducName.setText( pickOrder.getProductName());
			orderItemHolder.SpecialInstructions.setText(pickOrder.getSpecialInstructions());
//			if (pickOrder.getStatus().equalsIgnoreCase(Constants.StatusOrderItem_Picked)) {
//				orderItemHolder.OrderRef.setBackgroundColor(Color.YELLOW);
//				orderItemHolder.ProducName.setBackgroundColor(Color.YELLOW);
//				orderItemHolder.SpecialInstructions.setBackgroundColor(Color.YELLOW);
//			}else{
//				orderItemHolder.OrderRef.setBackgroundColor(Color.WHITE);
//				orderItemHolder.ProducName.setBackgroundColor(Color.WHITE);
//				orderItemHolder.SpecialInstructions.setBackgroundColor(Color.WHITE);
//			}
		}else if (object instanceof PickPart) {
			
			
			PartHolder partHolder ;
			PickPart pickPart = (PickPart) object;
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			partHolder = new PartHolder();
			convertView = inflater.inflate(R.layout.item_newpick_part, parent, false);
			
			LinearLayout showhide = (LinearLayout)convertView.findViewById(R.id.part_hide_newpick);
			partHolder.PartID = (TextView) convertView.findViewById(R.id.newpick_part_id);
			partHolder.PartName = (TextView) convertView.findViewById(R.id.newpick_part_name);
			partHolder.PartSwipe = (TextView) convertView.findViewById(R.id.newpick_part_swipe_scan);
			partHolder.Picked = (TextView) convertView.findViewById(R.id.newpick_part_picked);
			
			
			convertView.setTag(partHolder);
			partHolder.PartID.setText(String.format("%05d", pickPart.getPartID()));
			partHolder.PartName.setText(pickPart.getPartName() + " | QTY: " + pickPart.getQuantity() + " | Location: "+ pickPart.getLocationName());
			//partHolder.PartSwipe.setText( "Swipe: " + pickPart.getSwipeStack() + "/"  + pickPart.getQuantity());
			partHolder.PartSwipe.setText( "Qty: " + pickPart.getQuantity());
			Log.d("hehe", "swipe stack: " + pickPart.getSwipeStack());
			partHolder.Picked.setText("Stacked: " + pickPart.getStackedBy());
			if (pickPart.getStackedBy().equalsIgnoreCase("null")) {
				
				partHolder.PartID.setTextColor(Color.parseColor("#404040"));
				partHolder.PartName.setTextColor(Color.parseColor("#404040"));
				partHolder.PartSwipe.setTextColor(Color.parseColor("#404040"));
				partHolder.Picked.setTextColor(Color.parseColor("#404040"));
				
				partHolder.Picked.setVisibility(View.GONE);
			}else{

				partHolder.PartID.setTextColor(Color.parseColor("#CC0000"));
				partHolder.PartName.setTextColor(Color.parseColor("#CC0000"));
				partHolder.PartSwipe.setTextColor(Color.parseColor("#CC0000"));
				partHolder.Picked.setTextColor(Color.parseColor("#CC0000"));
				
				partHolder.Picked.setVisibility(View.VISIBLE);
				
				if (hide) {
					showhide.setVisibility(View.GONE);
				}else{
					showhide.setVisibility(View.VISIBLE);
				}
			}
			
		}
		
		
		
		return convertView;
	}
	
	
	public void hide(boolean hide) {
		this.hide = hide;
	}
	
	
	public static class PartHolder{
		TextView PartID;
		TextView PartName;
		TextView PartSwipe;
		TextView Picked;
//		TextView PickType;
//		TextView PickTypeID;
//		TextView PartName;
//		TextView PartQTy;
//		TextView PartTotalPack;
//		TextView PartLoc;
	}
	
	public static class OrderItemHolder{
		TextView OrderRef;
		TextView ProducName;
		TextView SpecialInstructions;
//		TextView PartQTy;
//		TextView PartTotalPack;
//		TextView PartLoc;
	}

}
