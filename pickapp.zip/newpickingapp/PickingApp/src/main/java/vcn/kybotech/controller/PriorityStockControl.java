package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;

public class PriorityStockControl {
	private JSONParser jsonParser;
	private int userid;
	private String username;
	
	public PriorityStockControl(Context context){
		jsonParser = new JSONParser();
		FileSave file = new FileSave(context, Constants.GET);
		userid = file.getPickerID();
		username = file.getPickerName();
		if(!file.getName().equals("")){
			username = username + " - " + file.getName();
		}
	}
	
	public JSONObject getPriorityStock(int partid){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "getshippriority"));
		params.add(new BasicNameValuePair("partid", String.valueOf(partid)));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
	
	public JSONObject uploadPriority(int partid, String data, String reason){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "saveshippriority"));
		params.add(new BasicNameValuePair("PartID", String.valueOf(partid)));
		params.add(new BasicNameValuePair("Data", data));
		params.add(new BasicNameValuePair("Reason", reason));
		params.add(new BasicNameValuePair("UserID", String.valueOf(userid)));
		params.add(new BasicNameValuePair("UserName", username));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
