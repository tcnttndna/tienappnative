package vcn.kybotech.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vcn.kybotech.adapter.PickNewPickAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickOrder;
import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickLoads;
import vcn.kybotech.sqlite.sql_PickOrders;
import vcn.kybotech.sqlite.sql_PickParts;

public class PickingNewPickFragment extends android.app.Fragment{
	TextView TvLoadID;
	ListView listView;
	PickNewPickAdapter adapter;
	List<Object> list;
	Button buttonHidePart;
	ProgressBar progressBar;
	ProgressDialog progressDialog;
	private String LoadID;
	FileSave fileSave ;
	private GPSTracker gpsTracker;
	private CommunicatingFragments communicatingFragments;
	RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
	private final static String Tag = "RequesConfirm";
	
	View.OnTouchListener gestureListener;
	GestureDetector gestureDetector;
	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 100;
	
	
	

	
	@Override
	public void onAttach(Activity activity) {
		
		super.onAttach(activity);
		try {
			communicatingFragments = (CommunicatingFragments)getActivity();
		} catch (Exception e) {
			throw new ClassCastException(activity.toString() + " must implement CommunicatingFragments");
		}

	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_picking_load_newpick, container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
		
		TvLoadID = (TextView)rootView.findViewById(R.id.fragment_picking_newpick_loadID);
		progressBar = (ProgressBar)rootView.findViewById(R.id.progressShowPart);
		buttonHidePart = (Button)rootView.findViewById(R.id.btnHidePartSwipe);
		
		listView = (ListView)rootView.findViewById(R.id.lvNewPick);
		return rootView;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		
		requestQueue = Volley.newRequestQueue(getActivity());
		gpsTracker = new  GPSTracker(getActivity());
		fileSave = new FileSave(getActivity(), Constants.GET);
		
		progressDialog = new ProgressDialog(getActivity());
		progressDialog.setMessage(getString(R.string.fragment_login_waiting));
		progressDialog.setCancelable(false);
		
		LoadID = getArguments().getString(Constants.key_bundle_loadid);
		TvLoadID.setText("Load " + LoadID);
		
		int h = Integer.parseInt(buttonHidePart.getTag().toString()) ;
		if (h==0) {
			buttonHidePart.setText("Hide");
		}else {
			buttonHidePart.setText("Show");
		}
		
		list = new ArrayList<Object>() ;
		adapter = new PickNewPickAdapter(getActivity(), R.layout.item_newpick_order, list);
		listView.setAdapter(adapter);
		gestureDetector = new GestureDetector(new MyGestureDetector());
		gestureListener = new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
					gestureDetector.onTouchEvent(event);
						return false;
			}
		};
		listView.setOnTouchListener(gestureListener);
		
		onLoadData();
		onClickButton();
	}
	
	private void onClickButton() {
			buttonHidePart.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					int hi = Integer.parseInt(buttonHidePart.getTag().toString()) ;
					if (hi==0) {
						buttonHidePart.setTag(1);
						buttonHidePart.setText("Show");
						adapter.hide(true);
						adapter.notifyDataSetChanged();
					}else {
						buttonHidePart.setTag(0);
						buttonHidePart.setText("Hide");
						adapter.hide(false);
						adapter.notifyDataSetChanged();
					}
					
				}
			});
		
	}

	private void onLoadData() {
		try {
			
			/*Chuan bi du lieu tron vao List nay de hien thi len listview*/

			sql_PickParts sqlPickParts = new sql_PickParts(getActivity());
			sql_PickOrders sqlPickOrders = new sql_PickOrders(getActivity());
			list.clear();
			/*List nay lay ra cac danh sach order trong cung Load(khong lay order da remove hoac picked)*/
			List<PickOrder> listOrder = sqlPickOrders.getListOrders(LoadID);
			for (int j = 0; j < listOrder.size(); j++) {
				/*1 - Add Order*/
				list.add(listOrder.get(j));
				int orderItemID = listOrder.get(j).getOrderItemID();
				List<PickPart> listPart = sqlPickParts.getListParts(String.valueOf(orderItemID));
				if (listPart.size()>0) {
					/*2 - Add Part*/
					list.addAll(listPart);
				}
			}
			
			if (adapter!=null) {
				adapter.notifyDataSetChanged();
			}
			if (progressBar!=null) {
				progressBar.setVisibility(View.GONE);
			}
			progressDialog.dismiss();
		} catch (Exception e) {
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
			e.printStackTrace();
		}
			
		
	}


	class MyGestureDetector extends SimpleOnGestureListener {
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,	float velocityY) {
			try {
				if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
					return false;
				// right to left swipe
				if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//					YourSlideRightToLeft(listView.pointToPosition((int) e1.getX(), (int) e1.getY()));

				} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					// left to right swipe
					YourSlideLeftToRight(listView.pointToPosition((int) e1.getX(), (int) e1.getY()));
				}
			} catch (Exception e) {
				if (progressDialog!=null) {
					progressDialog.dismiss();
				}
				// nothing
				return true;
			}

			return true;

		}
	}

	
	public void YourSlideLeftToRight(int position)
	{
		
		Object object = list.get(position);
		if (object instanceof PickPart) {
			
			try {
				sql_PickParts sqlParts = new sql_PickParts(getActivity());
				PickPart pickPart =  (PickPart) object;
				/*Check xem da scanned chua neu roi thi bao scanned full*/
				boolean isScanned = sqlParts.checkPartScanned(pickPart.getOrderItemID(), pickPart.getPartID(), pickPart.getId());
				onContinueProcessScanPart(isScanned, pickPart, position);
			} catch (Exception e) {
				progressDialog.dismiss();
				e.printStackTrace();
			}
		}
	}

	private void onContinueProcessScanPart(boolean isScanned, PickPart pickPart , int position) {
		
		progressDialog.show();
		
		String lat = String.valueOf(gpsTracker.getLatitude());
	    String lng = String.valueOf(gpsTracker.getLongitude());
		
		final int picker_id = fileSave.getPickerID();
		final String  picker_name = fileSave.getPickerName();
		
		if (isScanned) {
			/*Clear scan no*/
			/*Clear thi truyen false, confirm part thi truyen true*/
			
			if (fileSave.getPickerName().equalsIgnoreCase(pickPart.getPickedBy())) {
				onConfirmPart(false, pickPart, picker_id, picker_name, lng, lng);
			}else{
				progressDialog.dismiss();
				AlertDialog.Builder dialog = new Builder(getActivity());
				dialog.setTitle("Message")
				.setMessage("You not permission swipe part this")
				.setPositiveButton("OK", null)
				.show();
			}

		}else{
			try {
				/*Bat dau scan*/

				final int id = pickPart.getId();
				final int part_id = pickPart.getPartID();
				final int order_item_id = pickPart.getOrderItemID();
				
				sql_PickParts sqlParts = new sql_PickParts(getActivity());
				if (sqlParts.checkSwipeConfirm(String.valueOf(pickPart.getOrderItemID()), String.valueOf(pickPart.getPartID()),pickPart.getId() )) {
					/*request server neu thanh cong thi moi update neu khong thi bao loi*/
					
					onConfirmPart(true, pickPart, picker_id, picker_name, lat, lng);
					/*onLoadData da xu ly trong ham onConfirmPart()*/
				}else{
					sqlParts.updateSwipe(order_item_id, part_id, id, "null");
					onLoadData();
				}
			} catch (Exception e) {
				progressDialog.dismiss();
				e.printStackTrace();
			}
			
		}
		
	}

	private void onConfirmPart(final boolean isConfirmPart, final PickPart pickPart , final int picker_id, final String picker_name, final String Lat, final String Lng) {
		
		
		Response.Listener<String> listener = new Response.Listener<String>(){

			@Override
			public void onResponse(String response) {


				try {
					JSONObject jsonObject = new JSONObject(response.toString());
					if (jsonObject.getBoolean("success")) {
						/*confirm len service truoc, neu confirm thanh cong moi cho ++swipe scan*/
						sql_PickParts sqlParts = new sql_PickParts(getActivity());
						
						/*Neu isConfirmPart true thi confirm --> updateSwipe, else thi clear part do*/
						if (isConfirmPart) {
							sqlParts.updateSwipe(pickPart.getOrderItemID(), pickPart.getPartID(), pickPart.getId(),picker_name);
							
						}else{
							sqlParts.clearScanPart(pickPart.getOrderItemID(), pickPart.getPartID(), pickPart.getId());
						}
						
//						updateButtonShowHide(String.valueOf(intOrdersItemID));
						checkConfirmOrderItem( pickPart.getOrderItemID() );
						checkConfirmLoad();
						onLoadData();
						
						
					}else {
						Toast.makeText(getActivity(), "success:false\nServer is problem!", Toast.LENGTH_SHORT).show();
					}
				} catch (JSONException e) {
					e.printStackTrace();
					DialogServerProblem();
//					Toast.makeText(getActivity(), "success:false\nServer is problem!", Toast.LENGTH_SHORT).show();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				if (progressDialog!=null) {
					progressDialog.dismiss();
				}

			}
			
		};
		
		Response.ErrorListener errorListener = new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError volleyError) {
				if (progressDialog!=null) {
					progressDialog.dismiss();
				}
				Toast.makeText(getActivity(), "Connection to your server disconnected!" , Toast.LENGTH_SHORT).show();
			}
		};
		
		
		StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener){
			@Override
			protected Map<String, String> getParams(){
				
				Map<String, String> params ;
				
				sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
				sql_PickParts sqlParts = new sql_PickParts(getActivity());
				
				/*Kiem tra xem neu la orderItem Cuoi cung chua confirm va part cuoi cung chua confirm thi gui isorderconfirmed = true, else isorderconfirmed= false*/
				int countNotPicked = sqlOrders.getCountOrdersNotPickedInOrderRef(LoadID, pickPart.getOrderRef());
				int countPartNotScanned = sqlParts.getCountPartNotScan(pickPart.getOrderRef());
				if (countNotPicked == 1 && countPartNotScanned == 1) {
					params = onCreateParams(true);
				}else{
					params = onCreateParams(false);
				}
				return params;
			}

			private Map<String, String> onCreateParams(boolean isorderconfirmed)  {
				
				Map<String, String> params = new HashMap<String, String>();
				params.put("type", "scanpart");
				params.put("loadid", LoadID);
				
				params.put("orderref", pickPart.getOrderRef());
				params.put("orderitemid", String.valueOf(pickPart.getOrderItemID()));
				params.put("partid", String.valueOf(pickPart.getPartID()));
	
				params.put("partname", pickPart.getPartName());
				params.put("qty", String.valueOf(pickPart.getQuantity()));
				
				params.put("locationname", pickPart.getLocationName());
				params.put("pickerid", String.valueOf(fileSave.getPickerID()));
				
				params.put("pickername", fileSave.getPickerName());
				params.put("isscanned", String.valueOf(isConfirmPart));
				
				params.put("typepick", String.valueOf(Constants.type_pick_newpick));
				params.put("isorderconfirmed", isorderconfirmed? "1":"0");
				
				
				params.put("InApp", "NewPickingApp");
				params.put("lat", Lat);
				params.put("lng", Lng);
				
				SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String date = "";
				String version ="";
				try {
					date =  formatngay.format(new Date());
					version = android.os.Build.MODEL + " | " +android.os.Build.VERSION.RELEASE + " | " + getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionCode;
					
					Log.e("reques ConfirmOrderItem", "Toa Do: "+ Lat + " ; " + Lng);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				params.put("version", version);
				params.put("phonedate", date);
				return params;
			}
		};
		
//		RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
		postRequest.setTag(Tag);
		postRequest.setShouldCache(false);
		requestQueue.add(postRequest);
		
	}
	
	public void DialogServerProblem(){
		Log.e("LoginFramgment", "server is problem");
		if (getActivity()==null) {
			return;
		}
		Builder dialog = new  AlertDialog.Builder(getActivity());
		dialog.setTitle("Message");
		dialog.setMessage("Server is problem");
		dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				
			}
		});
		dialog.show();
	}
	
	protected void checkConfirmOrderItem(int OrderItemID ) {
		
		sql_PickParts sqlParts = new sql_PickParts(getActivity());
		sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
	    boolean isAllPartScan = sqlParts.isAllPartScanned(String.valueOf(OrderItemID));
	    if (isAllPartScan) {
	    	sqlOrders.updateConfirmSpickedOrder(String.valueOf(OrderItemID));
		}
//	    else{
//			sqlOrders.updateClearConfirmSpickedOrder(String.valueOf(OrderItemID));
//		}
		
	}

	protected void checkConfirmLoad() {
		sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
		boolean confirmLoad = sqlOrders.checkAllOrderConfirm();
		sql_PickLoads sqlPickLoadAssigneds = new sql_PickLoads(getActivity());
		if (confirmLoad) {
			sqlPickLoadAssigneds.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picked);
//			Log.e("PickingOrderActivity", "LoadAssigned load in Sqlite");
//			listLoadAssigned.clear();
//			listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//			adapter.notifyDataSetChanged();
//			adapter.notifyDataSetChangedCustom();
//			lvLoadAssigned.setSelectionAfterHeaderView();
			
			AlertDialog.Builder dialog = new Builder(getActivity());
			dialog.setTitle("Message")
			.setMessage(" Load " + LoadID + " - is confirmed")
			.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					communicatingFragments.onConfirmLoadPicked(LoadID);
				}
			})
			.setCancelable(false)
			.show();
		}
//		else{
//			sqlPickLoadAssigneds.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picking);
//		}
	}

	@Override
	public void onDetach() {
		requestQueue.cancelAll(Tag);
		super.onDetach();
	}

}
