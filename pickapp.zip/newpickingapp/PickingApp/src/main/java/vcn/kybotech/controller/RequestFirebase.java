package vcn.kybotech.controller;

/**
 * Created by User on 1/30/2018.
 */

import android.content.Context;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.UnsupportedEncodingException;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.fragment.LoginFragment;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.MainActivity;
import vcn.kybotech.pickingapp.R;

/**
 * Created by User on 1/18/2018.
 */

public class RequestFirebase {

    private RequestFirebaseListener listener;
    private String pickerId,deviceId;
    private Context context;
    public static String did_static;
    private String didFromFirebase,pidFromFirebase;
    private String pid,did;

    public RequestFirebase(RequestFirebaseListener mListener,Context mContext, String mPickerID, String mDeviceId){

        this.listener = mListener;
        this.context = mContext;
        this.pickerId = mPickerID;
        this.deviceId = mDeviceId;

    }

    public void execute() throws UnsupportedEncodingException{

//        if (pickerId.equals(LoginFragment.pickerIdLogin)){

            FirebaseDatabase.getInstance().getReference().child(Constants.firebase_key_main)
                    .child(pickerId)
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            Log.e("Firebase pickerId: ",pickerId + "");

                            // check liên tục pid
                            FileSave fileNew = new FileSave(context, Constants.GET);
                            if (!fileNew.getDeviceID().equals("") && fileNew.getPickerID() != -1) {
                                pid = String.valueOf(fileNew.getPickerID());
                                did = fileNew.getDeviceID();
                            }

                            didFromFirebase = dataSnapshot.child(Constants.firebase_key_deviceId)
                                    .getValue().toString();

                            pidFromFirebase = dataSnapshot.child(Constants.firebase_key_pickerId)
                                    .getValue().toString();

                            boolean kq;

                            // Nếu pid của Main k bằng pickerId đang execute thì sẽ k chạy
                            // Nếu bằng thì chạy
                            if (pid != null && did != null){

                                // Lúc out ra login hay login pickerId mới thì sẽ k nhận requestFirebase
                                // từ lần execute trước nữa!!!
                                if (pid.equals(pickerId) && !MainActivity.isLoggedOut){

                                    try {
                                        if (deviceId != null && pickerId.equals(pidFromFirebase)){

                                            if (!didFromFirebase.equals(deviceId) && !didFromFirebase.equals(did_static)){

                                                FileSave file = new FileSave(context, Constants.PUT);
                                                if (file != null){
                                                    file.putIsRememberLogin(false);
                                                    file.putIsDeviceLogin(false);
//                                        Log.e("device login",false+"");
                                                    dialogLogoutService();
                                                }
                                                kq = false;

                                                listener.onRequestFirebaseSuccess(kq);

                                                Log.e("check activity log","Đã nhận " + kq + "\n"
                                                        + "did_static:" + did_static + "\n"
                                                        + "did:" + deviceId + "\n"
                                                        + "pid:" + pickerId);

                                                did_static = didFromFirebase;

                                            }else {

                                                kq = true;
                                                listener.onRequestFirebaseSuccess(kq);

                                                Log.e("check activity log","Đã nhận " + kq + "\n"
                                                        + "did_static:" + did_static + "\n"
                                                        + "did:" + deviceId+ "\n"
                                                        + "pid:" + pickerId);
                                                did_static = deviceId;
                                            }

                                        }
                                    }catch (Exception e){
                                        e.printStackTrace();
                                    }

                                }

                            }


                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

//        }


    }

    public void dialogLogoutService() {
        try {
            final Notification.Builder builder = new Notification.Builder(context);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                builder.setStyle(new Notification.BigTextStyle(builder)
                        .bigText("Your account has been login with another device. Please reopen this application to continue working!")
                        .setBigContentTitle("Picking App"))
                        .setContentTitle("Picking App")
                        .setSmallIcon(R.drawable.ic_launcher);
                final NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify(0, builder.build());
            }
        } catch (Exception ex) {
            Toast.makeText(context, "" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


}

