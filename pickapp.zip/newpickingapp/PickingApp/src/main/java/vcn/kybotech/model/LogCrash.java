package vcn.kybotech.model;

public class LogCrash {
	private int ID;
	private int PickerId;
	private String Message;
	private String StackTrace;
	private String DeviceModel;
	private String AndroidVersion;
	private int AppVersionCode;
	private String AppVersionName;
	private int IsCrashed;
	private String DateTime;
	
	public LogCrash() {
		super();
	}
	
	public LogCrash(int pickerId, String message, String stackTrace,
			String deviceModel, String androidVersion, int appVersionCode,
			String appVersionName, int isCrashed, String dateTime) {
		super();
		PickerId = pickerId;
		Message = message;
		StackTrace = stackTrace;
		DeviceModel = deviceModel;
		AndroidVersion = androidVersion;
		AppVersionCode = appVersionCode;
		AppVersionName = appVersionName;
		IsCrashed = isCrashed;
		DateTime = dateTime;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public int getPickerId() {
		return PickerId;
	}

	public void setPickerId(int pickerId) {
		PickerId = pickerId;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public String getStackTrace() {
		return StackTrace;
	}

	public void setStackTrace(String stackTrace) {
		StackTrace = stackTrace;
	}

	public String getDeviceModel() {
		return DeviceModel;
	}

	public void setDeviceModel(String deviceModel) {
		DeviceModel = deviceModel;
	}

	public String getAndroidVersion() {
		return AndroidVersion;
	}

	public void setAndroidVersion(String androidVersion) {
		AndroidVersion = androidVersion;
	}

	public int getAppVersionCode() {
		return AppVersionCode;
	}

	public void setAppVersionCode(int appVersionCode) {
		AppVersionCode = appVersionCode;
	}

	public String getAppVersionName() {
		return AppVersionName;
	}

	public void setAppVersionName(String appVersionName) {
		AppVersionName = appVersionName;
	}

	public int getIsCrashed() {
		return IsCrashed;
	}

	public void setIsCrashed(int isCrashed) {
		IsCrashed = isCrashed;
	}

	public String getDateTime() {
		return DateTime;
	}

	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}
}
