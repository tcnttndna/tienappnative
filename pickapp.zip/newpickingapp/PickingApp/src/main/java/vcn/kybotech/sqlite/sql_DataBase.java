package vcn.kybotech.sqlite;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.google.firebase.crash.FirebaseCrash;


public class sql_DataBase extends SQLiteOpenHelper {

	private static final int DATABASE_VERSION = 133;
	private static final String DATABASE_NAME = "PickingDataBase";

    public sql_DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL(sql_PickLoads.CREATE_TABLE_LOAD_ASSIGNED);
            db.execSQL(sql_PickOrders.CREATE_TABLE_ORDERS);
            db.execSQL(sql_PickParts.CREATE_TABLE_PART);
            db.execSQL(sql_PickAccount.CREATE_TABLE_ACCOUNT);
            db.execSQL(sql_PickPartType.CREATE_TABLE_PICK_TYPE);
            db.execSQL(sql_LogCrash.CREATE_TABLE_LOG_CRASH);
            db.execSQL(sql_Image.CREATE_TABLE_IMAGE);
            db.execSQL(sql_LogData.CREATE_TABLE_LOG_DATA);
            db.execSQL(sql_PickOrderType.CREATE_TABLE);
            db.execSQL(sql_WareHouse.CREATE_TABLE_WARE_HOUSE);
            db.execSQL(sql_Site.CREATE_TABLE_SITE);
            db.execSQL(sql_PickPartStack.CREATE_TABLE_PART);
            db.execSQL(sql_PickReturnParts.CREATE_TABLE_RETURN_PART);
            db.execSQL(sql_PickReturnLoads.CREATE_TABLE_RETURN_LOAD);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickLoads.TABLE_LOAD_ASSIGNED);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickOrders.TABLE_ORDERS);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickParts.TABLE_PARTS);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickAccount.TABLE_PICK_ACCOUNT);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickPartType.TABLE_PARTS_WITH_TYPE);
            db.execSQL("DROP TABLE IF EXISTS " + sql_LogCrash.TABLE_LOG_CRASH);
            db.execSQL("DROP TABLE IF EXISTS " + sql_Image.TABLE_IMAGE);
            db.execSQL("DROP TABLE IF EXISTS " + sql_LogData.TABLE_LOG_DATA);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickOrderType.TABLE_PICK_ORDERS_WITH_TYPE);
            db.execSQL("DROP TABLE IF EXISTS " + sql_WareHouse.TABLE_WARE_HOUSE);
            db.execSQL("DROP TABLE IF EXISTS " + sql_Site.TABLE_SITE);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickPartStack.TABLE_PARTS);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickReturnParts.TABLE_PICK_RETURN_PART);
            db.execSQL("DROP TABLE IF EXISTS " + sql_PickReturnLoads.TABLE_PICK_RETURN_LOAD);
            onCreate(db);
    }
}
