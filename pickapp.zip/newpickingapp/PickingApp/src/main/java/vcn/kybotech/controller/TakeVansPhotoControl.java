package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;

public class TakeVansPhotoControl {
	private JSONParser jsonParser;
	
	public TakeVansPhotoControl(){
		jsonParser = new JSONParser();
	}
	
	public JSONObject confirm(int LoadId){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "checkloadnew"));
		params.add(new BasicNameValuePair("loadid", String.valueOf(LoadId)));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
