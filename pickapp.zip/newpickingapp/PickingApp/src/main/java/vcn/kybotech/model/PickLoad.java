package vcn.kybotech.model;

import java.io.Serializable;

public class PickLoad implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int LoadID;
	private String LoadCode;
	private String LoadStatus;
	private int CreatedByUserID;
	private String CreatedDate;

	private String Username;
	private String PlannedDeliveryDate;
	private String CarrierName;

	private String DriverName;
	private String Name;

	private int VehicleMaxWeight;
	private int BayNumber;
	private String LoadMobileStatus;
	private boolean IsLocked;
	private int PickerID;

	private int DriverID;
	private double Weight;
	private String IsQC;

	public PickLoad() {
		super();
	}

	public PickLoad(int loadID, String loadCode, String loadStatus,
			String createDate, String plannedDeliveryDate, String driverName , int bayNumber,String loadMobileStatus,
					double weight,String carrierName, String isQC) {
		super();
		LoadID = loadID;
		LoadCode = loadCode;
		LoadStatus = loadStatus;
		CreatedDate = createDate;
		PlannedDeliveryDate = plannedDeliveryDate;
		DriverName = driverName;
		BayNumber = bayNumber;
		LoadMobileStatus = loadMobileStatus;
		Weight = weight;
		CarrierName = carrierName;
		IsQC = isQC;
	}

	public String isQC() {
		return IsQC;
	}

	public void setQC(String QC) {
		IsQC = QC;
	}

	public int getLoadID() {
		return LoadID;
	}

	public void setLoadID(int loadID) {
		LoadID = loadID;
	}

	public String getLoadCode() {
		return LoadCode;
	}

	public void setLoadCode(String loadCode) {
		LoadCode = loadCode;
	}

	public String getLoadStatus() {
		return LoadStatus;
	}

	public void setLoadStatus(String loadStatus) {
		LoadStatus = loadStatus;
	}

	public int getCreatedByUserID() {
		return CreatedByUserID;
	}

	public void setCreatedByUserID(int createdByUserID) {
		CreatedByUserID = createdByUserID;
	}

	public String getCreatedDate() {
		return CreatedDate;
	}

	public void setCreatedDate(String createdDate) {
		CreatedDate = createdDate;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPlannedDeliveryDate() {
		return PlannedDeliveryDate;
	}

	public void setPlannedDeliveryDate(String plannedDeliveryDate) {
		PlannedDeliveryDate = plannedDeliveryDate;
	}

	public String getCarrierName() {
		return CarrierName;
	}

	public void setCarrierName(String carrierName) {
		this.CarrierName = carrierName;
	}

	public String getDriverName() {
		return DriverName;
	}

	public void setDriverName(String driverName) {
		DriverName = driverName;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getVehicleMaxWeight() {
		return VehicleMaxWeight;
	}

	public void setVehicleMaxWeight(int vehicleMaxWeight) {
		VehicleMaxWeight = vehicleMaxWeight;
	}

	public int getBayNumber() {
		return BayNumber;
	}

	public void setBayNumber(int bayNumber) {
		BayNumber = bayNumber;
	}

	public String getLoadMobileStatus() {
		return LoadMobileStatus;
	}

	public void setLoadMobileStatus(String loadMobileStatus) {
		LoadMobileStatus = loadMobileStatus;
	}

	public boolean isIsLocked() {
		return IsLocked;
	}

	public void setIsLocked(boolean isLocked) {
		IsLocked = isLocked;
	}

	public int getPickerID() {
		return PickerID;
	}

	public void setPickerID(int pickerID) {
		PickerID = pickerID;
	}

	public int getDriverID() {
		return DriverID;
	}

	public void setDriverID(int driverID) {
		DriverID = driverID;
	}

	public double getWeight() {
		return Weight;
	}

	public void setWeight(double weight) {
		Weight = weight;
	}
	
}
