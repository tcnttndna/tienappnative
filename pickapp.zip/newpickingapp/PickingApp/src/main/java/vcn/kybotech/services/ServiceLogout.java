package vcn.kybotech.services;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;

import vcn.kybotech.pickingapp.R;

public class ServiceLogout extends Service {

    private int min = 0;
    private int sec = 59;
    private Handler mDemnguocHandler;
    private DemNguocRunnable mDemnguocRun;
    private String pid, did;

    public ServiceLogout() {

    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        FileSave file = new FileSave(getApplicationContext(), Constants.GET);
        mDemnguocHandler = new Handler();
        mDemnguocRun = new DemNguocRunnable();
        if (!file.getDeviceID().equals("") && file.getPickerID() != -1) {
            pid = String.valueOf(file.getPickerID());
            did = file.getDeviceID();
        }
        showDemNguoc();
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        mDemnguocHandler.removeCallbacks(mDemnguocRun);
        super.onDestroy();
    }

    public class DemNguocRunnable implements Runnable {
        @Override
        public void run() {
            handleDemnguoc(pid, did);
        }
    }

    private void showDemNguoc() {
        mDemnguocHandler.removeCallbacks(mDemnguocRun);
        mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
    }

    private void handleDemnguoc(String pid, String did) {
        try {
            sec--;
            if (sec < 0) {
                min--;
                sec = 59;
            }
//        Toast.makeText(this, min + ":" + sec, Toast.LENGTH_SHORT).show();
            mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
            if (min == 0 && sec == 0) {
//                Toast.makeText(this, "Gửi Request", Toast.LENGTH_SHORT).show();
                min = 0;
                sec = 59;
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair(Constants.appname, "NewPickingApp"));
                params.add(new BasicNameValuePair(Constants.type, Constants.type_checkdevice));
                params.add(new BasicNameValuePair(Constants.pickerid, pid));
                params.add(new BasicNameValuePair(Constants.deviceid, did));

				/*Bat dau tien hanh dang nhap*/
                checkConnectServiceAndLogin(Constants.LINK_PICK_ACCOUNT, params);
                showDemNguoc();
            }
        } catch (Exception ex) {
            Log.e("Service Handle", ex.getMessage());
        }
    }

    protected void checkConnectServiceAndLogin(final String url, final List<NameValuePair> params) {
        new AsyncTask<String, Void, JSONObject>() {

            protected void onPreExecute() {
            }

            @Override
            protected JSONObject doInBackground(String... arg0) {
                JSONObject jsonObject = new JSONParser().getJsonTuUrl(url, params);
                return jsonObject;
            }

            protected void onPostExecute(JSONObject jsonObject) {
                try {
                    if (jsonObject == null) {
                        return;
                    } else if (jsonObject.getString("success").equals("true")) {
                        FileSave file = new FileSave(getApplicationContext(), Constants.PUT);
                        file.putIsDeviceLogin(true);
//                        Toast.makeText(ServiceLogout.this, pid + " Đang online..." + did, Toast.LENGTH_SHORT).show();
                        Log.e("Service Logout", "Running...");
                    } else if (jsonObject.getString("success").equals("false")) {
                        mDemnguocHandler.removeCallbacks(mDemnguocRun);
//                        onDestroy();
                        FileSave file = new FileSave(getApplicationContext(), Constants.PUT);
                        file.putIsRememberLogin(false);
                        file.putIsDeviceLogin(false);
                        dialogLogoutService();
//                        Toast.makeText(ServiceLogout.this, pid + " Đã log out..." + did, Toast.LENGTH_SHORT).show();
                        Log.e("Service Logout", "Log out");
                    } else {
                        Log.e("LoginFramgment", "loginfalse - out of");
                    }
                } catch (JSONException e) {
                    Log.e("Service Logout", e.getMessage());
                }
            }
        }.execute();
    }

    public void dialogLogoutService() {
        try {
            final Notification.Builder builder = new Notification.Builder(this);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                builder.setStyle(new Notification.BigTextStyle(builder)
                        .bigText("Your account has been login with another device. Please reopen this application to continue working!")
                        .setBigContentTitle("Picking App"))
                        .setContentTitle("Picking App")
                        .setSmallIcon(R.drawable.ic_launcher);
                final NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify(0, builder.build());
            }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


}
