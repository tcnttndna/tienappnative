package vcn.kybotech.model;

import java.util.List;

public class Unpack {
	private int PackId;
	private int PartId;
	private int GRNID;
	private String PartName;
	private double Volume;
	private String PackSupplierId;
	private int GRNItemID;
	private String UnpackStatus;
	private List<PackDetails> packdetails;
	public Unpack() {
		super();
	}
	public Unpack(int packId, int partId, int gRNID, String partName,
			double volume, String packSupplierId, int gRNItemID,
			String unpackStatus, List<PackDetails> packdetails) {
		super();
		PackId = packId;
		PartId = partId;
		GRNID = gRNID;
		PartName = partName;
		Volume = volume;
		PackSupplierId = packSupplierId;
		GRNItemID = gRNItemID;
		UnpackStatus = unpackStatus;
		this.packdetails = packdetails;
	}
	public int getPackId() {
		return PackId;
	}
	public void setPackId(int packId) {
		PackId = packId;
	}
	public int getPartId() {
		return PartId;
	}
	public void setPartId(int partId) {
		PartId = partId;
	}
	public int getGRNID() {
		return GRNID;
	}
	public void setGRNID(int gRNID) {
		GRNID = gRNID;
	}
	public String getPartName() {
		return PartName;
	}
	public void setPartName(String partName) {
		PartName = partName;
	}
	public double getVolume() {
		return Volume;
	}
	public void setVolume(double volume) {
		Volume = volume;
	}
	public String getPackSupplierId() {
		return PackSupplierId;
	}
	public void setPackSupplierId(String packSupplierId) {
		PackSupplierId = packSupplierId;
	}
	public int getGRNItemID() {
		return GRNItemID;
	}
	public void setGRNItemID(int gRNItemID) {
		GRNItemID = gRNItemID;
	}
	public String getUnpackStatus() {
		return UnpackStatus;
	}
	public void setUnpackStatus(String unpackStatus) {
		UnpackStatus = unpackStatus;
	}
	public List<PackDetails> getPackdetails() {
		return packdetails;
	}
	public void setPackdetails(List<PackDetails> packdetails) {
		this.packdetails = packdetails;
	}
}
