package vcn.kybotech.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.adapter.SipnnerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.AddStockControl;
import vcn.kybotech.controller.AjustStockControl;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.controller.CurrentStockControl;
import vcn.kybotech.controller.UpdateVersionControl;
import vcn.kybotech.model.CurrentStock;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.model.WareHouseItem;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class AjustStockFragment extends Fragment {
    private EditText etNewQty;
    private ImageView imgNewQty;
    public static EditText etTapToScan;
    private ImageView imgTapToScan;
    private LinearLayout layCheck;
    private ImageView imgCheck;
    private ProgressBar proLoad;
    private Spinner spinWarehose;
    private TextView tvCurrent;
    private TextView tvAllocated;
    private ImageButton btnscan;
    private Button btnConfirm;
    private int intWarehose = 0;
    public static ArrayList<CurrentStock> listCurrentStock;
    private JSONArray arrJSON = null;
    private List<SpinnerItem> itemSpinnerWareHouse;
    private List<WareHouseItem> itemWareHouse;
    private int CHECK_QTY = 2;
    private Dialog dialog;
    private int SCAN_AJUST = 6;
    private Boolean includedallocated = true;
//    private int min = 0;
//    private int sec = 59;
//    private Handler mDemnguocHandler;
//    private DemNguocRunnable mDemnguocRun;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_ajust_stock,container,false);

//        mDemnguocHandler = new Handler();
//        mDemnguocRun = new DemNguocRunnable();
//        showDemNguoc();

        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        if (isOnline()) {
            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
        } else {
            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
        ((AppCompatActivity)getActivity()).getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(false);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);
        HamKhoiTao(view);

        return view;
    }



    public void HamKhoiTao(View v) {
        // KHAI BAO GIAO DIEN
        etNewQty = (EditText) v.findViewById(R.id.fragment_ajust_stock_new_qty);
        imgNewQty = (ImageView) v.findViewById(R.id.fragment_ajust_stock_new_qty_img);
        etTapToScan = (EditText) v.findViewById(R.id.fragment_ajust_stock_taptoscan);
        imgTapToScan = (ImageView) v.findViewById(R.id.fragment_ajust_stock_taptoscan_img);
        layCheck = (LinearLayout) v.findViewById(R.id.fragment_ajust_stock_layout_check);
        imgCheck = (ImageView) v.findViewById(R.id.fragment_ajust_stock_images_check);
        proLoad = (ProgressBar) v.findViewById(R.id.fragment_ajust_stock_progressbar_load);
        spinWarehose = (Spinner) v.findViewById(R.id.fragment_ajust_stock_spinner_warehouse);
        tvCurrent = (TextView) v.findViewById(R.id.fragment_ajust_stock_textview_current);
        tvAllocated = (TextView) v.findViewById(R.id.fragment_ajust_stock_textview_allocated);
        btnConfirm = (Button) v.findViewById(R.id.fragment_ajust_stock_button_confirm);
        btnscan = (ImageButton) v.findViewById(R.id.fragment_ajust_stock_button_button_take_photo_ajust);
        listCurrentStock = new ArrayList<CurrentStock>();
        // ==================
        // SET COMBOBOX WHARE HOUSE
        getWareHouse();
        // ========================
        BatSuKien();
    }

    public void BatSuKien() {
        etNewQty.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
                if (etNewQty.getText().toString().length() > 0) {
                    imgNewQty.setVisibility(View.VISIBLE);
                } else {
                    imgNewQty.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
            }

            @Override
            public void afterTextChanged(Editable arg0) {

            }
        });

        imgNewQty.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                etNewQty.setText(null);
                etNewQty.requestFocus();
            }
        });

        etTapToScan.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
                if (etTapToScan.getText().toString().length() > 0) {
                    imgTapToScan.setVisibility(View.VISIBLE);
                    if (etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN) {
                        getCurrentStock();
                        etNewQty.setText("1");
                    }
                } else {
                    tvCurrent.setText("0");
                    tvAllocated.setText("0");
                    imgTapToScan.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
            }

            @Override
            public void afterTextChanged(Editable arg0) {

            }
        });

        imgTapToScan.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                etTapToScan.setText(null);
                etTapToScan.requestFocus();
            }
        });

        layCheck.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = Integer.parseInt(imgCheck.getTag().toString());
                if (i == 0) {
                    imgCheck.setBackgroundResource(R.drawable.ic_checked_true);
                    imgCheck.setTag(1);
                    includedallocated = true;
                } else {
                    imgCheck.setBackgroundResource(R.drawable.ic_checked_false);
                    imgCheck.setTag(0);
                    includedallocated = false;
                }
            }
        });

        spinWarehose.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                intWarehose = arg2;
                if (listCurrentStock.size() != 0) {
                    for (int i = 0; i < listCurrentStock.size(); i++) {
                        if (listCurrentStock.get(i).getWarehouseID() == itemWareHouse
                                .get(intWarehose).getWarehouseID()) {
                            tvCurrent.setText(String.valueOf(listCurrentStock
                                    .get(i).getFreeStock()));
                            tvAllocated.setText(String.valueOf(listCurrentStock
                                    .get(i).getAllocatedStock()));
                            break;
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });

        btnConfirm.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etTapToScan.getText().toString().trim().length() == Constants.LENGTH_TAP_TO_SCAN) {
                    if (etNewQty.getText().toString().trim().length() == 0 ||
                            Integer.parseInt(etNewQty.getText().toString().trim()) == 0) {
                        dialogAddLocation(CHECK_QTY);
                    } else {
                        uploadAjustStrock();
                    }
                } else {
                    etTapToScan.requestFocus();
                    OpenKeyBoard(getActivity());
                }
            }
        });

        btnscan.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onSCanBarCode(SCAN_AJUST);
            }
        });
    }

    public void getWareHouse() {
        new AsyncTask<String, String, JSONObject>() {
            JSONObject objJSON;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                proLoad.setVisibility(View.VISIBLE);
            }

            @Override
            protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
                AddStockControl ctrAddStock = new AddStockControl(
                        getActivity());
                objJSON = ctrAddStock.getWareHouse();
                return objJSON;
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;

            }

            @Override
            protected void onPostExecute(JSONObject objJSON) {
                if (objJSON != null) {
                    try {
                        if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                            if (objJSON.getString(Constants.KEY_SUCCESS)
                                    .equals(Constants.KEY_TRUE)) {
                                itemSpinnerWareHouse = new ArrayList<SpinnerItem>();
                                itemWareHouse = new ArrayList<WareHouseItem>();
                                JSONArray obj = objJSON.getJSONArray("data");
                                for (int i = 0; i < obj.length(); i++) {
                                    JSONObject objItem = obj.getJSONObject(i);
                                    itemSpinnerWareHouse
                                            .add(new SpinnerItem(
                                                    objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
                                    itemWareHouse
                                            .add(new WareHouseItem(
                                                    objItem.getInt(WareHouseItem.COLUMN_WARE_HOUSE_ID),
                                                    objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
                                }
                                SipnnerAdapter adapter = new SipnnerAdapter(
                                        getActivity(),
                                        R.layout.custom_spinner,
                                        itemSpinnerWareHouse);
                                spinWarehose.setAdapter(adapter);

                                // SET HIEN THI CHO COMBOBOX WHARE HOUSE
                                for (int i = 0; i < itemWareHouse.size(); i++) {
                                    if (itemWareHouse.get(i).getWarehouseID() == 19) {
                                        spinWarehose.setSelection(i);
                                        break;
                                    }
                                }
                                // ======================================
                            }
                        } else {
                            Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                    DialogDisconnectToServer();
                }
                proLoad.setVisibility(View.GONE);
            }
        }.execute();
    }

    public void getCurrentStock() {
        new AsyncTask<String, String, JSONObject>() {
            JSONObject objJSON;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                proLoad.setVisibility(View.VISIBLE);
            }

            @Override
            protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
                try {
                    CurrentStockControl ctrCurrentStock = new CurrentStockControl(
                            getActivity());
                    int partid = Integer.parseInt(etTapToScan.getText().toString()
                            .trim());
                    objJSON = ctrCurrentStock.getCurrentStock(partid);
                    return objJSON;
                } catch (Exception ex) {
                    return null;
                }
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;

            }

            @Override
            protected void onPostExecute(JSONObject objJSON) {
                if (objJSON != null) {
                    try {
                        if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                            if (objJSON.getString(Constants.KEY_SUCCESS)
                                    .equals(Constants.KEY_TRUE)) {
                                listCurrentStock.clear();
                                arrJSON = objJSON.getJSONArray("data");
                                if (arrJSON.length() == 0) {
                                    Toast.makeText(getActivity(),
                                            "No items available",
                                            Toast.LENGTH_SHORT).show();
                                }
                                for (int i = 0; i < arrJSON.length(); i++) {
                                    JSONObject obj = arrJSON.getJSONObject(i);
                                    CurrentStock objCurrentStock = new CurrentStock();
                                    objCurrentStock
                                            .setPartID(obj
                                                    .getInt(CurrentStock.COLUMN_PART_ID));
                                    objCurrentStock
                                            .setPartName(obj
                                                    .getString(CurrentStock.COLUMN_PART_NAME));
                                    objCurrentStock
                                            .setWarehouseID(obj
                                                    .getInt(CurrentStock.COLUMN_WARE_HOUSE_ID));
                                    objCurrentStock
                                            .setWarehouseName(obj
                                                    .getString(CurrentStock.COLUMN_WARE_HOUSE_NAME));
                                    objCurrentStock
                                            .setFreeStock(obj
                                                    .getInt(CurrentStock.COLUMN_FREE_STOCK));
                                    objCurrentStock
                                            .setAllocatedStock(obj
                                                    .getInt(CurrentStock.COLUMN_ALLOCATED_STOCK));
                                    objCurrentStock
                                            .setPickedNotLoadedStock(obj
                                                    .getInt(CurrentStock.COLUMN_PICKED_NOT_LOADED_STOCK));
                                    objCurrentStock
                                            .setShippingPriority(obj
                                                    .getInt(CurrentStock.COLUMN_SHIPPING_PRIORITY));
                                    listCurrentStock.add(objCurrentStock);
                                }
                                // XU LY VIEW DU LIEU SAU KHI LOAD
                                for (int i = 0; i < listCurrentStock.size(); i++) {
                                    if (listCurrentStock.get(i)
                                            .getWarehouseID() == itemWareHouse
                                            .get(intWarehose).getWarehouseID()) {
                                        tvCurrent
                                                .setText(String
                                                        .valueOf(listCurrentStock
                                                                .get(i)
                                                                .getFreeStock()));
                                        tvAllocated.setText(String
                                                .valueOf(listCurrentStock
                                                        .get(i)
                                                        .getAllocatedStock()));
                                        break;
                                    }
                                }
                            } else {
                                if (objJSON.getString(Constants.KEY_SUCCESS)
                                        .equals(Constants.KEY_FALSE)) {
                                    Toast.makeText(getActivity(),
                                            objJSON.getString(Constants.KEY_MESSAGE),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                    DialogDisconnectToServer();
                }
                proLoad.setVisibility(View.GONE);
            }
        }.execute();
    }

    public void dialogAddLocation(final int type) {
        dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.custom_dialog);
        TextView tvnoidung = (TextView) dialog
                .findViewById(R.id.custom_dialog_textview_noidung);
        final EditText etlocation = (EditText) dialog
                .findViewById(R.id.custom_dialog_edittext_location);
        final ImageView imglocation = (ImageView) dialog
                .findViewById(R.id.custom_dialog_edittext_location_img);
        Button btncancel = (Button) dialog
                .findViewById(R.id.custom_dialog_button_cancel);
        Button btnok = (Button) dialog
                .findViewById(R.id.custom_dialog_button_ok);

        if (type == CHECK_QTY) {
            dialog.setTitle(Constants.NOTIFICATION);
            tvnoidung.setText(Constants.QUANTITY_IS_NOT_NUMBER);
            etlocation.setVisibility(View.GONE);
            btncancel.setVisibility(View.GONE);
        }

        etlocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
                if (etlocation.getText().toString().length() > 0) {
                    imglocation.setVisibility(View.VISIBLE);
                } else {
                    imglocation.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {

            }

            @Override
            public void afterTextChanged(Editable arg0) {

            }
        });
        imglocation.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                etlocation.setText(null);
            }
        });
        btncancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                dialog.dismiss();
            }
        });

        btnok.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (type == CHECK_QTY) {
                    etNewQty.requestFocus();
                }
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public void onSCanBarCode(int types) {
        try {
            Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
            intent.putExtra("SCAN_FORMATS", "QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
            startActivityForResult(intent, types);
        } catch (Exception e) {
            Log.e("NOT SCAN", e.toString());
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SCAN_AJUST && resultCode == RESULT_OK) {
            try {

                String qrcode = (data.getStringExtra("SCAN_RESULT"));
                BarcodeSubString barcodeSubString = new BarcodeSubString();
                qrcode = barcodeSubString.CutBarcode(qrcode, "");
                etTapToScan.setText(qrcode);
            } catch (Exception e) {
                dialogPartIDFail();
            }
        }
    }

    public void uploadAjustStrock() {
        new AsyncTask<String, String, JSONObject>() {
            JSONObject objJSON;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                proLoad.setVisibility(View.VISIBLE);
            }

            @Override
            protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
                try {
                    AjustStockControl ctrAjustStock = new AjustStockControl(getActivity());
                    int partid = Integer.parseInt(etTapToScan.getText().toString()
                            .trim());
                    int warehouseid = itemWareHouse.get(intWarehose).getWarehouseID();
                    String freeqty = tvCurrent.getText().toString();
                    String allocatedqty = tvAllocated.getText().toString();
                    String newqty = etNewQty.getText().toString();
                    objJSON = ctrAjustStock.uploadAjustStock(partid, warehouseid, freeqty, allocatedqty, newqty, String.valueOf(includedallocated));
                    return objJSON;
                } catch (Exception ex) {
                    return null;
                }
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
            }

            @Override
            protected void onPostExecute(JSONObject objJSON) {
                if (objJSON != null) {
                    try {
                        if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                            if (objJSON.getString(Constants.KEY_SUCCESS)
                                    .equals(Constants.KEY_TRUE)) {
                                Toast.makeText(
                                        getActivity(),
                                        Constants.ADJUST_STOCK_SUCCESSFUL,
                                        Toast.LENGTH_SHORT).show();
                                tvCurrent.setText("0");
                                tvAllocated.setText("0");
                                etNewQty.setText(null);
                                imgCheck.setBackgroundResource(R.drawable.ic_checked_true);
                                imgCheck.setTag(1);
                                includedallocated = true;
                                etTapToScan.setText(null);
                                etTapToScan.requestFocus();
                            } else {
                                if (objJSON.getString(Constants.KEY_SUCCESS)
                                        .equals(Constants.KEY_FALSE)) {
                                    Toast.makeText(getActivity(),
                                            objJSON.getString(Constants.KEY_MESSAGE),
                                            Toast.LENGTH_SHORT).show();
                                    etTapToScan.requestFocus();
                                }
                            }
                        } else {
                            Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("Error", Constants.ERR_SERVICE_NETWORK);
                    DialogDisconnectToServer();
                }
                proLoad.setVisibility(View.GONE);
            }
        }.execute();
    }


//    @SuppressLint("NewApi")
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getActivity().getMenuInflater().inflate(R.menu.menu_stock_control, menu);
//        int version_in_manifest = 0;
//        try {
//            version_in_manifest = getActivity().getPackageManager()
//                    .getPackageInfo(getActivity().getPackageName(), 0).versionCode;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (Constants.LINK_DONE.equals(Constants.LINK_COMPARE_VIEW_VERSION)) {
//            menu.findItem(R.id.test_menu).setTitle(Constants.VERSION_TYPE + String.valueOf(version_in_manifest));
//        } else {
//            menu.findItem(R.id.test_menu).setTitle(R.string.Test);
//        }
//        return true;
//    }

    @SuppressLint("NewApi")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case R.id.test_menu:
                break;
            case R.id.menu_logout:
                dialog();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void DialogDisconnectToServer() {
        try {
            Log.e("LoginFramgment", "disconnect to server");
            Builder dialog = new AlertDialog.Builder(getActivity());
            dialog.setTitle("Message");
            dialog.setMessage(getString(R.string.fragment_login_Message_no_response_checkagain));
            dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {

                }
            });
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.LOGOUT);
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent returnIntent = new Intent();
                getActivity().setResult(RESULT_OK, returnIntent);
                getActivity().finish();
            }
        });
        dialog.setNegativeButton("No", null);
        dialog.show();
    }

    // For open keyboard
    public void OpenKeyBoard(Context mContext) {
        InputMethodManager imm = (InputMethodManager) mContext
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    // For close keyboard
    public void CloseKeyBoard(Context mContext) {
        InputMethodManager imm = (InputMethodManager) mContext
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
    }

    public void dialogPartIDFail() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.PARTID_FAIL);
        dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dialog.show();
    }

    private Handler mHandler = new Handler();

    private Runnable setTitleColor = new Runnable() {
        @Override
        public void run() {
            try {
                new isOnline().execute();
                mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

//        mHandler.removeCallbacks(setTitleColor);
//        try {
//            mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        } catch (Exception ex) {
//
//        }
    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    private class isOnline extends AsyncTask<String, String, JSONObject> {
        JSONObject objJSON;
        int version_in_manifest = 0;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... params) {
//			ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//			NetworkInfo netInfo = cm.getActiveNetworkInfo();
//			if (netInfo != null && netInfo.isConnected()) {
//				try {
//					URL url = new URL(Constants.GOOGLE_LINK);
//					HttpURLConnection httpUrlConn = (HttpURLConnection) url
//							.openConnection();
//					httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//					httpUrlConn.connect();
//					if (httpUrlConn.getResponseCode() == 200) {
            UpdateVersionControl ctrUpdateVersion = new UpdateVersionControl();
            try {
                version_in_manifest = getActivity().getPackageManager()
                        .getPackageInfo(getActivity().getPackageName(), 0).versionCode;
            } catch (NameNotFoundException e) {
                e.printStackTrace();
            }
            objJSON = ctrUpdateVersion.requestServer(version_in_manifest);
            return objJSON;
//					}
//				} catch (MalformedURLException e) {
//					e.printStackTrace();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//			return null;

        }

        @Override
        protected void onPostExecute(JSONObject objJSON) {
            if (objJSON != null) {
                try {
                    if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                        if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
                        } else {
                            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
            }
        }
    }

//    public class DemNguocRunnable implements Runnable {
//        @Override
//        public void run() {
//            handleDemnguoc();
//        }
//    }
//
//    private void showDemNguoc() {
//        mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//    }
//
//    private void handleDemnguoc() {
//        try {
//            sec--;
//            if (sec < 0) {
//                min--;
//                sec = 59;
//            }
////        Toast.makeText(this, min + ":" + sec, Toast.LENGTH_SHORT).show();
//            mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//            if (min == 0 && sec == 29) {
//                Toast.makeText(getActivity(), "Gửi Request", Toast.LENGTH_SHORT).show();
//                FileSave file = new FileSave(getActivity(), Constants.GET);
//                if (!file.getIsDeviceLogin()) {
//                    Intent intent = new Intent();
//                    file = new FileSave(getActivity(), Constants.PUT);
//                    file.putIsDeviceLogin(true);
//                    getActivity().setResult(Constants.RESULT_SERVICE_LOGOUT, intent);
//                    getActivity().finish();
//                }
//                min = 0;
//                sec = 59;
//                showDemNguoc();
//            }
//        } catch (Exception ex) {
//            Log.e("Service Handle", ex.getMessage());
//        }
//    }

//    @Override
//    public void onBackPressed() {
//        Intent intent = new Intent();
//        setResult(Constants.RESULT_SERVICE_LOGOUT, intent);
//        finish();
//    }
}
