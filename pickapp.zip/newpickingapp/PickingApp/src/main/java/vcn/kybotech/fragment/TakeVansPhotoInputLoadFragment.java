package vcn.kybotech.fragment;

import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.TakeVansPhotoControl;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.R;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.desarrollodroide.libraryfragmenttransactionextended.FragmentTransactionExtended;

public class TakeVansPhotoInputLoadFragment extends Fragment{
	private EditText etLoadId;
	private Button btnConfirm;
	private ImageView imgLoadId;
	private ProgressBar proLoad;
	private TextView tvEmpty,tvNull1,tvNull2;
	
	private Dialog dialog;
	private int CHECK_LOAD_ID = 1;
	private int CHECK_REQUEST = 2;
	
	private RadioGroup radioPhotoType;
	private int PhotoType = 1; //1. Van Photo, 2. After Delivery
	
	private FragmentManager fragment_manager;
	
	
	public TakeVansPhotoInputLoadFragment callHamTao(){
		TakeVansPhotoInputLoadFragment mFragment = new TakeVansPhotoInputLoadFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_take_vans_photo_input, container, false);
		
		HamKhoiTao(rootView);
		return rootView;
	}


	public void HamKhoiTao(View v){
		etLoadId = (EditText) v.findViewById(R.id.fragment_take_vans_photo_input_textview_loadId);
		btnConfirm = (Button) v.findViewById(R.id.fragment_take_vans_photo_input_button_confirm);
		imgLoadId = (ImageView) v.findViewById(R.id.fragment_take_vans_photo_input_imageView_loadId);
		proLoad = (ProgressBar) v.findViewById(R.id.fragment_take_vans_photo_input_progressbar_load);
		radioPhotoType = (RadioGroup) v.findViewById(R.id.fragment_take_vans_photo_input_radio_photo_type);
		tvEmpty = (TextView) v.findViewById(R.id.tv_empty);
		tvNull1 = (TextView) v.findViewById(R.id.null_block1);
		tvNull2 = (TextView) v.findViewById(R.id.null_block2);
		OpenKeyBoard(TakeVansPhotoInputLoadFragment.this.getActivity());
		BatSuKien();
	}
	
	public void BatSuKien(){
		etLoadId.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				if(etLoadId.getText().toString().length() > 0){
					imgLoadId.setVisibility(View.VISIBLE);
				}else{
					imgLoadId.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
			}
		});
		
		imgLoadId.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etLoadId.setText(null);
				etLoadId.requestFocus();
			}
		});
		
		btnConfirm.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(etLoadId.getText().toString().length() > 0){
					CloseKeyBoard(TakeVansPhotoInputLoadFragment.this.getActivity());
					Confirm();
				}else{
					dialogConfirm(CHECK_LOAD_ID);
				}
			}
		});
		
		radioPhotoType.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				if (checkedId == R.id.fragment_take_vans_photo_input_radioVan) {
					PhotoType = 1;
				}else if (checkedId == R.id.fragment_take_vans_photo_input_radioAD) {
					PhotoType = 2;
				}else {
					PhotoType = 3;
				}
			}
		});

		tvEmpty.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});
		tvNull1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});
		tvNull2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});
	}
	
	public void dialogConfirm(final int type) {
		dialog = new Dialog(TakeVansPhotoInputLoadFragment.this.getActivity());
		dialog.setContentView(R.layout.custom_dialog);
		TextView tvnoidung = (TextView) dialog
				.findViewById(R.id.custom_dialog_textview_noidung);
		final EditText etlocation = (EditText) dialog
				.findViewById(R.id.custom_dialog_edittext_location);
		final ImageView imglocation = (ImageView) dialog
				.findViewById(R.id.custom_dialog_edittext_location_img);
		Button btncancel = (Button) dialog
				.findViewById(R.id.custom_dialog_button_cancel);
		Button btnok = (Button) dialog
				.findViewById(R.id.custom_dialog_button_ok);
		
		if (type == CHECK_LOAD_ID) {
			dialog.setTitle(Constants.NOTICE);
			tvnoidung.setText(Constants.MESSAGE_CANT_FIND_LOAD);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		
		if (type == CHECK_REQUEST) {
			dialog.setTitle(Constants.NOTICE);
			tvnoidung.setText("Can't find load have ID "+ etLoadId.getText().toString().trim() +", please input correct LoadId and try again!");
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}

		etlocation.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etlocation.getText().toString().length() > 0) {
					imglocation.setVisibility(View.VISIBLE);
				} else {
					imglocation.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {

			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		imglocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etlocation.setText(null);
			}
		});
		btncancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});

		btnok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (type == CHECK_LOAD_ID) {
					etLoadId.requestFocus();
					OpenKeyBoard(TakeVansPhotoInputLoadFragment.this.getActivity());
				}
				if (type == CHECK_REQUEST) {
					etLoadId.setText(null);
					etLoadId.requestFocus();
					OpenKeyBoard(TakeVansPhotoInputLoadFragment.this.getActivity());
				}
				dialog.dismiss();
			}
		});

		dialog.show();
	}
	
	public void Confirm(){
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) TakeVansPhotoInputLoadFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
							TakeVansPhotoControl ctrTakeVansPhoto = new TakeVansPhotoControl();
							int LoadId = Integer.parseInt(etLoadId.getText().toString().trim());
							objJSON = ctrTakeVansPhoto.confirm(LoadId);
							return objJSON;
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
								if(!objJSON.getString(Constants.KEY_LOAD_CODE).equals(Constants.KEY_NONE)){

									FileSave file = new FileSave(TakeVansPhotoInputLoadFragment.this.getActivity(), Constants.PUT);
									file.putLoadId(Integer.parseInt(etLoadId.getText().toString().trim()));
									file.putLoadCode(objJSON.getString(Constants.KEY_LOAD_CODE));
									file.putCountPhoto(objJSON.getInt(Constants.KEY_COUNT_PHOTO));
									file.putCountPhotoAD(objJSON.getInt(Constants.KEY_COUNT_PHOTOAD));
									file.putPhotoType(PhotoType);
									callTakeVansPhotoPicture();
								}else{
									dialogConfirm(CHECK_REQUEST);
								}
							} else {
								if (!objJSON.getBoolean(Constants.KEY_SUCCESS)) {
									dialogConfirm(CHECK_REQUEST);
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}
	
	public void DialogDisconnectToServer(){
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new  AlertDialog.Builder(TakeVansPhotoInputLoadFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					
				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}
	
	public void callTakeVansPhotoPicture(){
		Fragment fragment = null;
		fragment_manager = getFragmentManager();
		fragment = new TakeVansPhotoPictureFragment().callHamTao();
		if (fragment != null){
            FragmentTransaction fragmentTransaction = fragment_manager.beginTransaction();
            FragmentTransactionExtended fragmentTransactionExtended = new FragmentTransactionExtended(TakeVansPhotoInputLoadFragment.this.getActivity(), fragmentTransaction, fragment, fragment,R.id.activity_take_vans_photo_layout_frame);
            fragmentTransactionExtended.addTransition(Constants.ANIMATION);
            fragmentTransactionExtended.commit();
		}
	}
}
