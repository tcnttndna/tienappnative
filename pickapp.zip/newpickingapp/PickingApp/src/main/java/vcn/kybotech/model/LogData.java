package vcn.kybotech.model;

public class LogData {
	private int Id;
	private int PickerId;
	private String PickerName;
	private int Action;
	private int LoadId;
	private String OrderRef;
	private String Description;
	private double Lat;
	private double Lng;
	private String Version;
	private String PhoneDate;
	public LogData() {
		super();
	}
	public LogData(int id, int pickerId, String pickerName, int action,
			int loadId, String orderRef, String description, double lat,
			double lng, String version, String phoneDate) {
		super();
		Id = id;
		PickerId = pickerId;
		PickerName = pickerName;
		Action = action;
		LoadId = loadId;
		OrderRef = orderRef;
		Description = description;
		Lat = lat;
		Lng = lng;
		Version = version;
		PhoneDate = phoneDate;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getPickerId() {
		return PickerId;
	}
	public void setPickerId(int pickerId) {
		PickerId = pickerId;
	}
	public String getPickerName() {
		return PickerName;
	}
	public void setPickerName(String pickerName) {
		PickerName = pickerName;
	}
	public int getAction() {
		return Action;
	}
	public void setAction(int action) {
		Action = action;
	}
	public int getLoadId() {
		return LoadId;
	}
	public void setLoadId(int loadId) {
		LoadId = loadId;
	}
	public String getOrderRef() {
		return OrderRef;
	}
	public void setOrderRef(String orderRef) {
		OrderRef = orderRef;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public double getLat() {
		return Lat;
	}
	public void setLat(double lat) {
		Lat = lat;
	}
	public double getLng() {
		return Lng;
	}
	public void setLng(double lng) {
		Lng = lng;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	public String getPhoneDate() {
		return PhoneDate;
	}
	public void setPhoneDate(String phoneDate) {
		PhoneDate = phoneDate;
	}
}
