package vcn.kybotech.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.RequestQueue;

import java.util.List;

import vcn.kybotech.model.PickReturnPart;
import vcn.kybotech.pickingapp.R;

@SuppressLint("SimpleDateFormat")
public class PartsReturnLoadAdapter extends ArrayAdapter<PickReturnPart> {

    Context context;
    int ResID;
    List<PickReturnPart> listLoadAssigned;
    RequestQueue requestQueue;

    public PartsReturnLoadAdapter(Context context, int resource, List<PickReturnPart> objects) {
        super(context, resource, objects);
        this.context = context;
        this.ResID = resource;
        listLoadAssigned = objects;

    }


    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final PartHolder partHolder;
        View itemView = convertView;
        if (itemView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            partHolder = new PartHolder();
            itemView = inflater.inflate(ResID, parent, false);

            partHolder.btnAddToStock = (Button) itemView.findViewById(R.id.item_part_btnAddToStock);
            partHolder.soThuTu = (TextView) itemView.findViewById(R.id.item_part_soThuTu);
            partHolder.PartID = (TextView) itemView.findViewById(R.id.item_part_partID);
            partHolder.PartName = (TextView) itemView.findViewById(R.id.item_part_partName);
            partHolder.PartQTy = (TextView) itemView.findViewById(R.id.item_part_QTy);
            itemView.setTag(partHolder);
        } else {
            partHolder = (PartHolder) itemView.getTag();
        }


        try {
            if (listLoadAssigned.get(position).isConfirmed()) {
                partHolder.btnAddToStock.setVisibility(View.GONE);
                partHolder.PartID.setTextColor(Color.RED);
                partHolder.PartName.setTextColor(Color.RED);
                partHolder.PartQTy.setTextColor(Color.RED);
            } else {
                partHolder.btnAddToStock.setVisibility(View.VISIBLE);
                partHolder.PartID.setTextColor(Color.parseColor("#009900"));
                partHolder.PartName.setTextColor(Color.parseColor("#009900"));
                partHolder.PartQTy.setTextColor(Color.parseColor("#404040"));
//				partHolder.PartTotalPack.setTextColor(Color.parseColor("#404040"));
//				partHolder.PartLoc.setTextColor(Color.parseColor("#404040"));
//				partHolder.PartFreeStock.setTextColor(Color.parseColor("#404040"));
            }
            partHolder.soThuTu.setText((position + 1) + ".   ");
            int iPartID = listLoadAssigned.get(position).getPartID();
            partHolder.PartID.setText(String.format("%05d", iPartID));
            partHolder.PartName.setText(listLoadAssigned.get(position).getPartName());
            int sQTy = listLoadAssigned.get(position).getPartQuantity();
            partHolder.PartQTy.setText(sQTy + "");

            partHolder.btnAddToStock.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((ListView) parent).performItemClick(view, position, 0); // Let the event be handled in onItemClick()
                }
            });
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return itemView;
    }


    public static class PartHolder {
        TextView soThuTu;
        TextView PartID;
        TextView PartName;
        TextView PartQTy;
        Button btnAddToStock;
        //		TextView PartTotalPack;
//        TextView PartLoc;
        //		TextView PartFreeStock;
//        TextView CustomPart;
//        TextView PartGroup;
    }
}
