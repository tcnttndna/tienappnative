package vcn.kybotech.parseapi.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Admin-PC on 1/17/2018.
 */

public class Loadreturnfailorder {

    @SerializedName("success")
    @Expose
    private Boolean success;
    @SerializedName("data")
    @Expose
    private ArrayList<Datareturnfailoder> datareturnfailoder = null;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public ArrayList<Datareturnfailoder> getDatareturnfailoder() {
        return datareturnfailoder;
    }

    public void setDatareturnfailoder(ArrayList<Datareturnfailoder> datareturnfailoder) {
        this.datareturnfailoder = datareturnfailoder;
    }

}

