package vcn.kybotech.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.R;

@SuppressLint("SimpleDateFormat")
public class QCPartsPickerAdapter extends ArrayAdapter<PickPart> {

    Context context;
    int ResID;
    List<PickPart> listLoadAssigned;
//    GestureDetector gestureDetector;
//    private static final int SWIPE_MIN_DISTANCE = 120;
//    private static final int SWIPE_MAX_OFF_PATH = 250;
//    private static final int SWIPE_THRESHOLD_VELOCITY = 100;
//    private Animation inFromRight, outToRight, outToLeft, inFromLeft;

    //	List<PickPart> listLoadAssignedFilter;
    public QCPartsPickerAdapter(Context context, int resource, List<PickPart> objects) {
        super(context, resource, objects);
        this.context = context;
        this.ResID = resource;
//		listLoadAssignedFilter = objects;

        listLoadAssigned = objects;
//		listLoadAssigned.addAll(objects);

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        PartHolder partHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            partHolder = new PartHolder();
            convertView = inflater.inflate(R.layout.item_part_swipe, parent, false);
            partHolder.layout_swipe = (LinearLayout) convertView.findViewById(R.id.layout_swipe);
            partHolder.soThuTu = (TextView) convertView.findViewById(R.id.item_part_soThuTu);
            partHolder.PartID = (TextView) convertView.findViewById(R.id.item_part_partID);
            partHolder.PartName = (TextView) convertView.findViewById(R.id.item_part_partName);
            partHolder.PartQTy = (TextView) convertView.findViewById(R.id.item_part_QTy);
//			partHolder.PartTotalPack = (TextView) convertView.findViewById(R.id.item_part_TotalPack);
            partHolder.PartLoc = (TextView) convertView.findViewById(R.id.item_part_Loc);
//			partHolder.PartFreeStock = (TextView) convertView.findViewById(R.id.item_part_FreeStock);
            partHolder.CustomPart = (TextView) convertView.findViewById(R.id.tv_Custom_part);
            partHolder.PartGroup = (TextView) convertView.findViewById(R.id.tv_part_group);

//            gestureDetector = new GestureDetector(new MyGestureDetector(context,convertView));

            convertView.setTag(partHolder);
        } else {
            partHolder = (PartHolder) convertView.getTag();
        }

//		String dateCovert = "";

        try {
//			String dateString = listLoadAssignedFilter.get(position).getPlannedDeliveryDate();
//			Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(dateString);
//			dateCovert = new SimpleDateFormat("MMM d, yyyy").format(date);
            partHolder.soThuTu.setText((position + 1) + ".   ");
            int iPartID = listLoadAssigned.get(position).getPartID();
            partHolder.PartID.setText(String.format("%05d", iPartID));
            String sLocationName = listLoadAssigned.get(position).getLocationName();
            String checkPartName = listLoadAssigned.get(position).getPartName().toLowerCase();
            //isNeedScan
//            listLoadAssigned.get(position).setNeedScan(true);
            boolean isNeedScan = listLoadAssigned.get(position).isNeedScan();
            partHolder.PartLoc.setVisibility(View.VISIBLE);
            //action custom part
            if (iPartID == 26257) {
                partHolder.PartName.setVisibility(View.VISIBLE);
                partHolder.PartLoc.setVisibility(View.GONE);
                partHolder.CustomPart.setVisibility(View.VISIBLE);
//                partHolder.CustomPart.setText("Custom part");
            } else {
                partHolder.PartName.setVisibility(View.GONE);
                partHolder.PartLoc.setVisibility(View.VISIBLE);
                //part group
                partHolder.CustomPart.setVisibility(View.GONE);
//                listLoadAssigned.get(position).setPartGroup("PartGroup");
//                partHolder.CustomPart.setText(listLoadAssigned.get(position).getPartGroup());
            }
            //action forces scan
            if (isNeedScan && iPartID != 26257 && !checkPartName.contains("tack")) {
                partHolder.PartName.setVisibility(View.GONE);
                partHolder.PartGroup.setVisibility(View.VISIBLE);
                partHolder.PartGroup.setText(listLoadAssigned.get(position).getPartGroup());
            } else {
                partHolder.PartName.setVisibility(View.VISIBLE);
                partHolder.PartGroup.setVisibility(View.GONE);
            }
            partHolder.PartName.setText(listLoadAssigned.get(position).getPartName());


            String sQTy = listLoadAssigned.get(position).getSwipeQC() + " / " + listLoadAssigned
                    .get(position).getQuantity();
            partHolder.PartQTy.setText(sQTy);
//			partHolder.PartTotalPack.setText();
            partHolder.PartLoc.setText(sLocationName);
//			partHolder.PartFreeStock.setText();


            if (listLoadAssigned.get(position).isQC()) {
                partHolder.PartID.setTextColor(Color.RED);
                partHolder.PartName.setTextColor(Color.RED);
                partHolder.PartQTy.setTextColor(Color.RED);
//				partHolder.PartTotalPack.setTextColor(Color.RED);
//				partHolder.PartLoc.setTextColor(Color.RED);
//				partHolder.PartFreeStock.setTextColor(Color.RED);
                partHolder.CustomPart.setTextColor(Color.RED);
                partHolder.layout_swipe.setBackgroundColor(Color.WHITE);

            } else {
                partHolder.PartID.setTextColor(Color.parseColor("#009900"));
                partHolder.PartName.setTextColor(Color.parseColor("#009900"));
                partHolder.PartQTy.setTextColor(Color.parseColor("#404040"));
//				partHolder.PartTotalPack.setTextColor(Color.parseColor("#404040"));
//				partHolder.PartLoc.setTextColor(Color.parseColor("#404040"));
//				partHolder.PartFreeStock.setTextColor(Color.parseColor("#404040"));
                partHolder.CustomPart.setTextColor(Color.parseColor("#404040"));
                partHolder.layout_swipe.setBackgroundResource(R.drawable.ic_sw2);
            }

//            partHolder.layout_swipe.setOnTouchListener(new View.OnTouchListener() {
//                @Override
//                public boolean onTouch(View v, MotionEvent event) {
//                    gestureDetector.onTouchEvent(event);
//                    return true;
//                }
//            });


        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return convertView;
    }


    public static class PartHolder {
        TextView soThuTu;
        TextView PartID;
        TextView PartName;
        TextView PartQTy;
        //		TextView PartTotalPack;
        TextView PartLoc;
        //		TextView PartFreeStock;
        TextView CustomPart;
        TextView PartGroup;
        LinearLayout layout_swipe;
    }

//    public class MyGestureDetector extends GestureDetector.SimpleOnGestureListener {
//        PartHolder holder = new PartHolder();
//
//        public MyGestureDetector(Context ctx, View convertView) {
//            holder.layout_swipe = (LinearLayout) convertView.findViewById(R.id.layout_swipe);
//            outToRight = AnimationUtils.loadAnimation(ctx, R.anim.out_to_right);
//        }
//
//        @Override
//        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
//
//            try {
//                if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
//                    return false;
                // right to left swipe
//                if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//                    YourSlideRightToLeft(lvPart.pointToPosition((int) e1.getX(), (int) e1.getY()));
//
//                } else
//                if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
//                        && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//                    // left to right swipe
////                YourSlideLeftToRight(lvPartsInOrder.pointToPosition((int) e1.getX(), (int) e1.getY()));
//                    holder.layout_swipe.startAnimation(outToRight);
//                    holder.layout_swipe.setVisibility(View.VISIBLE);
//                }
//            } catch (Exception ex) {
//                return true;
//            }
//
//            return true;
//        }
//    }

}
