package vcn.kybotech.model;

public class PickType {

	String PickedBy;
	String PickType;
	int PickTypeID;

	public PickType() {
		super();
	}

	
	public PickType(String pickType, int pickTypeID) {
		super();
		PickType = pickType;
		PickTypeID = pickTypeID;
	}

	public String getPickedBy() {
		return PickedBy;
	}

	public void setPickedBy(String pickedBy) {
		PickedBy = pickedBy;
	}

	public String getPickType() {
		return PickType;
	}

	public void setPickType(String pickType) {
		PickType = pickType;
	}

	public int getPickTypeID() {
		return PickTypeID;
	}

	public void setPickTypeID(int pickTypeID) {
		PickTypeID = pickTypeID;
	}

}
