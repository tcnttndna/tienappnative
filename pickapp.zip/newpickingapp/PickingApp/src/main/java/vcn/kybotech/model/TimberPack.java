package vcn.kybotech.model;

public class TimberPack {
	public int PackID;
	public String Supplier;
	public int GRNID;
	public String GRNNumber;
	public int PartID;
	public String VariantID;
	public String PartName;
	public int PackQty;
	public double Volume;
	public int PackLength;
	public String Dimension;

	public TimberPack(int packID, String supplier, int gRNID, String gRNNumber, int partID, String variantID,
			String partName, int packQty, double volume, int packLength, String dimension) {
		super();
		PackID = packID;
		Supplier = supplier;
		GRNID = gRNID;
		GRNNumber = gRNNumber;
		PartID = partID;
		VariantID = variantID;
		PartName = partName;
		PackQty = packQty;
		Volume = volume;
		PackLength = packLength;
		Dimension = dimension;
	}

	public int getPackID() {
		return PackID;
	}

	public void setPackID(int packID) {
		PackID = packID;
	}

	public String getSupplier() {
		return Supplier;
	}

	public void setSupplier(String supplier) {
		Supplier = supplier;
	}

	public int getGRNID() {
		return GRNID;
	}

	public void setGRNID(int gRNID) {
		GRNID = gRNID;
	}

	public String getGRNNumber() {
		return GRNNumber;
	}

	public void setGRNNumber(String gRNNumber) {
		GRNNumber = gRNNumber;
	}

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public String getVariantID() {
		return VariantID;
	}

	public void setVariantID(String variantID) {
		VariantID = variantID;
	}

	public String getPartName() {
		return PartName;
	}

	public void setPartName(String partName) {
		PartName = partName;
	}

	public int getPackQty() {
		return PackQty;
	}

	public void setPackQty(int packQty) {
		PackQty = packQty;
	}

	public double getVolume() {
		return Volume;
	}

	public void setVolume(double volume) {
		Volume = volume;
	}

	public int getPackLength() {
		return PackLength;
	}

	public void setPackLength(int packLength) {
		PackLength = packLength;
	}

	public String getDimension() {
		return Dimension;
	}

	public void setDimension(String dimension) {
		Dimension = dimension;
	}
}
