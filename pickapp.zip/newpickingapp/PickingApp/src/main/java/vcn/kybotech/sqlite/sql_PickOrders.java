package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.PickOrder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class sql_PickOrders {

    private sql_DataBase data;
    public static final String TABLE_ORDERS = "PickOrders";

    public static final String COLUMN0_DROP_ID = "DropID";
    public static final String COLUMN1_LOAD_ID = "LoadID";
    public static final String COLUMN2_ORDER_ID = "OrderID";
    public static final String COLUMN3_PRODUCT_OPTION_ID = "ProductOptionID";
    public static final String COLUMN4_PRODUCT_OPTION_NAME = "ProductOptionName";

    public static final String COLUMN5_DROP_NUMBER = "DropNumber";
    public static final String COLUMN6_DATE_PLACED = "DatePlaced";
    public static final String COLUMN7_ORDER_REF = "OrderRef";
    public static final String COLUMN8_PRODUCT_NAME = "ProductName";
    public static final String COLUMN9_ORDER_ITEM_ID = "OrderItemID";

    public static final String COLUMN10_QUANTITY = "Quantity";
    public static final String COLUMN11_BAYNUMBER = "BayNumber";
    public static final String COLUMN12_WEIGHT_KG = "WeightKG";
    public static final String COLUMN13_ADDRESS = "Address";
    public static final String COLUMN14_CUSTOMER_NAME = "CustomerName";

    public static final String COLUMN15_POST_CODE = "Postcode";
    public static final String COLUMN16_FAIL_LOAD_REASON = "FailLoadReason";
    public static final String COLUMN17_IS_ORDER_PICKED = "IsOrderPicked";
    public static final String COLUMN18_IS_ORDER_CONFIRMED = "IsOrderConfirmed";
    public static final String COLUMN19_DELIVERY_STATUS = "DeliveryStatus";

    public static final String COLUMN20_TELEPHONE1 = "Telephone1";
    public static final String COLUMN21_TELEPHONE2 = "Telephone2";
    public static final String COLUMN22_SHIPPING_ADDRESS = "ShippingAddress";
    public static final String COLUMN23_SPECIAL_INSTRUCTIONS = "SpecialInstructions";

    public static final String COLUMN24_IS_CUSTOMER_PRESENT = "IsCustomerPresent";
    public static final String COLUMN25_IS_REPLAN_ATHUB = "IsReplanAtHub";
    public static final String COLUMN26_PRODUCT_SUB_OPTIONS = "ProductSubOptions";
    public static final String COLUMN27_STATUS = "Status";
    public static final String COLUMN28_IsItemConfirmedQA = "IsItemConfirmedQA";

    public static final String COLUMN29_IsItemStacked = "IsItemStacked";
    public static final String COLUMN30_IsItemChecked = "IsItemChecked";
    public static final String COLUMN31_IsItemLoaded = "IsItemLoaded";
    public static final String COLUMN32_IsItemConfirmedQC = "IsItemQC";

    public static final String CREATE_TABLE_ORDERS = "CREATE TABLE " + TABLE_ORDERS + " ("

            + COLUMN0_DROP_ID + " INTEGER, " + COLUMN1_LOAD_ID + " INTEGER, " + COLUMN2_ORDER_ID + " INTEGER , "
            + COLUMN3_PRODUCT_OPTION_ID + " INTEGER, " + COLUMN4_PRODUCT_OPTION_NAME + " TEXT, "

            + COLUMN5_DROP_NUMBER + " INTEGER, " + COLUMN6_DATE_PLACED + " TEXT, " + COLUMN7_ORDER_REF + " TEXT, "
            + COLUMN8_PRODUCT_NAME + " TEXT, " + COLUMN9_ORDER_ITEM_ID + " INTEGER , "
            // +COLUMN9_ORDER_ITEM_ID + " INTEGER PRIMARY KEY, "
            + COLUMN10_QUANTITY + " INTEGER, " + COLUMN11_BAYNUMBER + " INTEGER, " + COLUMN12_WEIGHT_KG + " REAL, "
            + COLUMN13_ADDRESS + " TEXT, " + COLUMN14_CUSTOMER_NAME + " TEXT, "

            + COLUMN15_POST_CODE + " TEXT, " + COLUMN16_FAIL_LOAD_REASON + " TEXT, " + COLUMN17_IS_ORDER_PICKED
            + " TEXT, " + COLUMN18_IS_ORDER_CONFIRMED + " TEXT, " + COLUMN19_DELIVERY_STATUS + " TEXT, "

            + COLUMN20_TELEPHONE1 + " TEXT, " + COLUMN21_TELEPHONE2 + " TEXT, " + COLUMN22_SHIPPING_ADDRESS + " TEXT, "
            + COLUMN23_SPECIAL_INSTRUCTIONS + " TEXT, " + COLUMN24_IS_CUSTOMER_PRESENT + " TEXT, "
            + COLUMN25_IS_REPLAN_ATHUB + " TEXT, " + COLUMN26_PRODUCT_SUB_OPTIONS + " TEXT, " + COLUMN27_STATUS
            + " TEXT, " + COLUMN28_IsItemConfirmedQA + " TEXT, " + COLUMN29_IsItemStacked + " TEXT, "
            + COLUMN30_IsItemChecked + " TEXT, " + COLUMN31_IsItemLoaded + " TEXT, " + COLUMN32_IsItemConfirmedQC + " TEXT )";

    public sql_PickOrders(Context context) {
        data = new sql_DataBase(context);
    }

    /* Kiem tra su ton tai cua du lieu */
    public boolean checkExistsData() {
        boolean output = false;
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        if (cursor.getCount() > 0) {
            output = true;
        }
        cursor.close();
        db.close();
        return output;
    }

    /*
     * NewPickingApp NormalPick - Dem xem co bao nhieu Order trong mot OrderID
     * chua duoc confirm
     */
    public int getCountOrdersNotPicked(String LoadID, String OrderID) {
        int c = 0;
        SQLiteDatabase db = data.getReadableDatabase();
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID
                + " AND " + COLUMN2_ORDER_ID + " = " + OrderID + " AND " + COLUMN27_STATUS + " = 'None'";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return c;
    }

    /*
     * NewPickingApp Dem xem co bao nhieu Order trong mot OrderRef chua duoc
     * confirm
     */
    public int getCountOrdersNotPickedInOrderRef(String LoadID, String OrderRef) {
        int c = 0;
        SQLiteDatabase db = data.getReadableDatabase();
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID
                + " AND " + COLUMN7_ORDER_REF + " = '" + OrderRef + "' AND " + COLUMN27_STATUS + " = 'None'";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return c;
    }

    /*
     * NewPickingApp PreViewLoad - QA - Dem xem co bao nhieu Order trong mot
     * Load khong tinh cac Order da remove
     */
    public int getCountOrdersNotRemove(String LoadID) {
        int c = 0;
        SQLiteDatabase db = data.getReadableDatabase();
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID
                + " AND " + COLUMN27_STATUS + " != 'Remove'";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return c;
    }

    /* NewPickingApp NormalPick - Dem xem co bao nhieu Order */
    public int getCountOrders(String LoadID) {
        int c = 0;
        SQLiteDatabase db = data.getReadableDatabase();
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return c;
    }

    public List<PickOrder> getAllListOrders(String LoadID) {
//		List<sql_PickOrders> c = null;
//		SQLiteDatabase db = data.getReadableDatabase();
//		String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID;
//		Cursor cursor = null;

        SQLiteDatabase db = data.getWritableDatabase();
        List<PickOrder> list = new ArrayList<PickOrder>();
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID;
        Cursor cursor = null;

        cursor = db.rawQuery(sqlSelect, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                list.add(new PickOrder(

                        // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                        // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
                        //
                        cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
                        cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                        cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                        //
                        cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                        // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                        // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
                        //
                        // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
                        // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
                        //
                        // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
                        cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
                        //
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
                        cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),

                        Constants.StatusOrderItem_None,
                        Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                        Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC)))
                ));

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

//    public List<PickOrder> getListOrdersToQC(String LoadID) {
////		List<sql_PickOrders> c = null;
////		SQLiteDatabase db = data.getReadableDatabase();
////		String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID;
////		Cursor cursor = null;
//
//        SQLiteDatabase db = data.getWritableDatabase();
//        List<PickOrder> list = new ArrayList<PickOrder>();
//        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoadID + " AND "
//                + COLUMN27_STATUS + " ='" + Constants.StatusOrderItem_Picked + "'";
//        Cursor cursor = null;
//
//        cursor = db.rawQuery(sqlSelect, null);
//        if (cursor.getCount() > 0) {
//            cursor.moveToFirst();
//            do {
//                list.add(new PickOrder(
//
//                        // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
//                        cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
//                        cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
//                        // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
//                        //
//                        cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
//                        cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
//                        cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
//                        cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
//                        //
//                        cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
//                        // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
//                        // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
//                        //
//                        // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
//                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
//                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
//                        //
//                        // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
//                        // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
//                        cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
//                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
//                        //
//                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
//                        cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),
//
//                        Constants.StatusOrderItem_None,
//                        Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
//                        Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC)))));
//
//            } while (cursor.moveToNext());
//        }
//        cursor.close();
//        db.close();
//        return list;
//    }

    /* NewPicking NormalPick - NewPick - Update ConfirmOrderItem */
    public int updateConfirmSpickedOrder(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN27_STATUS, Constants.StatusOrderItem_Picked);
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    public int clearConfirmSpickedOrder(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN27_STATUS, Constants.StatusOrderItem_None);
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    public int updateConfirmLoadedOrder(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN31_IsItemLoaded, Constants.StatusOrderItem_Loaded);
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    public int clearConfirmLoadedOrder(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN31_IsItemLoaded, "false");
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    /* QA CONFIRM ORDERITEM */
    public int updateConfirmQAOrderItem(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN28_IsItemConfirmedQA, "true");
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    /* QC CONFIRM ORDERITEM */
    public int updateConfirmQCOrderItem(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN32_IsItemConfirmedQC, "true");
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    /* STACK - Update ConfirmOrderItem */
    public int updateConfirmStackedOrder(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN29_IsItemStacked, "true");
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    /* CHECK - Update ConfirmOrderItem */
    public int updateConfirmCheckedOrder(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN30_IsItemChecked, "true");
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }
    /* NewPicking NewPick - Update UnConfirmOrderItem */
    // public int updateClearConfirmSpickedOrder(String orderItemID) {
    //
    // SQLiteDatabase db = data.getWritableDatabase();
    // int i = 0;
    //
    // try {
    // ContentValues values = new ContentValues();
    // values.put(COLUMN27_STATUS, Constants.StatusOrderItem_None);
    // i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new
    // String[] {orderItemID});
    // db.close();
    // Log.e("update confirm OrderItem " + orderItemID, i + "");
    // } catch (Exception e) {
    // e.printStackTrace();
    // if (db!=null) {
    // db.close();
    // }
    // }
    //
    // return i;
    // }

    public int updateRemoveOrderItem(String orderItemID) {

        SQLiteDatabase db = data.getWritableDatabase();
        int i = 0;

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN27_STATUS, Constants.StatusOrderItem_Remove);
            i = db.update(TABLE_ORDERS, values, COLUMN9_ORDER_ITEM_ID + " = ? ", new String[]{orderItemID});
            db.close();
            Log.e("update confirm OrderItem " + orderItemID, i + "");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return i;
    }

    // public int setConfirmSpickedOrder(String orderID) {
    //
    // SQLiteDatabase db = data.getWritableDatabase();
    // int i = -1;
    // ContentValues values = new ContentValues();
    // values.put(COLUMN17_IS_ORDER_PICKED, "true");
    //
    // i = db.update(TABLE_ORDERS, values, COLUMN2_ORDER_ID + " = ?", new
    // String[] {orderID});
    // db.close();
    //
    // return i;
    // }

    /* Khong can tham So Load ID vi du lieu trong bang nay cung mot loadID */
    /* NewPick */
    public boolean checkAllOrderConfirm() {
        Cursor cursor = null;
        Cursor cursor2 = null;
        SQLiteDatabase db = data.getWritableDatabase();

        String sql1 = "Select COUNT(*) from " + TABLE_ORDERS + " where " + COLUMN27_STATUS + " = 'None'";
        String sql2 = "Select COUNT(*) from " + TABLE_ORDERS;

        cursor = db.rawQuery(sql1, null);
        int cNone = 0;
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            cNone = cursor.getInt(0);
        }

        cursor2 = db.rawQuery(sql2, null);
        int c = 0;
        if (cursor2.getCount() > 0) {
            cursor2.moveToFirst();
            c = cursor2.getInt(0);
        }

        cursor.close();
        cursor2.close();
        db.close();
        return (cNone == 0) && (c > 0);
    }

    public boolean checkAllOrderStacked() {
        Cursor cursor = null;
        Cursor cursor2 = null;
        SQLiteDatabase db = data.getWritableDatabase();

        String sql1 = "Select COUNT(*) from " + TABLE_ORDERS + " where " + COLUMN29_IsItemStacked + " = 'true'";
        String sql2 = "Select COUNT(*) from " + TABLE_ORDERS;

        cursor = db.rawQuery(sql1, null);
        int cNone = 0;
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            cNone = cursor.getInt(0);
        }

        cursor2 = db.rawQuery(sql2, null);
        int c = 0;
        if (cursor2.getCount() > 0) {
            cursor2.moveToFirst();
            c = cursor2.getInt(0);
        }

        cursor.close();
        cursor2.close();
        db.close();
        return (c > 0) && (cNone == c);
    }

    public boolean checkAllOrderChecked() {
        Cursor cursor = null;
        Cursor cursor2 = null;
        SQLiteDatabase db = data.getWritableDatabase();

        String sql1 = "Select COUNT(*) from " + TABLE_ORDERS + " where " + COLUMN30_IsItemChecked + " = 'true'";
        String sql2 = "Select COUNT(*) from " + TABLE_ORDERS;

        cursor = db.rawQuery(sql1, null);
        int cNone = 0;
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            cNone = cursor.getInt(0);
        }

        cursor2 = db.rawQuery(sql2, null);
        int c = 0;
        if (cursor2.getCount() > 0) {
            cursor2.moveToFirst();
            c = cursor2.getInt(0);
        }

        cursor.close();
        cursor2.close();
        db.close();
        return (c > 0) && (cNone == c);
    }

    /*
     * NormalPick - Lay ra danh sach Order trong mot load ma COLUMN27_STATUS =
     * None
     */
    public List<PickOrder> getListOrdersAccept(String LoaidID) {
        SQLiteDatabase db = data.getWritableDatabase();
        List<PickOrder> list = new ArrayList<PickOrder>();

        Cursor cursor = null;

        cursor = db.query(TABLE_ORDERS, null, COLUMN1_LOAD_ID + " = ? AND " + COLUMN27_STATUS + " = ?  ",
                new String[]{LoaidID, "None"}, null, null, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                list.add(new PickOrder(

                        // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                        // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
                        //
                        cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
                        cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                        cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                        //
                        cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                        // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                        // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
                        //
                        // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
                        // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
                        //
                        // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
                        // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
                        cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
                        //
                        // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
                        cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),

                        Constants.StatusOrderItem_None,
                        Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                        Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC)))));

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    public List<PickOrder> getListOrdersLoading(String LoaidID) {
        SQLiteDatabase db = data.getWritableDatabase();
        // Cursor cursor = db.query(TABLE_ORDERS, null, null, null, null, null,
        // null);
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN31_IsItemLoaded + " = 'false' AND "
                + COLUMN27_STATUS + " != '" + Constants.StatusOrderItem_Remove + "' Order By " + COLUMN5_DROP_NUMBER + " desc ";
        List<PickOrder> list = new ArrayList<PickOrder>();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    PickOrder order = new PickOrder(cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN27_STATUS)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC))));

                    list.add(order);

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /* QA - getList OrderItem for Stack */
    public List<PickOrder> getListOrdersStack() {
        SQLiteDatabase db = data.getWritableDatabase();
        // Cursor cursor = db.query(TABLE_ORDERS, null, null, null, null, null,
        // null);
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN27_STATUS + " != '"
                + Constants.StatusOrderItem_Remove + "' ";
        List<PickOrder> list = new ArrayList<PickOrder>();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    PickOrder order = new PickOrder(

                            // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                            // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
                            // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
                            //
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN27_STATUS)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC))));

                    list.add(order);

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /* QA - getList OrderItem for QA */
    public List<PickOrder> getListOrdersQA() {
        SQLiteDatabase db = data.getWritableDatabase();
        // Cursor cursor = db.query(TABLE_ORDERS, null, null, null, null, null,
        // null);
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN28_IsItemConfirmedQA + " = 'false' AND "
                + COLUMN27_STATUS + " != '" + Constants.StatusOrderItem_Remove + "' ";
        List<PickOrder> list = new ArrayList<PickOrder>();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    PickOrder order = new PickOrder(

                            // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                            // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
                            // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
                            //
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN27_STATUS)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC))));

                    list.add(order);

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /* QA - getList OrderItem for QA */
    public List<PickOrder> getListOrdersQC() {
        SQLiteDatabase db = data.getWritableDatabase();
        // Cursor cursor = db.query(TABLE_ORDERS, null, null, null, null, null,
        // null);
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN32_IsItemConfirmedQC + " = 'false' AND "
                + COLUMN27_STATUS + " != '" + Constants.StatusOrderItem_Remove + "' ";
        List<PickOrder> list = new ArrayList<PickOrder>();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    PickOrder order = new PickOrder(

                            // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                            // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
                            // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
                            //
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN27_STATUS)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC))));

                    list.add(order);

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /*
     * PreViewLoad NewPick - PickByType Lay ra danh sach Order(chu y khong lay
     * Order da remove khoi load)
     */
    public List<PickOrder> getListOrders(String LoaidID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS + " WHERE " + COLUMN1_LOAD_ID + " = " + LoaidID + " AND "
                + COLUMN27_STATUS + " != '" + Constants.StatusOrderItem_Remove + "' ";
        List<PickOrder> list = new ArrayList<PickOrder>();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    PickOrder order = new PickOrder(

                            // cursor.getInt(cursor.getColumnIndex(COLUMN0_DROP_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_LOAD_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN2_ORDER_ID)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN3_PRODUCT_OPTION_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN4_PRODUCT_OPTION_NAME)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_DROP_NUMBER)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN6_DATE_PLACED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getString(cursor.getColumnIndex(COLUMN8_PRODUCT_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_ORDER_ITEM_ID)),
                            //
                            cursor.getInt(cursor.getColumnIndex(COLUMN10_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                            // cursor.getDouble(cursor.getColumnIndex(COLUMN12_WEIGHT_KG)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_ADDRESS)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_CUSTOMER_NAME)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_POST_CODE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN16_FAIL_LOAD_REASON)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_ORDER_PICKED))),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_ORDER_CONFIRMED))),
                            // cursor.getString(cursor.getColumnIndex(COLUMN19_DELIVERY_STATUS)),
                            //
                            // cursor.getString(cursor.getColumnIndex(COLUMN20_TELEPHONE1)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN21_TELEPHONE2)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN22_SHIPPING_ADDRESS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN23_SPECIAL_INSTRUCTIONS)),
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_CUSTOMER_PRESENT))),
                            //
                            // Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN25_IS_REPLAN_ATHUB))),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_PRODUCT_SUB_OPTIONS)),
                            cursor.getString(cursor.getColumnIndex(COLUMN27_STATUS)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN28_IsItemConfirmedQA))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN32_IsItemConfirmedQC))));

                    list.add(order);

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /* Clear du lieu */
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            db.delete(TABLE_ORDERS, null, null);
            db.close();
            Log.e("sql_PickOrders", " Clear Data succes");
        } catch (Exception e) {
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
    }

    /* Insert du lieu su dung transaction */
    public void insertPickOrdersTransaciton(JSONArray jsonArr) {

		/* Chuoi JSONArray truyen vao la mot mang cac doi tuong */

        String sql = "INSERT INTO " + TABLE_ORDERS + " ("

                + COLUMN0_DROP_ID + ", " + COLUMN1_LOAD_ID + ", " + COLUMN2_ORDER_ID + ", " + COLUMN3_PRODUCT_OPTION_ID
                + ", " + COLUMN4_PRODUCT_OPTION_NAME + ", " + COLUMN5_DROP_NUMBER + ", " + COLUMN6_DATE_PLACED + ", "
                + COLUMN7_ORDER_REF + ", " + COLUMN8_PRODUCT_NAME + ", " + COLUMN9_ORDER_ITEM_ID + ", "
                + COLUMN10_QUANTITY + ", " + COLUMN11_BAYNUMBER + ", " + COLUMN12_WEIGHT_KG + ", " + COLUMN13_ADDRESS
                + ", " + COLUMN14_CUSTOMER_NAME + ", " + COLUMN15_POST_CODE + ", " + COLUMN16_FAIL_LOAD_REASON + ", "
                + COLUMN17_IS_ORDER_PICKED + ", " + COLUMN18_IS_ORDER_CONFIRMED + ", " + COLUMN19_DELIVERY_STATUS + ", "
                + COLUMN20_TELEPHONE1 + ", "
                //
                + COLUMN21_TELEPHONE2 + ", " + COLUMN22_SHIPPING_ADDRESS + ", " + COLUMN23_SPECIAL_INSTRUCTIONS + ", "
                + COLUMN24_IS_CUSTOMER_PRESENT + ", " + COLUMN25_IS_REPLAN_ATHUB + ", " + COLUMN26_PRODUCT_SUB_OPTIONS
                + ", " + COLUMN27_STATUS + ", " + COLUMN28_IsItemConfirmedQA + ", " + COLUMN31_IsItemLoaded + ", "
                + COLUMN32_IsItemConfirmedQC + " "
                + ") VALUES  (?, ?, ?, ?, ?, " + " ? ,?, ?, ?, ?, " + " ?, ?, ?, ?, ?, " + " ?, ?, ?, ?, ?, "
                + " ?, ?, ?, ?, ?, " + " ?, ?, ?, ?, ? , ?)";
        clearData();
        SQLiteDatabase db = data.getWritableDatabase();

        try {
            db.beginTransactionNonExclusive();
            SQLiteStatement sqlSTMT = db.compileStatement(sql);
            Log.e("sql_PickOrders ", "so ban ghi PickOrders can duoc insert vao sqlite = " + jsonArr.length());
            try {
                for (int i = 0; i < jsonArr.length(); i++) {
                    Log.e("hehe", "in in xot xot");

                    JSONObject jsonLoadAssigned = jsonArr.getJSONObject(i);

                    sqlSTMT.bindLong(1, jsonLoadAssigned.getInt("DropID"));
                    sqlSTMT.bindLong(2, jsonLoadAssigned.getInt("LoadID"));
                    sqlSTMT.bindLong(3, jsonLoadAssigned.getInt("OrderID"));
                    sqlSTMT.bindLong(4, jsonLoadAssigned.getInt("ProductOptionID"));
                    sqlSTMT.bindString(5, jsonLoadAssigned.getString("ProductOptionName"));

                    sqlSTMT.bindLong(6, jsonLoadAssigned.getInt("DropNumber"));
                    sqlSTMT.bindString(7, jsonLoadAssigned.getString("DatePlaced"));
                    sqlSTMT.bindString(8, jsonLoadAssigned.getString("OrderRef"));
                    sqlSTMT.bindString(9, jsonLoadAssigned.getString("ProductName"));
                    sqlSTMT.bindLong(10, jsonLoadAssigned.getInt("OrderItemID"));

                    sqlSTMT.bindLong(11, jsonLoadAssigned.getInt("Quantity"));
                    sqlSTMT.bindLong(12, jsonLoadAssigned.getInt("BayNumber"));
                    sqlSTMT.bindDouble(13, jsonLoadAssigned.getDouble("WeightKG"));
                    sqlSTMT.bindString(14, jsonLoadAssigned.getString("Address"));
                    sqlSTMT.bindString(15, jsonLoadAssigned.getString("CustomerName"));

                    sqlSTMT.bindString(16, jsonLoadAssigned.getString("Postcode"));
                    sqlSTMT.bindString(17, jsonLoadAssigned.getString("FailLoadReason"));
                    sqlSTMT.bindString(18, jsonLoadAssigned.getString("IsOrderPicked"));
                    sqlSTMT.bindString(19, jsonLoadAssigned.getString("IsOrderConfirmed"));
                    sqlSTMT.bindString(20, jsonLoadAssigned.getString("DeliveryStatus"));

                    sqlSTMT.bindString(21, jsonLoadAssigned.getString("Telephone1"));
                    sqlSTMT.bindString(22, jsonLoadAssigned.getString("Telephone2"));
                    sqlSTMT.bindString(23, jsonLoadAssigned.getString("ShippingAddress"));
                    sqlSTMT.bindString(24, jsonLoadAssigned.getString("SpecialInstructions"));
                    sqlSTMT.bindString(25, jsonLoadAssigned.getString("IsCustomerPresent"));

                    sqlSTMT.bindString(26, jsonLoadAssigned.getString("IsReplanAtHub"));
                    sqlSTMT.bindString(27, jsonLoadAssigned.getString("ProductSubOptions"));

                    String status = Constants.StatusOrderItem_None;// Neu
                    // OrderItem
                    // chua
                    // picked;
                    if (jsonLoadAssigned.getString("IsItemPicked").equalsIgnoreCase("true")) {
                        status = Constants.StatusOrderItem_Picked;
                    }
                    sqlSTMT.bindString(28, status);
                    sqlSTMT.bindString(29, jsonLoadAssigned.getString("IsItemConfirmedQA"));
                    sqlSTMT.bindString(30, jsonLoadAssigned.getString("IsItemLoaded"));
                    sqlSTMT.bindString(31, jsonLoadAssigned.getString("IsItemQC"));
                    sqlSTMT.execute();
                    sqlSTMT.clearBindings();
                }
                db.setTransactionSuccessful();
                db.endTransaction();
            } catch (Exception e) {
                if (db != null) {
                    db.close();
                }
                e.printStackTrace();
                Log.e("sql_PickOrders", " insertTransaction jsonOrder to sqlite error ");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
    }

    public boolean checkOrderItemIdQC(String orderItemId) {
        boolean output = false;
        String sqlSelect = "SELECT * FROM " + TABLE_ORDERS
                + " WHERE " + COLUMN9_ORDER_ITEM_ID + "='" + orderItemId + "' AND " + COLUMN32_IsItemConfirmedQC + " ='true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                output = true;
            }
            cursor.close();
            db.close();
        } catch (Exception ex) {
            cursor.close();
            db.close();
        }
        return output;
    }
// try {
//    cursor = db.rawQuery(sqlSelect, null);
//            if (cursor.getCount() > 0) {
//        cursor.moveToFirst();
//        c = cursor.getInt(0);
//    }
//            cursor.close();
//            db.close();
//} catch (Exception e) {
//        e.printStackTrace();
//        if (cursor != null) {
//        cursor.close();
//        }
//        if (db != null) {
//        db.close();
//        }
    // public String getUserID(tbl_Users user) {
    // String UserID = null;
    // String selectUser = "SELECT " + COLUMN_USERID + " FROM " + TABLE_USERS
    // + " WHERE " + COLUMN_USERNAME + " = '" + user.getUsername()
    // + "' AND " + COLUMN_USERPASSWORD + " = '"
    // + user.getUserPassword() + "'";
    // SQLiteDatabase db = data.getReadableDatabase();
    // Cursor cursor = db.rawQuery(selectUser, null);
    // cursor.moveToFirst();
    // UserID = cursor.getString(0);
    // cursor.close();
    // db.close();
    // return UserID;
    // }

    // public String[] getSearchUsername(String search) {
    // String[] username;
    // String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
    // SQLiteDatabase db = data.getReadableDatabase();
    // Cursor cursor = db.rawQuery(sqlSelect, null);
    // username = new String[cursor.getCount()];
    // cursor.moveToFirst();
    // for (int i = 0; i < cursor.getCount(); i++) {
    // username[i] = cursor.getString(0);
    // cursor.moveToNext();
    // }
    // cursor.close();
    // db.close();
    // return username;
    // }
    //
    // public int getCountSearch(String search) {
    // int count = 0;
    // String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
    // SQLiteDatabase db = data.getReadableDatabase();
    // Cursor cursor = db.rawQuery(sqlSelect, null);
    // count = cursor.getCount();
    // cursor.close();
    // db.close();
    // return count;
    // }

}
