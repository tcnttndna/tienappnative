package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.LogData;

public class LogDataControl {
	private JSONParser jsonParser;
	
	public LogDataControl(){
		jsonParser = new JSONParser();
	}
	
	public JSONObject upload(LogData obj){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "auditnewpickingapp"));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(obj.getPickerId())));
		params.add(new BasicNameValuePair("pickername", obj.getPickerName()));
		params.add(new BasicNameValuePair("action", String.valueOf(obj.getAction())));
		params.add(new BasicNameValuePair("loadid", String.valueOf(obj.getLoadId())));
		params.add(new BasicNameValuePair("orderref", obj.getOrderRef()));
		params.add(new BasicNameValuePair("description", obj.getDescription()));
		params.add(new BasicNameValuePair("lat", String.valueOf(obj.getLat())));
		params.add(new BasicNameValuePair("lng", String.valueOf(obj.getLng())));
		params.add(new BasicNameValuePair("version", obj.getVersion()));
		params.add(new BasicNameValuePair("phonedate", String.valueOf(obj.getPhoneDate())));
		params.add(new BasicNameValuePair("inapp", "NewPickingApp"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
}
