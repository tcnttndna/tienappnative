package vcn.kybotech.adapter;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.Driver;
import vcn.kybotech.model.PartLocation;
import vcn.kybotech.pickingapp.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ListPartLocationAdapter extends ArrayAdapter<PartLocation> {
	private Context context;
	private int layoutId;
	private List<PartLocation> listData;
	private JSONParser jsonParser;

	public ListPartLocationAdapter(Context context, int layoutId, List<PartLocation> list) {
		super(context, layoutId, list);
		this.context = context;
		this.layoutId = layoutId;
		this.listData = list;
		jsonParser = new JSONParser();
	}

	public static class Holder {
		TextView tvPartID;
		TextView tvLocation;
		Button btnRemove;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		View view = convertView;
		Holder holder;
		if (view == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			view = inflater.inflate(layoutId, parent, false);
			holder = new Holder();

			holder.tvPartID = (TextView) view.findViewById(R.id.item_sls_tvpartid);
			holder.tvLocation = (TextView) view.findViewById(R.id.item_sls_tvlocation);
			holder.btnRemove = (Button) view.findViewById(R.id.item_sls_btnremove);
			view.setTag(holder);
		} else {
			holder = (Holder) view.getTag();
		}

		final PartLocation pl = listData.get(position);
		holder.tvPartID.setText("" + pl.getPartID());
		holder.tvLocation.setText(pl.getLocation());
		holder.btnRemove.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new AlertDialog.Builder(getContext()).setTitle("Confirm")
						.setMessage("Do you want to remove this part location ?")
						.setIcon(android.R.drawable.ic_dialog_alert)
						.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int whichButton) {
						Remove(pl.getId(), position);	
					}
				}).setNegativeButton(android.R.string.no, null).show();
			}
		});
		return view;
	}

	private void Remove(final int id, final int position) {
		new AsyncTask<String, Void, JSONObject>() {
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
			}

			@Override
			protected JSONObject doInBackground(String... arg0) {
				List<NameValuePair> params = new ArrayList<NameValuePair>();
				params.add(new BasicNameValuePair(Constants.type, "slsremovepartlocation"));
				params.add(new BasicNameValuePair("id", id + ""));
				JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
				return objJSON;
			}

			protected void onPostExecute(JSONObject jsonObject) {
				try {
					if (jsonObject == null) {
						Toast.makeText(getContext(), "Error, please try again !", Toast.LENGTH_SHORT).show();
					} else {
						if (jsonObject.getBoolean("success")) {
							Toast.makeText(getContext(), "Remove successful !", Toast.LENGTH_SHORT).show();
							listData.remove(position);
							notifyDataSetChanged();
						}else {
							Toast.makeText(getContext(), "Remove error, please check again !", Toast.LENGTH_SHORT).show();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
				}
			};
		}.execute();
	}

}
