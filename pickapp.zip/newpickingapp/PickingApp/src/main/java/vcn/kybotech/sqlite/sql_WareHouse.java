package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.model.SiteItem;
import vcn.kybotech.model.WareHouseItem;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class sql_WareHouse {
	private sql_DataBase data;
	private Context context;
	public static final String TABLE_WARE_HOUSE = "WareHouse";
	public static final String COLUMN0_ID = "ID";
	public static final String COLUMN1_WAREHOUSE_ID = "WarehouseID";
	public static final String COLUMN2_WAREHOUSE_NAME = "WarehouseName";

	public static final String CREATE_TABLE_WARE_HOUSE = "CREATE TABLE "
			+ TABLE_WARE_HOUSE + "(" + COLUMN0_ID
			+ " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN1_WAREHOUSE_ID
			+ " INTEGER, " + COLUMN2_WAREHOUSE_NAME + " TEXT)";

	public sql_WareHouse(Context context) {
		data = new sql_DataBase(context);
		this.context = context;
	}

	public void inser(JSONArray arr) throws JSONException {
		String sql = "INSERT INTO " + TABLE_WARE_HOUSE + "("
				+ COLUMN1_WAREHOUSE_ID + ", " + COLUMN2_WAREHOUSE_NAME
				+ ") VALUES (?, ?)";
		SQLiteDatabase db = data.getWritableDatabase();
		db.beginTransactionNonExclusive();
		SQLiteStatement sqlSTMT = db.compileStatement(sql);
		for (int i = 0; i < arr.length(); i++) {
			JSONObject obj = arr.getJSONObject(i);
			sqlSTMT.bindLong(1, obj.getInt(COLUMN1_WAREHOUSE_ID));
			sqlSTMT.bindString(2, obj.getString(COLUMN2_WAREHOUSE_NAME));
			sqlSTMT.execute();
			sqlSTMT.clearBindings();
		}
		db.setTransactionSuccessful();
		db.endTransaction();
		db.close();
	}

	public boolean checkData() {
		boolean output = false;
		String sqlSelect = "SELECT * FROM " + TABLE_WARE_HOUSE;
		SQLiteDatabase db = data.getReadableDatabase();
		Cursor cursor = db.rawQuery(sqlSelect, null);
		if (cursor.getCount() > 0) {
			output = true;
		}
		cursor.close();
		db.close();
		return output;
	}

	public List<WareHouseItem> select() {
		List<WareHouseItem> list = null;
		WareHouseItem obj = null;
		SQLiteDatabase db = data.getReadableDatabase();
		String sql = "SELECT * FROM " + TABLE_WARE_HOUSE + "";
		Cursor cursor = null;
		cursor = db.rawQuery(sql, null);
		if (cursor.getCount() > 0) {
			list = new ArrayList<WareHouseItem>();
			cursor.moveToFirst();
			sql_Site sqlSite = new sql_Site(this.context);
			do {
				obj = new WareHouseItem();
				obj.setWarehouseID(cursor.getInt(1));
				obj.setWarehouseName(cursor.getString(2));
				List<SiteItem> listSite = new ArrayList<SiteItem>();
				switch (cursor.getInt(1)) {
				case 1:
				case 7:
					listSite = sqlSite.select(cursor.getInt(1));
					break;
				default:
					listSite = sqlSite.select(0);
					break;
				}
				obj.setSite(listSite);
				list.add(obj);
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}
}
