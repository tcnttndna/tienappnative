package vcn.kybotech.mycustom;

import android.content.Context;
import android.os.Handler;

import com.google.firebase.crash.FirebaseCrash;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;

/**
 * Created by Cuong.nv on 1/4/2018.
 */

public class LoggingExceptionHandler implements Thread.UncaughtExceptionHandler {
    private final Context context;
    private final Thread.UncaughtExceptionHandler rootHandler;

    public LoggingExceptionHandler(Context context) {
        this.context = context;
        rootHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        try {
            FileSave file = new FileSave(context, Constants.GET);
            String log = "PickerName: " + file.getPickerName();
            FirebaseCrash.report(new Exception(" LOG_PickingApp: " + log +" "+ throwable));
            Thread.sleep(2000);
            android.os.Process.killProcess(android.os.Process.myPid());
        } catch (Exception e) {
            FirebaseCrash.report(e);
        }
    }
}
