package vcn.kybotech.model;

import java.io.Serializable;

/**
 * Created by Cuong.nv on 12/21/2017.
 */

public class PickReturnLoad implements Serializable {

    public int LoadID;
    public String LoadCode;
    public boolean Returned;

    public PickReturnLoad(int loadID, String loadCode, boolean returned) {
        LoadID = loadID;
        LoadCode = loadCode;
        Returned = returned;
    }

    public int getLoadID() {
        return LoadID;
    }

    public void setLoadID(int loadID) {
        LoadID = loadID;
    }

    public String getLoadCode() {
        return LoadCode;
    }

    public void setLoadCode(String loadCode) {
        LoadCode = loadCode;
    }

    public boolean isReturned() {
        return Returned;
    }

    public void setReturned(boolean returned) {
        Returned = returned;
    }
}
