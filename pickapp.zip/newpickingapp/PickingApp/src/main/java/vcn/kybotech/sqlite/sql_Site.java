package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.model.SiteItem;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class sql_Site {
	private sql_DataBase data;
	public static final String TABLE_SITE = "Site";
	public static final String COLUMN0_ID = "ID";
	public static final String COLUMN1_WAREHOUSE_ID = "WarehouseID";
	public static final String COLUMN2_SITE_NAME = "SiteName";
	
	public static final String CREATE_TABLE_SITE = "CREATE TABLE "
				+ TABLE_SITE +"("
				+ COLUMN0_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "
				+ COLUMN1_WAREHOUSE_ID +" INTEGER, "
				+ COLUMN2_SITE_NAME +" TEXT)";
	
	public sql_Site(Context context){
		data = new sql_DataBase(context);
	}
	
	public void inser(JSONArray arr) throws JSONException{
		String sql = "INSERT INTO "+ TABLE_SITE +"("+ COLUMN1_WAREHOUSE_ID +", "+ COLUMN2_SITE_NAME +") VALUES (?, ?)";
		SQLiteDatabase db = data.getWritableDatabase();
		db.beginTransactionNonExclusive();
		SQLiteStatement sqlSTMT = db.compileStatement(sql);
		for (int i = 0; i < arr.length(); i++) {
			JSONObject obj = arr.getJSONObject(i);
			sqlSTMT.bindLong(1, obj.getInt(COLUMN1_WAREHOUSE_ID));
			sqlSTMT.bindString(2, obj.getString(COLUMN2_SITE_NAME));
			sqlSTMT.execute();
			sqlSTMT.clearBindings();
		}
		db.setTransactionSuccessful();
		db.endTransaction();
		db.close();
	}

	public boolean checkData(){
		boolean output = false;
		String sqlSelect = "SELECT * FROM " + TABLE_SITE;
		SQLiteDatabase db = data.getReadableDatabase();
		Cursor cursor = db.rawQuery(sqlSelect, null);
		if (cursor.getCount() > 0) {
			output = true;
		}
		cursor.close();
		db.close();
		return output;
	}
	
	public List<SiteItem> select(int WarehouseId) {
		List<SiteItem> list = null;
		SiteItem obj = null;
		SQLiteDatabase db = data.getReadableDatabase();
		String sql = "SELECT * FROM " + TABLE_SITE + " WHERE "+ COLUMN1_WAREHOUSE_ID +" = '"+ String.valueOf(WarehouseId) +"'";
		Cursor cursor = null;
		cursor = db.rawQuery(sql, null);
		if (cursor.getCount() > 0) {
			list = new ArrayList<SiteItem>();
			cursor.moveToFirst();
			do {
				obj = new SiteItem();
				obj.setWarehouseID(cursor.getInt(1));
				obj.setSiteName(cursor.getString(2));
				list.add(obj);
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}
}
