package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.PickOrderType;
import vcn.kybotech.model.PickType;
import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
@SuppressLint({ "SimpleDateFormat", "ViewHolder" }) 
public class PickByTypeAdapter extends ArrayAdapter<Object> {

	Context context;
	List<Object> listObj;
	boolean hide;
	
	public PickByTypeAdapter(Context context, int resource, List<Object> objects) {
		super(context, resource, objects);
		this.context = context;
		this.listObj = objects;
//		this.ResID = resource;
		hide = false;
		
	}
	
//	List<PickPart> listLoadAssignedFilter;
//	public PickByTypeAdapter(Context context, int resource, List<PickOrder> listOrder, List<PickPart> listPart) {
//		this.context = context;
//		this.ResID = resource;
//		listLoadAssignedFilter = objects;
//		sql_PickPartsWithType partsWithType = new sql_PickPartsWithType(context);
//		listPartWithType = objects;
//		listLoadAssigned.addAll(objects);
		
//	}

	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		
//			PickPartWithType order = (PickPartWithType) listObj.get(position);
			Object object = listObj.get(position);
			
			
			
			if (object instanceof PickType) {
				
				TypeHolder typeHolder;
				PickType type = (PickType) object;
				
//				if (convertView == null) {
					LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
					typeHolder = new TypeHolder();
					convertView = inflater.inflate(R.layout.item_by_type, parent, false);
					
					typeHolder.TypeName = (TextView) convertView.findViewById(R.id.byTypeName);
					
					convertView.setTag(typeHolder);
//				}else {
//					orderHolder = (OrderHolder) convertView.getTag();
//				}
				
				typeHolder.TypeName.setText(type.getPickType());
				
				
			}else if (object instanceof PickOrderType) {
				
				OrderHolder orderHolder;
				PickOrderType order = (PickOrderType) object;
				
//				if (convertView == null) {
					LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
					orderHolder = new OrderHolder();
					convertView = inflater.inflate(R.layout.item_by_order, parent, false);
					
					orderHolder.OrderRef = (TextView) convertView.findViewById(R.id.byOrderRef);
					
					convertView.setTag(orderHolder);
//				}else {
//					orderHolder = (OrderHolder) convertView.getTag();
//				}
				
					
				String stOrderRef = order.getOrderRef();
				
				if (stOrderRef.indexOf("KTC")>=0) {
					orderHolder.OrderRef.setTextColor(Color.RED);
					orderHolder.OrderRef.setText(order.getDropNumber() + " - " + "TESCO - " + order.getOrderRef() + " - " + order.getProductOption() + " - " + order.getProductName());
//					orderHolder.ProducName.setTextColor(Color.RED);
				}else{
					orderHolder.OrderRef.setTextColor(Color.parseColor("#0000E5"));
					orderHolder.OrderRef.setText(order.getDropNumber() + " - " + order.getOrderRef() + " - " + order.getProductOption() + " - " + order.getProductName());
//					orderHolder.ProducName.setTextColor(Color.parseColor("#0000E5"));
				}
					
				
				
			}else if (object instanceof PickPart) {
//				PickPart part = (PickPart) listObj.get(position);
				
				PartHolder partHolder;
				PickPart part = (PickPart) object;
				
//				if (convertView == null) {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				partHolder = new PartHolder();
				convertView = inflater.inflate(R.layout.item_by_part, parent, false);
				LinearLayout showhide = (LinearLayout)convertView.findViewById(R.id.part_hide);
				partHolder.PartID = (TextView) convertView.findViewById(R.id.by_part_id);
				partHolder.PartName = (TextView) convertView.findViewById(R.id.by_part_name);
				partHolder.PartSwipe = (TextView) convertView.findViewById(R.id.by_part_swipe_scan);
				
				convertView.setTag(partHolder);
//				}else {
//					partHolder = (PartHolder) convertView.getTag();
//				}
				partHolder.PartID.setText(String.format("%05d", part.getPartID()));
				partHolder.PartName.setText(part.getPartName() 
						+ " | QTY: " + part.getQuantity() 
						+ " | Location: "+ part.getLocationName()
						+ " | PickingNotes: "+ part.getPickingNotes());
				partHolder.PartSwipe.setText( "Swipe: " + part.getSwipe() + "/"  + part.getQuantity());
				
				if (part.getSwipe() == part.getQuantity()) {
					partHolder.PartID.setTextColor(Color.RED);
					partHolder.PartName.setTextColor(Color.RED);
					partHolder.PartSwipe.setTextColor(Color.RED);
					
					if (hide) {
						showhide.setVisibility(View.GONE);
					}
				}
				
				
			}
	
		
		
//		if (convertView == null) {
//			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//			partHolder = new PartHolder();
//			convertView = inflater.inflate(R.layout.item_pick_by_type, parent, false);
//			
//			partHolder.PickType = (TextView) convertView.findViewById(R.id.type_name_pick_by_type);
//			partHolder.PartID = (TextView) convertView.findViewById(R.id.item_part_partID);
//			partHolder.PartName = (TextView) convertView.findViewById(R.id.item_part_partName);
//			partHolder.PartQTy = (TextView) convertView.findViewById(R.id.item_part_QTy);
//			partHolder.PartTotalPack = (TextView) convertView.findViewById(R.id.item_part_TotalPack);
//			partHolder.PartLoc = (TextView) convertView.findViewById(R.id.item_part_Loc);
			
			
			/*Tao list hien thi cac Orders trong mot kieu PickType*/
//			ListView listViewOrder = (ListView)convertView.findViewById(R.id.lvOrderRefInPickType);
//			
//			sql_PickPartsWithType partsWithType = new sql_PickPartsWithType(context);
//			String typePick = listPartWithType.get(position).getPickType();
//			List<PickPartWithType> objects = partsWithType.getOrderRefInPickType(typePick);
//			OrderRefInPickTypeAdapter adapter = new OrderRefInPickTypeAdapter(context, R.layout.item_order_ref_in_pick_type, objects);
//			listViewOrder.setAdapter(adapter);
//			
//			convertView.setTag(partHolder);
//		}else {
//			partHolder = (PartHolder) convertView.getTag();
//		}
		
//		String dateCovert = "";
		
//		try {
//			String dateString = listLoadAssignedFilter.get(position).getPlannedDeliveryDate();
//			Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(dateString);
//			dateCovert = new SimpleDateFormat("MMM d, yyyy").format(date);
//			partHolder.PickType.setText("Type: "+listPartWithType.get(position).getPickType());
//			partHolder.PartID.setText(listLoadAssigned.get(position).getPartID()+"");
//			partHolder.PartName.setText(listLoadAssigned.get(position).getPartName());
//			partHolder.PartQTy.setText("QTY: " + listLoadAssigned.get(position).getQuantity()+"");
//			partHolder.PartTotalPack.setText("Total Pack: " + listLoadAssigned.get(position).getTotalPack()+"");
//			partHolder.PartLoc.setText("Location: " + listLoadAssigned.get(position).getLocationName());
			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return convertView;
	}
	
	public void hide(boolean hide) {
		this.hide = hide;
	}
//	public void filter(String charText){
//		
//		listLoadAssignedFilter.clear();
//		
//			for (PickLoadAssigned loadAssigned : listLoadAssigned) 
//			{
//				int i = String.valueOf(loadAssigned.getLoadID()).indexOf(charText);
//				if (i==0) {
//					listLoadAssignedFilter.add(loadAssigned);
//				}
//
//			}
//		notifyDataSetChanged();
//		
//	}
//	
	
//	public void filterLoadMobileStatus(String charText){
//		
//		if (charText.equals(Constants.LoadMobileStatus_All_Status)) {
//			return;
//		}
//		List<PickLoadAssigned> listIsFilterID = new ArrayList<PickLoadAssigned>();
//		listIsFilterID.addAll(listLoadAssignedFilter);
//		listLoadAssignedFilter.clear();
//		for (PickLoadAssigned loadAssigned : listIsFilterID) 
//		{
//			/*Filter theo LoadMoblieStatus neu chon trang thai == Ready to Pick thi loc ra cac LoadAssign co LoadMobileStatus = "null" hoac = "Ready to Pick"*/
////			boolean check1 = (loadAssigned.getLoadMobileStatus().equals("null") && Constants.LoadMobileStatus_Ready_To_Pick.equals(charText));
////			boolean check2 = charText.equals(loadAssigned.getLoadMobileStatus());
////			boolean check = check1||check2;
////			Log.e("check = ", check+"");
////			if (check) {
////				listLoadAssignedFilter.add(loadAssigned);
////			}
////			Log.e("check = ", check+"");
//			if (((loadAssigned.getLoadMobileStatus().equals("null") && Constants.LoadMobileStatus_Ready_To_Pick.equals(charText)))||(charText.equals(loadAssigned.getLoadMobileStatus()))) {
//				listLoadAssignedFilter.add(loadAssigned);
//			}
//		}
//		notifyDataSetChanged();
//		
//	}
//	
//	public void notifyDataSetChangedCustom() {
//		listLoadAssigned.clear();
//		listLoadAssigned.addAll(listLoadAssignedFilter);
//	}
	
	
	public static class PartHolder{
		TextView PartID;
		TextView PartName;
		TextView PartSwipe;
//		TextView PickType;
//		TextView PickTypeID;
//		TextView PartName;
//		TextView PartQTy;
//		TextView PartTotalPack;
//		TextView PartLoc;
	}
	
	public static class OrderHolder{
		TextView OrderRef;
//		TextView PickType;
//		TextView PickTypeID;
//		TextView PartName;
//		TextView PartQTy;
//		TextView PartTotalPack;
//		TextView PartLoc;
	}
	
	public static class TypeHolder{
		TextView TypeName;
//		TextView PickType;
//		TextView PickTypeID;
//		TextView PartName;
//		TextView PartQTy;
//		TextView PartTotalPack;
//		TextView PartLoc;
	}
	
	
	
	
}
