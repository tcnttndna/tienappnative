package vcn.kybotech.adapter;

import java.util.ArrayList;

import vcn.kybotech.model.CurrentStock;
import vcn.kybotech.pickingapp.R;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CurrentStockAdapter extends ArrayAdapter<CurrentStock> {
	private Context context;
	private int layoutId;
	private ArrayList<CurrentStock> listCurrentStock;

	public CurrentStockAdapter(Context context, int layoutId, ArrayList<CurrentStock> listCurrentStock) {
		super(context, layoutId, listCurrentStock);
		this.context = context;
		this.layoutId = layoutId;
		this.listCurrentStock = listCurrentStock;
	}

	private static class Holder {
		TextView tvWareHouse;
		TextView tvFree;
		TextView tvAllocated;
		TextView tvPickedNotLoaded;
	}

	@Override
	public CurrentStock getItem(int position) {
		return listCurrentStock.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public int getCount() {
		if (listCurrentStock != null && listCurrentStock.size() != 0) {
			return listCurrentStock.size();
		}
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View obj = convertView;
		Holder holder;
		if (obj == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			;
			obj = inflater.inflate(layoutId, parent, false);
			holder = new Holder();
			holder.tvWareHouse = (TextView) obj.findViewById(R.id.custom_listview_current_stock_ware_house);
			holder.tvFree = (TextView) obj.findViewById(R.id.custom_listview_current_stock_free);
			holder.tvAllocated = (TextView) obj.findViewById(R.id.custom_listview_current_stock_allocated);
			holder.tvPickedNotLoaded = (TextView) obj
					.findViewById(R.id.custom_listview_current_stock_picked_not_loaded);

			obj.setTag(holder);
		} else {
			holder = (Holder) obj.getTag();
		}

		holder.tvWareHouse.setText(listCurrentStock.get(position).getWarehouseName());
		holder.tvFree.setText(String.valueOf(listCurrentStock.get(position).getFreeStock()));
		holder.tvAllocated.setText(String.valueOf(listCurrentStock.get(position).getAllocatedStock()));
		holder.tvPickedNotLoaded.setText(String.valueOf(listCurrentStock.get(position).getPickedNotLoadedStock()));
		return obj;
	}
}
