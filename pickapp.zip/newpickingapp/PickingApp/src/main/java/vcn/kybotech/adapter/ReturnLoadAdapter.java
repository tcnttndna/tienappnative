package vcn.kybotech.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import vcn.kybotech.model.PickReturnLoad;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickReturnLoads;
import vcn.kybotech.sqlite.sql_PickReturnParts;

/**
 * Created by Cuong.nv on 12/12/2017.
 */

public class ReturnLoadAdapter extends ArrayAdapter<PickReturnLoad> {

    private Context context;
    private int ResID;
    private List<PickReturnLoad> listLoadAssigned;
    sql_PickReturnLoads sqlPickReturnLoads;
    sql_PickReturnParts sql_pickReturnParts;

    public ReturnLoadAdapter(Context context, int resource, List<PickReturnLoad> objects) {
        super(context, resource, objects);
        this.context = context;
        this.ResID = resource;
        listLoadAssigned = objects;
        sqlPickReturnLoads = new sql_PickReturnLoads(context);
        sql_pickReturnParts = new sql_PickReturnParts(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder = new ViewHolder();
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(ResID, parent, false);
            holder.LoadId = (TextView) convertView.findViewById(R.id.item_returnload_loadId);
            holder.OrderCount = (TextView) convertView.findViewById(R.id.item_returnload_order_count);
            holder.PartCount = (TextView) convertView.findViewById(R.id.item_returnload_part_count);
            holder.ImageReturned = (ImageView) convertView.findViewById(R.id.item_returnload_img_returned);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        try {

            if (listLoadAssigned.get(position).isReturned()) {
                holder.ImageReturned.setVisibility(View.VISIBLE);
            } else {
                holder.ImageReturned.setVisibility(View.GONE);
            }

            holder.LoadId.setText(listLoadAssigned.get(position).getLoadID() + "");
            int partCount = 0;
            int orderCount = 0;
            orderCount = sql_pickReturnParts.getCountOrderOfLoad(String.valueOf(listLoadAssigned.get(position).getLoadID()));
            partCount = sql_pickReturnParts.getSumPartByLoad(listLoadAssigned.get(position).getLoadID());

            holder.PartCount.setText(partCount + "");
            holder.OrderCount.setText(orderCount + "");

        } catch (Exception ex) {
            String str = ex.getMessage();
        }


        return convertView;
    }

    public class ViewHolder {
        TextView LoadId;
        TextView OrderCount;
        TextView PartCount;
        ImageView ImageReturned;
    }
}
