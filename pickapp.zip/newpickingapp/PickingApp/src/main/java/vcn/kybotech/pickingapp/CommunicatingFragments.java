package vcn.kybotech.pickingapp;



public interface CommunicatingFragments {
	//	public void onUpdateWeatherLocation();
	
	//hien thi vi tri luu luoc su trong file txt toi ban do
	public void onNormalPickMoveConfirmLoad(String LoadID);
	public void onQAConfirmLoad(String LoadID);
	public void onLoadingConfirmLoad(String LoadID);
	public void onConfirmLoadPicked(String LoadID);
	public void onConfirmLoadQA(String LoadID);
	public void onConfirmLoadLoading(String LoadID);
	public void onConfirmLoadStacked(String LoadID);
	public void onDespatchedLoad(String LoadID);
	public void onRefeshAllLoad();
	
	

	// hien thi vi tri luu trong sql toi ban do;	
//	public void onAddMarkerYourPlaces(YourPlacesDTO placesDTO);
//	public void onSettingHideButtonInMap();
	
//	public void onNearBySearch(int position );
//	public void onAddMarkerNearBySearch(List<ResultNearBySearch> listMarker);
	
	//Update SavePlacesFragment
//	public void onUpdateSavePlaceFragment(Spot spot);
	
	//Update EditPlacesFragment
//	public void onUpdateEditPlaceFragment(Spot spot);
	
//	public void onGeoCode(List<ReultGeoCode> listMarker);
	
	
	
}
