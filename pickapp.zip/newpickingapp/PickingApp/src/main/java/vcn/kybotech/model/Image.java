package vcn.kybotech.model;

public class Image {
	private int Id;
	private int LoadId;
	private String LoadCode;
	private String OrderRef;
	private String OrderItemId;
	private int PickerId;
	private String PickerName;
	private String ImageData;
	private String ImageName;
	private int ImageType;
	private int PackId;
	private int PartId;
	public Image() {
		super();
	}
	public Image(int id, int loadId, String loadCode, String orderRef,
			String orderItemId, int pickerId, String pickerName,
			String imageData, String imageName, int imageType) {
		super();
		Id = id;
		LoadId = loadId;
		LoadCode = loadCode;
		OrderRef = orderRef;
		OrderItemId = orderItemId;
		PickerId = pickerId;
		PickerName = pickerName;
		ImageData = imageData;
		ImageName = imageName;
		ImageType = imageType;
	}
	public int getLoadId() {
		return LoadId;
	}
	public void setLoadId(int loadId) {
		LoadId = loadId;
	}
	public String getLoadCode() {
		return LoadCode;
	}
	public void setLoadCode(String loadCode) {
		LoadCode = loadCode;
	}
	public String getOrderRef() {
		return OrderRef;
	}
	public void setOrderRef(String orderRef) {
		OrderRef = orderRef;
	}
	public String getOrderItemId() {
		return OrderItemId;
	}
	public void setOrderItemId(String orderItemId) {
		OrderItemId = orderItemId;
	}
	public int getPickerId() {
		return PickerId;
	}
	public void setPickerId(int pickerId) {
		PickerId = pickerId;
	}
	public String getPickerName() {
		return PickerName;
	}
	public void setPickerName(String pickerName) {
		PickerName = pickerName;
	}
	public String getImageData() {
		return ImageData;
	}
	public void setImageData(String imageData) {
		ImageData = imageData;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getImageName() {
		return ImageName;
	}
	public void setImageName(String imageName) {
		ImageName = imageName;
	}
	public int getImageType() {
		return ImageType;
	}
	public void setImageType(int imageType) {
		ImageType = imageType;
	}
	public int getPackId() {
		return PackId;
	}
	public void setPackId(int packId) {
		PackId = packId;
	}
	public int getPartId() {
		return PartId;
	}
	public void setPartId(int partId) {
		PartId = partId;
	}
}
