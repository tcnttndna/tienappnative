package vcn.kybotech.fragment;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.adapter.SipnnerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.AddStockControl;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PartLocationItem;
import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.model.WareHouseItem;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class AddStockFragment extends Fragment {
	private EditText etReason;
	private ImageView imgReason;
	private EditText etQty;
	private ImageView imgQty;
	public static EditText etTapToScan;
	private ImageView imgTapToScan;
	private Spinner spinWarehose;
	private int intWarehose = 0;
	private Spinner spinLocation;
	private int intLocation = 0;
	private ImageButton btnAddLocation;
	private Button btnAppPart;
	private ProgressBar proLoad;
	private ImageButton btnTakePhoto;
	private List<SpinnerItem> itemSpinnerLocation;
	private List<SpinnerItem> itemSpinnerWareHouse;
	private SipnnerAdapter adapter;
	private List<WareHouseItem> itemWareHouse;
	private int ADD_LOCATION = 1;
	private int CHECK_QTY = 2;
	private int ADD_PART = 3;
	private int CHECK_REASON = 4;
	public static int SCAN_ADD = 1;
	public static int SCAN_REDUCE = 2;
	public static int SCAN_TRANSFER = 3;
	public static int SCAN_CURRENT = 4;
	public static int SCAN_PRIORITY = 5;
	public static int SCAN_ADD_PALLET = 6;

	private Dialog dialog;

	public AddStockFragment callHamTao() {
		AddStockFragment mFragment = new AddStockFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_add_stock,
				container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT));
		HamKhoiTao(rootView);
		BatSuKien();
		return rootView;
	}

	public void HamKhoiTao(View v) {
		// KHAI BAO GIAO DIEN
		etReason = (EditText) v.findViewById(R.id.fragment_add_stock_reason);
		imgReason = (ImageView) v
				.findViewById(R.id.fragment_add_stock_reason_img);

		etQty = (EditText) v.findViewById(R.id.fragment_add_stock_qty);
		imgQty = (ImageView) v.findViewById(R.id.fragment_add_stock_qty_img);

		etTapToScan = (EditText) v
				.findViewById(R.id.fragment_add_stock_taptoscan);
		imgTapToScan = (ImageView) v
				.findViewById(R.id.fragment_add_stock_taptoscan_img);

		spinWarehose = (Spinner) v
				.findViewById(R.id.fragment_add_stock_spinner_warehouse);

		spinLocation = (Spinner) v
				.findViewById(R.id.fragment_add_stock_spinner_location);

		btnAddLocation = (ImageButton) v
				.findViewById(R.id.fragment_add_stock_button_add_location);
		proLoad = (ProgressBar) v
				.findViewById(R.id.fragment_add_stock_progressbar_load);

		btnAppPart = (Button) v
				.findViewById(R.id.fragment_add_stock_button_add_part);
		btnTakePhoto = (ImageButton) v
				.findViewById(R.id.fragment_add_stock_button_take_photo_add);
		// ==================
		// SET COMBOBOX WHARE HOUSE
		getWareHouse();
		// ========================

		// SET COMBOBOX LOCATION
		itemSpinnerLocation = new ArrayList<SpinnerItem>();
		adapter = new SipnnerAdapter(getActivity(), R.layout.custom_spinner,
				itemSpinnerLocation);
		spinLocation.setAdapter(adapter);
		// =====================
	}

	public void BatSuKien() {
		etReason.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etReason.getText().toString().length() > 0) {
					imgReason.setVisibility(View.VISIBLE);
				} else {
					imgReason.setVisibility(View.INVISIBLE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});

		imgReason.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etReason.setText(null);
				etReason.requestFocus();
			}
		});
		etQty.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etQty.getText().toString().length() > 0) {
					imgQty.setVisibility(View.VISIBLE);
				} else {
					imgQty.setVisibility(View.INVISIBLE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});

		imgQty.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etQty.setText(null);
				etQty.requestFocus();
			}
		});

		etTapToScan.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etTapToScan.getText().toString().length() > 0) {
					imgTapToScan.setVisibility(View.VISIBLE);
					if (etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN) {
						getPartLocation();
					}
				} else {
					imgTapToScan.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});

		imgTapToScan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etTapToScan.setText(null);
				etTapToScan.requestFocus();
			}
		});

		btnAddLocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialogAddLocation(ADD_LOCATION);
			}
		});

		spinWarehose.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				intWarehose = arg2;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

		spinLocation.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				intLocation = arg2;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

		btnAppPart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (etTapToScan.getText().toString().trim().length() == Constants.LENGTH_TAP_TO_SCAN) {
					if(itemSpinnerLocation.size() > 0){
						if(etReason.getText().toString().trim().length() == 0){
							dialogAddLocation(CHECK_REASON);
						} else{
							if (etQty.getText().toString().trim().length() == 0 || 
									Integer.parseInt(etQty.getText().toString().trim()) == 0 ||
									Integer.parseInt(etQty.getText().toString().trim()) > 401){
								dialogAddLocation(CHECK_QTY);
							} else {
								dialogAddLocation(ADD_PART);
							}
						}
					}
				}else{
					etTapToScan.requestFocus();
					OpenKeyBoard(AddStockFragment.this.getActivity());
				}
			}
		});
		
		btnTakePhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				onSCanBarCode(SCAN_ADD);
			}
		});

	}

	public void onSCanBarCode(int types) {
		try {
			Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
			intent.putExtra("SCAN_FORMATS",
					"QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
			startActivityForResult(intent, types);
		} catch (Exception e) {
			Log.e("NOT SCAN", e.toString());
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SCAN_ADD && resultCode == RESULT_OK) {
			try {

				String qrcode = (data.getStringExtra("SCAN_RESULT"));
				BarcodeSubString barcodeSubString = new BarcodeSubString();
				qrcode = barcodeSubString.CutBarcode(qrcode, "");
				etTapToScan.setText(qrcode);
			} catch (Exception e) {
				//dialogPartIDFail();
			}
		}
	}

	public void getWareHouse() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) AddStockFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
							AddStockControl ctrAddStock = new AddStockControl(getActivity());
							objJSON = ctrAddStock.getWareHouse();
							return objJSON;
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS)
									.equals(Constants.KEY_TRUE)) {
								itemSpinnerWareHouse = new ArrayList<SpinnerItem>();
								itemWareHouse = new ArrayList<WareHouseItem>();
								JSONArray obj = objJSON.getJSONArray("data");
								for (int i = 0; i < obj.length(); i++) {
									JSONObject objItem = obj.getJSONObject(i);
									itemSpinnerWareHouse
											.add(new SpinnerItem(
													objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
									itemWareHouse
											.add(new WareHouseItem(
													objItem.getInt(WareHouseItem.COLUMN_WARE_HOUSE_ID),
													objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
								}
								SipnnerAdapter adapter = new SipnnerAdapter(
										getActivity(), R.layout.custom_spinner,
										itemSpinnerWareHouse);
								spinWarehose.setAdapter(adapter);

								// SET HIEN THI CHO COMBOBOX WHARE HOUSE
								// KHAI BAO TEP LUU DU LIEU
								FileSave file = new FileSave(getActivity(), Constants.GET);
								int warehouseid = file.getWarehouselocationID();
								if (warehouseid > 0) {
									spinWarehose.setEnabled(false);
									for (int i = 0; i < itemWareHouse.size(); i++) {
										if (itemWareHouse.get(i)
												.getWarehouseID() == warehouseid) {
											spinWarehose.setSelection(i);
											break;
										}
									}
								} else {
									spinWarehose.setEnabled(true);
								}
								// ======================================
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void getPartLocation() {
		try {
			new AsyncTask<String, String, JSONObject>() {
				JSONObject objJSON;

				@Override
				protected void onPreExecute() {
					super.onPreExecute();
					proLoad.setVisibility(View.VISIBLE);
				}

				@Override
				protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) AddStockFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
					try {
						AddStockControl ctrAddStock = new AddStockControl(getActivity());
						objJSON = ctrAddStock.getPartLocation(Integer
								.parseInt(etTapToScan.getText().toString().trim()));
						return objJSON;
					}catch (Exception ex){
						return null;
					}

//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
				}

				@Override
				protected void onPostExecute(JSONObject objJSON) {
					if (objJSON != null) {
						try {
							if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
								if (objJSON.getString(Constants.KEY_SUCCESS)
										.equals(Constants.KEY_TRUE)) {
									itemSpinnerLocation.clear();
									itemSpinnerLocation
											.add(new SpinnerItem("None"));
									JSONArray obj = objJSON.getJSONArray("data");
									for (int i = 0; i < obj.length(); i++) {
										JSONObject objItem = obj.getJSONObject(i);
										itemSpinnerLocation
												.add(new SpinnerItem(
														objItem.getString(PartLocationItem.COLUMN_LOCATION_NAME)));
									}
									adapter.notifyDataSetChanged();
									etQty.setText("1");
								} else {
									if (objJSON.getString(Constants.KEY_SUCCESS)
											.equals(Constants.KEY_FALSE)) {
										itemSpinnerLocation.clear();
									}
								}
							} else {
								Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						Log.e("Error", Constants.ERR_SERVICE_NETWORK);
						DialogDisconnectToServer();
					}
					proLoad.setVisibility(View.GONE);
				}
			}.execute();
		}catch (Exception ex){

		}
	}

	public void uploadAddPart() {
		btnAppPart.setVisibility(View.GONE);
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) AddStockFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
				try {
					AddStockControl ctrAddStock = new AddStockControl(getActivity());
					int partid = Integer.parseInt(etTapToScan.getText().toString()
							.trim());
					String reason = etReason.getText().toString().trim();
					String quantity = etQty.getText().toString().trim();
					String location = itemSpinnerLocation.get(intLocation)
							.getSpinner().toString();
					objJSON = ctrAddStock.uploadAddPart(partid, reason,
							itemWareHouse.get(intWarehose).getWarehouseID(),
							quantity, location);
					return objJSON;
				} catch (Exception e) {
					e.printStackTrace();
					btnAppPart.setVisibility(View.VISIBLE);
					return null;
				}
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS)
									.equals(Constants.KEY_TRUE)) {
								Toast.makeText(
										getActivity(),
										"Part "
												+ objJSON.getJSONObject("data")
														.getString("PartName")
												+ " was added successfully",
										Toast.LENGTH_SHORT).show();
								btnAppPart.setVisibility(View.VISIBLE);
								etReason.setText(null);
								etQty.setText(null);
								itemSpinnerLocation.clear();
								adapter.notifyDataSetChanged();
								etTapToScan.setText(null);
								etTapToScan.requestFocus();
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS)
										.equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(),
											objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_SHORT).show();
									etTapToScan.requestFocus();
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void dialogAddLocation(final int type) {
		dialog = new Dialog(getActivity());
		dialog.setContentView(R.layout.custom_dialog);
		TextView tvnoidung = (TextView) dialog
				.findViewById(R.id.custom_dialog_textview_noidung);
		final EditText etlocation = (EditText) dialog
				.findViewById(R.id.custom_dialog_edittext_location);
		final ImageView imglocation = (ImageView) dialog
				.findViewById(R.id.custom_dialog_edittext_location_img);
		Button btncancel = (Button) dialog
				.findViewById(R.id.custom_dialog_button_cancel);
		Button btnok = (Button) dialog
				.findViewById(R.id.custom_dialog_button_ok);

		if (type == ADD_LOCATION) {
			dialog.setTitle(Constants.NEW_LOCATION);
			tvnoidung.setText(Constants.INPUT_LOCATION_TO_ADD_STOCK);
			etlocation.setVisibility(View.VISIBLE);
		}
		if (type == CHECK_QTY) {
			dialog.setTitle(Constants.NOTIFICATION);
			tvnoidung.setText(Constants.QUANTITY_IS_NOT_NUMBER);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		if(type == CHECK_REASON){
			dialog.setTitle(Constants.NOTIFICATION);
			tvnoidung.setText(Constants.QUANTITY_IS_NOT_VALUES);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		if (type == ADD_PART) {
			dialog.setTitle(Constants.QUANTITY_PART_CONFIRM);
			tvnoidung.setText("Are you sure add quantity for partID "
					+ etTapToScan.getText().toString().trim() + " quantity "
					+ etQty.getText().toString().trim() + " to location "
					+ itemSpinnerLocation.get(intLocation).getSpinner() + "");
			etlocation.setVisibility(View.GONE);
			btncancel.setText("No");
		}

		etlocation.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etlocation.getText().toString().length() > 0) {
					imglocation.setVisibility(View.VISIBLE);
				} else {
					imglocation.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {

			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		imglocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etlocation.setText(null);
			}
		});
		btncancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});

		btnok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (type == ADD_LOCATION) {
					if (etlocation.getText().toString().length() > 0) {
						itemSpinnerLocation.add(new SpinnerItem(etlocation
								.getText().toString().trim()));
						adapter.notifyDataSetChanged();

						spinLocation.setSelection(itemSpinnerLocation.size() - 1);
					}
				}
				if (type == CHECK_QTY) {
					etQty.requestFocus();
				}
				if(type == CHECK_REASON){
					etReason.requestFocus();
				}
				if (type == ADD_PART) {
					uploadAddPart();
				}

				dialog.dismiss();
			}
		});

		dialog.show();
	}
	
	public void DialogDisconnectToServer(){
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new  AlertDialog.Builder(AddStockFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_checkagain));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					
				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}
}
