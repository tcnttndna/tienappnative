package vcn.kybotech.model;

public class PriorityStock {
	public static String COLUMN_WARE_HOUSE_ID = "WarehouseID";
	public static String COLUMN_WARE_HOUSE_NAME = "WarehouseName";
	public static String COLUMN_STOCK_LEVEL = "StockLevel";
	public static String COLUMN_PRIORITY_ORDER = "PriorityOrder";
	public static String COLUMN_SHIPPING_PRIORITY = "ShippingPriority";
	public static String COLUMN_ORIGINAL_STOCK_LEVEL = "originalStockLevel";
	public static String COLUMN_ORIGINAL_PRIORITY = "originalPriority";
	private int WarehouseId;
	private String WarehouseName;
	private int StockLevel;
	private String PriorityOrder;

	private int StockLevelOld;
	private String PriorityOrderOld;

	public PriorityStock() {
		super();
	}

	public PriorityStock(int warehouseId, String warehouseName, int stockLevel,
			String priorityOrder) {
		super();
		WarehouseId = warehouseId;
		WarehouseName = warehouseName;
		StockLevel = stockLevel;
		PriorityOrder = priorityOrder;
	}

	public int getWarehouseId() {
		return WarehouseId;
	}

	public void setWarehouseId(int warehouseId) {
		WarehouseId = warehouseId;
	}

	public String getWarehouseName() {
		return WarehouseName;
	}

	public void setWarehouseName(String warehouseName) {
		WarehouseName = warehouseName;
	}

	public int getStockLevel() {
		return StockLevel;
	}

	public void setStockLevel(int stockLevel) {
		StockLevel = stockLevel;
	}

	public String getPriorityOrder() {
		return PriorityOrder;
	}

	public void setPriorityOrder(String priorityOrder) {
		PriorityOrder = priorityOrder;
	}

	public int getStockLevelOld() {
		return StockLevelOld;
	}

	public void setStockLevelOld(int stockLevelOld) {
		StockLevelOld = stockLevelOld;
	}

	public String getPriorityOrderOld() {
		return PriorityOrderOld;
	}

	public void setPriorityOrderOld(String priorityOrderOld) {
		PriorityOrderOld = priorityOrderOld;
	}
}
