package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.model.PickLoad;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class sql_PickLoads {

    private sql_DataBase data;
    public static final String TABLE_LOAD_ASSIGNED = "PickLoadAssigned";

    public static final String COLUMN0_LOADID = "LoadID";
    public static final String COLUMN1_LOADCODE = "LoadCode";
    public static final String COLUMN2_LOADSTATUS = "LoadStatus";
    public static final String COLUMN3_CREATED_BY_USERID = "CreatedByUserID";
    public static final String COLUMN4_CREATED_DATE = "CreatedDate";

    public static final String COLUMN5_USERNAME = "Username";
    public static final String COLUMN6_PLANED_DELIVERY_DATE = "PlannedDeliveryDate";
    public static final String COLUMN7_CARRIER_NAME = "carrierName";
    public static final String COLUMN8_DRIVER_NAME = "DriverName";
    public static final String COLUMN9_NAME = "Name";

    public static final String COLUMN10_VEHICLE_MAX_WEIGHT = "VehicleMaxWeight";
    public static final String COLUMN11_BAYNUMBER = "BayNumber";
    public static final String COLUMN12_LOADMOBILESTATUS = "LoadMobileStatus";
    public static final String COLUMN13_ISLOCKED = "IsLocked";
    public static final String COLUMN14_PICKERID = "PickerID";

    public static final String COLUMN15_DRIVERID = "DriverID";
    public static final String COLUMN16_WEIGHT = "Weight";
    public static final String COLUMN17_CANQC = "CanQC";


    public static final String CREATE_TABLE_LOAD_ASSIGNED = "CREATE TABLE "
            + TABLE_LOAD_ASSIGNED + " ("

            + COLUMN0_LOADID + " INTEGER PRIMARY KEY, "
            + COLUMN1_LOADCODE + " TEXT, "
            + COLUMN2_LOADSTATUS + " TEXT, "
            + COLUMN3_CREATED_BY_USERID + " INTEGER, "
            + COLUMN4_CREATED_DATE + " TEXT, "
            + COLUMN5_USERNAME + " TEXT, "
            + COLUMN6_PLANED_DELIVERY_DATE + " TEXT, "
            + COLUMN7_CARRIER_NAME + " TEXT, "
            + COLUMN8_DRIVER_NAME + " TEXT, "
            + COLUMN9_NAME + " TEXT, "
            + COLUMN10_VEHICLE_MAX_WEIGHT + " INTEGER, "
            + COLUMN11_BAYNUMBER + " INTEGER, "
            + COLUMN12_LOADMOBILESTATUS + " TEXT, "
            + COLUMN13_ISLOCKED + " TEXT, "
            + COLUMN14_PICKERID + " INTEGER, "
            + COLUMN15_DRIVERID + " INTEGER, "
            + COLUMN16_WEIGHT + " REAL, "
            + COLUMN17_CANQC + " TEXT "
            + " )";

    public sql_PickLoads(Context context) {
        data = new sql_DataBase(context);
    }


    /* Kiem tra su ton tai cua du lieu*/
    public boolean checkExistsData() {
        boolean output = false;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_LOAD_ASSIGNED;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            if (cursor.getInt(0) > 0) {
                output = true;
            }
        }

        cursor.close();
        db.close();
        return output;
    }

    /* Kiem tra xem co bao nhieu ban ghi*/
    public int getCountLoadAssigned() {
        int c = 0;
        String sqlSelect = "SELECT * FROM " + TABLE_LOAD_ASSIGNED;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        c = cursor.getCount();
        cursor.close();
        db.close();
        return c;
    }

    public void insertPickLoadAssigned(JSONArray jsonArr) {
        SQLiteDatabase db = data.getWritableDatabase();
        Log.e("sql_PickLoadAssigned ", "so ban ghi PickLoadAssigned can duoc insert vao sqlite = " + jsonArr.length());
        for (int i = 0; i < jsonArr.length(); i++) {

            try {
                JSONObject jsonLoadAssigned = jsonArr.getJSONObject(i);
                ContentValues values = new ContentValues();

                values.put(COLUMN0_LOADID, jsonLoadAssigned.getLong("LoadID"));
//				values.put(COLUMN1_LOADCODE, jsonLoadAssigned.getString("LoadCode"));
                values.put(COLUMN2_LOADSTATUS, jsonLoadAssigned.getString("LoadStatus"));
//				values.put(COLUMN3_CREATED_BY_USERID, jsonLoadAssigned.getInt("CreatedByUserID"));
//				values.put(COLUMN4_CREATED_DATE, jsonLoadAssigned.getString("CreatedDate"));
//
//				values.put(COLUMN5_USERNAME, jsonLoadAssigned.getString("Username"));
                values.put(COLUMN6_PLANED_DELIVERY_DATE, jsonLoadAssigned.getString("PlannedDeliveryDate"));
//				values.put(COLUMN7_CARRIER_NAME, jsonLoadAssigned.getString("carrierName"));
                values.put(COLUMN8_DRIVER_NAME, jsonLoadAssigned.getString("DriverName"));
//				values.put(COLUMN9_NAME, jsonLoadAssigned.getString("Name"));
//
//				values.put(COLUMN10_VEHICLE_MAX_WEIGHT, jsonLoadAssigned.getInt("VehicleMaxWeight"));
                values.put(COLUMN11_BAYNUMBER, jsonLoadAssigned.getInt("BayNumber"));
                values.put(COLUMN12_LOADMOBILESTATUS, jsonLoadAssigned.getString("LoadMobileStatus"));
//				values.put(COLUMN13_ISLOCKED, jsonLoadAssigned.getString("IsLocked"));
//				values.put(COLUMN14_PICKERID, jsonLoadAssigned.getInt("PickerID"));
//
//				values.put(COLUMN15_DRIVERID, jsonLoadAssigned.getInt("DriverID"));
                values.put(COLUMN16_WEIGHT, jsonLoadAssigned.getDouble("Weight"));
                values.put(COLUMN17_CANQC, jsonLoadAssigned.getString("IsQC"));
//				values.put(COLUMN18_IS_LOCAL_MODIFIED, jsonLoadAssigned.getString("IsLocalModified"));
//				values.put(COLUMN19_ORDER_REFS, jsonLoadAssigned.getString("OrderRefs"));
//				
//				values.put(COLUMN20_PART_ITEMS, jsonLoadAssigned.getString("PartItems"));


                db.insert(TABLE_LOAD_ASSIGNED, null, values);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("sql_PickLoadAssign", " insert jsonLoadAssigned to sqlite error ");
            }
            db.close();
            Log.e("sql_PickLoadAssign", " so ban ghi duoc insert  =  " + getCountLoadAssigned());
        }
    }


    public List<PickLoad> getAllLoadAssigned() {
        SQLiteDatabase db = data.getWritableDatabase();
        Cursor cursor = db.query(TABLE_LOAD_ASSIGNED, null, null, null, null, null, null);
        List<PickLoad> list = new ArrayList<PickLoad>();
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                list.add(new PickLoad(

                                cursor.getInt(cursor.getColumnIndex(COLUMN0_LOADID)),
                                cursor.getString(cursor.getColumnIndex(COLUMN1_LOADCODE)),
                                cursor.getString(cursor.getColumnIndex(COLUMN2_LOADSTATUS)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN3_CREATED_BY_USERID)),
                                cursor.getString(cursor.getColumnIndex(COLUMN4_CREATED_DATE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN5_USERNAME)),
                                cursor.getString(cursor.getColumnIndex(COLUMN6_PLANED_DELIVERY_DATE)),
                                cursor.getString(cursor.getColumnIndex(COLUMN8_DRIVER_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN9_NAME)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN10_VEHICLE_MAX_WEIGHT)),
                                cursor.getInt(cursor.getColumnIndex(COLUMN11_BAYNUMBER)),
                                cursor.getString(cursor.getColumnIndex(COLUMN12_LOADMOBILESTATUS)),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN13_ISLOCKED))),
//						cursor.getInt(cursor.getColumnIndex(COLUMN14_PICKERID)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN15_DRIVERID)),
                                cursor.getDouble(cursor.getColumnIndex(COLUMN16_WEIGHT)),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN17_IS_LOAD_COMPLETE))),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN18_IS_LOCAL_MODIFIED))),
//						cursor.getString(cursor.getColumnIndex(COLUMN19_ORDER_REFS)),
//						cursor.getString(cursor.getColumnIndex(COLUMN20_PART_ITEMS))
                                cursor.getString(cursor.getColumnIndex(COLUMN7_CARRIER_NAME)),
                                cursor.getString(cursor.getColumnIndex(COLUMN17_CANQC)))
                );
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    /*Clear du lieu*/
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            db.delete(TABLE_LOAD_ASSIGNED, null, null);
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }
    }

    /*Insert du lieu su dung transaction*/
    public void insertPickLoadAssignedTransaciton(JSONArray jsonArr) {

		/*Chuoi JSONArray truyen vao la mot mang cac doi tuong */


        String sql = "INSERT INTO " + TABLE_LOAD_ASSIGNED + " ("

                + COLUMN0_LOADID + ", "
                + COLUMN1_LOADCODE + ", "
                + COLUMN2_LOADSTATUS + ", "
//				+COLUMN3_CREATED_BY_USERID + ", "
                + COLUMN4_CREATED_DATE + ", "
//				+COLUMN5_USERNAME + ", "
                + COLUMN6_PLANED_DELIVERY_DATE + ", "
                + COLUMN7_CARRIER_NAME + ", "
                + COLUMN8_DRIVER_NAME + ", "
//				+COLUMN9_NAME + ", "
//				+COLUMN10_VEHICLE_MAX_WEIGHT + ", "
                + COLUMN11_BAYNUMBER + ", "
                + COLUMN12_LOADMOBILESTATUS + ", "
//				+COLUMN13_ISLOCKED + ", "
//				+COLUMN14_PICKERID + ", "
//				+COLUMN15_DRIVERID + ", "
                + COLUMN16_WEIGHT + ", "
//				+COLUMN17_IS_LOAD_COMPLETE + ", "
//				+COLUMN18_IS_LOCAL_MODIFIED + ", "
//				+COLUMN19_ORDER_REFS + ", "
//				+COLUMN20_PART_ITEMS
                + COLUMN17_CANQC

                + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        SQLiteDatabase db = data.getWritableDatabase();
        db.beginTransactionNonExclusive();

        Log.e("sql_PickLoadAssigned ", "so ban ghi PickLoadAssigned can duoc insert vao sqlite = " + jsonArr.length());
        try {
            SQLiteStatement sqlSTMT = db.compileStatement(sql);
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonLoadAssigned = jsonArr.getJSONObject(i);

				/*Tam thoi chi insert cac cot can su dung con cac cot khong su dung tam thoi comment*/
                sqlSTMT.bindLong(1, jsonLoadAssigned.getInt("LoadID"));
                sqlSTMT.bindString(2, jsonLoadAssigned.getString("LoadCode"));
                sqlSTMT.bindString(3, jsonLoadAssigned.getString("LoadStatus"));
                sqlSTMT.bindString(4, jsonLoadAssigned.getString("CreatedDate"));
                sqlSTMT.bindString(5, jsonLoadAssigned.getString("PlannedDeliveryDate"));
                sqlSTMT.bindString(6, jsonLoadAssigned.getString("carrierName"));
                sqlSTMT.bindString(7, jsonLoadAssigned.getString("DriverName"));
                sqlSTMT.bindLong(8, jsonLoadAssigned.getInt("BayNumber"));
                sqlSTMT.bindString(9, jsonLoadAssigned.getString("LoadMobileStatus"));
                sqlSTMT.bindDouble(10, jsonLoadAssigned.getDouble("Weight"));
                sqlSTMT.bindString(11, jsonLoadAssigned.getString("IsQC"));

//			sqlSTMT.bindLong(1, jsonLoadAssigned.getInt("LoadID"));
////			sqlSTMT.bindString(2,jsonLoadAssigned.getString("LoadCode"));
//			sqlSTMT.bindString(3, jsonLoadAssigned.getString("LoadStatus"));
////			sqlSTMT.bindLong(4, jsonLoadAssigned.getInt("CreatedByUserID"));
////			sqlSTMT.bindString(5, jsonLoadAssigned.getString("CreatedDate") );
////			
////			sqlSTMT.bindString(6, jsonLoadAssigned.getString("Username"));
//			sqlSTMT.bindString(7, jsonLoadAssigned.getString("PlannedDeliveryDate"));
////			sqlSTMT.bindString(8, jsonLoadAssigned.getString("carrierName"));
////			sqlSTMT.bindString(9, jsonLoadAssigned.getString("DriverName") );
////			sqlSTMT.bindString(10, jsonLoadAssigned.getString("Name") );
////			
////			sqlSTMT.bindLong(11, jsonLoadAssigned.getInt("VehicleMaxWeight") );
//			sqlSTMT.bindLong(12, jsonLoadAssigned.getInt("BayNumber") );
//			sqlSTMT.bindString(13, jsonLoadAssigned.getString("LoadMobileStatus") );
////			sqlSTMT.bindString(14, jsonLoadAssigned.getString("IsLocked") );
////			sqlSTMT.bindLong(15, jsonLoadAssigned.getInt("PickerID") );
////			
////			sqlSTMT.bindLong(16, jsonLoadAssigned.getInt("DriverID"));
//			sqlSTMT.bindDouble(17, jsonLoadAssigned.getDouble("Weight"));
////			sqlSTMT.bindString(18, jsonLoadAssigned.getString("IsLoadComplete") );			
////			sqlSTMT.bindString(19, jsonLoadAssigned.getString("IsLocalModified"));
////			sqlSTMT.bindString(20, jsonLoadAssigned.getString("OrderRefs"));
////			
////			sqlSTMT.bindString(21, jsonLoadAssigned.getString("PartItems"));

                sqlSTMT.execute();
                sqlSTMT.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.e("sql_PickLoadAssign", " insertTransaction jsonLoadAssigned to sqlite error ");
        }
        db.close();
        Log.e("sql_PickLoadAssign", " so ban ghi duoc qickly insert  =  " + getCountLoadAssigned());
    }


    public PickLoad getLoadWhereID(String LoadID) {
        PickLoad loadAssigned;

        String selectUser = "SELECT "
                + COLUMN0_LOADID + ", "
                + COLUMN1_LOADCODE + ", "
                + COLUMN2_LOADSTATUS + ", "
                + COLUMN4_CREATED_DATE + ", "
                + COLUMN6_PLANED_DELIVERY_DATE + ", "
                + COLUMN8_DRIVER_NAME + ", "
                + COLUMN11_BAYNUMBER + ", "
                + COLUMN12_LOADMOBILESTATUS + ", "
                + COLUMN16_WEIGHT + ", "
                + COLUMN7_CARRIER_NAME + ", "
                + COLUMN17_CANQC + " "
                + " FROM " + TABLE_LOAD_ASSIGNED + " WHERE " + COLUMN0_LOADID + " = '" + LoadID + "'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectUser, null);
        cursor.moveToFirst();

        loadAssigned = new PickLoad(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getInt(6), cursor.getString(7), cursor.getDouble(8), cursor.getString(9), cursor.getString(10));
//		loadAssigned.setLoadID(cursor.getInt(0));
//		loadAssigned.setLoadStatus(cursor.getString(1));
//		loadAssigned.setPlannedDeliveryDate(cursor.getString(2));
//		loadAssigned.setDriverName(cursor.getString(3));
//		loadAssigned.setBayNumber(cursor.getInt(4));
//		loadAssigned.setLoadMobileStatus(cursor.getString(5));
//		loadAssigned.setWeight(cursor.getDouble(6));
        cursor.close();
        db.close();
        return loadAssigned;
    }


    public int updateLoadMobileStatus(String LoadID, String LoadMobileStatus) {

        SQLiteDatabase db = data.getReadableDatabase();
//		String sql  = "Update "+ TABLE_LOAD_ASSIGNED + " set " + COLUMN12_LOADMOBILESTATUS + " = '" + LoadMobileStatus + "' WHERE " + COLUMN0_LOADID + " = " + LoadID;
        ContentValues values = new ContentValues();
        values.put(COLUMN12_LOADMOBILESTATUS, LoadMobileStatus);
        int c = 0;
        try {
            c = db.update(TABLE_LOAD_ASSIGNED, values, COLUMN0_LOADID + " = ?", new String[]{LoadID});
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }
        return c;
    }


    public int deleteLoad(String LoadID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int c = 0;
        try {
            c = db.delete(TABLE_LOAD_ASSIGNED, COLUMN0_LOADID + " = ?", new String[]{LoadID});

            db.close();
            Log.e("Delete Load Depatched " + LoadID, "success!");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }

        return c;
    }


    //	public String[] getSearchUsername(String search) {
//	String[] username;
//	String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
//	SQLiteDatabase db = data.getReadableDatabase();
//	Cursor cursor = db.rawQuery(sqlSelect, null);
//	username = new String[cursor.getCount()];
//	cursor.moveToFirst();
//	for (int i = 0; i < cursor.getCount(); i++) {
//		username[i] = cursor.getString(0);
//		cursor.moveToNext();
//	}
//	cursor.close();
//	db.close();
//	return username;
//}
//
//public int getCountSearch(String search) {
//	int count = 0;
//	String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
//	SQLiteDatabase db = data.getReadableDatabase();
//	Cursor cursor = db.rawQuery(sqlSelect, null);
//	count = cursor.getCount();
//	cursor.close();
//	db.close();
//	return count;
//}

}
