package vcn.kybotech.model;

import vcn.kybotech.constants.Constants;

import android.content.Context;
import android.content.SharedPreferences;


public class FileSave {
    private int userID;
    private String userName;
    private int pickerID;
    private String pickerName;
    private int warehouselocationID;
    private boolean islogin;
    private boolean isadmin;
    private boolean isRememberLogin;
    private boolean isAppInstalled;
    private String LoadCode;
    private int CountPhoto;
    private int CountPhotoAD;
    private int PhotoType;
    private int LoadId;
    private String name;
    private String deviceID;
    private Context context;
    private boolean isDevicedLogin;
    private SharedPreferences.Editor editor;
    private SharedPreferences preferences;

    public FileSave(Context context, String type) {
        super();
        this.context = context;
        if (context == null) {
            return;
        } else if (type.equals(Constants.PUT)) {
            editor = context.getSharedPreferences(Constants.TEMP_PICKING_APP, 0).edit();
        } else {
            if (type.equals(Constants.GET)) {
                preferences = context.getSharedPreferences(Constants.TEMP_PICKING_APP, 0);
            }
        }
    }

    public int getUserID() {
        if (context == null) {
            return -1;
        }
        this.userID = preferences.getInt(Constants.key_int_UserID, -1);
        return userID;
    }

    public void putUserID(int userID) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_UserID, userID);
        editor.commit();
    }

    public String getUserName() {
        if (context == null) {
            return "";
        }
        this.userName = preferences.getString(Constants.key_String_UserName, "");
        return userName;
    }

    public void putUserName(String userName) {
        if (context == null) {
            return;
        }
        editor.putString(Constants.key_String_UserName, userName);
        editor.commit();
    }

    public int getPickerID() {
        if (context == null) {
            return -1;
        }
        this.pickerID = preferences.getInt(Constants.key_int_PickerID, -1);
        return pickerID;
    }

    public void putPickerID(int pickerID) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_PickerID, pickerID);
        editor.commit();
    }

    public String getPickerName() {
        if (context == null) {
            return "";
        }
        this.pickerName = preferences.getString(Constants.key_String_PickerName, "");
        return pickerName;
    }

    public void putPickerName(String pickerName) {
        if (context == null) {
            return;
        }
        editor.putString(Constants.key_String_PickerName, pickerName);
        editor.commit();
    }

    public int getWarehouselocationID() {
        if (context == null) {
            return -1;
        }
        this.warehouselocationID = preferences.getInt(Constants.key_int_WarehouseLocationID, -1);
        return warehouselocationID;
    }

    public void putWarehouselocationID(int warehouselocationID) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_WarehouseLocationID, warehouselocationID);
        editor.commit();
    }

    public boolean getIslogin() {
        if (context == null) {
            return false;
        }
        this.islogin = preferences.getBoolean(Constants.key_boolean_islogin, false);
        return islogin;
    }

    public void putIslogin(boolean islogin) {
        if (context == null) {
            return;
        }
        editor.putBoolean(Constants.key_boolean_islogin, islogin);
        editor.commit();
    }

    public boolean getIsAdmin() {
        if (context == null) {
            return false;
        }
        this.isadmin = preferences.getBoolean(Constants.key_boolean_isadmin, false);
        return isadmin;
    }

    public void putIsAdmin(boolean isadmin) {
        if (context == null) {
            return;
        }
        editor.putBoolean(Constants.key_boolean_isadmin, isadmin);
        editor.commit();
    }

    public boolean getRememberLogin() {
        if (context == null) {
            return false;
        }
        this.isRememberLogin = preferences.getBoolean(Constants.key_boolean_remember_login, false);
        return isRememberLogin;
    }

    public void putIsRememberLogin(boolean isRememberLogin) {
        if (context == null) {
            return;
        }
        editor.putBoolean(Constants.key_boolean_remember_login, isRememberLogin);
        editor.commit();
    }

    public boolean getAppInstalled() {
        if (context == null) {
            return false;
        }
        this.isAppInstalled = preferences.getBoolean(Constants.key_boolean_app_installed, false);
        return isAppInstalled;
    }

    public void putAppInstalled(boolean isAppInstalled) {
        if (context == null) {
            return;
        }
        editor.putBoolean(Constants.key_boolean_app_installed, isAppInstalled);
        editor.commit();
    }

    public String getLoadCode() {
        if (context == null) {
            return "";
        }
        this.LoadCode = preferences.getString(Constants.key_String_LoadCode, "");
        return LoadCode;
    }

    public void putLoadCode(String loadCode) {
        if (context == null) {
            return;
        }
        editor.putString(Constants.key_String_LoadCode, loadCode);
        editor.commit();
    }

    public int getCountPhoto() {
        if (context == null) {
            return -1;
        }
        this.CountPhoto = preferences.getInt(Constants.key_int_CountPhoto, -1);
        return CountPhoto;
    }

    public int getCountPhotoAD() {
        if (context == null) {
            return -1;
        }
        this.CountPhotoAD = preferences.getInt(Constants.key_int_CountPhotoAD, -1);
        return CountPhotoAD;
    }

    public int getPhotoType() {
        if (context == null) {
            return 1;
        }
        this.PhotoType = preferences.getInt(Constants.key_int_PhotoType, -1);
        return PhotoType;
    }

    public void putCountPhoto(int countPhoto) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_CountPhoto, countPhoto);
        editor.commit();
    }

    public void putCountPhotoAD(int countPhotoAD) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_CountPhotoAD, countPhotoAD);
        editor.commit();
    }

    public void putPhotoType(int photoType) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_PhotoType, photoType);
        editor.commit();
    }

    public int getLoadId() {
        if (context == null) {
            return -1;
        }
        this.LoadId = preferences.getInt(Constants.key_int_LoadId, -1);
        return LoadId;
    }

    public void putLoadId(int loadId) {
        if (context == null) {
            return;
        }
        editor.putInt(Constants.key_int_LoadId, loadId);
        editor.commit();
    }

    public String getName() {
        if (context == null) {
            return "";
        }
        this.name = preferences.getString(Constants.key_String_Name, "");
        return name;
    }


    public void putName(String userName) {
        if (context == null) {
            return;
        }
        editor.putString(Constants.key_String_Name, userName);
        editor.commit();
    }


    public void putDeviceID(String deviceID) {
        if (context == null) {
            return;
        }
        editor.putString(Constants.key_String_DeviceID, deviceID);
        editor.commit();
    }

    public String getDeviceID() {
        if (context == null) {
            return "";
        }
        this.deviceID = preferences.getString(Constants.key_String_DeviceID, "");
        return deviceID;
    }

    public boolean getIsDeviceLogin() {
        if (context == null) {
            return false;
        }
        this.isDevicedLogin = preferences.getBoolean(Constants.key_boolean_isDevicelogin, false);
        return isDevicedLogin;
    }

    public void putIsDeviceLogin(boolean isDevicedLogin) {
        if (context == null) {
            return;
        }
        editor.putBoolean(Constants.key_boolean_isDevicelogin, isDevicedLogin);
        editor.commit();
    }
}
