package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;

public class PickerAccountJSONArray {
	private JSONParser jsonParser;

	public PickerAccountJSONArray() {
		jsonParser = new JSONParser();
	}

	public JSONObject getJSONListPickerAccount() {
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(Constants.type, Constants.type_ListPickers));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PICK_ACCOUNT, params);
		return objJSON;
	}
}
