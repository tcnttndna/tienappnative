package vcn.kybotech.constants;

public class DeviceInfo {

	public static String deviceName() {
		
		String Model = android.os.Build.MODEL ;
		return Model;
	}
	
	public static String deviceAndroidVersion() {
		
		String Android_version = android.os.Build.VERSION.RELEASE ;
		return Android_version;
	}
}
