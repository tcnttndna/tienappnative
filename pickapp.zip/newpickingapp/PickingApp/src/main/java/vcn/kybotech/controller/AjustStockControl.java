package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;
import android.content.Context;

public class AjustStockControl {
	private JSONParser jsonParser;
	private String username;
	private int pickerid;
	
	public AjustStockControl(Context context){
		jsonParser = new JSONParser();
		FileSave file = new FileSave(context, Constants.GET);
		pickerid = file.getPickerID();
		username = file.getPickerName();
		if(!file.getName().equals("")){
			username = username + " - " + file.getName();
		}
	}
	
	public JSONObject uploadAjustStock(int partid, int warehouseid, String freeqty, String allocatedqty, String newqty, String includedallocated){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "ajuststock"));
		params.add(new BasicNameValuePair("partid", String.valueOf(partid)));
		params.add(new BasicNameValuePair("warehouseid", String.valueOf(warehouseid)));
		params.add(new BasicNameValuePair("freeqty", freeqty));
		params.add(new BasicNameValuePair("allocatedqty", allocatedqty));
		params.add(new BasicNameValuePair("newqty", newqty));
		params.add(new BasicNameValuePair("includedallocated", includedallocated));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(pickerid)));
		params.add(new BasicNameValuePair("pickername", username));
		params.add(new BasicNameValuePair("appname", "Load Mobile New"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
