package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import vcn.kybotech.model.PickPart;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class sql_PickParts {

    private sql_DataBase data;
    public static final String TABLE_PARTS = "PickParts";

    public static final String COLUMN0_ID = "Id";
    public static final String COLUMN1_PART_ID = "PartID";
    public static final String COLUMN2_IS_SCANNED = "IsScanned";
    public static final String COLUMN3_IS_QA = "IsQA";
    public static final String COLUMN4_PART_NAME = "PartName";
    public static final String COLUMN5_QUANTITY = "Quantity";

    public static final String COLUMN6_BAR_CODE = "Barcode";
    public static final String COLUMN7_ORDER_REF = "OrderRef";
    public static final String COLUMN8_ORDER_ITEM_ID = "OrderItemID";
    public static final String COLUMN9_TOTAL_PACK = "TotalPack";
    public static final String COLUMN10_DATE_SCANNED = "DateScanned";

    public static final String COLUMN11_LOCATION_NAME = "LocationName";
    public static final String COLUMN12_PICKED_BY = "PickedBy";
    public static final String COLUMN13_PICK_TYPE_ID = "PickTypeID";
    public static final String COLUMN14_PICK_TYPE = "PickType";
    public static final String COLUMN15_PRODUCT_NAME = "ProductName";

    public static final String COLUMN16_PRODUCT_OPTION = "ProductOption";
    public static final String COLUMN17_DROP_NUMBER = "DropNumber";
    public static final String COLUMN18_LOAD_CODE = "LoadCode";
    public static final String COLUMN19_PACKAGE = "Package";
    public static final String COLUMN20_SPECIAL_INSTRUCTIONS = "SpecialInstructions";
    public static final String COLUMN21_SWIPE = "Swipe";
    public static final String COLUMN22_FREE_STOCK = "FreeStock";
    public static final String COLUMN23_SWIPE_QA = "SwipeQA";
    public static final String COLUMN24_IS_STACKED = "IsStacked";
    public static final String COLUMN25_SWIPE_STACK = "SwipeStack";
    public static final String COLUMN26_STACKED_BY = "StackedBy";
    public static final String COLUMN27_IS_CHECKED = "IsChecked";
    public static final String COLUMN28_SWIPE_CHECK = "SwipeCheck";
    public static final String COLUMN29_CHECKED_BY = "CheckedBy";
    public static final String COLUMN30_PICKING_NOTES = "PickingNotes";
    public static final String COLUMN31_IS_LOADED = "IsLoaded";
    public static final String COLUMN32_SWIPE_LOADING = "SwipeLoading";
    public static final String COLUMN33_LOADED_BY = "LoadedBy";
    public static final String COLUMN34_PART_GROUP_NAME = "PartGroupName";
    public static final String COLUMN35_IS_NEED_SCAN = "NeedScan";
    public static final String COLUMN36_PART_GROUP_ID = "PartGroupID";
    public static final String COLUMN37_SWIPE_QC = "SwipeQC";
    public static final String COLUMN38_IS_QC = "IsQC";

    public static final String CREATE_TABLE_PART = "CREATE TABLE " + TABLE_PARTS + " (" + COLUMN0_ID
            + " INTEGER PRIMARY KEY, " + COLUMN1_PART_ID + " INTEGER, " + COLUMN2_IS_SCANNED + " TEXT, " + COLUMN3_IS_QA
            + " TEXT, " + COLUMN4_PART_NAME + " TEXT, " + COLUMN5_QUANTITY + " INTEGER, "

            + COLUMN6_BAR_CODE + " TEXT, " + COLUMN7_ORDER_REF + " TEXT, " + COLUMN8_ORDER_ITEM_ID + " INTEGER, "
            + COLUMN9_TOTAL_PACK + " INTEGER, " + COLUMN10_DATE_SCANNED + " TEXT, "

            + COLUMN11_LOCATION_NAME + " TEXT, " + COLUMN12_PICKED_BY + " TEXT, " + COLUMN13_PICK_TYPE_ID + " INTEGER, "
            + COLUMN14_PICK_TYPE + " TEXT, " + COLUMN15_PRODUCT_NAME + " TEXT, "

            + COLUMN16_PRODUCT_OPTION + " TEXT, " + COLUMN17_DROP_NUMBER + " INTEGER, " + COLUMN18_LOAD_CODE + " TEXT, "
            + COLUMN19_PACKAGE + " INTEGER, " + COLUMN20_SPECIAL_INSTRUCTIONS + " TEXT, " + COLUMN21_SWIPE
            + " INTEGER, " + COLUMN22_FREE_STOCK + " INTEGER, " + COLUMN23_SWIPE_QA + " INTEGER, " + COLUMN24_IS_STACKED
            + " TEXT, " + COLUMN25_SWIPE_STACK + " INTEGER, " + COLUMN26_STACKED_BY + " TEXT ," + COLUMN27_IS_CHECKED
            + " TEXT, " + COLUMN28_SWIPE_CHECK + " INTEGER, " + COLUMN29_CHECKED_BY + " TEXT, " + COLUMN30_PICKING_NOTES
            + " TEXT, " + COLUMN31_IS_LOADED + " TEXT, " + COLUMN32_SWIPE_LOADING + " INTEGER, " + COLUMN33_LOADED_BY
            + " TEXT, " + COLUMN34_PART_GROUP_NAME + " TEXT, " + COLUMN35_IS_NEED_SCAN + " TEXT " + " , " + COLUMN36_PART_GROUP_ID + " INTEGER, "
            + COLUMN37_SWIPE_QC + " INTEGER, " + COLUMN38_IS_QC  + " TEXT " + " )";

    public sql_PickParts(Context context) {
        data = new sql_DataBase(context);
    }

    /* Pick QA - Normal Pick */
    public boolean checkExistsBarCode(String OrderItemID, String Barcode) {
        boolean output = false;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN6_BAR_CODE + " = '" + Barcode + "' ";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                int c = cursor.getInt(0);
                if (c > 0) {
                    return true;
                }
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    /* Pick QA - Normal Pick */
    /* Picking QA - NormalPick */
    public boolean checkExistsData(String OrderItemID, String PartID) {
        boolean output = false;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN1_PART_ID + " = " + PartID;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                int c = cursor.getInt(0);
                if (c > 0) {
                    return true;
                }
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    /* Kiem tra xem co bao nhieu ban ghi */
    public int getCountParts() {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {

            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return c;
    }

    /* NewPickApp NormalPicking - Dem so Part in OrderItem */
    public int getCountParts(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " WHERE " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* NewPickApp NormalPicking - Dem so Part scanned in OrderItem */
    public int getCountPartScanned(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN2_IS_SCANNED + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* NewPickApp NormalPicking - Dem so Part scanned in OrderItem */
    public int getCountPartLoaded(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN31_IS_LOADED + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* NewPick dem so part con lai chua scanned */
    public int getCountPartNotScan(String OrderRef) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN7_ORDER_REF + " = '" + OrderRef
                + "' AND " + COLUMN2_IS_SCANNED + " = 'false'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* NewPickApp QA - Dem so Part scanned in OrderItem */
    public int getCountPartScannedQA(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN3_IS_QA + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* NewPickApp QA - Dem so Part scanned in OrderItem */
    public int getCountPartScannedQC(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN38_IS_QC + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
        }
        return c;
    }

    /* NewPickApp Stack - Dem so Part scanned in OrderItem */
    public int getCountPartScannedStack(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN24_IS_STACKED + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* NewPickApp Double Check - Dem so Part scanned in OrderItem */
    public int getCountPartScannedCheck(String OrderItemID) {
        int c = 0;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PARTS + " Where " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + " AND " + COLUMN27_IS_CHECKED + " = 'true'";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(sqlSelect, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                c = cursor.getInt(0);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();

            if (cursor != null) {
                cursor.close();
            }

            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return c;
    }

    /* Clear du lieu */
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            db.delete(TABLE_PARTS, null, null);
            db.close();
            Log.e("sql_PickParts", " Clear Data succes");
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
    }

    /* Insert du lieu su dung transaction */
    public void insertPickLoadAssignedTransaciton(JSONArray jsonArr) {

		/* Chuoi JSONArray truyen vao la mot mang cac doi tuong */

        String sql = "INSERT INTO " + TABLE_PARTS + " ("

                + COLUMN1_PART_ID + ", " + COLUMN2_IS_SCANNED + ", " + COLUMN3_IS_QA + ", " + COLUMN4_PART_NAME + ", "
                + COLUMN5_QUANTITY + ", " + COLUMN6_BAR_CODE + ", " + COLUMN7_ORDER_REF + ", " + COLUMN8_ORDER_ITEM_ID
                + ", " + COLUMN9_TOTAL_PACK + ", " + COLUMN10_DATE_SCANNED + ", " + COLUMN11_LOCATION_NAME + ", "
                + COLUMN12_PICKED_BY + ", " + COLUMN13_PICK_TYPE_ID + ", " + COLUMN14_PICK_TYPE + ", "
                + COLUMN15_PRODUCT_NAME + ", " + COLUMN16_PRODUCT_OPTION + ", " + COLUMN17_DROP_NUMBER + ", "
                + COLUMN18_LOAD_CODE + ", " + COLUMN19_PACKAGE + ", " + COLUMN20_SPECIAL_INSTRUCTIONS + ", "
                + COLUMN21_SWIPE + ", " + COLUMN22_FREE_STOCK + ", " + COLUMN23_SWIPE_QA + ", " + COLUMN24_IS_STACKED
                + ", " + COLUMN25_SWIPE_STACK + ", " + COLUMN26_STACKED_BY + ", " + COLUMN27_IS_CHECKED + ", "
                + COLUMN28_SWIPE_CHECK + ", " + COLUMN29_CHECKED_BY + ", " + COLUMN30_PICKING_NOTES + ", "
                + COLUMN31_IS_LOADED + ", " + COLUMN32_SWIPE_LOADING + ", " + COLUMN33_LOADED_BY + ", "
                + COLUMN34_PART_GROUP_NAME + ", " + COLUMN35_IS_NEED_SCAN + ", " + COLUMN36_PART_GROUP_ID  + ", " + COLUMN37_SWIPE_QC + ", " + COLUMN38_IS_QC + " ) VALUES" +
                "(?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?, "
                + "?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?, " + "? , ?, ?, ?, ?, ? , ? , ? )";

        SQLiteDatabase db = data.getWritableDatabase();
        db.beginTransactionNonExclusive();
        SQLiteStatement sqlSTMT = db.compileStatement(sql);
        Log.e("sql_PickParts ", "so ban ghi PickParts can duoc insert vao sqlite = " + jsonArr.length());
        try {
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonParts = jsonArr.getJSONObject(i);

				/*
                 * Tam thoi chi insert cac cot can su dung con cac cot khong su
				 * dung tam thoi comment
				 */
                sqlSTMT.bindLong(1, jsonParts.getLong("PartID"));

				/*
                 * Neu da scanned thi phai co ten nguoi da pickedby, neu chua
				 * scanned thi pickedby=null
				 */
                String pickby = jsonParts.getString("PickedBy");
                String iscanned = "true";
                if (pickby.equalsIgnoreCase("null")) {
                    iscanned = "false";
                }
                Log.e("sql insert part", " isScanned: " + iscanned);
                sqlSTMT.bindString(2, iscanned);
                sqlSTMT.bindString(3, jsonParts.getString("IsQA"));
                sqlSTMT.bindString(4, jsonParts.getString("PartName"));
                sqlSTMT.bindLong(5, jsonParts.getLong("Quantity"));
                //
                sqlSTMT.bindString(6, jsonParts.getString("Barcode"));
                sqlSTMT.bindString(7, jsonParts.getString("OrderRef"));
                sqlSTMT.bindLong(8, jsonParts.getLong("OrderItemID"));
                sqlSTMT.bindLong(9, jsonParts.getLong("TotalPack"));
                // sqlSTMT.bindString(10, jsonParts.getString("DateScanned") );
                //
                sqlSTMT.bindString(11, jsonParts.getString("LocationName"));
                sqlSTMT.bindString(12, jsonParts.getString("PickedBy"));
                sqlSTMT.bindLong(13, jsonParts.getLong("PickTypeID"));
                sqlSTMT.bindString(14, jsonParts.getString("PickType"));
                // sqlSTMT.bindString(15, jsonParts.getString("ProductName") );
                //
                // sqlSTMT.bindString(16, jsonParts.getString("ProductOption"));
                // sqlSTMT.bindLong(17, jsonParts.getLong("DropNumber"));
                // sqlSTMT.bindString(18, jsonParts.getString("LoadCode") );
                sqlSTMT.bindLong(19, jsonParts.getInt("Package"));
                sqlSTMT.bindString(20, jsonParts.getString("SpecialInstructions"));

				/* Neu da swipe het roi thi set swipe = Quantity, else = 0 */
                if (Boolean.parseBoolean(iscanned)) {
                    sqlSTMT.bindLong(21, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(21, 0);
                }
                sqlSTMT.bindLong(22, jsonParts.getInt("FreeStock"));

				/* Neu da swipe QA het roi thi set swipeQA = Quantity, else = 0 */
                if (jsonParts.getBoolean("IsQA")) {
                    sqlSTMT.bindLong(23, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(23, 0);
                }

				/*
                 * Neu da stacked thi phai co ten nguoi da stackedby, neu chua
				 * stacked thi stackedby=null
				 */
                String stackedby = jsonParts.getString("StackedBy");
                String isstacked = "true";
                if (stackedby.equalsIgnoreCase("null")) {
                    isstacked = "false";
                }

				/* Neu da swipe het roi thi set swipe = Quantity, else = 0 */
                if (Boolean.parseBoolean(isstacked)) {
                    sqlSTMT.bindLong(25, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(25, 0);
                }

                Log.e("sql insert part", " isstacked: " + isstacked);
                sqlSTMT.bindString(24, isstacked);
                sqlSTMT.bindString(26, stackedby);

				/*
                 * Neu da stacked thi phai co ten nguoi da stackedby, neu chua
				 * stacked thi stackedby=null
				 */
                String checkedby = jsonParts.getString("CheckedBy");
                String ischecked = "true";
                if (checkedby.equalsIgnoreCase("null")) {
                    ischecked = "false";
                }

				/* Neu da swipe het roi thi set swipe = Quantity, else = 0 */
                if (Boolean.parseBoolean(ischecked)) {
                    sqlSTMT.bindLong(28, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(28, 0);
                }

                sqlSTMT.bindString(27, ischecked);
                sqlSTMT.bindString(29, checkedby);
                sqlSTMT.bindString(30, jsonParts.getString("PickingNotes"));

				/*
				 * Neu da loaded thi phai co ten nguoi da loadedby, neu chua
				 * loaded thi loadedby=null
				 */
                String loadedby = jsonParts.getString("LoadedBy");
                String isloaded = "true";
                if (loadedby.equalsIgnoreCase("null")) {
                    isloaded = "false";
                }

				/* Neu da load het roi thi set swipeLoaded = Quantity, else = 0 */
                if (Boolean.parseBoolean(isloaded)) {
                    sqlSTMT.bindLong(32, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(32, 0);
                }

                sqlSTMT.bindString(31, isloaded);
                sqlSTMT.bindString(33, loadedby);
                sqlSTMT.bindString(34, jsonParts.getString("PartGroupName"));
                sqlSTMT.bindString(35, jsonParts.getString("NeedScan"));
                sqlSTMT.bindLong(36, jsonParts.getLong("PartGroupID"));
                /* Neu da swipe QC het roi thi set swipeQC = Quantity, else = 0 */
                if (jsonParts.getBoolean("IsQC")) {
                    sqlSTMT.bindLong(37, jsonParts.getLong("Quantity"));
                } else {
                    sqlSTMT.bindLong(37, 0);
                }

//                String pickby = jsonParts.getString("PickedBy");
//                String iscanned = "true";
//                if (pickby.equalsIgnoreCase("null")) {
//                    iscanned = "false";
//                }
//                Log.e("sql insert part", " isScanned: " + iscanned);
//                sqlSTMT.bindString(2, iscanned);

                sqlSTMT.bindString(38, jsonParts.getString("IsQC"));
                sqlSTMT.execute();
                sqlSTMT.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (Exception e) {
            if (db != null) {
                db.close();
            }

            e.printStackTrace();
            Log.e("sql_PickParts", " insertTransaction jsonParts to sqlite error ");
        }
        db.close();
        Log.e("sql_PickParts", " so ban ghi duoc qickly insert  =  " + getCountParts());
    }

    /* Ham nay dung de scan part NormalPick - NewPick */
	/* Da try cat */
	/*
	 * Do trong bang Part co the co nhieu hon 2 part co cung id, orderItemID nen
	 * phai dung cot id de xac dinh
	 */
    public int updateSwipe(int OrderItemID, int PartID, int id, String pickedBy) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickParts set Swipe = (Swipe +1) where OrderItemID = " + OrderItemID + " and PartID = "
                + PartID + " and " + COLUMN2_IS_SCANNED + " = 'false' and " + COLUMN0_ID + "  = " + id;

		/* Neu swipe full cua tung part thi no se update PickedBy nguoi swipe */
        ContentValues values = new ContentValues();
        values.put(COLUMN2_IS_SCANNED, "true");
        values.put(COLUMN12_PICKED_BY, pickedBy);

        String whereClause = COLUMN21_SWIPE + " = " + COLUMN5_QUANTITY + "  AND " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + "  AND " + COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;

    }

    public int updateSwipeLoading(int OrderItemID, int PartID, int id, String pickedBy) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickParts set SwipeLoading = (SwipeLoading +1) where OrderItemID = " + OrderItemID + " and PartID = "
                + PartID + " and " + COLUMN31_IS_LOADED + " = 'false' and " + COLUMN0_ID + "  = " + id;

		/* Neu swipe full cua tung part thi no se update PickedBy nguoi swipe */
        ContentValues values = new ContentValues();
        values.put(COLUMN31_IS_LOADED, "true");
        values.put(COLUMN33_LOADED_BY, pickedBy);

        String whereClause = COLUMN32_SWIPE_LOADING + " = " + COLUMN5_QUANTITY + "  AND " + COLUMN8_ORDER_ITEM_ID
                + " = " + OrderItemID + "  AND " + COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;

    }

    /* UPDATE SCAN FOR QA */
    public int updateSwipeQA(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickParts set SwipeQA = (SwipeQA +1) where OrderItemID = " + OrderItemID + " and PartID = "
                + PartID + " and " + COLUMN3_IS_QA + " = 'false' and " + COLUMN0_ID + "  = " + id;

		/* Neu swipe full cua tung part thi no se update PickedBy nguoi swipe */
        ContentValues values = new ContentValues();
        values.put(COLUMN3_IS_QA, "true");

        String whereClause = COLUMN23_SWIPE_QA + " = " + COLUMN5_QUANTITY + "  AND " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + "  AND " + COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan QA part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned QA 	part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;

    }

    public int updateSwipeQC(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickParts set SwipeQC = (SwipeQC +1) where OrderItemID = " + OrderItemID + " and PartID = "
                + PartID + " and " + COLUMN38_IS_QC + " = 'false' and " + COLUMN0_ID + "  = " + id;

		/* Neu swipe full cua tung part thi no se update PickedBy nguoi swipe */
        ContentValues values = new ContentValues();
        values.put(COLUMN38_IS_QC, "true");

        String whereClause = COLUMN37_SWIPE_QC + " = " + COLUMN5_QUANTITY + "  AND " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + "  AND " + COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan QC part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned QC 	part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;

    }

    /* UPDATE SCAN FOR STACK */
    public int updateSwipeStack(int OrderItemID, int PartID, int id, String pickedBy) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickParts set SwipeStack = (SwipeStack +1) where OrderItemID = " + OrderItemID
                + " and PartID = " + PartID + " and " + COLUMN24_IS_STACKED + " = 'false' and " + COLUMN0_ID + "  = "
                + id;

		/* Neu swipe full cua tung part thi no se update PickedBy nguoi swipe */
        ContentValues values = new ContentValues();
        values.put(COLUMN24_IS_STACKED, "true");
        values.put(COLUMN26_STACKED_BY, pickedBy);

        String whereClause = COLUMN25_SWIPE_STACK + " = " + COLUMN5_QUANTITY + "  AND " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + "  AND " + COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan Stack part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned Stack 	part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;

    }

    /* UPDATE SCAN FOR STACK */
    public int updateSwipeCheck(int OrderItemID, int PartID, int id, String pickedBy) {
        SQLiteDatabase db = data.getWritableDatabase();
        String sql = "update PickParts set SwipeCheck = (SwipeCheck +1) where OrderItemID = " + OrderItemID
                + " and PartID = " + PartID + " and " + COLUMN27_IS_CHECKED + " = 'false' and " + COLUMN0_ID + "  = "
                + id;

		/* Neu swipe full cua tung part thi no se update PickedBy nguoi swipe */
        ContentValues values = new ContentValues();
        values.put(COLUMN27_IS_CHECKED, "true");
        values.put(COLUMN29_CHECKED_BY, pickedBy);

        String whereClause = COLUMN28_SWIPE_CHECK + " = " + COLUMN5_QUANTITY + "  AND " + COLUMN8_ORDER_ITEM_ID + " = "
                + OrderItemID + "  AND " + COLUMN1_PART_ID + " = " + PartID + " AND " + COLUMN0_ID + " = " + id;

        int output = -1;
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                output = cursor.getInt(0);
                Log.e("update scan Check part", "true + output = " + output);
            }
            cursor.close();

            int c2 = db.update(TABLE_PARTS, values, whereClause, null);
            if (c2 > 0) {
                Log.e("update is scanned Check part", "true");
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;

    }

    /* Normal - kiem tra xem tat ca cac part da scanned chua */
    public boolean isAllPartScanned(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartScanned(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    /* QA - kiem tra xem tat ca cac part da scanned chua */
    public boolean isAllPartScannedQA(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartScannedQA(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    /* QA - kiem tra xem tat ca cac part da scanned chua */
    public boolean isAllPartScannedQC(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartScannedQC(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    /* Stack - kiem tra xem tat ca cac part da stacked chua */
    public boolean isAllPartScannedStacked(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartScannedStack(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    /* Check - kiem tra xem tat ca cac part da Checked chua */
    public boolean isAllPartScannedChecked(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartScannedCheck(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    public boolean isAllPartLoaded(String OrderItemID) {
        int countPick = getCountParts(OrderItemID);
        int countScanned = getCountPartLoaded(OrderItemID);
        if ((countPick > 0) && (countPick == countScanned)) {
            return true;
        }
        return false;
    }

    /* Check swipe confirm - Normal */
    public boolean checkSwipeConfirm(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN21_SWIPE};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /* Check swipe confirm - Normal */
    public boolean checkSwipeConfirmLoading(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN32_SWIPE_LOADING};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /* Check swipe confirm - QA */
    public boolean checkSwipeConfirmQA(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN23_SWIPE_QA};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /* Check swipeQC confirm - QC */
    public boolean checkSwipeConfirmQC(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN37_SWIPE_QC};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /* Check swipe confirm - Stack */
    public boolean checkSwipeConfirmStack(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN25_SWIPE_STACK};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /* Check swipe confirm - Stack */
    public boolean checkSwipeConfirmCheck(String OrderItemID, String PartID, int id) {
        SQLiteDatabase db = data.getReadableDatabase();
        String where = COLUMN8_ORDER_ITEM_ID + " = ?  AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ?";
        String[] args = new String[]{OrderItemID, PartID, String.valueOf(id)};
        String[] colums = new String[]{COLUMN5_QUANTITY, COLUMN28_SWIPE_CHECK};
        Cursor cursor = null;
        int swipe = 0;
        int total = 0;

        try {
            cursor = db.query(TABLE_PARTS, colums, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                total = cursor.getInt(0);
                swipe = cursor.getInt(1);

            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return (((total - 1) == swipe) && (total > 0));
    }

    /*
     * NormalPick - tham so dau vao chi co OrderItemID va PartID nen phai check
     * tat ca cac part co cung PartID, OrderItemID
     */
    public boolean checkPartScanned(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN2_IS_SCANNED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    public boolean checkPartScannedLoading(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN31_IS_LOADED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* CHECK SCANNED FOR QA */
    public boolean checkPartScannedQA(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN3_IS_QA + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* CHECK SCANNED FOR QA */
    public boolean checkPartScannedQC(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN37_SWIPE_QC + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* CHECK SCANNED FOR STACK */
    public boolean checkPartScannedStack(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN24_IS_STACKED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID
                + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check stacked part full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* CHECK SCANNED FOR STACK */
    public boolean checkPartScannedCheck(int OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN27_IS_CHECKED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID
                + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql, new String[]{String.valueOf(PartID), String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check checked part full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* NewPickApp */
    public boolean checkPartScanned(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN2_IS_SCANNED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN0_ID + " = ?";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql,
                    new String[]{String.valueOf(PartID), String.valueOf(OrderItemID), String.valueOf(id)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* NewPickApp */
    public boolean checkPartScannedStack(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN24_IS_STACKED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID
                + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN0_ID + " = ?";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql,
                    new String[]{String.valueOf(PartID), String.valueOf(OrderItemID), String.valueOf(id)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* NewPickApp */
    public boolean checkPartScannedCheck(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN27_IS_CHECKED + " from " + TABLE_PARTS + " where " + COLUMN1_PART_ID
                + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN0_ID + " = ?";
        Cursor cursor = null;
		/*
		 * Trong bang Part co the co 2 Part co cung PartID giong nhau va cung
		 * trong mot OrderItemID
		 */
		/*
		 * Vi vay de xem mot Part nao chua scanned thi lay ra de scan dung
		 * dowhile de loc ra
		 */
        try {
            cursor = db.rawQuery(sql,
                    new String[]{String.valueOf(PartID), String.valueOf(OrderItemID), String.valueOf(id)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /*
     * Normal Pick - chi kiem tra xem con cai nao chua scan, khong can dung toi
     * id cua bang Part
     */
    public boolean checkPartScannedWhereBarCode(int OrderItemID, String PartBarCode) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN2_IS_SCANNED + " from " + TABLE_PARTS + " where " + COLUMN6_BAR_CODE
                + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, new String[]{PartBarCode, String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());

                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    public boolean checkPartScannedWhereBarCodeLoading(int OrderItemID, String PartBarCode) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScanned = "false";
        String sql = "select " + COLUMN31_IS_LOADED + " from " + TABLE_PARTS + " where " + COLUMN6_BAR_CODE
                + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, new String[]{PartBarCode, String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    isScanned = cursor.getString(0);
                    if (isScanned.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());

                Log.e("sql_PickPart", "check scanpart full ==>" + isScanned);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScanned);

    }

    /* CHECK XEM DA SCANNED QA */
    public boolean checkPartScannedWhereBarCodeQA(int OrderItemID, String PartBarCode) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScannedQA = "false";
        String sql = "select " + COLUMN3_IS_QA + " from " + TABLE_PARTS + " where " + COLUMN6_BAR_CODE + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, new String[]{PartBarCode, String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    isScannedQA = cursor.getString(0);
                    if (isScannedQA.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());

                Log.e("sql_PickPart", "check scanpart full ==>" + isScannedQA);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScannedQA);

    }

    /* CHECK XEM DA SCANNED QC */
    public boolean checkPartScannedWhereBarCodeQC(int OrderItemID, String PartBarCode) {
        SQLiteDatabase db = data.getWritableDatabase();
        String isScannedQC = "false";
        String sql = "select " + COLUMN38_IS_QC + " from " + TABLE_PARTS + " where " + COLUMN6_BAR_CODE + " = ? AND "
                + COLUMN8_ORDER_ITEM_ID + " = ? ";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(sql, new String[]{PartBarCode, String.valueOf(OrderItemID)});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    isScannedQC = cursor.getString(0);
                    if (isScannedQC.equalsIgnoreCase("false")) {
                        break;
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return Boolean.parseBoolean(isScannedQC);

    }

    /* NewPickApp trong class NormalPicking - Clear part */
    public int clearScanPart(String OrderItemID, int PartID) {
        SQLiteDatabase db = data.getWritableDatabase();

        int output = -1;

        ContentValues values = new ContentValues();
        values.put(COLUMN21_SWIPE, 0);
        values.put(COLUMN2_IS_SCANNED, "false");
        values.put(COLUMN12_PICKED_BY, "null");
        output = db.update(TABLE_PARTS, values, COLUMN1_PART_ID + " = ? AND " + COLUMN8_ORDER_ITEM_ID + " = ? ",
                new String[]{String.valueOf(PartID), OrderItemID});
        db.close();
        Log.e("sql_PickPart", "clear thanh cong swipe");
        db.close();
        return output;

    }

    /* NewPickApp trong class NewPicking - PickByType - Clear part */
    public int clearScanPart(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();

        int output = -1;

        ContentValues values = new ContentValues();
        values.put(COLUMN21_SWIPE, 0);
        values.put(COLUMN2_IS_SCANNED, "false");
        values.put(COLUMN12_PICKED_BY, "null");
        output = db.update(TABLE_PARTS, values,
                COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ? ",
                new String[]{String.valueOf(OrderItemID), String.valueOf(PartID), String.valueOf(id)});
        db.close();
        Log.e("sql_PickPart", "clearScanPartNewPick thanh cong swipe");
        db.close();
        return output;

    }

    /*
     * NewPickApp NormalPicking - Clear cac part dang scan nua chung, chua
     * scanned
     */
    public int clearScanPartNotScanned(String OrderItemID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN21_SWIPE, 0);
        // values.put(COLUMN1_IS_SCANNED, "false" );
        try {
            output = db.update(TABLE_PARTS, values,
                    COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN2_IS_SCANNED + " = 'false'",
                    new String[]{OrderItemID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    /* NewPickApp NormalPicking - Clear cac part */
    public int clearAllScanPart(String OrderItemID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN21_SWIPE, 0);
        values.put(COLUMN2_IS_SCANNED, "false");
        values.put(COLUMN12_PICKED_BY, "null");
        try {
            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    public int clearAllLoadedPart(String OrderItemID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN32_SWIPE_LOADING, 0);
        values.put(COLUMN31_IS_LOADED, "false");
        values.put(COLUMN33_LOADED_BY, "null");
        try {
            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    //loading (loader)
    public int clearLoadedPart(String OrderItemID, String partID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN32_SWIPE_LOADING, 0);
        values.put(COLUMN31_IS_LOADED, "false");
        values.put(COLUMN33_LOADED_BY, "null");
        try {
//            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID});
            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + " = ? ", new String[]{OrderItemID, partID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    //Normalpick (picker)
    public int clearScanPart(String OrderItemID, String partID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN21_SWIPE, 0);
        values.put(COLUMN2_IS_SCANNED, "false");
        values.put(COLUMN12_PICKED_BY, "null");
        try {
//            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID});
            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + " = ? ", new String[]{OrderItemID, partID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    /* NewPickApp QA - Clear cac part */
    public int clearScanQAPart(String OrderItemID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN23_SWIPE_QA, 0);
        values.put(COLUMN3_IS_QA, "false");
        try {
            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return output;
    }

    public int clearScanQCPart(String OrderItemID) {
        SQLiteDatabase db = data.getWritableDatabase();
        int output = -1;
        ContentValues values = new ContentValues();
        values.put(COLUMN37_SWIPE_QC, 0);
        values.put(COLUMN38_IS_QC, "false");
        try {
            output = db.update(TABLE_PARTS, values, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID});
            db.close();
        } catch (Exception e) {

            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }
        return output;
    }


    /* NewPickApp trong class Stack - Clear part */
    public int clearScanPartStack(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();

        int output = -1;

        ContentValues values = new ContentValues();
        values.put(COLUMN25_SWIPE_STACK, 0);
        values.put(COLUMN24_IS_STACKED, "false");
        values.put(COLUMN26_STACKED_BY, "null");
        output = db.update(TABLE_PARTS, values,
                COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ? ",
                new String[]{String.valueOf(OrderItemID), String.valueOf(PartID), String.valueOf(id)});
        db.close();
        Log.e("sql_PickPart", "clearScanPartStack thanh cong swipe");
        db.close();
        return output;

    }

    /* NewPickApp trong class Check - Clear part */
    public int clearScanPartCheck(int OrderItemID, int PartID, int id) {
        SQLiteDatabase db = data.getWritableDatabase();

        int output = -1;

        ContentValues values = new ContentValues();
        values.put(COLUMN28_SWIPE_CHECK, 0);
        values.put(COLUMN27_IS_CHECKED, "false");
        values.put(COLUMN29_CHECKED_BY, "null");
        output = db.update(TABLE_PARTS, values,
                COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + " = ? AND " + COLUMN0_ID + " = ? ",
                new String[]{String.valueOf(OrderItemID), String.valueOf(PartID), String.valueOf(id)});
        db.close();
        Log.e("sql_PickPart", "clearScanPartCheck thanh cong swipe");
        db.close();
        return output;

    }

    /*
     * NewPickapp NormalPicking - Lay ra cac part co the chon scanned hoac not
     * scanned
     */
    public List<PickPart> getListParts(String OrderItemID, String isScanned) {

        List<PickPart> list = new ArrayList<PickPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? " + " AND " + COLUMN2_IS_SCANNED + " = ? ";
        String[] args = new String[]{OrderItemID, isScanned};
        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN27_IS_CHECKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN28_SWIPE_CHECK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN29_CHECKED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN30_PICKING_NOTES)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN31_IS_LOADED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN32_SWIPE_LOADING)),
                            cursor.getString(cursor.getColumnIndex(COLUMN33_LOADED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN34_PART_GROUP_NAME)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN35_IS_NEED_SCAN))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN36_PART_GROUP_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                    ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /* PickByType - Lay ra cac part theo type */
    public List<PickPart> getListPartsType(String OrderItemID, String type) {

        List<PickPart> list = new ArrayList<PickPart>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? " + " AND " + COLUMN14_PICK_TYPE + " = ? ";
        String[] args = new String[]{OrderItemID, type};
        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, COLUMN1_PART_ID + " ASC ");
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            cursor.getString(cursor.getColumnIndex(COLUMN30_PICKING_NOTES)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                            ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    /*
     * NewPickApp NormalPick - Lay ra cac Part chua scanned de gui len server
     * thuc hien scanned
     */
    public PickPart getPickPartNotScanned(String OderItemID, String PartID, String id) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + "  = ? AND " + COLUMN0_ID + " = ? ";
        String[] args = new String[]{OderItemID, PartID, id};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* NewPickApp NormalPick - Lay ra Part chua scanned */
    public PickPart getPickPartNotScanned(String OderItemID, String PartID) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + "  = ? AND " + COLUMN2_IS_SCANNED
                + " = ?";
        String[] args = new String[]{OderItemID, PartID, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* NewPickApp NormalPick - Lay ra Part chua scanned */
    public PickPart getPickPartNotScannedLoading(String OderItemID, String PartID) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + "  = ? AND " + COLUMN31_IS_LOADED
                + " = ?";
        String[] args = new String[]{OderItemID, PartID, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* GET PICK NOT SCAN FOR QA */
    public PickPart getPickPartNotScannedQA(String OderItemID, String PartID) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + "  = ? AND " + COLUMN3_IS_QA + " = ?";
        String[] args = new String[]{OderItemID, PartID, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
                part.setSwipeQA(cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* GET PICK NOT SCAN FOR QC */
    public PickPart getPickPartNotScannedQC(String OderItemID, String PartID) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN1_PART_ID + "  = ? AND " + COLUMN38_IS_QC + " = ?";
        String[] args = new String[]{OderItemID, PartID, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
                part.setSwipeQC(cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* NormalPick - Scan GTIN */
    public PickPart getPickPartWhereBarCode(String OderItemID, String BarCode) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN6_BAR_CODE + "  = ? AND " + COLUMN2_IS_SCANNED
                + " = ?";
        String[] args = new String[]{OderItemID, BarCode, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setBarcode(cursor.getString(cursor.getColumnIndex(COLUMN6_BAR_CODE)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* NormalPick - Scan GTIN */
    public PickPart getPickPartWhereBarCodeLoading(String OderItemID, String BarCode) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN6_BAR_CODE + "  = ? AND " + COLUMN31_IS_LOADED
                + " = ?";
        String[] args = new String[]{OderItemID, BarCode, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setBarcode(cursor.getString(cursor.getColumnIndex(COLUMN6_BAR_CODE)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* GET PART WHERE GTIN FOR QA */
    public PickPart getPickPartWhereBarCodeQA(String OderItemID, String BarCode) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN6_BAR_CODE + "  = ? AND " + COLUMN3_IS_QA + " = ?";
        String[] args = new String[]{OderItemID, BarCode, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setBarcode(cursor.getString(cursor.getColumnIndex(COLUMN6_BAR_CODE)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
                part.setSwipeQA(cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }

    /* GET PART WHERE GTIN FOR QA */
    public PickPart getPickPartWhereBarCodeQC(String OderItemID, String BarCode) {
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        PickPart part = null;
        String where = COLUMN8_ORDER_ITEM_ID + " = ? AND " + COLUMN6_BAR_CODE + "  = ? AND " + COLUMN38_IS_QC + " = ?";
        String[] args = new String[]{OderItemID, BarCode, "false"};

        try {
            cursor = db.query(TABLE_PARTS, null, where, args, null, null, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                part = new PickPart();
                part.setId(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)));
                part.setPartID(cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)));
                part.setIsScanned(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))));
                part.setPartName(cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)));
                part.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)));
                part.setBarcode(cursor.getString(cursor.getColumnIndex(COLUMN6_BAR_CODE)));
                part.setOrderRef(cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)));
                part.setOrderItemID(cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)));
                part.setTotalPack(cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)));
                part.setLocationName(cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)));
                part.setPickTypeID(cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)));
                part.setPackage(cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)));
                part.setSpecialInstructions(cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)));
                part.setSwipe(cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)));
                part.setSwipeQC(cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC)));
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }

        return part;
    }


    /* NewPickApp: NormalPick -- NewPick - QA */
    public List<PickPart> getListParts(String OrderItemID) {
        List<PickPart> list = new ArrayList<PickPart>();

        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_PARTS, null, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID}, null,
                    null, COLUMN31_IS_LOADED + " ASC");
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN27_IS_CHECKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN28_SWIPE_CHECK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN29_CHECKED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN30_PICKING_NOTES)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN31_IS_LOADED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN32_SWIPE_LOADING)),
                            cursor.getString(cursor.getColumnIndex(COLUMN33_LOADED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN34_PART_GROUP_NAME)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN35_IS_NEED_SCAN))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN36_PART_GROUP_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                            ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }


    /* NewPickApp: NormalPick -- NewPick - QA */
    public List<PickPart> getListPartsQC(String OrderItemID) {
        List<PickPart> list = new ArrayList<PickPart>();

        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_PARTS, null, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID}, null,
                    null, COLUMN38_IS_QC + " ASC");
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN27_IS_CHECKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN28_SWIPE_CHECK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN29_CHECKED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN30_PICKING_NOTES)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN31_IS_LOADED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN32_SWIPE_LOADING)),
                            cursor.getString(cursor.getColumnIndex(COLUMN33_LOADED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN34_PART_GROUP_NAME)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN35_IS_NEED_SCAN))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN36_PART_GROUP_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                    ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }

    public List<PickPart> getListPartsPickedASC(String OrderItemID) {
        List<PickPart> list = new ArrayList<PickPart>();

        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_PARTS, null, COLUMN8_ORDER_ITEM_ID + " = ? ", new String[]{OrderItemID}, null,
                    null, COLUMN2_IS_SCANNED + " ASC");
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickPart(cursor.getInt(cursor.getColumnIndex(COLUMN0_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN1_PART_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_SCANNED))),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN3_IS_QA))),
                            cursor.getString(cursor.getColumnIndex(COLUMN4_PART_NAME)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN5_QUANTITY)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN7_ORDER_REF)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN8_ORDER_ITEM_ID)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN9_TOTAL_PACK)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
                            cursor.getString(cursor.getColumnIndex(COLUMN11_LOCATION_NAME)),
                            cursor.getString(cursor.getColumnIndex(COLUMN12_PICKED_BY)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN13_PICK_TYPE_ID)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
                            // cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
                            // cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN19_PACKAGE)),
                            cursor.getString(cursor.getColumnIndex(COLUMN20_SPECIAL_INSTRUCTIONS)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN21_SWIPE)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN22_FREE_STOCK)),
                            cursor.getInt(cursor.getColumnIndex(COLUMN23_SWIPE_QA)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN24_IS_STACKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN25_SWIPE_STACK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN26_STACKED_BY)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN27_IS_CHECKED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN28_SWIPE_CHECK)),
                            cursor.getString(cursor.getColumnIndex(COLUMN29_CHECKED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN30_PICKING_NOTES)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN31_IS_LOADED))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN32_SWIPE_LOADING)),
                            cursor.getString(cursor.getColumnIndex(COLUMN33_LOADED_BY)),
                            cursor.getString(cursor.getColumnIndex(COLUMN34_PART_GROUP_NAME)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN35_IS_NEED_SCAN))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN36_PART_GROUP_ID)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN38_IS_QC))),
                            cursor.getInt(cursor.getColumnIndex(COLUMN37_SWIPE_QC))
                            ));

                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
            // new LogCrashActivity().inserException(e);
        }
        return list;
    }


}
