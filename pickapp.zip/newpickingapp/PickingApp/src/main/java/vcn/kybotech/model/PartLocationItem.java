package vcn.kybotech.model;

public class PartLocationItem {
	public static String COLUMN_PART_ID = "PartID";
	public static String COLUMN_LOCATION_ID = "LocationID";
	public static String COLUMN_LOCATION_NAME = "LocationName";
	public static String COLUMN_QTY = "Qty";
	public static String COLUMN_LAST_UPDATE = "LastUpdate";
	private int PartID;
	private int LocationID;
	private String LocationName;
	private int Qty;
	private String LastUpdate;
	
	public PartLocationItem() {
		super();
	}

	public PartLocationItem(int partID, int locationID, String locationName,
			int qty, String lastUpdate) {
		super();
		PartID = partID;
		LocationID = locationID;
		LocationName = locationName;
		Qty = qty;
		LastUpdate = lastUpdate;
	}

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public int getLocationID() {
		return LocationID;
	}

	public void setLocationID(int locationID) {
		LocationID = locationID;
	}

	public String getLocationName() {
		return LocationName;
	}

	public void setLocationName(String locationName) {
		LocationName = locationName;
	}

	public int getQty() {
		return Qty;
	}

	public void setQty(int qty) {
		Qty = qty;
	}

	public String getLastUpdate() {
		return LastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		LastUpdate = lastUpdate;
	}
	
	
}
