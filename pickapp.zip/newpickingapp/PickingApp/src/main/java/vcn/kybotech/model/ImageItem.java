package vcn.kybotech.model;

public class ImageItem {
	private String pathImage;
	private boolean checked;

	private String imageType;
	private String loadid;
	private String loadcode;

	private String pickerid;
	private String pickername;
	private String imageuri;

	private String orderid;
	private String orderref;
	private String orderitemid;

	public ImageItem(String pathImage, boolean checked) {
		super();
		this.pathImage = pathImage;
		this.checked = checked;
	}

	public ImageItem(String pathImage, boolean checked, String imageType,
			String loadid, String loadcode, String pickerid, String pickername,
			String imageuri, String orderid, String orderref, String orderitemid) {
		super();
		this.pathImage = pathImage;
		this.checked = checked;
		this.imageType = imageType;
		this.loadid = loadid;
		this.loadcode = loadcode;
		this.pickerid = pickerid;
		this.pickername = pickername;
		this.imageuri = imageuri;
		this.orderid = orderid;
		this.orderref = orderref;
		this.orderitemid = orderitemid;
	}

	public String getPathImage() {
		return pathImage;
	}

	public void setPathImage(String pathImage) {
		this.pathImage = pathImage;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getImageType() {
		return imageType;
	}

	public void setImageType(String imageType) {
		this.imageType = imageType;
	}

	public String getLoadid() {
		return loadid;
	}

	public void setLoadid(String loadid) {
		this.loadid = loadid;
	}

	public String getLoadcode() {
		return loadcode;
	}

	public void setLoadcode(String loadcode) {
		this.loadcode = loadcode;
	}

	public String getPickerid() {
		return pickerid;
	}

	public void setPickerid(String pickerid) {
		this.pickerid = pickerid;
	}

	public String getPickername() {
		return pickername;
	}

	public void setPickername(String pickername) {
		this.pickername = pickername;
	}

	public String getImageuri() {
		return imageuri;
	}

	public void setImageuri(String imageuri) {
		this.imageuri = imageuri;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getOrderref() {
		return orderref;
	}

	public void setOrderref(String orderref) {
		this.orderref = orderref;
	}

	public String getOrderitemid() {
		return orderitemid;
	}

	public void setOrderitemid(String orderitemid) {
		this.orderitemid = orderitemid;
	}

}
