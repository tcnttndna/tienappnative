package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;

public class AddStockControl {
	private JSONParser jsonParser;
	private int userid;
	private int warehouseid;
	private String username;

	public AddStockControl(Context context) {
		jsonParser = new JSONParser();
		FileSave file = new FileSave(context, Constants.GET);
		userid = file.getPickerID();
		warehouseid = file.getWarehouselocationID();
		username = file.getPickerName();
		if (!file.getName().equals("")) {
			username = username + " - " + file.getName();
		}
	}

	public JSONObject getWareHouse() {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "warehouse"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}

	public JSONObject getPallet() {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "loadpallet"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}

	public JSONObject getPalletDetails(String barcode) {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "palletdetail"));
		params.add(new BasicNameValuePair("palletbarcode", barcode));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}

	public JSONObject getPartLocation(int partid) {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "getpartlocation"));
		params.add(new BasicNameValuePair("partid", String.valueOf(partid)));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}

	public JSONObject uploadAddPart(int partid, String reason, int warehouseid, String quantity, String location) {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "add"));
		params.add(new BasicNameValuePair("partid", String.valueOf(partid)));
		params.add(new BasicNameValuePair("userid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("reason", reason));
		if (this.warehouseid != -1) {
			if (this.warehouseid != 0) {
				params.add(new BasicNameValuePair("warehouseid", String.valueOf(this.warehouseid)));
			} else {
				params.add(new BasicNameValuePair("warehouseid", String.valueOf(warehouseid)));
			}
		}
		params.add(new BasicNameValuePair("quantity", quantity));
		params.add(new BasicNameValuePair("username", username));
		params.add(new BasicNameValuePair("location", location));
		params.add(new BasicNameValuePair("appname", "Load Mobile New"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}

	public JSONObject uploadAddPallet(int warehouseid, String palletcode, String partid, String qtyinpallet, String reason) {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "addpallet"));
		params.add(new BasicNameValuePair("warehouseid", String.valueOf(warehouseid)));
		params.add(new BasicNameValuePair("palletcode", palletcode));
		params.add(new BasicNameValuePair("partid", partid));
		params.add(new BasicNameValuePair("qtyinpallet", qtyinpallet));
		params.add(new BasicNameValuePair("reason", reason));
		params.add(new BasicNameValuePair("userid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("username", username));
		params.add(new BasicNameValuePair("appname", "Load Mobile New"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
}
