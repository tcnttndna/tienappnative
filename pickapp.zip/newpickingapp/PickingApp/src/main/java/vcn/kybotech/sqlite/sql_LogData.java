package vcn.kybotech.sqlite;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.LogData;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class sql_LogData {
	private sql_DataBase data;
	
	private int PICKER_ID;
	private String PICKER_NAME;
	private String DATE_TIME;
	private String VERSION;
	private GPSTracker gps;
	private double LAT;
	private double LNG;
	
	public static final String TABLE_LOG_DATA = "LogData";
	public static final String COLUMN0_ID = "Id";
	public static final String COLUMN1_PICKER_ID = "PickerId";
	public static final String COLUMN2_PICKER_NAME = "PickerName";
	public static final String COLUMN3_ACTION = "Action";
	public static final String COLUMN4_LOAD_ID = "LoadId";
	public static final String COLUMN5_ORDER_REF = "OrderRef";
	public static final String COLUMN6_DESCRIPTION = "Description";
	public static final String COLUMN7_LAT = "Lat";
	public static final String COLUMN8_LNG = "Lng";
	public static final String COLUMN9_VERSION = "Version";
	public static final String COLUMN10_PHONE_DATE = "PhoneDate";
	
	public static final String CREATE_TABLE_LOG_DATA = "CREATE TABLE "
			+ TABLE_LOG_DATA +"("
			+ COLUMN0_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ COLUMN1_PICKER_ID +" INTEGER, "
			+ COLUMN2_PICKER_NAME +" TEXT, "
			+ COLUMN3_ACTION +" INTEGER, "
			+ COLUMN4_LOAD_ID +" INTEGER, "
			+ COLUMN5_ORDER_REF +" TEXT, "
			+ COLUMN6_DESCRIPTION +" TEXT, "
			+ COLUMN7_LAT +" REAL, "
			+ COLUMN8_LNG +" REAL, "
			+ COLUMN9_VERSION +" TEXT, "
			+ COLUMN10_PHONE_DATE +" TEXT)";
	
	public sql_LogData(Context context){
		data = new sql_DataBase(context);
		try {
			FileSave file = new FileSave(context, Constants.GET);
			PICKER_ID = file.getPickerID();
			PICKER_NAME = file.getPickerName();
			if(!file.getName().equals("")){
				PICKER_NAME = PICKER_NAME + " - " + file.getName();
			}
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DATE_TIME = dateFormat.format(calendar.getTime());
			VERSION = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE + " | " + String.valueOf(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
		
			gps = new GPSTracker(context);
			if (gps.canGetLocation()) {
				LAT = gps.getLatitude();
				LNG = gps.getLongitude();
			}
			gps.stopUsingGPS();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void insert(LogData obj){
		SQLiteDatabase db = data.getWritableDatabase();
		ContentValues values = new ContentValues();		
		values.put(COLUMN1_PICKER_ID, PICKER_ID);
		values.put(COLUMN2_PICKER_NAME, PICKER_NAME);
		values.put(COLUMN3_ACTION, obj.getAction());
		values.put(COLUMN4_LOAD_ID, obj.getLoadId());
		values.put(COLUMN5_ORDER_REF, obj.getOrderRef());
		values.put(COLUMN6_DESCRIPTION, obj.getDescription());
		values.put(COLUMN7_LAT, LAT);
		values.put(COLUMN8_LNG, LNG);
		values.put(COLUMN9_VERSION, VERSION);
		values.put(COLUMN10_PHONE_DATE, DATE_TIME);
		
		if(db.insert(TABLE_LOG_DATA, null, values) > 0){
			Log.e("Insert Log Data:", "LUU LOG DATA THANH CONG");
		}
		db.close();
	}
	
	public List<LogData> selectTop() {
		List<LogData> list = null;
		LogData log = null;
		SQLiteDatabase db = data.getReadableDatabase();
		String sql = "SELECT * FROM " + TABLE_LOG_DATA + "";
		Cursor cursor = db.rawQuery(sql, null);
		if (cursor.getCount() > 0) {
			list = new ArrayList<LogData>();
			cursor.moveToFirst();
			do {
				log = new LogData();

				log.setId(cursor.getInt(0));
				log.setPickerId(cursor.getInt(1));
				log.setPickerName(cursor.getString(2));
				log.setAction(cursor.getInt(3));
				log.setLoadId(cursor.getInt(4));
				log.setOrderRef(cursor.getString(5));
				log.setDescription(cursor.getString(6));
				log.setLat(cursor.getDouble(7));
				log.setLng(cursor.getDouble(8));
				log.setVersion(cursor.getString(9));
				log.setPhoneDate(cursor.getString(10));
				
				list.add(log);
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}
	
	public boolean delete(LogData obj) {
		boolean output = false;
		SQLiteDatabase db = data.getWritableDatabase();
		int sodong = db.delete(TABLE_LOG_DATA,
				COLUMN0_ID + " = " + obj.getId(), null);
		if (sodong == 1) {
			output = true;
		}
		db.close();
		return output;
	}
}
