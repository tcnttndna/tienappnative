package vcn.kybotech.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.model.PickReturnLoad;

public class sql_PickReturnLoads {

    private sql_DataBase data;
    public static final String TABLE_PICK_RETURN_LOAD = "PickReturnLoad";

    public static final String COLUMN0_LOADID = "LoadID";
    public static final String COLUMN1_LOADCODE = "LoadCode";
    public static final String COLUMN2_RETURNED = "Returned";


    public static final String CREATE_TABLE_RETURN_LOAD = "CREATE TABLE "
            + TABLE_PICK_RETURN_LOAD + " ("
            + COLUMN0_LOADID + " INTEGER PRIMARY KEY, "
            + COLUMN1_LOADCODE + " TEXT, "
            + COLUMN2_RETURNED + " TEXT "
            + " )";

    public sql_PickReturnLoads(Context context) {
        data = new sql_DataBase(context);
    }


    /* Kiem tra su ton tai cua du lieu*/
    public boolean checkExistsData() {
        boolean output = false;
        String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PICK_RETURN_LOAD;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            if (cursor.getInt(0) > 0) {
                output = true;
            }
        }

        cursor.close();
        db.close();
        return output;
    }

    /* Kiem tra xem co bao nhieu ban ghi*/
    public int getCountLoadAssigned() {
        int c = 0;
        String sqlSelect = "SELECT * FROM " + TABLE_PICK_RETURN_LOAD;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        c = cursor.getCount();
        cursor.close();
        db.close();
        return c;
    }



    /*Clear du lieu*/
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        try {
            db.delete(TABLE_PICK_RETURN_LOAD, null, null);
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
        }
    }

    /*Insert du lieu su dung transaction*/
    public void insertPickReturnLoadTransaciton(JSONArray jsonArr) {

		/*Chuoi JSONArray truyen vao la mot mang cac doi tuong */


        String sql = "INSERT INTO " + TABLE_PICK_RETURN_LOAD + " ("

                + COLUMN0_LOADID + ", "
                + COLUMN1_LOADCODE + ", "
                + COLUMN2_RETURNED + " "
                + ") VALUES (?, ?, ?)";

        SQLiteDatabase db = data.getWritableDatabase();
        db.beginTransactionNonExclusive();
        try {

            SQLiteStatement sqlSTMT = db.compileStatement(sql);
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonLoadAssigned = jsonArr.getJSONObject(i);

				/*Tam thoi chi insert cac cot can su dung con cac cot khong su dung tam thoi comment*/
                sqlSTMT.bindLong(1, jsonLoadAssigned.getInt("LoadID"));
                sqlSTMT.bindString(2, jsonLoadAssigned.getString("LoadCode"));
                sqlSTMT.bindString(3, String.valueOf(jsonLoadAssigned.getBoolean("Returned")));

                sqlSTMT.execute();
                sqlSTMT.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            db.close();
        }

    }


    public List<PickReturnLoad> getAllLoad() {

        List<PickReturnLoad> list = new ArrayList<PickReturnLoad>();
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_PICK_RETURN_LOAD, null, null, null, null, null, COLUMN0_LOADID + " ASC ");
            cursor.moveToFirst();
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new PickReturnLoad(
                            cursor.getInt(cursor.getColumnIndex(COLUMN0_LOADID)),
                            cursor.getString(cursor.getColumnIndex(COLUMN1_LOADCODE)),
                            Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_RETURNED)))));

                } while (cursor.moveToNext());
            }
            cursor.close();

        } catch (Exception e) {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        } finally {
            db.close();
        }

        return list;
    }

    public int updateConfirmedReturnLoad(String LoadID) {

        SQLiteDatabase db = data.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN2_RETURNED, "true");
        int c = 0;
        try {
            c = db.update(TABLE_PICK_RETURN_LOAD, values, COLUMN0_LOADID + " = ?", new String[]{LoadID});

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
        return c;
    }

}
