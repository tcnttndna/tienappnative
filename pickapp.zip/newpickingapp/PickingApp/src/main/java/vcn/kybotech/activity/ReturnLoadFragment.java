package vcn.kybotech.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.crash.FirebaseCrash;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vcn.kybotech.adapter.ReturnLoadAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.fragment.ReturnOrderFragment;
import vcn.kybotech.model.PickReturnLoad;
import vcn.kybotech.mycustom.LoggingExceptionHandler;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickReturnLoads;
import vcn.kybotech.sqlite.sql_PickReturnParts;

import static android.app.Activity.RESULT_OK;


public class ReturnLoadFragment extends android.app.Fragment implements interfaceReturnLoad {

    RequestQueue requestQueue;
    private final static String Tag = "cancelAll";
    private List<PickReturnLoad> listLoads;
    private ListView lvReturnLoad;
    private ReturnLoadAdapter adapter;
    private ImageButton img_refresh;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_main_return_load,container,false);
        new LoggingExceptionHandler(getActivity());
        requestQueue = Volley.newRequestQueue(getActivity());
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        if (isOnline()) {
            setActionBarBlue();
        } else {
            setActionBarRed();
        }

        ((AppCompatActivity)getActivity()).getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(false);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);

        initView(view);
        initData();
        eventOnclick();
        return view;
    }



    private void initView(View v) {
        listLoads = new ArrayList<PickReturnLoad>();
        lvReturnLoad = (ListView) v.findViewById(R.id.activity_order_picking_lvReturnLoad);
        img_refresh = (ImageButton) v.findViewById(R.id.activity_order_picking_button_refresh);
        adapter = new ReturnLoadAdapter(getActivity(), R.layout.item_return_load, listLoads);
        lvReturnLoad.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void ReInitData() {
        getReturnPartOnServer();
    }


    public void initData() {
        getReturnPartOnServer();
    }

    private void eventOnclick() {

        lvReturnLoad.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {


                    android.app.Fragment fragment = new ReturnOrderFragment();
                    Bundle bundleOrder = new Bundle();
                    bundleOrder.putSerializable(Constants.key_bundle_pickreturnload, listLoads.get(i));
                    fragment.setArguments(bundleOrder);

                    if (fragment != null) {
                        getFragmentManager().beginTransaction()
                                .add(R.id.container_main_picking_xml, fragment, "ReturnOrderFragment")
                                .addToBackStack("ReturnOrderFragment").commit();
                    }
                } catch (Exception ex) {
                    String str = ex.getMessage();
                }

            }
        });

        img_refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initData();
            }
        });
    }

    private void getReturnLoadOnServer() {
        listLoads.clear();
        adapter.notifyDataSetChanged();
        final sql_PickReturnLoads loadAssigned = new sql_PickReturnLoads(getActivity().getApplicationContext());
        loadAssigned.clearData();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {

                    JSONObject jsonObject = new JSONObject(response.toString());
                    if (jsonObject.getBoolean("success")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        if (jsonArray.length() == 0) return;

                        loadAssigned.insertPickReturnLoadTransaciton(jsonArray);
                        List<PickReturnLoad> temp = new ArrayList<PickReturnLoad>();
                        temp = loadAssigned.getAllLoad();
                        listLoads.addAll(temp);
                        setActionBarBlue();
                    } else {
                        setActionBarRed();

                        Toast.makeText(getActivity().getApplicationContext(), "Success: false, server is problem!",
                                Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e2) {
                } finally {
                    adapter.notifyDataSetChanged();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                try {
                    setActionBarRed();

                    Toast.makeText(getActivity().getApplicationContext(), "Connection to your server disconnected!", Toast.LENGTH_SHORT)
                            .show();
                    Log.e("OrderPickingActivity.java", "Load Data AccountPicker disconnect");
                    Log.e("OrderPickingActivity.java", volleyError.toString());
                } catch (Exception ex) {

                }

            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String getDate = dateFormat.format(new Date());
                params.put("type", Constants.type_returnload);
                params.put("date", getDate); // getDate
                return params;
            }
        };

        // RequestQueue requestQueue = Volley.newRequestQueue(this);
        int socketTimeout = 30000;// 30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest.setRetryPolicy(policy);
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);
    }

    private void getReturnPartOnServer() {
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();
        final sql_PickReturnParts listPart = new sql_PickReturnParts(getActivity().getApplicationContext());
        listPart.clearData();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {

                    JSONObject jsonObject = new JSONObject(response.toString());
                    if (jsonObject.getBoolean("success")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        if (jsonArray.length() == 0) return;
                        listPart.insertPickReturnLoadTransaciton(jsonArray);
                        getReturnLoadOnServer();
                        setActionBarBlue();
                    } else {
                        setActionBarRed();

                        Toast.makeText(getActivity().getApplicationContext(), "Success: false, server is problem!",
                                Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e2) {
                    FirebaseCrash.report(e2);
                } finally {
                    progressDialog.dismiss();
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                try {
                    setActionBarRed();

                    Toast.makeText(getActivity().getApplicationContext(), "Connection to your server disconnected!", Toast.LENGTH_SHORT)
                            .show();
                    Log.e("OrderPickingActivity.java", "Load Data AccountPicker disconnect");
                    Log.e("OrderPickingActivity.java", volleyError.toString());
                } catch (Exception ex) {
                    FirebaseCrash.report(ex);
                }finally {
                    progressDialog.dismiss();
                }

            }

        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String getDate = dateFormat.format(new Date());
                params.put("type", Constants.type_returnstock);
                params.put("date", getDate); // getDate
                return params;
            }
        };

        // RequestQueue requestQueue = Volley.newRequestQueue(this);
        int socketTimeout = 30000;// 30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest.setRetryPolicy(policy);
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);
    }

    public void setActionBarBlue() {
        if (((AppCompatActivity)getActivity()).getSupportActionBar() != null) {
            ((AppCompatActivity)getActivity()).getSupportActionBar()
                    .setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
        }

    }

    public void setActionBarRed() {
        if (((AppCompatActivity)getActivity()).getSupportActionBar() != null) {
            ((AppCompatActivity)getActivity()).getSupportActionBar()
                    .setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
    }

    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }



    @SuppressLint("NewApi")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                getActivity().finish();
                break;
            case R.id.menu_order_picking_user:
                dialogLogout();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogLogout() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.LOGOUT);
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent returnIntent = new Intent();
                getActivity().setResult(RESULT_OK, returnIntent);
                getActivity().finish();
            }
        });
        dialog.setNegativeButton("No", null);
        dialog.show();
    }



}
