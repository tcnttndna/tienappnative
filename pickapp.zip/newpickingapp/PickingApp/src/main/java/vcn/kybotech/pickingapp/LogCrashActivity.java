package vcn.kybotech.pickingapp;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.LogCrash;
import vcn.kybotech.mycustom.LoggingExceptionHandler;
import vcn.kybotech.sqlite.sql_LogCrash;
import android.app.Application;
import android.util.Log;

import com.google.firebase.crash.FirebaseCrash;

import java.util.Calendar;

public class LogCrashActivity extends Application {
//	private boolean mCrashing;
	@Override
	public void onCreate() {
		super.onCreate();
		new LoggingExceptionHandler(this);
	}
	
//	private class Handler implements Thread.UncaughtExceptionHandler {
//
//		public void uncaughtException(Thread t, Throwable e) {
//			if (mCrashing) return;
//			mCrashing = true;
//			try {
//				LogCrash crash = new LogCrash();
//
//				FileSave file = new FileSave(getApplicationContext(), Constants.GET);
//				crash.setPickerId(file.getPickerID());
//
//				StackTraceElement[] arrStackTrace = e.getStackTrace();
//				StringBuffer sbStackTrace = new StringBuffer();
//				sbStackTrace.append(e.getMessage());
//				sbStackTrace.append("\n");
//				sbStackTrace.append(e.getCause());
//				for (StackTraceElement i : arrStackTrace) {
//					sbStackTrace.append("\n");
//					sbStackTrace.append(i.toString());
//				}
//				crash.setMessage(e.getMessage());
//				crash.setStackTrace(sbStackTrace.toString());
//				Log.e("LogCrashActivity", crash.getMessage());
//				Log.e("LogCrashActivity", crash.getStackTrace());
////				crash.setDeviceModel(android.os.Build.MODEL);
////				crash.setAndroidVersion(android.os.Build.VERSION.RELEASE);
////				crash.setAppVersionCode(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode);
////				crash.setAppVersionName(getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
//				crash.setIsCrashed(1);
//
//				insertError(crash);
//				FirebaseCrash.report(new Exception("LOGACTIVITY " + Calendar.getInstance().getTime() + e));
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			} finally {
//				android.os.Process.killProcess(android.os.Process.myPid());
//				System.exit(10);
//			}
//		}
//	}
//
//	public void insertError(LogCrash crash) {
//		sql_LogCrash sqlCrash = new sql_LogCrash(LogCrashActivity.this);
//		sqlCrash.insert(crash);
//	}
}
