package vcn.kybotech.model;

import java.util.List;

public class PartPallet {
	public static String COLUMN_PART_PALLET_ID = "PartPalletId";
	public static String COLUMN_PARTID = "PartID";
	public static String COLUMN_QTY_IN_PALLET = "QtyInPallet";
	public static String COLUMN_PALLET_CODE = "PalletCode";
	public static String COLUMN_BARCODE = "Barcode";
	public static String COLUMN_ACTIVE = "Active";
	
	private int PartPalletID;
	private int PartID;
	private int QtyInPallet;
	private String PalletCode;
	private String Barcode;
	private Boolean Active;
	
	public PartPallet() {
		super();
	}
	
	public PartPallet(int partPalletID, int partID, int qtyInPallet, String palletCode, String barcode,
			Boolean active) {
		super();
		PartPalletID = partPalletID;
		PartID = partID;
		QtyInPallet = qtyInPallet;
		PalletCode = palletCode;
		Barcode = barcode;
		Active = active;
	}

	public int getPartPalletID() {
		return PartPalletID;
	}

	public void setPartPalletID(int partPalletID) {
		PartPalletID = partPalletID;
	}

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public int getQtyInPallet() {
		return QtyInPallet;
	}

	public void setQtyInPallet(int qtyInPallet) {
		QtyInPallet = qtyInPallet;
	}

	public String getPalletCode() {
		return PalletCode;
	}

	public void setPalletCode(String palletCode) {
		PalletCode = palletCode;
	}

	public String getBarcode() {
		return Barcode;
	}

	public void setBarcode(String barcode) {
		Barcode = barcode;
	}

	public Boolean getActive() {
		return Active;
	}

	public void setActive(Boolean active) {
		Active = active;
	}

	
}
