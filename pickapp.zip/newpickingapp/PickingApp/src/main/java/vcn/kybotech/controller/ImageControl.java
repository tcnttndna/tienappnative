package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.Image;

public class ImageControl {
	private JSONParser jsonParser;
	private String username;
	private int userid;
	
	public ImageControl(Context context){
		jsonParser = new JSONParser();
		FileSave file = new FileSave(context, Constants.GET);
		userid = file.getPickerID();
		username = file.getPickerName();
		if(!file.getName().equals("")){
			username = username + " - " + file.getName();
		}
	}
	
	public JSONObject upload(Image obj){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "uploadimagenew"));
		params.add(new BasicNameValuePair("loadid", String.valueOf(obj.getLoadId())));
		params.add(new BasicNameValuePair("loadcode", obj.getLoadCode()));
		params.add(new BasicNameValuePair("orderref", obj.getOrderRef()));
		params.add(new BasicNameValuePair("orderitemid", obj.getOrderItemId()));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("pickername", username));
		params.add(new BasicNameValuePair("imagename", obj.getImageName()));
		params.add(new BasicNameValuePair("imagetype", String.valueOf(obj.getImageType())));
		params.add(new BasicNameValuePair("imageuri", obj.getImageData()));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
	
	
	public JSONObject uploadUnpackImage(Image obj){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "uploadimagenew"));
		params.add(new BasicNameValuePair("imagetype", String.valueOf(obj.getImageType())));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("pickername", username));
		params.add(new BasicNameValuePair("packid", String.valueOf(obj.getPackId())));
		params.add(new BasicNameValuePair("partid", String.valueOf(obj.getPartId())));
		params.add(new BasicNameValuePair("imageuri", obj.getImageData()));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
	
	public JSONObject uploadTimberDeliveredImage(Image obj){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "uploadimagenew"));
		params.add(new BasicNameValuePair("imagetype", String.valueOf(obj.getImageType())));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("pickername", username));
		params.add(new BasicNameValuePair("packid", String.valueOf(obj.getPackId())));
		params.add(new BasicNameValuePair("imageuri", obj.getImageData()));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
}
