package vcn.kybotech.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SlidingDrawer;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vcn.kybotech.adapter.FilterTypeAdapter;
import vcn.kybotech.adapter.PickByTypeAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickOrderType;
import vcn.kybotech.model.PickPart;
import vcn.kybotech.model.PickType;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickLoads;
import vcn.kybotech.sqlite.sql_PickOrderType;
import vcn.kybotech.sqlite.sql_PickOrders;
import vcn.kybotech.sqlite.sql_PickPartType;
import vcn.kybotech.sqlite.sql_PickParts;

@SuppressWarnings("deprecation")
public class PickingPickByTypeFragment extends android.app.Fragment {
	
	RelativeLayout layoutFrame;
	TextView TvLoadID;
	String LoadID;
	ListView listView;
	ListView lvFilter;
	PickByTypeAdapter adapter;
	List<Object> list;
	Button buttonHidePart;
	ProgressBar progressBar;
	ProgressDialog progressDialog;
	ImageButton btnFilterType;
	SlidingDrawer slidingDrawer;
	FileSave fileSave ;
	private GPSTracker gpsTracker;
	private CommunicatingFragments communicatingFragments;
	private final static String Tag = "RequesConfirm";
	RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
	View.OnTouchListener gestureListener;
	GestureDetector gestureDetector;
	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 100;
	
	/*Luu tam kieu Loc theo loai*/
	private int TempFilter;

	
	@Override
	public void onAttach(Activity activity) {
		
		super.onAttach(activity);
		try {
			communicatingFragments = (CommunicatingFragments)getActivity();
		} catch (Exception e) {
			throw new ClassCastException(activity.toString() + " must implement CommunicatingFragments");
		}

	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_picking_load_pickbytype,container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
		
		layoutFrame = (RelativeLayout)rootView.findViewById(R.id.fragment_picking_load_pickbytype_xml);
		slidingDrawer =  (SlidingDrawer)rootView.findViewById(R.id.sliding_Filter_Type);
		btnFilterType = (ImageButton)rootView.findViewById(R.id.btnFilterType);
		TvLoadID = (TextView)rootView.findViewById(R.id.fragment_picking_load_pickbytype_loadID);
		listView =(ListView)rootView.findViewById(R.id.lvPickByType);
		lvFilter =(ListView)rootView.findViewById(R.id.lvFilterType);
		progressBar = (ProgressBar)rootView.findViewById(R.id.progressShowPart);
		buttonHidePart = (Button)rootView.findViewById(R.id.btnHidePartSwipe);
		

		return rootView;
	}

	
	
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		requestQueue = Volley.newRequestQueue(getActivity());
		
		progressDialog = new ProgressDialog(getActivity());
		progressDialog.setMessage(getString(R.string.fragment_login_waiting));
		progressDialog.setCancelable(false);
		
		TempFilter = 0;
		gpsTracker = new  GPSTracker(getActivity());
		fileSave = new FileSave(getActivity(), Constants.GET);
		
		LoadID = getArguments().getString(Constants.key_bundle_loadid);
		
		list = new ArrayList<Object>() ;
		adapter = new PickByTypeAdapter(getActivity(), R.layout.item_pick_by_type, list);
		listView.setAdapter(adapter);
		
		onShowDataInListViewFilter(TempFilter);
		onClickButton();
	}

	private void onClickButton() {
		TvLoadID.setText("Load "+LoadID);
		int h = Integer.parseInt(buttonHidePart.getTag().toString()) ;
		if (h==0) {
			buttonHidePart.setText("Hide");
		}else {
			buttonHidePart.setText("Show");
		}
		
		
		sql_PickPartType partsWithType = new sql_PickPartType(getActivity());
		List<PickType> listType = partsWithType.getListType();
		
		List<PickType> listSelectType = new ArrayList<PickType>();
		listSelectType.addAll(listType);
		listSelectType.add(0, new PickType("Selection All", -1));
		FilterTypeAdapter typeAdapter = new FilterTypeAdapter(getActivity(), R.layout.item_listview_filter_type, listSelectType);
		lvFilter.setAdapter(typeAdapter);
		
		layoutFrame.setOnClickListener(null);
		
		buttonHidePart.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				int hi = Integer.parseInt(buttonHidePart.getTag().toString()) ;
				if (hi==0) {
					buttonHidePart.setTag(1);
					buttonHidePart.setText("Show");
					adapter.hide(true);
					adapter.notifyDataSetChanged();
				}else {
					buttonHidePart.setTag(0);
					buttonHidePart.setText("Hide");
					adapter.hide(false);
					adapter.notifyDataSetChanged();
				}
				
			}
		});
		
		btnFilterType.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				if (slidingDrawer.isOpened()) {
					btnFilterType.setImageResource(R.drawable.abc_ic_search_api_mtrl_alpha);
					slidingDrawer.close();
				}else {
					btnFilterType.setImageResource(R.drawable.ic_close_filter);
					slidingDrawer.open();
				}
			}
		});
		
		lvFilter.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int positon, long arg3) {
				TempFilter = positon;
				
				onShowDataInListViewFilter(TempFilter);
					
				
				btnFilterType.setImageResource(R.drawable.abc_ic_search_api_mtrl_alpha);
				slidingDrawer.close();
				
			}
			
		});
		
		gestureDetector = new GestureDetector(new MyGestureDetector());
		gestureListener = new View.OnTouchListener() {
			@SuppressLint("ClickableViewAccessibility")
			public boolean onTouch(View v, MotionEvent event) {
					gestureDetector.onTouchEvent(event);
						return false;
			}
		};
		listView.setOnTouchListener(gestureListener);
	}
	
	private void onShowDataInListViewFilter(final int positon) {
		
		
		if (positon == 0) {
			updateListView();
			return;
		}
		/*-----------------------------------------------------------------------------------*/
		
		sql_PickOrderType sqlOrderType = new sql_PickOrderType(getActivity());
		sql_PickPartType sqlPickPartsWithType = new sql_PickPartType(getActivity());
		sql_PickParts sqlPickParts = new sql_PickParts(getActivity());
		/*ListType se luu cac kieu Type*/
		List<PickType> listType = sqlPickPartsWithType.getListType();
		
		list.clear();
		list.add(listType.get(positon-1));
		
		String type = listType.get(positon-1).getPickType();
		/*List nay lay ra cac danh sach order trong cung type*/
		List<PickOrderType> listOrder = sqlOrderType.getOrderItemType(type);
		for (int j = 0; j < listOrder.size(); j++) {
			/*2Add Order*/
			list.add(listOrder.get(j));
			int orderItemID = listOrder.get(j).getOrderItemID();
			List<PickPart> listPart = sqlPickParts.getListPartsType(String.valueOf(orderItemID), type);
			if (listPart.size()>0) {
				/*3Add Part*/
				list.addAll(listPart);
			}
		}
		
		
		try {
			adapter.notifyDataSetChanged();
			progressBar.setVisibility(View.GONE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
	class MyGestureDetector extends SimpleOnGestureListener {
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,	float velocityY) {
			try {
				if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
					return false;
				// right to left swipe
				if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
//					YourSlideRightToLeft(listView.pointToPosition((int) e1.getX(), (int) e1.getY()));

				} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					// left to right swipe
					YourSlideLeftToRight(listView.pointToPosition((int) e1.getX(), (int) e1.getY()));
				}
			} catch (Exception e) {
				// nothing
				return true;
			}

			return true;

		}
	}

	// Command for Slide Left to Right (<-----)
	public void YourSlideLeftToRight(int position)
	{
		
		
		final String  lat = String.valueOf(gpsTracker.getLatitude());
		final String  lng = String.valueOf(gpsTracker.getLongitude());
		
		Object object = list.get(position);
		if (object instanceof PickPart) {
			progressDialog.show();
			final PickPart part = (PickPart) object;
//			((PickPart) list.get(position)).setSwipe(swp);
			
			final int picker_id = fileSave.getPickerID();
			final String  picker_name = fileSave.getPickerName();
			/*Kiem tra xem scan da full chua neu full thi clear scann*/
			final sql_PickParts sqlParts = new sql_PickParts(getActivity());
			
			boolean isScanned = sqlParts.checkPartScanned(part.getOrderItemID(), part.getPartID(), part.getId());
			if (isScanned) {
				/*confirm len service truoc, neu confirm thanh cong moi cho clearn scan*/
				onConfirmPart(false, part, picker_id, picker_name, lat, lng);
			}else {
				
				try {
					/*Bat dau scan*/
					if (sqlParts.checkSwipeConfirm(String.valueOf(part.getOrderItemID()), String.valueOf(part.getPartID()),part.getId() )) {
						/*request server neu thanh cong thi moi update neu khong thi bao loi*/
						onConfirmPart(true, part, picker_id, picker_name, lat, lng);
						/*onLoadData da xu ly trong ham onConfirmPart()*/
					}else{
						sqlParts.updateSwipe(part.getOrderItemID(), part.getPartID(), part.getId(), "null");
						onShowDataInListViewFilter(TempFilter);
						progressDialog.dismiss();
					}
				} catch (Exception e) {
					progressDialog.dismiss();
					e.printStackTrace();
				}

			}
//			Toast.makeText(getActivity(), "---> Your Slide Left to Right position = " + position , Toast.LENGTH_SHORT).show();
		}
	}

	private void onConfirmPart(final boolean isConfirmPart, final PickPart pickPart , final int picker_id, final String picker_name, final String Lat, final String Lng) {
		Response.Listener<String> listener = new Response.Listener<String>(){

			@Override
			public void onResponse(String response) {

				try {
					JSONObject jsonObject = new JSONObject(response.toString());
					if (jsonObject.getBoolean("success")) {
						if (jsonObject.getBoolean("success")) {
							/*confirm len service truoc, neu confirm thanh cong moi cho ++swipe scan*/
							sql_PickParts sqlParts = new sql_PickParts(getActivity());
							
							/*Neu isConfirmPart true thi confirm --> updateSwipe, else thi clear part do*/
							if (isConfirmPart) {
								sqlParts.updateSwipe(pickPart.getOrderItemID(), pickPart.getPartID(), pickPart.getId(),picker_name);
								
							}else{
								sqlParts.clearScanPart(pickPart.getOrderItemID(), pickPart.getPartID(), pickPart.getId());
							}
							
							checkConfirmOrderItem( pickPart.getOrderItemID() );
							checkConfirmLoad();
							onShowDataInListViewFilter(TempFilter);
							
						}else {
							Toast.makeText(getActivity(), "succes: false,\nServer is problem!", Toast.LENGTH_SHORT).show();
						}
						
					}else {
						Toast.makeText(getActivity(), "success:false\nServer is problem!", Toast.LENGTH_SHORT).show();
					}
				}catch(JSONException e){
					e.printStackTrace();
					DialogServerProblem();
				}
				catch (Exception e2) {
					e2.printStackTrace();
				}
				if (progressDialog!=null) {
					progressDialog.dismiss();
//					Toast.makeText(getActivity(), "CLOSE DIALOG", Toast.LENGTH_SHORT).show();
				}
			}
			
		};
		
		Response.ErrorListener errorListener = new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError volleyError) {
				if (progressDialog!=null) {
					progressDialog.dismiss();
				}
				Toast.makeText(getActivity(), "Connection to your server disconnected!", Toast.LENGTH_SHORT).show();
			}
		};
		
		StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener){
			@Override
			protected Map<String, String> getParams(){
				Map<String, String> params ;
				
				sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
				sql_PickParts sqlParts = new sql_PickParts(getActivity());
				
				/*Kiem tra xem neu la orderItem Cuoi cung chua confirm va part cuoi cung chua confirm thi gui isorderconfirmed = true, else isorderconfirmed= false*/
				int countNotPicked = sqlOrders.getCountOrdersNotPickedInOrderRef(LoadID, pickPart.getOrderRef());
				int countPartNotScanned = sqlParts.getCountPartNotScan(pickPart.getOrderRef());
				
				if (countNotPicked == 1 && countPartNotScanned == 1) {
					params = onCreateParams(true);
				}else{
					params = onCreateParams(false);
				}
				return params;
			}

			private Map<String, String> onCreateParams(boolean isorderconfirmed)  {
				
				Map<String, String> params = new HashMap<String, String>();
				params.put("type", "scanpart");
				params.put("loadid", LoadID);
				
				params.put("orderref", pickPart.getOrderRef());
				params.put("orderitemid", String.valueOf(pickPart.getOrderItemID()));
				params.put("partid", String.valueOf(pickPart.getPartID()));
	
				params.put("partname", pickPart.getPartName());
				params.put("qty", String.valueOf(pickPart.getQuantity()));
				
				params.put("locationname", pickPart.getLocationName());
				params.put("pickerid", String.valueOf(fileSave.getPickerID()));
				
				params.put("pickername", fileSave.getPickerName());
				params.put("isscanned", String.valueOf(isConfirmPart));/*scan or clear scan*/
				
				params.put("typepick", String.valueOf(Constants.type_pick_pickbytype));
				params.put("isorderconfirmed", isorderconfirmed? "1":"0");
				
				
				params.put("InApp", "NewPickingApp");
				params.put("lat", Lat);
				params.put("lng", Lng);
				
				SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String date = "";
				String version ="";
				try {
					date =  formatngay.format(new Date());
					version = android.os.Build.MODEL + " | " +android.os.Build.VERSION.RELEASE + " | " + getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionCode;
					
					Log.e("reques ConfirmOrderItem", "Toa Do: "+ Lat + " ; " + Lng);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				params.put("version", version);
				params.put("phonedate", date);
				return params;
			}
		};
		
//		RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
		postRequest.setTag(Tag);
		postRequest.setShouldCache(false);
		requestQueue.add(postRequest);
	}
	
	
	public void DialogServerProblem(){
		Log.e("LoginFramgment", "server is problem");
		if (getActivity()==null) {
			return;
		}
		Builder dialog = new  AlertDialog.Builder(getActivity());
		dialog.setTitle("Message");
		dialog.setMessage("Server is problem");
		dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				
			}
		});
		dialog.show();
	}
	
	protected void checkConfirmOrderItem(int OrderItemID ) {
		
		sql_PickParts sqlParts = new sql_PickParts(getActivity());
		sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
	    boolean isAllPartScan = sqlParts.isAllPartScanned(String.valueOf(OrderItemID));
	    if (isAllPartScan) {
	    	sqlOrders.updateConfirmSpickedOrder(String.valueOf(OrderItemID));
		}
//	    else{
//			sqlOrders.updateClearConfirmSpickedOrder(String.valueOf(OrderItemID));
//		}
		
	}
	
	
	protected void checkConfirmLoad() {
		sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
		boolean confirmLoad = sqlOrders.checkAllOrderConfirm();
		sql_PickLoads sqlPickLoadAssigneds = new sql_PickLoads(getActivity());
		if (confirmLoad) {
			sqlPickLoadAssigneds.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picked);
//			Log.e("PickingOrderActivity", "LoadAssigned load in Sqlite");
//			listLoadAssigned.clear();
//			listLoadAssigned.addAll(sqlLoad.getAllLoadAssigned());
//			adapter.notifyDataSetChanged();
//			adapter.notifyDataSetChangedCustom();
//			lvLoadAssigned.setSelectionAfterHeaderView();
			
			AlertDialog.Builder dialog = new Builder(getActivity());
			dialog.setTitle("Message")
			.setMessage(" Load " + LoadID + " - is confirmed")
			.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					communicatingFragments.onConfirmLoadPicked(LoadID);
				}
			})
			.setCancelable(false)
			.show();
		}
//		else{
//			sqlPickLoadAssigneds.updateLoadMobileStatus(LoadID, Constants.LoadMobileStatus_Picking);
//		}
	}
	
	/*NewPicking */
	private void updateListView() {
		sql_PickOrderType sqlOrderType = new sql_PickOrderType(getActivity());
		sql_PickPartType sqlPickPartsWithType = new sql_PickPartType(getActivity());
		sql_PickParts sqlPickParts = new sql_PickParts(getActivity());
		/*ListType se luu cac kieu Type*/
		List<PickType> listType = sqlPickPartsWithType.getListType();
		
		list.clear();
		for (int i = 0; i < listType.size(); i++) {
			/*1Add Type*/
			list.add(listType.get(i));
			String type = listType.get(i).getPickType();
			/*List nay lay ra cac danh sach order trong cung type*/
			List<PickOrderType> listOrder = sqlOrderType.getOrderItemType(type);
			for (int j = 0; j < listOrder.size(); j++) {
				/*2Add Order*/
				list.add(listOrder.get(j));
				int orderItemID = listOrder.get(j).getOrderItemID();
				List<PickPart> listPart = sqlPickParts.getListPartsType(String.valueOf(orderItemID), type);
				if (listPart.size()>0) {
					/*3Add Part*/
					list.addAll(listPart);
				}
			}
		}
		
		try {
			adapter.notifyDataSetChanged();
			progressBar.setVisibility(View.GONE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@Override
	public void onDetach() {
		requestQueue.cancelAll(Tag);
		super.onDetach();
	}
}
