package vcn.kybotech.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.desarrollodroide.libraryfragmenttransactionextended.FragmentTransactionExtended;

import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.UpdateVersionControl;
import vcn.kybotech.fragment.TakeVansPhotoInputLoadFragment;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class TakeVansPhotoFragment extends Fragment {
    private FragmentManager fragment_manager;
//    private int min = 0;
//    private int sec = 59;
//    private Handler mDemnguocHandler;
//    private DemNguocRunnable mDemnguocRun;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_take_vans_photo,container,false);

        /* Create ActionBar */
//        mDemnguocHandler = new Handler();
//        mDemnguocRun = new DemNguocRunnable();
//        showDemNguoc();

        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        if (isOnline()) {
            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
        } else {
            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
        }
        ((AppCompatActivity)getActivity()).getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowTitleEnabled(false);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);

        Fragment fragment = null;
        fragment_manager = getActivity().getFragmentManager();
        fragment = new TakeVansPhotoInputLoadFragment().callHamTao();
        if (fragment != null) {
            FragmentTransaction fragmentTransaction = fragment_manager.beginTransaction();
            FragmentTransactionExtended fragmentTransactionExtended = new FragmentTransactionExtended(getActivity(), fragmentTransaction, fragment, fragment, R.id.activity_take_vans_photo_layout_frame);
            fragmentTransactionExtended.addTransition(Constants.ANIMATION);
            fragmentTransactionExtended.commit();
        }

        return view;
    }


    @SuppressLint("NewApi")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case R.id.test_menu:
                break;
            case R.id.menu_logout:
                dialog();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void dialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(Constants.LOGOUT);
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent returnIntent = new Intent();
                getActivity().setResult(RESULT_OK, returnIntent);
                getActivity().finish();
            }
        });
        dialog.setNegativeButton("No", null);
        dialog.show();
    }

    private Handler mHandler = new Handler();

    private Runnable setTitleColor = new Runnable() {
        @Override
        public void run() {
            try {
                new isOnline().execute();
                mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(setTitleColor);
//        try {
//            mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        } catch (Exception ex) {
//        }
    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    private class isOnline extends AsyncTask<String, String, JSONObject> {
        JSONObject objJSON;
        int version_in_manifest = 0;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... params) {

            UpdateVersionControl ctrUpdateVersion = new UpdateVersionControl();
            try {
                version_in_manifest = getActivity().getPackageManager()
                        .getPackageInfo(getActivity().getPackageName(), 0).versionCode;
            } catch (NameNotFoundException e) {
                e.printStackTrace();
            }
            objJSON = ctrUpdateVersion.requestServer(version_in_manifest);
            return objJSON;
        }

        @Override
        protected void onPostExecute(JSONObject objJSON) {
            if (objJSON != null) {
                try {
                    if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
                        if (objJSON.getBoolean(Constants.KEY_SUCCESS)) {
                            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
                        } else {
                            ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                ((AppCompatActivity)getActivity()).getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
            }
        }
    }

//    public class DemNguocRunnable implements Runnable {
//        @Override
//        public void run() {
//            handleDemnguoc();
//        }
//    }
//
//    private void showDemNguoc() {
//        mDemnguocHandler.removeCallbacks(mDemnguocRun);
//        mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//    }
//
//    private void handleDemnguoc() {
//        try {
//            sec--;
//            if (sec < 0) {
//                min--;
//                sec = 59;
//            }
////        Toast.makeText(this, min + ":" + sec, Toast.LENGTH_SHORT).show();
//            mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
//            if (min == 0 && sec == 29) {
//                Toast.makeText(getActivity(), "Gửi Request", Toast.LENGTH_SHORT).show();
//                FileSave file = new FileSave(getActivity(), Constants.GET);
//                if (!file.getIsDeviceLogin()) {
//                    Intent intent = new Intent();
//                    file = new FileSave(getActivity(), Constants.PUT);
//                    file.putIsDeviceLogin(true);
//                    getActivity().setResult(Constants.RESULT_SERVICE_LOGOUT, intent);
//                    getActivity().finish();
//                }
//                min = 0;
//                sec = 59;
//                showDemNguoc();
//            }
//        } catch (Exception ex) {
//            Log.e("Service Handle", ex.getMessage());
//        }
//    }

}
