package vcn.kybotech.fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import vcn.kybotech.activity.PickingNormalUploadImagesActivity;
import vcn.kybotech.activity.ReturnLoadFragment;
import vcn.kybotech.activity.interfaceReturnLoad;
import vcn.kybotech.adapter.OrdersReturnLoadAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickReturnLoad;
import vcn.kybotech.model.PickReturnPart;
import vcn.kybotech.parseapi.model.Datareturnfailoder;
import vcn.kybotech.parseapi.model.Loadreturnfailorder;
import vcn.kybotech.parseapi.remote.ApiUtils;
import vcn.kybotech.parseapi.remote.SOService;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickReturnLoads;
import vcn.kybotech.sqlite.sql_PickReturnParts;

/**
 * Created by Cuong.nv on 12/21/2017.
 */

public class ReturnOrderFragment extends android.app.Fragment implements interfaceReturnLoad  {

    private final static String Tag = "cancelAll";
    private TextView TvLoadID, TvComfirmedRL;
    private ListView lvOrder;
    private ImageView img_note;
    private OrdersReturnLoadAdapter ordersReturnLoadAdapter;
    private List<PickReturnPart> listOrderRef;
    private List<PickReturnPart> listPart;
    private Button btnBack;
    private Button btnConfirmLoad;
    private CheckBox ckbIsEmpty;
    public static int countImageUpLoaded;
    RequestQueue requestQueue;
    private int loadId;
    private int kiemtrafail = 0 ;
    private PickReturnLoad pickReturnLoad;
    sql_PickReturnParts sqlPickReturnParts;
    private SOService soService;
    ArrayList<Datareturnfailoder> listDataFail = new ArrayList<Datareturnfailoder>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_picking_return_order, container, false);
        rootView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        /* Phan dang ky findViewByID */
        requestQueue = Volley.newRequestQueue(getActivity());
        lvOrder = (ListView) rootView.findViewById(R.id.lvOrder_FragmentPickingReturnLoad);
        TvLoadID = (TextView) rootView.findViewById(R.id.tvLoadId);
        img_note = (ImageView) rootView.findViewById(R.id.img_NoteReturnLoad);
        TvComfirmedRL = (TextView) rootView.findViewById(R.id.tvComfirmedRL);
        btnBack = (Button) rootView.findViewById(R.id.btnBack);
        btnConfirmLoad = (Button) rootView.findViewById(R.id.btnConfirmLoad);
        ckbIsEmpty = (CheckBox) rootView.findViewById(R.id.ckbIsEmpty);
        listOrderRef = new ArrayList<PickReturnPart>();
        listPart = new ArrayList<PickReturnPart>();
        soService = ApiUtils.getSOService();

        return rootView;
    }

    private void kiemtrafail() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String date = df.format(Calendar.getInstance().getTime());

        soService.getOrderFail(date,date).enqueue(new Callback<Loadreturnfailorder>() {
            @Override
            public void onResponse(Call<Loadreturnfailorder> call, retrofit2.Response<Loadreturnfailorder> response) {
                if (response.isSuccessful()){
                    for (int i= 0;i<response.body().getDatareturnfailoder().size();i++){
                        if (loadId == response.body().getDatareturnfailoder().get(i).getLoadID()){
                            ordersReturnLoadAdapter.updatedAdapter(1);
                        }
                    }
                }
                else {

                }
            }

            @Override
            public void onFailure(Call<Loadreturnfailorder> call, Throwable t) {
                int g=0;
            }
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);

        try {
            this.pickReturnLoad = (PickReturnLoad) getArguments().getSerializable(Constants.key_bundle_pickreturnload);
            sqlPickReturnParts = new sql_PickReturnParts(getActivity());
            loadId = pickReturnLoad.getLoadID();
            TvLoadID.setText(loadId + "");
            // get API [SpFailedDeliveryOrders] truyen vao date now
            kiemtrafail();

            listOrderRef = sqlPickReturnParts.getListOrderOfLoad(String.valueOf(pickReturnLoad.getLoadID()));
            ordersReturnLoadAdapter = new OrdersReturnLoadAdapter(getActivity(), R.layout.item_return_order, listOrderRef,kiemtrafail);
            lvOrder.setAdapter(ordersReturnLoadAdapter);

            if (!pickReturnLoad.isReturned()) {
                TvComfirmedRL.setVisibility(View.GONE);
                lvOrder.setVisibility(View.VISIBLE);
                ckbIsEmpty.setVisibility(View.VISIBLE);
                btnConfirmLoad.setVisibility(View.VISIBLE);
            } else {
                TvComfirmedRL.setVisibility(View.VISIBLE);
                lvOrder.setVisibility(View.GONE);
                ckbIsEmpty.setVisibility(View.GONE);
                btnConfirmLoad.setVisibility(View.GONE);
            }

            onClickButton();
        } catch (Exception e) {
            String str = e.getMessage();
        }

    }

    private void onClickButton() {

        btnConfirmLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (listOrderRef.size() > 0) {
                        showRequesTakePhoto();

                    } else {
                        if (ckbIsEmpty.isChecked() == false) {
                            AlertDialog.Builder dialogRequesTakePhoto = new AlertDialog.Builder(getActivity());
                            dialogRequesTakePhoto.setTitle("Message").setMessage("If LOAD is empty, please tick to Return empty")
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface arg0, int arg1) {
                                            arg0.dismiss();
                                        }
                                    }).show();

                        } else {
                            showRequesTakePhoto();
                        }
                    }


                } catch (Exception e) {

                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                try {
                    getActivity().onBackPressed();
                } catch (Exception e) {
                    String str = e.getMessage();
                }
            }
        });

        img_note.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "Note clicked!", Toast.LENGTH_SHORT).show();
            }
        });

        lvOrder.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    android.app.Fragment fragment = new ReturnPartFragment();
                    Bundle bundlePickLoad = new Bundle();
                    bundlePickLoad.putSerializable(Constants.key_bundle_pickreturnload, listOrderRef.get(i));
                    fragment.setArguments(bundlePickLoad);

                    if (fragment != null) {
                        getActivity().getFragmentManager().beginTransaction()
                                .add(R.id.container_main_picking_xml, fragment, "ReturnPartFragment")
                                .addToBackStack("ReturnPartFragment").commit();
                        Log.e("addToBackStack", "ReturnPartFragment");
                    }
                } catch (Exception e) {
                    Log.d("hehe haha 6", "");
                    e.printStackTrace();
                }
            }
        });

    }


    protected void showDialogConfirm() {
        AlertDialog.Builder dialogRequesTakePhoto = new AlertDialog.Builder(getActivity());
        dialogRequesTakePhoto.setTitle("Message").setMessage("You want to confirm Return Load ?")
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        processConfirmReturnLoad();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void processConfirmReturnLoad() {

        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();
        try {
            Response.Listener<String> listener = new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {

                        JSONObject jsonObject = new JSONObject(response.toString());
                        if (jsonObject.getBoolean("success")) {
                            sql_PickReturnLoads sqlPickReturnLoads = new sql_PickReturnLoads(getActivity());
                            sqlPickReturnLoads.updateConfirmedReturnLoad(String.valueOf(pickReturnLoad.getLoadID()));
//                            ((interfaceReturnLoad)getActivity()).ReInitData();
//                             getActivity().onBackPressed();
                            ReturnLoadFragment fragment = new ReturnLoadFragment();
                            if (fragment != null) {
                                getActivity().getFragmentManager().beginTransaction()
                                        .add(R.id.container_main_picking_xml, fragment, "ReturnLoadFragment")
                                        .commit();
                                Log.e("addToBackStack", "ReturnPartFragment");
                            }

                        } else {
                            Toast.makeText(getActivity(), "Success: false, server is problem!",
                                    Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e2) {

                    } finally {
                        progressDialog.dismiss();
                    }
                }
            };

            Response.ErrorListener errorListener = new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    try {

                        Toast.makeText(getActivity(), "Connection to your server disconnected!", Toast.LENGTH_SHORT)
                                .show();
                    } catch (Exception ex) {

                    }
                }
            };

            StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                    errorListener) {

                @Override
                protected Map<String, String> getParams() {

                    Map<String, String> params = new HashMap<String, String>();
                    params.put("type", Constants.type_confirmreturnload);
                    params.put("loadID", String.valueOf(pickReturnLoad.getLoadID()));
                    params.put("isEmpty", String.valueOf(ckbIsEmpty.isChecked()));
                    return params;
                }
            };

            // RequestQueue requestQueue = Volley.newRequestQueue(this);
            int socketTimeout = 30000;// 30 seconds - change to what you want
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            postRequest.setRetryPolicy(policy);
            postRequest.setTag(Tag);
            postRequest.setShouldCache(false);
            requestQueue.add(postRequest);
        } catch (Exception ex) {

        } finally {
            progressDialog.dismiss();
        }
    }

    protected void showRequesTakePhoto() {
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
        View mview = getActivity().getLayoutInflater().inflate(R.layout.custom_dialog_takephoto_rl, null);
        Button btnTakePhoto = (Button) mview.findViewById(R.id.btnTakePhotoReturnLoad);
        mBuilder.setView(mview);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();
        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    openTakePhoto();
                    dialog.dismiss();
                } catch (Exception ex) {
                    Log.d("DialogQuestion", ex.getMessage());
                }
            }
        });
    }

    protected void openTakePhoto() {
        final FileSave fileSave = new FileSave(getActivity(), Constants.GET);
        Bundle bundle = new Bundle();

        bundle.putString("key_imagetype", Constants.image_ReturnLoad);
        bundle.putString("key_loadid", String.valueOf(pickReturnLoad.getLoadID()));
        bundle.putString("key_loadcode", pickReturnLoad.getLoadCode());

        bundle.putString("key_pickerid", String.valueOf(fileSave.getPickerID()));
        bundle.putString("key_pickername", fileSave.getPickerName());

        Intent intent = new Intent(getActivity(), PickingNormalUploadImagesActivity.class);
        intent.putExtra(Constants.key_bundle_upload_image, bundle);
        startActivityForResult(intent, Constants.RESULT_CONFIRMRETURNLOAD_UPLOAD_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.RESULT_CONFIRMRETURNLOAD_UPLOAD_IMAGE
                && resultCode == Constants.RESULT_CONFIRMRETURNLOAD_UPLOAD_IMAGE) {
            showDialogConfirm();
        }

    }

    @Override
    public void onDetach() {
        requestQueue.cancelAll("cancelAll");
        super.onDetach();
    }


    @Override
    public void ReInitData() {

    }
}
