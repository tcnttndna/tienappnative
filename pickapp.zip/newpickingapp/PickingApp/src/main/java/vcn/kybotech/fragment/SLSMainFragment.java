package vcn.kybotech.fragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.R;

public class SLSMainFragment extends android.app.Fragment {

    private int min = 0;
    private int sec = 59;
    private Handler mDemnguocHandler;
    private DemNguocRunnable mDemnguocRun;
    private Button btnSearch;
    private Button btnInput;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FileSave fileSave = new FileSave(getActivity(), Constants.GET);
            mDemnguocHandler = new Handler();
            mDemnguocRun = new DemNguocRunnable();
            showDemNguoc();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sls_main, container, false);

        btnSearch = (Button) rootView.findViewById(R.id.fragment_sls_main_btnsearch);
        btnInput = (Button) rootView.findViewById(R.id.fragment_sls_main_btninput);
        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        btnSearch.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Log.e("hehe", "111");
                SLSSearchFragment fragment = new SLSSearchFragment();
                if (fragment != null) {
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, fragment, "SLSSearchFragment")
                            .addToBackStack("SLSSearchFragment").commit();
                }
            }
        });

        btnInput.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                SLSAddFragment fragment = new SLSAddFragment();
                if (fragment != null) {
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, fragment, "SLSAddFragment")
                            .addToBackStack("SLSAddFragment").commit();
                }
            }
        });

    }

    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public class DemNguocRunnable implements Runnable {
        @Override
        public void run() {
            handleDemnguoc();
        }
    }

    private void showDemNguoc() {
        mDemnguocHandler.removeCallbacks(mDemnguocRun);
        mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
    }

    private void handleDemnguoc() {
        try {
            sec--;
            if (sec < 0) {
                min--;
                sec = 59;
            }
//        Toast.makeText(this, min + ":" + sec, Toast.LENGTH_SHORT).show();
            mDemnguocHandler.postDelayed(mDemnguocRun, 1000);
            if (min == 0 && sec == 29) {
                FileSave file = new FileSave(getActivity(), Constants.GET);
                if (!file.getIsDeviceLogin()) {
                    file = new FileSave(getActivity(), Constants.PUT);
                    file.putIsDeviceLogin(true);
                    getActivity().getFragmentManager().beginTransaction()
                            .replace(R.id.container, new LoginFragment(), "LoginFragment")
                            .commit();
                }
                min = 0;
                sec = 59;
                showDemNguoc();
            }
        } catch (Exception ex) {
            Log.e("Service Handle", ex.getMessage());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            mDemnguocHandler.removeCallbacks(mDemnguocRun);
        } catch (Exception ex) {
        }

    }

}
