package vcn.kybotech.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import vcn.kybotech.model.PickReturnPart;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickReturnParts;

@SuppressLint("SimpleDateFormat")
public class OrdersReturnLoadAdapter extends ArrayAdapter<PickReturnPart> {

    Context context;
    int ResID;
    List<PickReturnPart> listOrderAssigned;

    int kiemtrafail=0;

    public OrdersReturnLoadAdapter(Context context, int resource, List<PickReturnPart> objects, int kiemtrafail) {
        super(context, resource, objects);
        this.context = context;
        this.ResID = resource;
        listOrderAssigned = objects;
        this.kiemtrafail = kiemtrafail;
    }


    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final PartHolder partHolder;
        View itemView = convertView;
        if (itemView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            partHolder = new PartHolder();
            itemView = inflater.inflate(ResID, parent, false);

            partHolder.OrderRef = (TextView) itemView.findViewById(R.id.item_return_orderref);
            partHolder.PartCount = (TextView) itemView.findViewById(R.id.item_returnorder_part_count);
            partHolder.FailedDeliveryOrders = (TextView) itemView.findViewById(R.id.tv_FailedDeliveryOrders);
            itemView.setTag(partHolder);
        } else {
            partHolder = (PartHolder) itemView.getTag();
        }

        try {
            final sql_PickReturnParts sqlPickReturnLoads = new sql_PickReturnParts(context);
            int countPart = sqlPickReturnLoads.getSumPartByOrder(listOrderAssigned.get(position).getLoadID(), listOrderAssigned.get(position).getOrderRef());
            partHolder.OrderRef.setText(listOrderAssigned.get(position).getOrderRef());
            partHolder.PartCount.setText(countPart + " part(s)");

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        if (kiemtrafail ==1 ){
            partHolder.FailedDeliveryOrders.setVisibility(View.VISIBLE);
        }


        return itemView;
    }

    public void updatedAdapter(int i){
        this.kiemtrafail = i;
        notifyDataSetChanged();
    }


    public static class PartHolder {
        TextView OrderRef;
        TextView PartCount;
        TextView FailedDeliveryOrders;


    }
}
