package vcn.kybotech.pickingapp;

import android.content.Context;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.LogCrash;
import vcn.kybotech.sqlite.sql_LogCrash;

public class SaveLogTryCatch {

	private Context context;
	
	
	
	public SaveLogTryCatch(Context context) {
		super();
		this.context = context;
	}



	public void inserException(Exception e) {
		if (context==null) {
			return;
		}
		LogCrash crash = new LogCrash();

		FileSave file = new FileSave( context, Constants.GET);
		crash.setPickerId(file.getPickerID());

		StackTraceElement[] arrStackTrace = e.getStackTrace();
		StringBuffer sbStackTrace = new StringBuffer();
		sbStackTrace.append(e.getMessage());
		sbStackTrace.append("\n");
		sbStackTrace.append(e.getCause());
		for (StackTraceElement i : arrStackTrace) {
			sbStackTrace.append("\n");
			sbStackTrace.append(i.toString());
		}
		crash.setMessage(e.getMessage());
		crash.setStackTrace(sbStackTrace.toString());
		crash.setIsCrashed(0);

		insertError(crash);
	}
	
	
	public void insertError(LogCrash crash) {
		if (context==null) {
			return;
		}
		sql_LogCrash sqlCrash = new sql_LogCrash( context);
		sqlCrash.insert(crash);
	}
}
