package vcn.kybotech.model;

public class PickOrder {

	int DropID;
	int LoadID;
	int OrderID;
	int ProductOptionID;
	String ProductOptionName;
	int DropNumber;
	String DatePlaced;
	String OrderRef;
	String ProductName;
	int OrderItemID;
	int Quantity;
	int BayNumber;
	double WeightKG;
	String Address;
	String CustomerName;
	String Postcode;
	String FailLoadReason;
	boolean IsOrderPicked;
	boolean IsOrderConfirmed;
	String DeliveryStatus;
	String Telephone1;
	String Telephone2;
	String ShippingAddress;
	String SpecialInstructions;
	boolean IsCustomerPresent;
	boolean IsReplanAtHub;
	String ProductSubOptions;
	boolean hasStackImages = false;
	String Status;//Co 3 trang thai : 1-None; 2-IsItemPicked; 3- Remove;
	//Khai bao 3 trang thai o class Constants
	boolean IsQA;
	boolean IsQC;


	public PickOrder() {
		super();
	}


	public PickOrder(int loadID, int orderID, int dropNumber, String orderRef, String productName,  
			int ordersItemID, int quantity, String specialInstructions ,String productSubOptions, String status, boolean isQA, boolean isQC) {
		super();
		LoadID = loadID;
		OrderID = orderID;
		DropNumber = dropNumber;
		OrderRef = orderRef;
		ProductName = productName;
		OrderItemID = ordersItemID;
		Quantity = quantity;
		SpecialInstructions = specialInstructions;
		ProductSubOptions = productSubOptions;
		Status = status;
		IsQA = isQA;
		IsQC = isQC;
	}

	public boolean isQC() {
		return IsQC;
	}

	public void setQC(boolean QC) {
		IsQC = QC;
	}

	public boolean isHasStackImages() {
		return hasStackImages;
	}


	public void setHasStackImages(boolean hasStackImages) {
		this.hasStackImages = hasStackImages;
	}


	public int getDropID() {
		return DropID;
	}


	public void setDropID(int dropID) {
		DropID = dropID;
	}


	public int getLoadID() {
		return LoadID;
	}


	public void setLoadID(int loadID) {
		LoadID = loadID;
	}


	public int getOrderID() {
		return OrderID;
	}


	public void setOrderID(int orderID) {
		OrderID = orderID;
	}


	public int getProductOptionID() {
		return ProductOptionID;
	}


	public void setProductOptionID(int productOptionID) {
		ProductOptionID = productOptionID;
	}


	public String getProductOptionName() {
		return ProductOptionName;
	}


	public void setProductOptionName(String productOptionName) {
		ProductOptionName = productOptionName;
	}


	public int getDropNumber() {
		return DropNumber;
	}


	public void setDropNumber(int dropNumber) {
		DropNumber = dropNumber;
	}


	public String getDatePlaced() {
		return DatePlaced;
	}


	public void setDatePlaced(String datePlaced) {
		DatePlaced = datePlaced;
	}


	public String getOrderRef() {
		return OrderRef;
	}


	public void setOrderRef(String orderRef) {
		OrderRef = orderRef;
	}


	public String getProductName() {
		return ProductName;
	}


	public void setProductName(String productName) {
		ProductName = productName;
	}


	public int getOrderItemID() {
		return OrderItemID;
	}


	public void setOrderItemID(int orderItemID) {
		OrderItemID = orderItemID;
	}


	public int getQuantity() {
		return Quantity;
	}


	public void setQuantity(int quantity) {
		Quantity = quantity;
	}


	public int getBayNumber() {
		return BayNumber;
	}


	public void setBayNumber(int bayNumber) {
		BayNumber = bayNumber;
	}


	public double getWeightKG() {
		return WeightKG;
	}


	public void setWeightKG(double weightKG) {
		WeightKG = weightKG;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public String getCustomerName() {
		return CustomerName;
	}


	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}


	public String getPostcode() {
		return Postcode;
	}


	public void setPostcode(String postcode) {
		Postcode = postcode;
	}


	public String getFailLoadReason() {
		return FailLoadReason;
	}


	public void setFailLoadReason(String failLoadReason) {
		FailLoadReason = failLoadReason;
	}


	public boolean isIsOrderPicked() {
		return IsOrderPicked;
	}


	public void setIsOrderPicked(boolean isOrderPicked) {
		IsOrderPicked = isOrderPicked;
	}


	public boolean isIsOrderConfirmed() {
		return IsOrderConfirmed;
	}


	public void setIsOrderConfirmed(boolean isOrderConfirmed) {
		IsOrderConfirmed = isOrderConfirmed;
	}


	public String getDeliveryStatus() {
		return DeliveryStatus;
	}


	public void setDeliveryStatus(String deliveryStatus) {
		DeliveryStatus = deliveryStatus;
	}


	public String getTelephone1() {
		return Telephone1;
	}


	public void setTelephone1(String telephone1) {
		Telephone1 = telephone1;
	}


	public String getTelephone2() {
		return Telephone2;
	}


	public void setTelephone2(String telephone2) {
		Telephone2 = telephone2;
	}


	public String getShippingAddress() {
		return ShippingAddress;
	}


	public void setShippingAddress(String shippingAddress) {
		ShippingAddress = shippingAddress;
	}


	public String getSpecialInstructions() {
		return SpecialInstructions;
	}


	public void setSpecialInstructions(String specialInstructions) {
		SpecialInstructions = specialInstructions;
	}


	public boolean isIsCustomerPresent() {
		return IsCustomerPresent;
	}


	public void setIsCustomerPresent(boolean isCustomerPresent) {
		IsCustomerPresent = isCustomerPresent;
	}


	public boolean isIsReplanAtHub() {
		return IsReplanAtHub;
	}


	public void setIsReplanAtHub(boolean isReplanAtHub) {
		IsReplanAtHub = isReplanAtHub;
	}


	public String getProductSubOptions() {
		return ProductSubOptions;
	}


	public void setProductSubOptions(String productSubOptions) {
		ProductSubOptions = productSubOptions;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	public boolean isIsQA() {
		return IsQA;
	}


	public void setIsQA(boolean isQA) {
		IsQA = isQA;
	}
	
	
	
}
