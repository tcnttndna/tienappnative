package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.pickingapp.R;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class SipnnerAdapter  extends ArrayAdapter<SpinnerItem> {

	Context context;
	int layoutId;
	List<SpinnerItem> spinner;

	public SipnnerAdapter(Context context, int resource,
			List<SpinnerItem> objects) {
		super(context, resource, objects);

		this.context = context;
		this.layoutId = resource;
		this.spinner = objects;
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		return CustomSpinner(position, convertView, parent);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		return CustomSpinner(position, convertView, parent);
	}

	private static class view_frm_loai {
		TextView name;
	}

	public View CustomSpinner(int position, View convertView, ViewGroup parent) {
		View dong = convertView;
		view_frm_loai holder;

		if (dong == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			dong = inflater.inflate(layoutId, parent, false);
			holder = new view_frm_loai();

			holder.name = (TextView) dong.findViewById(R.id.cus_spinner_item);
			dong.setTag(holder);
		} else {
			holder = (view_frm_loai) dong.getTag();
		}

		SpinnerItem itemSpinner = spinner.get(position);
		holder.name.setText(itemSpinner.getSpinner());
		return dong;
	}

}