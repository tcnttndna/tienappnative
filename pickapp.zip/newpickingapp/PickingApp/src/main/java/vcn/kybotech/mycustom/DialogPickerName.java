package vcn.kybotech.mycustom;

import java.util.List;

import vcn.kybotech.adapter.AccountPickerAdapter;
import vcn.kybotech.model.PickAccount;
import vcn.kybotech.pickingapp.R;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class DialogPickerName extends Dialog{
	
	private ListView lvPickerName;

	// private TextView username;
	public DialogPickerName(Context context, final TextView username, final List<PickAccount> listPicker) {
		super(context);
		getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.dialog_select_picker_name);
		
		
//		final SharedPreferences.Editor preferences = context.getSharedPreferences(Constants.TEMP_PICKING_APP	, 0).edit();
		

		// this.username = username;
		lvPickerName = (ListView) findViewById(R.id.dialog_lvPickerName);
		AccountPickerAdapter adapter = new AccountPickerAdapter(getContext(),R.layout.item_picker_login, listPicker);

		lvPickerName.setAdapter(adapter);
		lvPickerName.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,	int postion, long arg3) {
				username.setText(listPicker.get(postion).getpName().toString().trim());
//				preferences.putInt(Constants.key_int_PickerID, listPicker.get(postion).getpId());
//				preferences.commit();
				
				
				
				DialogPickerName.this.dismiss();
			}
		});

	}

}
