package vcn.kybotech.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import vcn.kybotech.activity.AjustStockFragment;
import vcn.kybotech.activity.PickingMainLoadFragment;
import vcn.kybotech.activity.ReturnLoadFragment;
import vcn.kybotech.activity.ScanTimberPackFragment;
import vcn.kybotech.activity.StockControlFragment;
import vcn.kybotech.activity.TakeVansPhotoFragment;
import vcn.kybotech.pickingapp.MainActivity;
import vcn.kybotech.pickingapp.R;

public class MainTaskFragment extends Fragment {

    private Button _button_order_picking;
    private Button _button_return_load;
    private Button _button_stock_control;
    private Button _button_ajust_stock;
    private Button _button_take_vans_photo;
    private Button _button_sls;
    private Button _button_stp;
    private LinearLayout stock_control , order_picking, return_load, take_vans_photo, ajust_stock, stock_location, scan_timber;


    private RelativeLayout fragment_main_tasks_readagain;

    private Camera camera;
    private android.hardware.Camera.Parameters parms;
    private boolean isFlashOn = false;
    private boolean hasFlash;
    private ImageView img_calculaor_app, img_light_app, img_convert_app;

//    private FileSave fileSave;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
//        getActivity().startService(new Intent(getActivity(), ServiceLogout.class));
        MainActivity mainActivity = (MainActivity) getActivity();
        mainActivity.setTitle("Main Task");
        showDialogLoad();
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main_task, container, false);
        stock_control = (LinearLayout)rootView.findViewById(R.id.layout_stock_control);
        order_picking = (LinearLayout)rootView.findViewById(R.id.layout_oder_picking);
        return_load = (LinearLayout)rootView.findViewById(R.id.layout_return_load);
        take_vans_photo = (LinearLayout)rootView.findViewById(R.id.layout_take_vans_photo);
        ajust_stock = (LinearLayout)rootView.findViewById(R.id.layout_ajust_stock);
        stock_location = (LinearLayout)rootView.findViewById(R.id.layout_stock_location);
        scan_timber = (LinearLayout)rootView.findViewById(R.id.layout_scan_timber_park);
        _button_order_picking = (Button) rootView.findViewById(R.id.fragment_main_task_button_OrderPicking);
        _button_return_load = (Button) rootView.findViewById(R.id.fragment_main_task_button_ReturnLoad);
        _button_stock_control = (Button) rootView.findViewById(R.id.fragment_main_task_button_StockControl);
        _button_ajust_stock = (Button) rootView.findViewById(R.id.fragment_main_task_button_AjustStock);
        _button_take_vans_photo = (Button) rootView.findViewById(R.id.fragment_main_task_button_TakeVansPhoto);
        _button_sls = (Button) rootView.findViewById(R.id.fragment_main_task_button_SLS);
        _button_stp = (Button) rootView.findViewById(R.id.fragment_main_task_button_STP);

        img_calculaor_app = (ImageView) rootView.findViewById(R.id.frag_maintasks_icon_calculator_app);
        img_convert_app = (ImageView) rootView.findViewById(R.id.frag_maintasks_icon_convert_app);
        img_light_app = (ImageView) rootView.findViewById(R.id.frag_maintasks_icon_light_app);
        fragment_main_tasks_readagain = (RelativeLayout) rootView.findViewById(R.id.fragment_main_tasks_readagain);

        gethasFlash();

        return rootView;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);



        fragment_main_tasks_readagain.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialogLoad();
            }
        });

        img_light_app.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFlashOn) {
                    turnOffFlash();
                } else {
                    turnOnFlash();
                }
            }
        });

        img_calculaor_app.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                final Animation mAnima = AnimationUtils.loadAnimation(getActivity(), R.anim.animation_bounce_app);
                img_calculaor_app.startAnimation(mAnima);
                onOpenCalculatorApp();
                if(isFlashOn){
                    turnOffFlash();
                }
            }
        });

        img_convert_app.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                final Animation mAnima = AnimationUtils.loadAnimation(getActivity(), R.anim.animation_bounce_app);
                img_convert_app.startAnimation(mAnima);
                onOpenConverterApp();
                if(isFlashOn){
                    turnOffFlash();
                }

            }
        });


        // order picking
        order_picking.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if(isFlashOn){
                    turnOffFlash();
                }
                PickingMainLoadFragment fragment = new PickingMainLoadFragment();
                if (fragment != null) {
                    // TODO v7 dÃ¹ng FragmentManager thay getSupportFragmentManager
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, fragment, "PickingMainLoadFragment")
                            .addToBackStack("PickingMainLoadFragment").commit();
                }
            }
        });

        _button_order_picking.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if(isFlashOn){
                    turnOffFlash();
                }
                PickingMainLoadFragment fragment = new PickingMainLoadFragment();
                if (fragment != null) {
                    // TODO v7 dÃ¹ng FragmentManager thay getSupportFragmentManager
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, fragment, "PickingMainLoadFragment")
                            .addToBackStack("PickingMainLoadFragment").commit();
                }
            }
        });

        // return load
        return_load.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isFlashOn){
                    turnOffFlash();
                }
                ReturnLoadFragment returnLoadFragment = new ReturnLoadFragment();
                if (returnLoadFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, returnLoadFragment, "ReturnLoadFragment")
                            .addToBackStack("ReturnLoadFragment").commit();
                }
            }
        });
        _button_return_load.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isFlashOn){
                    turnOffFlash();
                }
                ReturnLoadFragment returnLoadFragment = new ReturnLoadFragment();
                if (returnLoadFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, returnLoadFragment, "ReturnLoadFragment")
                            .addToBackStack("ReturnLoadFragment").commit();
                }
            }
        });

        // stock control

        stock_control.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if(isFlashOn){
                    turnOffFlash();
                }
                StockControlFragment stockControlFragment = new StockControlFragment();
                if (stockControlFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, stockControlFragment, "StockControlFragment")
                            .addToBackStack("StockControlFragment").commit();
                }
            }
        });

        _button_stock_control.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if(isFlashOn){
                    turnOffFlash();
                }
                StockControlFragment stockControlFragment = new StockControlFragment();
                if (stockControlFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, stockControlFragment, "StockControlFragment")
                            .addToBackStack("StockControlFragment").commit();
                }
            }
        });

        // ajust stock
        _button_ajust_stock.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                AjustStockFragment ajustStockFragment = new AjustStockFragment();
                if (ajustStockFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, ajustStockFragment, "AjustStockfragment")
                            .addToBackStack("AjustStockfragment").commit();
                }
            }
        });

        ajust_stock.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                AjustStockFragment ajustStockFragment = new AjustStockFragment();
                if (ajustStockFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, ajustStockFragment, "AjustStockfragment")
                            .addToBackStack("AjustStockfragment").commit();
                }
            }
        });

        //take van photo
        _button_take_vans_photo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                TakeVansPhotoFragment takeVansPhotoFragment = new TakeVansPhotoFragment();
                if (takeVansPhotoFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, takeVansPhotoFragment, "TakeVansPhotoFragment")
                            .addToBackStack("TakeVansPhotoFragment").commit();
                }
            }
        });
        take_vans_photo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                TakeVansPhotoFragment takeVansPhotoFragment = new TakeVansPhotoFragment();
                if (takeVansPhotoFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, takeVansPhotoFragment, "TakeVansPhotoFragment")
                            .addToBackStack("TakeVansPhotoFragment").commit();
                }
            }
        });


        // stock location
        _button_sls.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                SLSMainFragment slsMainFragment = new SLSMainFragment();
                if (slsMainFragment != null) {
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, slsMainFragment, "SLSMainFragment")
                            .addToBackStack("SLSMainFragment").commit();
                }
            }
        });

        stock_location.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                SLSMainFragment slsMainFragment = new SLSMainFragment();
                if (slsMainFragment != null) {
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, slsMainFragment, "SLSMainFragment")
                            .addToBackStack("SLSMainFragment").commit();
                }
            }
        });

        //scan timber park
        _button_stp.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                ScanTimberPackFragment scanTimberPackFragment = new ScanTimberPackFragment();
                if (scanTimberPackFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, scanTimberPackFragment, "ScanTimberPackFragment")
                            .addToBackStack("ScanTimberPackFragment").commit();
                }
            }
        });

        scan_timber.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFlashOn){
                    turnOffFlash();
                }
                ScanTimberPackFragment scanTimberPackFragment = new ScanTimberPackFragment();
                if (scanTimberPackFragment != null){
                    getActivity().getFragmentManager().beginTransaction()
                            .add(R.id.container, scanTimberPackFragment, "ScanTimberPackFragment")
                            .addToBackStack("ScanTimberPackFragment").commit();
                }
            }
        });
    }

    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }



    public void showDialogLoad() {
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
        View mview = getActivity().getLayoutInflater().inflate(R.layout.new_dialog_beload_main, null);
        Button btnCo = (Button) mview.findViewById(R.id.new_dialog_button_iagree);
        mBuilder.setView(mview);
        mBuilder.setCancelable(false);
        final AlertDialog dialog = mBuilder.create();
        Window window = dialog.getWindow();
        window.setGravity(Gravity.TOP);
        dialog.show();
        btnCo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    public void onOpenConverterApp() {
        try {
            Intent launchConverter = getActivity().getPackageManager().getLaunchIntentForPackage("kr.sira.unit");
            if (launchConverter != null) {
                getActivity().startActivity(launchConverter);
            } else {
                Toast.makeText(getActivity(), "Sorry! The Unit Converter could not be found in your device.", Toast.LENGTH_SHORT).show();
                launchConverter = new Intent(Intent.ACTION_VIEW);
                launchConverter.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                launchConverter.setData(Uri.parse("https://play.google.com/store/apps/details?id=kr.sira.unit"));
                getActivity().startActivity(launchConverter);
            }
        } catch (Exception e) {
            Log.e("NOT CONVERTER", e.toString());
        }
    }

    public void onOpenCalculatorApp() {

        try {
            Intent launchCalculator = getActivity().getPackageManager().getLaunchIntentForPackage("com.google.android.calculator");
            if (launchCalculator != null) {
                getActivity().startActivity(launchCalculator);
            } else {
                Toast.makeText(getActivity(), "Sorry! The Calculator could not be found in your device.", Toast.LENGTH_SHORT).show();
                launchCalculator = new Intent(Intent.ACTION_VIEW);
                launchCalculator.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                launchCalculator.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.calculator"));
                getActivity().startActivity(launchCalculator);
            }
        } catch (Exception e) {
            Log.e("NOT CONVERTER", e.toString());
        }
    }


    public void gethasFlash() {
        hasFlash = getActivity().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        if (!hasFlash) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Error");
            builder.setMessage("Sorry, your device doesn't support flash light!");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
            return;
        }
    }



    public void turnOnFlash() {
        isFlashOn = true;
        camera = Camera.open();
        parms = camera.getParameters();
        parms.setFlashMode(android.hardware.Camera.Parameters.FLASH_MODE_TORCH);
        camera.setParameters(parms);
        camera.startPreview();
        img_light_app.setImageResource(R.drawable.new_ic_icon_light_app);
    }

    public void turnOffFlash() {
        camera.stopPreview();
        camera.release();
        img_light_app.setImageResource(R.drawable.ic_flashlight_off);
        isFlashOn = false;
    }

    @Override
    public void onPause() {
        super.onPause();
        if(isFlashOn){
            turnOffFlash();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

    }



//    @Override
//    public void onStop() {
//        super.onStop();
//        if (isFlashOn){
//            turnOffFlash();
//        }
//    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
