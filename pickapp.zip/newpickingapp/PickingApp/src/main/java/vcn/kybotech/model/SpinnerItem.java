package vcn.kybotech.model;

public class SpinnerItem {
	private String spinner;

	public SpinnerItem() {
		super();
	}

	public SpinnerItem(String spinner) {
		super();
		this.spinner = spinner;
	}

	public String getSpinner() {
		return spinner;
	}

	public void setSpinner(String spinner) {
		this.spinner = spinner;
	}
}
