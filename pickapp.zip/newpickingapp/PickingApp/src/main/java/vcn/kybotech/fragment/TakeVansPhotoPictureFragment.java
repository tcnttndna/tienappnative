package vcn.kybotech.fragment;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.ScalingUtilities;
import vcn.kybotech.constants.ScalingUtilities.ScalingLogic;
import vcn.kybotech.controller.ImageControl;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.Image;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_Image;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.desarrollodroide.libraryfragmenttransactionextended.FragmentTransactionExtended;

public class TakeVansPhotoPictureFragment extends Fragment {
	private TextView tvLoadCode,tvEmpty,tvFillEmpty;
	private TextView tvCountPhoto;
	private Button btnTakePhoto;
	private Button btnChangeLoad;
	private ProgressBar proLoad;
	private String addString = "Image Uploaded: ";
	private FragmentManager fragment_manager;
	private String imagePath = "";
	private int countPhoto = 0;
	private int photoType = 1;
	private boolean checkResult = false;

	public TakeVansPhotoPictureFragment callHamTao() {
		TakeVansPhotoPictureFragment mFragment = new TakeVansPhotoPictureFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_take_vans_photo_picture, container, false);
		HamKhoiTao(rootView);
		return rootView;
	}

	public void HamKhoiTao(View v) {
		tvLoadCode = (TextView) v.findViewById(R.id.fragment_take_vans_photo_picture_tv_LoadCode);
		tvCountPhoto = (TextView) v.findViewById(R.id.fragment_take_vans_photo_picture_tv_count_photo);
		btnTakePhoto = (Button) v.findViewById(R.id.fragment_take_vans_photo_picture_btn_take_photo);
		btnChangeLoad = (Button) v.findViewById(R.id.fragment_take_vans_photo_picture_btn_change_load);
		proLoad = (ProgressBar) v.findViewById(R.id.fragment_take_vans_photo_picture_progressbar_load);
		tvEmpty = (TextView) v.findViewById(R.id.tv_empty_fragment_take_vans_photo_picture);
		tvFillEmpty = (TextView) v.findViewById(R.id.tv_fill_empty);
		FileSave file = new FileSave(TakeVansPhotoPictureFragment.this.getActivity(), Constants.GET);
		String text = "Take Van Photo: ";
		countPhoto = file.getCountPhoto();
		photoType = file.getPhotoType();
		if (photoType == 2) {
			text = "After Delivery Photo: ";
			countPhoto = file.getCountPhotoAD();
		}
		if (photoType == 3) {
			text = "Take Loaded Photo: ";
			countPhoto = 0;
		}

		tvLoadCode.setText(text + file.getLoadCode());
		tvCountPhoto.setText(addString + String.valueOf(countPhoto));
		BatSuKien();
	}

	public void BatSuKien() {
		btnTakePhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				callTakePicture();
			}
		});

		btnChangeLoad.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				callTakeVansPhotoInput();
			}
		});

		tvEmpty.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});
		tvCountPhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});

		tvFillEmpty.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});

	}

	public void callTakeVansPhotoInput() {
		Fragment fragment = null;
		fragment_manager = getFragmentManager();
		fragment = new TakeVansPhotoInputLoadFragment().callHamTao();
		if (fragment != null) {
			FragmentTransaction fragmentTransaction = fragment_manager.beginTransaction();
			FragmentTransactionExtended fragmentTransactionExtended = new FragmentTransactionExtended(
					TakeVansPhotoPictureFragment.this.getActivity(), fragmentTransaction, fragment, fragment,
					R.id.activity_take_vans_photo_layout_frame);
			fragmentTransactionExtended.addTransition(Constants.ANIMATION);
			fragmentTransactionExtended.commit();
		}
	}

	public void callTakePicture() {
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent
				.resolveActivity(TakeVansPhotoPictureFragment.this.getActivity().getPackageManager()) != null) {
			File photoFile = null;
			try {
				photoFile = createFileImage();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			if (photoFile != null) {
				takePictureIntent.putExtra("imagePath", imagePath);
				takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
				startActivityForResult(takePictureIntent, Constants.TAKE_VANS_PHOTO);
			}
		}
	}

	@SuppressLint("SimpleDateFormat")
	private File createFileImage() throws IOException {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String fileImagename = "Vans_" + timeStamp;
		File StorageDir = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME),
				Constants.FOLDER_NAME_VANS);

		if (!StorageDir.exists()) {
			StorageDir.mkdirs();
		}
		File image = new File(StorageDir, fileImagename + ".png");

		imagePath = image.getAbsolutePath();
		return image;
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			switch (requestCode) {
			case Constants.TAKE_VANS_PHOTO:
				compressImage(imagePath, 800, 1400);
				checkResult = true;
				break;
			default:
				break;
			}
		}
	}

	private boolean compressImage(String path, int width, int height) {
		boolean isCompress = false;
		Bitmap scaledBitmap = null;
		try {
			Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, width, height, ScalingLogic.FIT);
			scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap, width, height, ScalingLogic.FIT);
			FileOutputStream fos = null;
			try {
				File fichero = new File(imagePath);
				if (fichero.canWrite()) {
					fichero.createNewFile();
					fos = new FileOutputStream(fichero);
					isCompress = scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, fos);
					fos.flush();
					fos.close();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			scaledBitmap.recycle();
		} catch (Throwable e) {
		}
		return isCompress;
	}

	private void callUploadImage(String path) {
		Image obj = new Image();
		FileSave file = new FileSave(TakeVansPhotoPictureFragment.this.getActivity(), Constants.GET);
		obj.setLoadId(file.getLoadId());
		obj.setLoadCode(file.getLoadCode());
		obj.setImageData(path);
		obj.setImageName(Constants.NAME_VANS_PHOTO);
		if (photoType == 1) {
			obj.setImageType(Constants.TYPE_VANS_PHOTO);
		} else if (photoType == 2) {
			obj.setImageType(Constants.TYPE_AFTER_DELIVERY_PHOTO);
		} else {
			obj.setImageType(Constants.TYPE_LOADED_PHOTO);
		}

		UploadImage(obj);
	}

	@Override
	public void onResume() {
		super.onResume();
		if (checkResult) {
			callUploadImage(imagePath);
		}
		checkResult = false;
	}

	public void UploadImage(final Image image) {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;
			BufferedInputStream buffInputStream = null;
			File file;
			String path;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				// ConnectivityManager cm = (ConnectivityManager)
				// TakeVansPhotoPictureFragment.this.getActivity().
				// getSystemService(Context.CONNECTIVITY_SERVICE);
				// NetworkInfo netInfo = cm.getActiveNetworkInfo();
				// if (netInfo != null && netInfo.isConnected()) {
				// try {
				// URL url = new URL(Constants.GOOGLE_LINK);
				// HttpURLConnection httpUrlConn = (HttpURLConnection) url
				// .openConnection();
				// httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
				// httpUrlConn.connect();
				// if (httpUrlConn.getResponseCode() == 200) {
				try {
					/** MA HOA ANH */
					byte byteAnh[] = null;
					path = image.getImageData();
					file = new File(path);
					FileInputStream inputStream = new FileInputStream(path);
					buffInputStream = new BufferedInputStream(inputStream);
					byteAnh = new byte[buffInputStream.available()];
					buffInputStream.read(byteAnh);
					String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
					image.setImageData(encodedString);

					/** GUI ANH VUA MA HOA LEN SERVICE */
					ImageControl ctrImage = new ImageControl(TakeVansPhotoPictureFragment.this.getActivity());
					objJSON = ctrImage.upload(image);
					return objJSON;
				} catch (Exception e) {
					return null;
				}
				// }
				// } catch (MalformedURLException e) {
				// e.printStackTrace();
				// } catch (IOException e) {
				// e.printStackTrace();
				// }
				// }
				// return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals("true")) {
								countPhoto = countPhoto + 1;
								tvCountPhoto.setText(addString + String.valueOf(countPhoto));
								if (file.delete()) {
									System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
								}
								buffInputStream.close();
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals("false")) {
									DialogDisconnectToServer(image, path);
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer(image, path);
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void DialogDisconnectToServer(final Image image, final String path) {
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new AlertDialog.Builder(TakeVansPhotoPictureFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.UpImage_Message_no_response_form_server));
			// NEU OK SE LUU ANH DE UPLOAD SAU
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					sql_Image sqlImage = new sql_Image(TakeVansPhotoPictureFragment.this.getActivity());
					image.setImageData(path);
					sqlImage.insert(image);
				}
			});
			// NEU CANCEL SE XOA ANH TRONG SD CARD
			dialog.setNegativeButton("Cancel", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					File file = new File(path);
					if (file.delete()) {
						System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
					}
				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
