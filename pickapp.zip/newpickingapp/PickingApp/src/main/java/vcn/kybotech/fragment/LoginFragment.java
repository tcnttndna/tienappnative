package vcn.kybotech.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.firebase.crash.FirebaseCrash;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.controller.PickerAccountJSONArray;
import vcn.kybotech.controller.RequestFirebase;
import vcn.kybotech.controller.RequestFirebaseListener;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.LogData;
import vcn.kybotech.model.PickAccount;
import vcn.kybotech.mycustom.DialogPickerName;
import vcn.kybotech.pickingapp.MainActivity;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_LogData;
import vcn.kybotech.sqlite.sql_PickAccount;

public class LoginFragment extends Fragment{

    private Button refresh;
    private Button login;
    private ImageView iconComboxUserName;
    private ImageView iconCheck;
    private ImageView iconClearPassword;
    private AutoCompleteTextView namePicker;
    private EditText password;
    private LinearLayout rememberLogin;
    private TextView loginError;
    private List<PickAccount> listPicker;
    private ArrayAdapter<String> adapter;
    private ProgressBar proLoad;
    private TableRow tblName;
    private EditText etName;
    private String android_id;
    private String pickerid;
    private ImageView iconClearName;
    private HashMap<String, Boolean> mapAgency;

    public static boolean requestedLogin = false;

    // Firebase
    private DatabaseReference mDatabase;

    public static String pickerIdLogin,deviceIdLogin;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_login, container, false);
        HamKhoiTao(rootView);
        XuLySuKien();
        /* 4. Lay cac du lieu ve account picker */
        onLoadListPicker();
        return rootView;
    }

    public void HamKhoiTao(View v) {
        /* 1. Khoi tao bien luu tam vao file */
        FileSave file = new FileSave(getActivity(), Constants.PUT);
        file.putIslogin(false);
//        getActivity().stopService(new Intent(getActivity(), ServiceLogout.class));
        getActivity().invalidateOptionsMenu();

		/* 2. Dang ky cac thanh phan voi xml */
        refresh = (Button) v.findViewById(R.id.fragment_login_button_refresh);
        login = (Button) v.findViewById(R.id.fragment_login_button_login);
        iconComboxUserName = (ImageView) v.findViewById(R.id.fragment_login_icon_ComboxUserName);
        iconCheck = (ImageView) v.findViewById(R.id.fragment_login_icon_Check);
        iconClearPassword = (ImageView) v.findViewById(R.id.fragment_login_icon_ClearPassword);
        namePicker = (AutoCompleteTextView) v.findViewById(R.id.fragment_login_edPickingName);
        password = (EditText) v.findViewById(R.id.fragment_login_etPassword);
        rememberLogin = (LinearLayout) v.findViewById(R.id.fragment_login_llRememberLogin);
        loginError = (TextView) v.findViewById(R.id.login_tvError);
        proLoad = (ProgressBar) v.findViewById(R.id.fragment_login_progressbar_load);
        tblName = (TableRow) v.findViewById(R.id.fragment_login_tableRow_Name);
        etName = (EditText) v.findViewById(R.id.fragment_login_etName);
        iconClearName = (ImageView) v.findViewById(R.id.fragment_login_icon_ClearName);

        // Khai bÃƒÂ¡o Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference().child("StateLogin");

        requestedLogin = false;

    }

    public void XuLySuKien() {
		/* 3. Cac su kien cho tung control */
        refresh.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                onLoadListPicker();
            }
        });

        rememberLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int i = Integer.parseInt(iconCheck.getTag().toString());
                if (i == 0) {
                    iconCheck.setBackgroundResource(R.drawable.ic_checked_true);
                    iconCheck.setTag(1);
                } else {
                    iconCheck.setBackgroundResource(R.drawable.ic_checked_false);
                    iconCheck.setTag(0);
                }
            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                if (password.getText().toString().trim().length() > 0) {
                    iconClearPassword.setVisibility(View.VISIBLE);
                } else {
                    iconClearPassword.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        iconClearPassword.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                password.setText(null);
            }
        });

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (etName.getText().toString().trim().length() > 0) {
                    iconClearName.setVisibility(View.VISIBLE);
                } else {
                    iconClearName.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        iconClearName.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                etName.setText(null);
            }
        });

        namePicker.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    if (namePicker.getText().toString().trim().length() > 0) {
                        if (mapAgency.get(namePicker.getText().toString().trim())) {
                            tblName.setVisibility(View.VISIBLE);
                        } else {
                            tblName.setVisibility(View.GONE);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    tblName.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        login.setOnClickListener(new OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View arg0) {
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                //txtName is a reference of an EditText Field
                imm.hideSoftInputFromWindow(namePicker.getWindowToken(), 0);

                String name = namePicker.getText().toString().trim() + "";
                String nameAgency = etName.getText().toString().trim();
                String LoginPicker = Constants.type_LoginPicker;
                sql_PickAccount account = new sql_PickAccount(getActivity());

                pickerid = String.valueOf(account.getPickID(name));

                String pass = password.getText().toString().trim() + "";
                android_id = Secure.getString(getActivity().getContentResolver(),
                        Secure.ANDROID_ID);

				/*Kiem tra nhap ten va nhap password*/
                if (name.length() == 0) {

                    loginError.setText(getString(R.string.fragment_login_EnterName));
                    return;
                }
                try {
                    if (mapAgency.get(namePicker.getText().toString().trim())) {
                        if (nameAgency.length() == 0) {
                            loginError.setText(getString(R.string.fragment_login_EnterNameAgency));
                            return;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (pass.length() == 0) {
                    loginError.setText(getString(R.string.fragment_login_EnterPassword));
                    return;
                }

				/*Chuan bi du lieu va cac tham so can thiet de request*/
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair(Constants.appname, "NewPickingApp"));
                params.add(new BasicNameValuePair(Constants.type, LoginPicker));
                params.add(new BasicNameValuePair(Constants.pickerid, pickerid));
                params.add(new BasicNameValuePair(Constants.password, pass));
                params.add(new BasicNameValuePair(Constants.deviceid, android_id));

				/*Bat dau tien hanh dang nhap*/
                checkConnectServiceAndLogin(Constants.LINK_PICK_ACCOUNT, params);
            }
        });

        iconComboxUserName.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listPicker.size() > 0) {
                    DialogPickerName dialogPickerName = new DialogPickerName(getActivity(), namePicker, listPicker);
                    dialogPickerName.show();
                }
            }
        });
    }

    private void onLoadListPicker() {
        listPicker = new ArrayList<PickAccount>();
        new AsyncTask<String, Void, JSONObject>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                proLoad.setVisibility(View.VISIBLE);
            }

            @Override
            protected JSONObject doInBackground(String... arg0) {
                return new PickerAccountJSONArray().getJSONListPickerAccount();
            }

            protected void onPostExecute(JSONObject jsonObject) {
                try {
                    if (jsonObject == null) {
                        Log.e("LoginFragment", "Load Data AccountPicker disconnect");
                        DialogDisconnectToServer();
                    } else {
                        if (jsonObject.getBoolean("success")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("data");

							/*Luu vao SQLite*/
                            sql_PickAccount pickAccount = new sql_PickAccount(getActivity());
                            mapAgency = new HashMap<String, Boolean>();
                            pickAccount.insertPickAccountTransaciton(jsonArray);

							/* Hien thi khi click vao*/
                            listPicker.clear();
                            String[] pickername = new String[jsonArray.length()];
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonPickAccount = jsonArray.getJSONObject(i);
                                listPicker.add(new PickAccount(jsonPickAccount.getString("pname")
                                        , jsonPickAccount.getInt("pid")
                                        , jsonPickAccount.getBoolean("isadmin")
                                        , jsonPickAccount.getInt("warehouseid")
                                        , jsonPickAccount.getBoolean("isqa")
                                        , jsonPickAccount.getString("canqc")));
                                pickername[i] = jsonPickAccount.getString("pname");
                                mapAgency.put(jsonPickAccount.getString("pname"), jsonPickAccount.getBoolean("isagency"));
//								Log.e("LoginFragment", jsonPickAccount.toString());
                            }

                            adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, pickername);
                            namePicker.setThreshold(1);
                            namePicker.setAdapter(adapter);
                        }
                    }
                } catch (JSONException e) {
                    FirebaseCrash.report(e);
                }
                proLoad.setVisibility(View.GONE);
            }
        }.execute();
    }

    protected void checkConnectServiceAndLogin(final String url, final List<NameValuePair> params) {
        /**
         * Kiem tra ket noi va dang nhap se tra ve 3 trang thai chinh
         * 1. Dang nhap thanh cong:           loginsuccess
         * 2. Dang nhap that bai:             loginfalse
         * 3. Khong ket noi toi server duoc:  disconnect
         */
        new AsyncTask<String, Void, JSONObject>() {
            ProgressDialog dialog;

            protected void onPreExecute() {
                proLoad.setVisibility(View.VISIBLE);
                dialog = new ProgressDialog(getActivity());
                dialog.setTitle("Login");
                dialog.setMessage(getString(R.string.fragment_login_waiting));
                dialog.show();
            }

            @Override
            protected JSONObject doInBackground(String... arg0) {
                JSONObject jsonObject = new JSONParser().getJsonTuUrl(url, params);
                return jsonObject;
            }

            public void onPostExecute(JSONObject jsonObject) {
                try {
                    dialog.dismiss();
                    if (jsonObject == null) {
                        DialogDisconnectToServer();
                    } else if (jsonObject.getString("success").equals("true")) {
                        Log.e("LoginFramgment", "loginsuccess");
                        FileSave file = new FileSave(getActivity(), Constants.PUT);
                        file.putIsDeviceLogin(true);
                        getActivity()
                                .getFragmentManager()
                                .beginTransaction()
                                .replace(R.id.container, new MainTaskFragment())
                                .commit();
                        Log.e("tag LoginFragment", "replace(R.id.container, new MainTaskFragment(), \"MainTaskFragment\")");
                        getActivity().invalidateOptionsMenu();

                        //Luu cac thong tin cua picker khi dang nhap;
                        JSONObject jsonObjectUSER = jsonObject.getJSONObject("user");

                        editFile(jsonObjectUSER.getInt("UserID"), jsonObjectUSER.getString("UserName"),
                                jsonObjectUSER.getInt("PickerID"), jsonObjectUSER.getString("PickerName"),
                                jsonObjectUSER.getInt("WarehouseLocationID"), jsonObjectUSER.getBoolean("UserAuth"),
                                true, etName.getText().toString().trim(), android_id);

                        //LUU LOG DATA
                        SaveLogLogin();

//                        Intent intent = new Intent(getActivity(), ServiceLogout.class);
//                        getActivity().startService(intent);
                    } else if (jsonObject.getString("success").equals("false")) {
                        loginError.setText(getResources().getString(R.string.fragment_login_Fail));
                        Log.e("LoginFramgment", "loginfalse");
                    } else {
                        loginError.setText(getResources().getString(R.string.fragment_login_Fail));
                        Log.e("LoginFramgment", "loginfalse - out of");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    loginError.setText(getResources().getString(R.string.fragment_login_Fail));
                    Log.e("LoginFramgment", "loginfalse - out of");
                }
                proLoad.setVisibility(View.GONE);
            }

            ;
        }.execute();
    }

    public void editFile(int userID, String userName, int pickerID, String pickerName, int warehouselocationID,
                         boolean isAdmin, boolean isLogin, String name, String deviceID) {
        FileSave file = new FileSave(getActivity(), Constants.PUT);

        file.putUserID(userID);
        file.putUserName(userName);
        file.putPickerID(pickerID);
        file.putPickerName(pickerName);
        file.putWarehouselocationID(warehouselocationID);
        Log.d("a a a", isAdmin + " ");
        file.putIsAdmin(isAdmin);
        file.putIslogin(isLogin);
        int i = Integer.parseInt(iconCheck.getTag().toString());
        if (i == 0) {
            file.putIsRememberLogin(false);
        } else {
            file.putIsRememberLogin(true);
        }
        file.putName(name);
        file.putDeviceID(deviceID);

        mDatabase.child(pickerID + "").child(Constants.firebase_key_pickerId).setValue(pickerID);
        mDatabase.child(pickerID + "").child(Constants.firebase_key_deviceId).setValue(deviceID);
        mDatabase.child(pickerID + "").child(Constants.firebase_key_pickername).setValue(pickerName);

        pickerIdLogin = String.valueOf(pickerID);
        deviceIdLogin = deviceID;

            try {
                Log.e("MainActivity create","pid: " + pickerID);
                new RequestFirebase((RequestFirebaseListener) getActivity(),getActivity(),String.valueOf(pickerID),deviceID).execute();
                requestedLogin = true;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

    }

    public void DialogDisconnectToServer() {
        Log.e("LoginFramgment", "disconnect to server");
        Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

    public void SaveLogLogin() {
        sql_LogData sqlLogData = new sql_LogData(LoginFragment.this.getActivity());
        LogData logLogin = new LogData();
        logLogin.setAction(Constants.LOG_LOGIN_INT);
        logLogin.setDescription(Constants.LOG_LOGIN_STRING);
        sqlLogData.insert(logLogin);
    }

//    @Override
//    public void onRequestFirebaseSuccess(boolean kq) {
//
//    }


    @Override
    public void onResume() {
        super.onResume();
        MainActivity.isLoggedOut = false;
    }

}
