package vcn.kybotech.model;

public class CurrentStock {
	public static String COLUMN_PART_ID = "PartID";
	public static String COLUMN_PART_NAME = "PartName";
	public static String COLUMN_WARE_HOUSE_ID = "WarehouseID";
	public static String COLUMN_WARE_HOUSE_NAME = "WarehouseName";
	public static String COLUMN_FREE_STOCK = "FreeStock";
	public static String COLUMN_ALLOCATED_STOCK = "AllocatedStock";
	public static String COLUMN_PICKED_NOT_LOADED_STOCK = "PickedNotLoadedStock";
	public static String COLUMN_SHIPPING_PRIORITY = "ShippingPriority";
	
	private int PartID;
	private String PartName;
	private int WarehouseID;
	private String WarehouseName;
	private int FreeStock;
	private int AllocatedStock;
	private int PickedNotLoadedStock;
	private int ShippingPriority;
	
	public CurrentStock() {
		super();
	}

	public CurrentStock(int partID, String warehouseName, int freeStock,
			int allocatedStock, int pickedNotLoadedStock) {
		super();
		PartID = partID;
		WarehouseName = warehouseName;
		FreeStock = freeStock;
		AllocatedStock = allocatedStock;
		PickedNotLoadedStock = pickedNotLoadedStock;
	}

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public String getWarehouseName() {
		return WarehouseName;
	}

	public void setWarehouseName(String warehouseName) {
		WarehouseName = warehouseName;
	}

	public int getFreeStock() {
		return FreeStock;
	}

	public void setFreeStock(int freeStock) {
		FreeStock = freeStock;
	}

	public int getAllocatedStock() {
		return AllocatedStock;
	}

	public void setAllocatedStock(int allocatedStock) {
		AllocatedStock = allocatedStock;
	}

	public int getPickedNotLoadedStock() {
		return PickedNotLoadedStock;
	}

	public void setPickedNotLoadedStock(int pickedNotLoadedStock) {
		PickedNotLoadedStock = pickedNotLoadedStock;
	}

	public String getPartName() {
		return PartName;
	}

	public void setPartName(String partName) {
		PartName = partName;
	}

	public int getWarehouseID() {
		return WarehouseID;
	}

	public void setWarehouseID(int warehouseID) {
		WarehouseID = warehouseID;
	}

	public int getShippingPriority() {
		return ShippingPriority;
	}

	public void setShippingPriority(int shippingPriority) {
		ShippingPriority = shippingPriority;
	}
}
