package vcn.kybotech.fragment;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.adapter.SipnnerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.controller.AddStockControl;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.controller.TransferStockControl;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.model.WareHouseItem;
import vcn.kybotech.pickingapp.R;

import static android.app.Activity.RESULT_OK;

public class TransferStockFragment extends Fragment{
	
	private EditText etReason;
	private ImageView imgReason;
	private EditText etQty;
	private ImageView imgQty;
	public static EditText etTapToScan;
	private ImageView imgTapToScan;
	private Spinner spinWareHouseFrom;
	private Spinner spinWareHouseTo;
	private ProgressBar proLoad;
	private Button btnTransferStockPart;
	private ImageButton btnTakePhoto;
	private List<SpinnerItem> listStringWareHouse;
	private List<WareHouseItem> listWareHouseFrom;
	private int intWareHouseFrom;
	private List<WareHouseItem> listWareHouseTo;
	private int intWareHouseTo;
	private int CHECK_QTY = 2;
	private int REDUCE_PART = 3;
	private int CHECK_REASON = 4;
	private int CHECK_ID_WAREHOUSE = 5;
	public static int SCAN_ADD = 1;
	public static int SCAN_REDUCE = 2;
	public static int SCAN_TRANSFER = 3;
	public static int SCAN_CURRENT = 4;
	public static int SCAN_PRIORITY = 5;
	public static int SCAN_ADD_PALLET = 6;
	
	private Dialog dialog;
	
	public TransferStockFragment callHamTao(){
		TransferStockFragment mFragment = new TransferStockFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_transfer_stock, container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT ));	
		HamKhoiTao(rootView);
		BatSuKien();
		return rootView;
	}
	
	public void HamKhoiTao(View v) {
		// KHAI BAO GIAO DIEN
		etReason = (EditText) v.findViewById(R.id.fragment_transfer_stock_reason);
		imgReason = (ImageView) v
				.findViewById(R.id.fragment_transfer_stock_reason_img);

		etQty = (EditText) v.findViewById(R.id.fragment_transfer_stock_qty);
		imgQty = (ImageView) v.findViewById(R.id.fragment_transfer_stock_qty_img);

		etTapToScan = (EditText) v
				.findViewById(R.id.fragment_transfer_stock_taptoscan);
		imgTapToScan = (ImageView) v
				.findViewById(R.id.fragment_transfer_stock_taptoscan_img);
		spinWareHouseFrom = (Spinner) v
				.findViewById(R.id.fragment_transfer_stock_spinner_ware_house_from);
		spinWareHouseTo = (Spinner) v
				.findViewById(R.id.fragment_transfer_stock_spinner_ware_house_to);
		proLoad = (ProgressBar) v
				.findViewById(R.id.fragment_transfer_stock_progressbar_load);
		btnTransferStockPart = (Button) v
				.findViewById(R.id.fragment_transfer_stock_button_transfer_stock_part);
		btnTakePhoto = (ImageButton) v
				.findViewById(R.id.fragment_transfer_stock_button_take_photo_transfer);
		// ==================
		// SET COMBOBOX WHARE HOUSE
		getWareHouse();
		// ========================
	}
	
	public void BatSuKien() {
		etReason.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etReason.getText().toString().length() > 0) {
					imgReason.setVisibility(View.VISIBLE);
				} else {
					imgReason.setVisibility(View.INVISIBLE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});

		imgReason.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etReason.setText(null);
				etReason.requestFocus();
			}
		});
		etQty.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etQty.getText().toString().length() > 0) {
					imgQty.setVisibility(View.VISIBLE);
				} else {
					imgQty.setVisibility(View.INVISIBLE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		
		imgQty.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etQty.setText(null);
				etQty.requestFocus();
			}
		});

		etTapToScan.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etTapToScan.getText().toString().length() > 0) {
					imgTapToScan.setVisibility(View.VISIBLE);
					if (etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN) {
						etQty.setText("1");
					}
				} else {
					imgTapToScan.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		
		imgTapToScan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etTapToScan.setText(null);
				etTapToScan.requestFocus();
			}
		});
		
		spinWareHouseFrom.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				intWareHouseFrom = arg2;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				
			}
		});
		
		spinWareHouseTo.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				intWareHouseTo = arg2;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				
			}
		});
		
		btnTransferStockPart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(etTapToScan.getText().toString().length() == Constants.LENGTH_TAP_TO_SCAN){
					if(etReason.getText().toString().trim().length() == 0){
						dialogAddLocation(CHECK_REASON);
					}else{
						if(etQty.getText().toString().trim().length() == 0 || 
								Integer.parseInt(etQty.getText().toString().trim()) == 0){
							dialogAddLocation(CHECK_QTY);
						} else{
							if(intWareHouseFrom == intWareHouseTo){
								dialogAddLocation(CHECK_ID_WAREHOUSE);
							}else{
								dialogAddLocation(REDUCE_PART);
							}
						}
					}
				}else{
					etTapToScan.requestFocus();
					OpenKeyBoard(TransferStockFragment.this.getActivity());
				}
			}
		});
		
		btnTakePhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				onSCanBarCode(SCAN_TRANSFER);
			}
		});
	}

	public void onSCanBarCode(int types) {
		try {
			Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
			intent.putExtra("SCAN_FORMATS",
					"QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
			startActivityForResult(intent, types);
		} catch (Exception e) {
			Log.e("NOT SCAN", e.toString());
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == SCAN_TRANSFER && resultCode == RESULT_OK) {
			try {

				String qrcode = (data.getStringExtra("SCAN_RESULT"));
				BarcodeSubString barcodeSubString = new BarcodeSubString();
				qrcode = barcodeSubString.CutBarcode(qrcode, "");
				etTapToScan.setText(qrcode);
			} catch (Exception e) {
				//dialogPartIDFail();
			}
		}
	}


	public void getWareHouse() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) TransferStockFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
							AddStockControl ctrAddStock = new AddStockControl(getActivity());
							objJSON = ctrAddStock.getWareHouse();
							return objJSON;
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS)
									.equals(Constants.KEY_TRUE)) {
								listStringWareHouse = new ArrayList<SpinnerItem>();
								listWareHouseFrom = new ArrayList<WareHouseItem>();
								listWareHouseTo = new ArrayList<WareHouseItem>();
								JSONArray obj = objJSON.getJSONArray("data");
								for (int i = 0; i < obj.length(); i++) {
									JSONObject objItem = obj.getJSONObject(i);
									listStringWareHouse
											.add(new SpinnerItem(
													objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
									listWareHouseFrom
											.add(new WareHouseItem(
													objItem.getInt(WareHouseItem.COLUMN_WARE_HOUSE_ID),
													objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
									listWareHouseTo
									.add(new WareHouseItem(
											objItem.getInt(WareHouseItem.COLUMN_WARE_HOUSE_ID),
											objItem.getString(WareHouseItem.COLUMN_WARE_HOUSE_NAME)));
								}
								SipnnerAdapter adapter = new SipnnerAdapter(
										getActivity(), R.layout.custom_spinner,
										listStringWareHouse);
								spinWareHouseFrom.setAdapter(adapter);
								spinWareHouseTo.setAdapter(adapter);

								// SET HIEN THI CHO COMBOBOX WHARE HOUSE
								FileSave file = new FileSave(getActivity(), Constants.GET);
								int warehouseid = file.getWarehouselocationID();
								if (warehouseid != -1) {
									for (int i = 0; i < listWareHouseFrom.size(); i++) {
										if (listWareHouseFrom.get(i)
												.getWarehouseID() == warehouseid) {
											spinWareHouseFrom.setSelection(i);
											break;
										}
									}
								}
								// ======================================
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}
	
	public void dialogAddLocation(final int type) {
		dialog = new Dialog(getActivity());
		dialog.setContentView(R.layout.custom_dialog);
		TextView tvnoidung = (TextView) dialog
				.findViewById(R.id.custom_dialog_textview_noidung);
		final EditText etlocation = (EditText) dialog
				.findViewById(R.id.custom_dialog_edittext_location);
		final ImageView imglocation = (ImageView) dialog
				.findViewById(R.id.custom_dialog_edittext_location_img);
		Button btncancel = (Button) dialog
				.findViewById(R.id.custom_dialog_button_cancel);
		Button btnok = (Button) dialog
				.findViewById(R.id.custom_dialog_button_ok);
		
		if (type == CHECK_QTY) {
			dialog.setTitle(Constants.NOTIFICATION);
			tvnoidung.setText(Constants.QUANTITY_IS_NOT_NUMBER);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		if(type == CHECK_REASON){
			dialog.setTitle(Constants.NOTIFICATION);
			tvnoidung.setText(Constants.QUANTITY_IS_NOT_VALUES);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}
		if (type == REDUCE_PART) {
			dialog.setTitle(Constants.QUANTITY_PART_CONFIRM);
			tvnoidung.setText("Are you sure transfer quantity for partID "
					+ etTapToScan.getText().toString().trim() + " quantity "
					+ etQty.getText().toString().trim() + "?");
			etlocation.setVisibility(View.GONE);
			btncancel.setText("No");
		}
		if(type == CHECK_ID_WAREHOUSE){
			dialog.setTitle(Constants.WAREHOUSE_ERROR);
			tvnoidung.setText(Constants.WAREHOUSE_ERROR_MESS);
			etlocation.setVisibility(View.GONE);
			btncancel.setVisibility(View.GONE);
		}

		etlocation.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				if (etlocation.getText().toString().length() > 0) {
					imglocation.setVisibility(View.VISIBLE);
				} else {
					imglocation.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {

			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		imglocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				etlocation.setText(null);
			}
		});
		btncancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});

		btnok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (type == CHECK_QTY) {
					etQty.requestFocus();
				}
				if(type == CHECK_REASON){
					etReason.requestFocus();
				}
				if (type == REDUCE_PART) {
					uploadTransferStockPart();
				}
				dialog.dismiss();
			}
		});

		dialog.show();
	}
	
	public void uploadTransferStockPart(){
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) TransferStockFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
				try {
					TransferStockControl ctrTransferStock = new TransferStockControl(getActivity());
					int partid = Integer.parseInt(etTapToScan.getText().toString()
							.trim());
					String reason = etReason.getText().toString().trim();
					String quantity = etQty.getText().toString().trim();
					objJSON = ctrTransferStock.uploadTransferStock(partid, reason, listWareHouseFrom.get(intWareHouseFrom).getWarehouseID(), listWareHouseTo.get(intWareHouseTo).getWarehouseID(), quantity);
					return objJSON;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS)
									.equals(Constants.KEY_TRUE)) {
								Toast.makeText(
										getActivity(),
										"Part "
												+ objJSON.getJSONObject("data")
														.getString("PartName")
												+ " was tranferred successfully",
										Toast.LENGTH_SHORT).show();
								etReason.setText(null);
								etQty.setText(null);
								etTapToScan.setText(null);
								etTapToScan.requestFocus();
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS)
										.equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(),
											objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_SHORT).show();
									etTapToScan.requestFocus();
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}
	
	public void DialogDisconnectToServer(){
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new  AlertDialog.Builder(TransferStockFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					
				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}
}

