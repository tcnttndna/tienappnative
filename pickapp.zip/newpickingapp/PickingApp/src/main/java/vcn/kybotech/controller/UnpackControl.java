package vcn.kybotech.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;

public class UnpackControl {
	private JSONParser jsonParser;
	private int userid;
//	private int warehouseid;
	private String username;
	private String DATE_TIME;
	private String VERSION;
	
	public UnpackControl(Context context){
		jsonParser = new JSONParser();
		try {
			FileSave file = new FileSave(context, Constants.GET);
			userid = file.getPickerID();
//			warehouseid = file.getWarehouselocationID();
			username = file.getPickerName();
			if(!file.getName().equals("")){
				username = username + " - " + file.getName();
			}
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DATE_TIME = dateFormat.format(calendar.getTime());
			VERSION = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE + " | " + String.valueOf(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public JSONObject timberPackDetail(String packId){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "timberpackdetail"));
		params.add(new BasicNameValuePair("packid", packId));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
	
	public JSONObject searchPack(int typeSearch, String packId){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "getpack"));
		params.add(new BasicNameValuePair("typesearch", String.valueOf(typeSearch)));
		params.add(new BasicNameValuePair("id", packId));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
	
	public JSONObject confirmUnpack(double lat, double lng, int packId, int partId, int GRNItemID, int WarehouseId, String Site, String DateUsed){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "confirmunpack"));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("pickername", username));
		params.add(new BasicNameValuePair("inapp", "NewPickingApp"));
		params.add(new BasicNameValuePair("kybopackid", String.valueOf(packId)));
		params.add(new BasicNameValuePair("partid", String.valueOf(partId)));
		params.add(new BasicNameValuePair("warehouseid", String.valueOf(WarehouseId)));
		params.add(new BasicNameValuePair("lat", String.valueOf(lat)));
		params.add(new BasicNameValuePair("lng", String.valueOf(lng)));
		params.add(new BasicNameValuePair("version", VERSION));
		params.add(new BasicNameValuePair("phonedate", DATE_TIME));
		params.add(new BasicNameValuePair("grnitemid", String.valueOf(GRNItemID)));
		params.add(new BasicNameValuePair("site", Site));
		params.add(new BasicNameValuePair("dateused", DateUsed));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
	
	public JSONObject confirmTimberDelivered(double lat, double lng, int packId){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "confirmtimberdelivered"));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(userid)));
		params.add(new BasicNameValuePair("pickername", username));
		params.add(new BasicNameValuePair("inapp", "NewPickingApp"));
		params.add(new BasicNameValuePair("packid", String.valueOf(packId)));
		params.add(new BasicNameValuePair("lat", String.valueOf(lat)));
		params.add(new BasicNameValuePair("lng", String.valueOf(lng)));
		params.add(new BasicNameValuePair("version", VERSION));
		params.add(new BasicNameValuePair("phonedate", DATE_TIME));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
