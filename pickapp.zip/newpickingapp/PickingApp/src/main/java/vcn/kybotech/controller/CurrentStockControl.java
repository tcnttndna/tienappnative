package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import android.content.Context;

public class CurrentStockControl {
	private JSONParser jsonParser;
	
	public CurrentStockControl(Context context){
		jsonParser = new JSONParser();
	}
	
	public JSONObject getCurrentStock(int partid){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "getcurrentstock"));
		params.add(new BasicNameValuePair("partID", String.valueOf(partid)));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
	
	public JSONObject getCurrentStockByBarcode(String barcode){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "getcurrentstockbybarcode"));
		params.add(new BasicNameValuePair("barcode", barcode));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
