package vcn.kybotech.activity;

/**
 * Created by Admin-PC on 1/22/2018.
 */

public interface interfaceReturnLoad {
    void ReInitData();
}
