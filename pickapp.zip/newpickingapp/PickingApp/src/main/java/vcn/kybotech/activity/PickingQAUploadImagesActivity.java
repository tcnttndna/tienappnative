package vcn.kybotech.activity;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.adapter.PickImageGridViewAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.fragment.PickingQAFragment;
import vcn.kybotech.model.ImageItem;
import vcn.kybotech.mycustom.LoggingExceptionHandler;
import vcn.kybotech.mycustom.ScalingUtilities;
import vcn.kybotech.mycustom.ScalingUtilities.ScalingLogic;
import vcn.kybotech.pickingapp.R;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources.NotFoundException;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class PickingQAUploadImagesActivity extends ActionBarActivity{

	
	private Button btnTakePhoto;
	private Button btnUpload;
	private GridView grdImagesUpload;
	public static PickImageGridViewAdapter adapter;
	public static ArrayList<ImageItem> data;
	private Bundle bundleData;
	private TextView orderRef;
	private TextView countImageUploaded;
	public static int countSelected = 0;
//	public static int countSelected;
//	public static int countUploadSuccess;
//	private TextView tile_UploadImage;
	private static String mCurrentPhotoPath;
	private RequestQueue requestQueue ;//= Volley.newRequestQueue(MainActivity.this);
	private final static String Tag = "tagRequesLoadData";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		new LoggingExceptionHandler(this);
		setContentView(R.layout.activity_picking_upload_images);
		requestQueue = Volley.newRequestQueue(this);
		
		getSupportActionBar().setDisplayHomeAsUpEnabled(false);
		if(isOnline()){
			getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
		}else{
			getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
		}
		getSupportActionBar().setIcon(R.drawable.ic_logo_kybotech);
		getSupportActionBar().setDisplayShowTitleEnabled(false);
		getSupportActionBar().setDisplayShowHomeEnabled(true);
		
		bundleData = getIntent().getBundleExtra(Constants.key_bundle_qa_upload_image);
		
		btnTakePhoto = (Button) findViewById(R.id.btnTakePhoto);
		btnUpload = (Button) findViewById(R.id.btnUpload);
		grdImagesUpload = (GridView) findViewById(R.id.grdListImagesUpload);
		countImageUploaded = (TextView) findViewById(R.id.countImageUploaded);
//		tile_UploadImage = (TextView) findViewById(R.id.tileupanh);
		String orderref =  bundleData.getString("key_orderref");
		orderRef = (TextView)findViewById(R.id.orderRef_in_form_upload_images);
		orderRef.setText(orderref);
		
		if (PickingQAFragment.countImageUpLoaded > 1) {
			countImageUploaded.setText("Total: " + PickingQAFragment.countImageUpLoaded + " images uploaded");
		}else if (PickingQAFragment.countImageUpLoaded > 0) {
			countImageUploaded.setText("Total: " + PickingQAFragment.countImageUpLoaded + " image uploaded");
		}
		
		btnUpload.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				if (data != null) {
					int cImageSelected = 0;
					/*doan nay chi la check xem co image nao chon chua thoi*/
					for (ImageItem imageItem : data) {	
						if (imageItem.isChecked()) {
							++cImageSelected;
							break;
						}
					}
					if (cImageSelected > 0) {
							onUploadImages();
					}else{
						AlertDialog.Builder dialog = new Builder(PickingQAUploadImagesActivity.this);
						dialog.setTitle("Message")
						.setMessage("Please select at least 1 photos upload to server.")
						.setNegativeButton("Cancel", null)
						.show();
					}
				}
			}
		});
		
		btnTakePhoto.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				onTakePhoto();				
			}
		});
		
		data = new ArrayList<ImageItem>();		
		adapter = new PickImageGridViewAdapter(PickingQAUploadImagesActivity.this, data);
		grdImagesUpload.setAdapter(adapter);
		
		new LoadImagesAsyn().execute();
		onTakePhoto();
		
	}
	
	
	protected void onUploadImages() {
		final ProgressDialog progressDialog = new ProgressDialog(PickingQAUploadImagesActivity.this);
		progressDialog.setTitle(getString(R.string.fragment_picking_upload_images));
		progressDialog.setMessage(getString(R.string.fragment_login_waiting));
		progressDialog.show();
		
		
		/*Dem so anh can upload*/
		countSelected = 0;
		for (final ImageItem image : data) {
			if (image.isChecked()) {
				++countSelected;
			}
		}
		/*Moi lan up anh chi cho toi da 10 anh*/
//		if (countSelected>10) {
//			countSelected =10;
//		}

//		int maxQTy = 0;
		for (final ImageItem image : data) {
			if (image.isChecked()) {
				/*Moi lan up anh chi cho toi da 10 anh*/
//				++ maxQTy;
//				if (maxQTy>10) 	break;
				
				try {
					byte byteAnh[] = null;
					String path = image.getPathImage();
					FileInputStream inputStream = new FileInputStream(path);
					
					BufferedInputStream buffInputStream = new BufferedInputStream(inputStream);
					byteAnh = new byte[buffInputStream.available()];
					buffInputStream.read(byteAnh);
					buffInputStream.close();
					String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
					
					/*xac dinh la anh QA hay Picker Upload*/
					String imagetype = bundleData.getString("key_imagetype");
					String loadid = bundleData.getString("key_loadid");
					String loadcode = bundleData.getString("key_loadcode");
					
					String pickerid = bundleData.getString("key_pickerid");
					String pickername = bundleData.getString("key_pickername");
//					String imageuri = bundleData.getString("key_imageurie");
					
					String orderid = bundleData.getString("key_orderid");
					String orderref = bundleData.getString("key_orderref");
					String orderitemid = bundleData.getString("key_orderitemid");
					
					/*xac dinh la anh QA hay Picker Upload*/
					image.setImageType(imagetype);
					image.setLoadid(loadid);
					image.setLoadcode(loadcode);
					
					image.setPickerid(pickerid);
					image.setPickername(pickername);
					image.setImageuri(encodedString);
					
					image.setOrderid(orderid);
					image.setOrderref(orderref);
					image.setOrderitemid(orderitemid);
					
					
					Response.Listener<String> listener = new Response.Listener<String>(){

						@Override
						public void onResponse(String response) {

							/*Giam so anh vua dem de set dissmis dialog*/
							-- countSelected;
							/*Neu da xu ly het anh da chon thi dissmis dialog*/
							if (progressDialog!=null&&countSelected == 0) {
								progressDialog.dismiss();
						    }

							try {
								JSONObject jsonObject = new JSONObject(response.toString());
								if (jsonObject.getBoolean("success")) {
									
									Log.e("Upload Images success", "");
									File f = new File(image.getPathImage());
									f.delete();
									
									data.remove(image);
									adapter.notifyDataSetChanged();
									
									PickingQAFragment.countImageUpLoaded += 1;
									if (PickingQAFragment.countImageUpLoaded > 1) {
										countImageUploaded.setText(PickingQAFragment.countImageUpLoaded + " images uploaded");
									}else if (PickingQAFragment.countImageUpLoaded > 0) {
										countImageUploaded.setText(PickingQAFragment.countImageUpLoaded + " image uploaded");
									}
									
									/* CHECK UPLOAD ALL DISSMIS DIALOG */
									boolean checkedAll = true;
									for (ImageItem image : data) {
										if (image.isChecked()) {
											checkedAll = false;
										}
									}
									
									if (checkedAll && progressDialog!=null) {
										progressDialog.dismiss();
										if (PickingQAFragment.countImageUpLoaded > 2 ) {
											
											new CountDownTimer(1000, 10) {
												
												public void onTick(long millisUntilFinished) {
												}
												public void onFinish() {
													PickingQAUploadImagesActivity.this.setResult(Constants.RESULT_QA_UPLOAD_IMAGE);
													PickingQAUploadImagesActivity.this.finish();
												}
											}.start();
										}
								    }
									
								}else {
									if (adapter!=null) {
										adapter.notifyDataSetChanged();
									}
									Toast.makeText(PickingQAUploadImagesActivity.this, "upload fail, server is problem!", Toast.LENGTH_SHORT).show();
								}
								
							}catch(JSONException e){
								DialogServerProblem();
								if (adapter!=null) {
									adapter.notifyDataSetChanged();
								}
							}
							catch (Exception e2) {
								if (adapter!=null) {
									adapter.notifyDataSetChanged();
								}
								e2.printStackTrace();
							}
							

							
						}
						
					};
					
					Response.ErrorListener errorListener = new Response.ErrorListener() {

						@Override
						public void onErrorResponse(VolleyError volleyError) {
							try {
								/*Giam so anh can upload*/
								-- countSelected;
								
								/*Neu da xu ly het anh da chon thi dissmis dialog*/
								if (progressDialog!=null&&countSelected==0) {
									progressDialog.dismiss();
									if (adapter!=null) {
										adapter.notifyDataSetChanged();
									}
								}
								
								Toast.makeText(PickingQAUploadImagesActivity.this, "Connection to your server disconnected!", Toast.LENGTH_SHORT).show();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					};
					
					
					StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener){
						@Override
						protected Map<String, String> getParams(){
							
							Map<String, String>	params = onCreateParams();
							return params;
						}

						private Map<String, String> onCreateParams() {
							Map<String, String>	params = new HashMap<String, String>();
							params.put("type", "uploadimagenew");
							params.put("imagetype", image.getImageType());
//							params.put("imagetype", "1"));
							params.put("loadid", image.getLoadid());
							params.put("loadcode", image.getLoadcode());
							
							params.put("pickerid", image.getPickerid());
							params.put("pickername", image.getPickername());
							
							params.put("orderid", image.getOrderid());
							params.put("orderref", image.getOrderref());
							params.put("orderitemid", image.getOrderitemid());
							params.put("imageuri", image.getImageuri());
							
							return params;
						}
					};
					
					
//					RequestQueue requestQueue = Volley.newRequestQueue(PickingQAUploadImagesActivity.this);
					postRequest.setTag(Tag);
					postRequest.setShouldCache(false);
					requestQueue.add(postRequest);
					
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		
	}
	
	
	public void onTakePhoto() {
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
			// Create the File where the photo should go
			File photoFile = null;
			try {
				photoFile = createImageFile();
			} catch (IOException ex) {
				// Error occurred while creating the File
				ex.printStackTrace();
			}
			// Continue only if the File was successfully created
			if (photoFile != null) {
				takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,	Uri.fromFile(photoFile));
				startActivityForResult(takePictureIntent, Constants.REQUEST_TAKE_PHOTO_QA_CONFIRM_ORDER);
			}
		}
		
	}
	
	public File createImageFile() throws IOException {
		// Create an image file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String imageFileName = "QAConfirmOrderItem_" + timeStamp;
		// File storageDir =
		// Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
//		File storageDir = Environment.getExternalStoragePublicDirectory("APPPICKING");
		File storageDir = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_QA);
		if (!storageDir.exists()) {
			storageDir.mkdirs();
		}

		File image = new File(storageDir, imageFileName + ".png");

		mCurrentPhotoPath = image.getAbsolutePath();
		return image;
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent dt)  {
		
		super.onActivityResult(requestCode, resultCode, dt);
		if(requestCode == Constants.REQUEST_TAKE_PHOTO_QA_CONFIRM_ORDER && resultCode == RESULT_OK){
			++ countSelected;
			data.add(0, new ImageItem(mCurrentPhotoPath, true));
			adapter.notifyDataSetChanged();
			compressImage(mCurrentPhotoPath, 800, 1400);
			onTakePhoto();
		}
	}
	
	private boolean compressImage(String path, int width, int height) {
		boolean isCompress = false;
		Bitmap scaledBitmap = null;
		try {
			// Part 1: Decode image
			Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, width,
					height, ScalingLogic.FIT);

			// if (!(unscaledBitmap.getWidth() <= width &&
			// unscaledBitmap.getHeight() <= height)) {
			// Part 2: Scale image
			scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap,
					width, height, ScalingLogic.FIT);
			// } else {
			// unscaledBitmap.recycle();
			// return isCompress;
			// }

			FileOutputStream fos = null;
			try {
				File fichero = new File(mCurrentPhotoPath);
				if (fichero.canWrite()) {
					fichero.createNewFile();
					fos = new FileOutputStream(fichero);
					isCompress = scaledBitmap.compress(
							Bitmap.CompressFormat.JPEG, 70, fos);
					fos.flush();
					fos.close();
				}
			} catch (FileNotFoundException e) {

				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			scaledBitmap.recycle();
		} catch (Throwable e) {
		}
		return isCompress;
	}
	
	
	
	@Override
	protected void onResume() {
		super.onResume();
		pingConnectionSerVer();
		mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		mHandler.removeCallbacks(setTitleColor);
		super.onPause();
		
	}
	
	@Override
	protected void onDestroy() {
		requestQueue.cancelAll(Tag);
		super.onDestroy();
	}
	
	private Handler mHandler = new Handler();
	
	private Runnable setTitleColor = new Runnable() {
	    @Override
	    public void run() {
	    	try {
	    		pingConnectionSerVer();
	    		mHandler.postDelayed(setTitleColor, Constants.TIMER * 1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	};

	public void DialogServerProblem(){
		Log.e("LoginFramgment", "server is problem");
		if (PickingQAUploadImagesActivity.this==null) {
			return;
		}
		Builder dialog = new  AlertDialog.Builder(this);
		dialog.setTitle("Message");
		dialog.setMessage("Server is problem");
		dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				
			}
		});
		dialog.show();
	}

	
	public boolean isOnline() {
	    ConnectivityManager cm =
	        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo netInfo = cm.getActiveNetworkInfo();
	    return netInfo != null && netInfo.isConnectedOrConnecting();
	}
	
	private void pingConnectionSerVer(){
		
		Response.Listener<String> listener = new Response.Listener<String>() {

			@Override
			public void onResponse(String response) {
				try {
					JSONObject jsonObject = new JSONObject(response.toString());
					Log.e("pingConnectionSerVer", jsonObject.toString());
//					if (jsonObject.getBoolean("success")) {
						getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar));
//					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		
		Response.ErrorListener errorListener = new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError arg0) {
				try {
					getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.background_color_actionbar_red));
				} catch (NotFoundException e) {
				}
			}
			
		};
		
		StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener, errorListener){
			@Override
			protected Map<String, String> getParams(){
				Map<String, String> params = new HashMap<String, String>();
				params.put("type", "checkversion");
				params.put("softType", "newpickingapp");
				params.put("curVersion", "1");
				return params;
			}
		};
		
		try {
			postRequest.setTag(Tag);
			postRequest.setShouldCache(false);
			requestQueue.add(postRequest);
		} catch (Exception e) {
		}
	}
	
	private void deleteImages() {
//		String targetPath = ExternalStorageDirectoryPath + "/APPPICKING/";
		File targetDirector = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_QA);
//		targetDirector.delete();
		File[] files = targetDirector.listFiles();
		if (files != null) {
			
			for (File file : files) {
				file.delete();
			}
		}
	}
	
	private void onQuestionDeleImages() {
		AlertDialog.Builder dialog = new Builder(this);
		dialog.setTitle("Delete images")
		.setMessage("Are you sure to delete all images?")
		.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				deleteImages();
				new LoadImagesAsyn().execute();
			}
		})
		.setNegativeButton("No", null)
		.show();
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_qa_upload_image, menu);

		return true;
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		int id = item.getItemId();

		switch (id) {
		case R.id.menu_qa_delete_images:
			onQuestionDeleImages();
			
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}


	public static class LoadImagesAsyn extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... params) {
			try {
//				String ExternalStorageDirectoryPath = Environment.getExternalStorageDirectory().getAbsolutePath();
//				String targetPath = ExternalStorageDirectoryPath + "/APPPICKING/";
//				String targetPath = ExternalStorageDirectoryPath + "/DCIM/Camera/";
//				File targetDirector = new File(targetPath);
				File targetDirector = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_QA);
				File[] files = targetDirector.listFiles();
				data.clear();
				if (files != null) {
					
					for (File file : files) {
//						++ countSelected;
						ImageItem imageItem = new ImageItem(file.getAbsolutePath(), true);
						data.add(0,imageItem);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(Void result) {

			adapter.notifyDataSetChanged();

		};

	}



}
