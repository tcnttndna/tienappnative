package vcn.kybotech.model;

public class PickOrderType {

	String OrderRef;
	int OrderItemID;
	int PartID;
	String PartName;
	String LocationName;
	String PickedBy;
	String PickType;
	int PickTypeID;
	String ProductName;
	String ProductOption;
	int DropNumber;
	int TotalPack;
	int Quantity;
	String SpecialInstructions;

	public PickOrderType() {
		super();
	}

	public PickOrderType(int orderItemID, String pickType, int pickTypeID) {
		super();
		OrderItemID = orderItemID;
		PickType = pickType;
		PickTypeID = pickTypeID;

	}

	public String getOrderRef() {
		return OrderRef;
	}

	public void setOrderRef(String orderRef) {
		OrderRef = orderRef;
	}

	public int getOrderItemID() {
		return OrderItemID;
	}

	public void setOrderItemID(int orderItemID) {
		OrderItemID = orderItemID;
	}

	public int getPartID() {
		return PartID;
	}

	public void setPartID(int partID) {
		PartID = partID;
	}

	public String getPartName() {
		return PartName;
	}

	public void setPartName(String partName) {
		PartName = partName;
	}

	public String getLocationName() {
		return LocationName;
	}

	public void setLocationName(String locationName) {
		LocationName = locationName;
	}

	public String getPickedBy() {
		return PickedBy;
	}

	public void setPickedBy(String pickedBy) {
		PickedBy = pickedBy;
	}

	public String getPickType() {
		return PickType;
	}

	public void setPickType(String pickType) {
		PickType = pickType;
	}

	public int getPickTypeID() {
		return PickTypeID;
	}

	public void setPickTypeID(int pickTypeID) {
		PickTypeID = pickTypeID;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public String getProductOption() {
		return ProductOption;
	}

	public void setProductOption(String productOption) {
		ProductOption = productOption;
	}

	public int getDropNumber() {
		return DropNumber;
	}

	public void setDropNumber(int dropNumber) {
		DropNumber = dropNumber;
	}

	public int getTotalPack() {
		return TotalPack;
	}

	public void setTotalPack(int totalPack) {
		TotalPack = totalPack;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public String getSpecialInstructions() {
		return SpecialInstructions;
	}

	public void setSpecialInstructions(String specialInstructions) {
		SpecialInstructions = specialInstructions;
	}

}
