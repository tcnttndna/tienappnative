package vcn.kybotech.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vcn.kybotech.adapter.PartsReturnLoadAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickReturnPart;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickReturnParts;

@SuppressLint({"CutPasteId", "InflateParams"})
public class ReturnPartFragment extends android.app.Fragment  {

    private TextView OrdersDropNumber;
    private TextView OrderRef;
    private TextView TvOrderItemID;
    private TextView TvLoadID;
    private ListView lvPartsInOrder;
    private PartsReturnLoadAdapter adapterPartReturnLoad;
    private List<PickReturnPart> listPartByOrder;
    private List<PickReturnPart> listOrderRef;
    //    private Button btnSkip;
//    private Button btnConfirm;
    private int iOrders;
    public static int countImageUpLoaded;
    RequestQueue requestQueue;
    //    private final static String Tag = "RequesConfirm";
//    RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
    int intOrdersItemID;
    PickReturnPart returnLoad;
    String strOrderRef;

    sql_PickReturnParts sqlPickReturnLoads;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_picking_return_part, container, false);
        rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        /* Phan dang ky findViewByID */

        OrdersDropNumber = (TextView) rootView.findViewById(R.id.tvOrdersDropNumber);
        TvOrderItemID = (TextView) rootView.findViewById(R.id.load_accept_OrderItemID);
        OrderRef = (TextView) rootView.findViewById(R.id.load_accept_OrderRef);
        lvPartsInOrder = (ListView) rootView.findViewById(R.id.lvPartsInOrder_FragmentPickingReturnLoad);
        TvLoadID = (TextView) rootView.findViewById(R.id.load_accept_LoadID);
//        btnConfirm = (Button) rootView.findViewById(R.id.btnConfirm);
//        btnSkip = (Button) rootView.findViewById(R.id.btnSkip);

        return rootView;
    }

    private void onProgressEvent(int indexOrder) {
        try {
            intOrdersItemID = listOrderRef.get(indexOrder).getOrderItemPartID();
            strOrderRef = listOrderRef.get(indexOrder).getOrderRef();
            TvLoadID.setText(returnLoad.getLoadID() + "");
            OrderRef.setText(strOrderRef);
            OrdersDropNumber.setText((indexOrder + 1) + "");
            TvOrderItemID.setText(intOrdersItemID + "");
            listPartByOrder = sqlPickReturnLoads.getListPartsByOrderRef(strOrderRef);
            if (listPartByOrder.size() == 0) return;

            adapterPartReturnLoad = new PartsReturnLoadAdapter(getActivity(), R.layout.item_part_return_load, listPartByOrder);
            lvPartsInOrder.setAdapter(adapterPartReturnLoad);
            adapterPartReturnLoad.notifyDataSetChanged();

        } catch (Exception ex) {
            String str = ex.getMessage();
        }
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);

        try {
            this.returnLoad = (PickReturnPart) getArguments().getSerializable(Constants.key_bundle_pickreturnload);
            sqlPickReturnLoads = new sql_PickReturnParts(getActivity());

            listOrderRef = sqlPickReturnLoads.getListOrderRef(String.valueOf(returnLoad.getLoadID()));
            iOrders = 0;
            if (listOrderRef.size() > 0) {
                onProgressEvent(iOrders);
            }
            onClickButton();
        } catch (Exception e) {
        }

    }

    private void onClickButton() {

        lvPartsInOrder.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                long viewId = view.getId();

                if (viewId == R.id.item_part_btnAddToStock) {
                    final ProgressDialog progressDialog;
                    progressDialog = new ProgressDialog(getActivity());
                    progressDialog.setMessage("waiting...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    requestQueue = Volley.newRequestQueue(getActivity());
//
                    Response.Listener<String> listener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response.toString());
                                if (jsonObject.getBoolean("success")) {
                                    sql_PickReturnParts pickReturnLoads = new sql_PickReturnParts(getActivity());
                                    pickReturnLoads.updateConfirmedAddToStock(
                                            String.valueOf(listPartByOrder.get(i).getLoadID()),
                                            String.valueOf(listPartByOrder.get(i).getOrderItemPartID()),
                                            String.valueOf(listPartByOrder.get(i).getPartID()));
                                    updateListView(listPartByOrder.get(i).getOrderRef());
                                } else {
                                    Toast.makeText(getActivity(), "Success: false, server is problem!",
                                            Toast.LENGTH_SHORT).show();
                                }

                            } catch (JSONException e2) {
                                e2.printStackTrace();
                            } finally {
                                adapterPartReturnLoad.notifyDataSetChanged();
                                progressDialog.dismiss();
                            }
                        }
                    };

                    Response.ErrorListener errorListener = new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError volleyError) {
                            try {

                                Toast.makeText(getActivity(), "Connection to your server disconnected!", Toast.LENGTH_SHORT)
                                        .show();
                                Log.e("OrderPickingActivity.java", "Load Data AccountPicker disconnect");
                                Log.e("OrderPickingActivity.java", volleyError.toString());
                            } catch (Exception ex) {

                            }
                        }
                    };

                    StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                            errorListener) {

                        @Override
                        protected Map<String, String> getParams() {
                            FileSave fileSave = new FileSave(getActivity(), Constants.GET);
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("type", Constants.type_addtostock);
                            params.put("orderRef", listPartByOrder.get(i).getOrderRef());
                            params.put("partID", String.valueOf(listPartByOrder.get(i).getPartID()));
                            params.put("partQty", String.valueOf(listPartByOrder.get(i).getPartQuantity()));
                            params.put("orderItemPartID", String.valueOf(listPartByOrder.get(i).getOrderItemPartID()));
                            params.put("userName", fileSave.getUserName());
                            params.put("userID", String.valueOf(fileSave.getUserID()));
                            return params;
                        }
                    };

                    // RequestQueue requestQueue = Volley.newRequestQueue(this);
                    int socketTimeout = 30000;// 30 seconds - change to what you want
                    RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                    postRequest.setRetryPolicy(policy);
                    postRequest.setTag("cancelAll");
                    postRequest.setShouldCache(false);
                    requestQueue.add(postRequest);
                }
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.REQUEST_NORMAL_UPLOAD_IMAGE
                && resultCode == Constants.RESULT_NORMAL_UPLOAD_IMAGE) {
        }

    }

    public void DialogServerProblem() {
        if (getActivity() == null) {
            return;
        }
        Builder dialog = new Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage("Server is problem");
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

//    @Override
//    public void onDetach() {
//        requestQueue.cancelAll("cancelAll");
//        super.onDetach();
//    }

    protected void updateListView(String OrderRef) {

        List<PickReturnPart> listNew = sqlPickReturnLoads.getListPartsByOrderRef(OrderRef);
        listPartByOrder.clear();
        listPartByOrder.addAll(listNew);
        adapterPartReturnLoad.notifyDataSetChanged();

    }
}
