package vcn.kybotech.parseapi.remote;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import vcn.kybotech.parseapi.model.Loadreturnfailorder;


/**
 * Created by Admin-PC on 1/13/2018.
 */

public interface SOService {

    @GET("ajax/Process.ashx?type=faileddeliveryorders&fromDate=2016-12-21&toDate=2016-12-21")
    Call<Loadreturnfailorder> getFails();

    @GET("ajax/Process.ashx?type=faileddeliveryorders")
    Call<Loadreturnfailorder> getOrderFail(@Query("fromDate") String fromdate,@Query("toDate") String todate);
}
