package vcn.kybotech.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.pickingapp.R;

public class SLSAddFragment extends android.app.Fragment {

    private int SCAN_PARTID = 1;
    private int SCAN_LOCATION = 2;
    private JSONParser jsonParser;
    private EditText etPartId;
    private EditText etLocation;
    private Button btnAdd;
    private Button btnScanPartId;
    private Button btnScanLocation;
    private ProgressBar pbLoading;
    FileSave fileSave;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sls_add, container, false);

        btnAdd = (Button) rootView.findViewById(R.id.fragment_sls_add_btnadd);
        etPartId = (EditText) rootView.findViewById(R.id.fragment_sls_add_etpartid);
        etLocation = (EditText) rootView.findViewById(R.id.fragment_sls_add_etlocation);
        pbLoading = (ProgressBar) rootView.findViewById(R.id.fragment_sls_add_pbLoading);
        btnScanPartId = (Button) rootView.findViewById(R.id.fragment_sls_add_btnScanPartId);
        btnScanLocation = (Button) rootView.findViewById(R.id.fragment_sls_add_btnScanLocation);

        jsonParser = new JSONParser();
        fileSave = new FileSave(getActivity(), Constants.GET);

        etLocation.setFilters(new InputFilter[]{new InputFilter.AllCaps()});

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        btnAdd.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                final String partId = etPartId.getText().toString();
                final String location = etLocation.getText().toString();

                if (partId.equals("")) {
                    Toast.makeText(getActivity(), "PartID is not valid !", Toast.LENGTH_SHORT).show();
                    etPartId.requestFocus();
                    return;
                }

                if (location.equals("")) {
                    Toast.makeText(getActivity(), "Location is not valid !", Toast.LENGTH_SHORT).show();
                    etLocation.requestFocus();
                    return;
                }

                btnAdd.setVisibility(View.GONE);
                pbLoading.setVisibility(View.VISIBLE);

                new AsyncTask<String, Void, JSONObject>() {
                    @Override
                    protected void onPreExecute() {
                        super.onPreExecute();
                    }

                    @Override
                    protected JSONObject doInBackground(String... arg0) {
                        List<NameValuePair> params = new ArrayList<NameValuePair>();
                        params.add(new BasicNameValuePair(Constants.type, "slsaddpartlocation"));
                        params.add(new BasicNameValuePair("partid", partId));
                        params.add(new BasicNameValuePair("location", location));
                        params.add(new BasicNameValuePair("pickerid", String.valueOf(fileSave.getPickerID())));
                        params.add(new BasicNameValuePair("pickername", fileSave.getPickerName()));
                        params.add(new BasicNameValuePair("appname", "NewPickingApp"));
                        JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
                        return objJSON;
                    }

                    protected void onPostExecute(JSONObject jsonObject) {
                        try {
                            if (jsonObject == null) {
                                Toast.makeText(getActivity(), "Can not get data, please try again !",
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                if (jsonObject.getBoolean("success")) {
                                    etPartId.setText("");
                                    etLocation.setText("");
                                    etPartId.requestFocus();
                                }
                                Toast.makeText(getActivity(), jsonObject.getString("message"),
                                        Toast.LENGTH_SHORT).show();
                            }
                            btnAdd.setVisibility(View.VISIBLE);
                            pbLoading.setVisibility(View.GONE);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "Error: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                            btnAdd.setVisibility(View.VISIBLE);
                            pbLoading.setVisibility(View.GONE);
                        }
                    }
                }.execute();
            }
        });

        btnScanPartId.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onScanBarCode(SCAN_PARTID);
            }
        });

        btnScanLocation.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onScanBarCode(SCAN_LOCATION);
            }
        });
    }

    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public void onScanBarCode(int types) {
        try {
            Intent intent = new Intent("com.google.zxing.client.android.pick.SCAN");
            intent.putExtra("SCAN_FORMATS",
                    "QR_CODE,EAN_13,EAN_8,RSS_14,UPC_A,UPC_E,CODE_39,CODE_93,CODE_128,ITF,CODABAR,DATA_MATRIX");
            startActivityForResult(intent, types);
        } catch (Exception e) {
            Log.e("NOT SCAN", e.toString());
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        String barcode = "";
        try {
            String format = data.getStringExtra("SCAN_RESULT_FORMAT");
            barcode = data.getStringExtra("SCAN_RESULT");
            if (requestCode == SCAN_PARTID){

                BarcodeSubString brcode = new BarcodeSubString();

                barcode = brcode.CutBarcode(barcode, format);
            }
//            if (format.equalsIgnoreCase("QR_CODE") && requestCode == SCAN_PARTID) {
//                if (barcode.toLowerCase().startsWith("part id") && barcode.length() > 11) {
//                    barcode = barcode.substring(6, 11);
//                }
//                if (barcode.length() > 5) {
//                    String[] s = barcode.split(",");
//                    if (s.length > 1) {
//                        barcode = s[0];
//                        if (s[0].toLowerCase().contains("k")) {
//                            barcode = s[1];
//                        }
//                    }
//                }
//                if (barcode.length() > 5) {
//                    barcode = barcode.substring(0, 5);
//                }
//            }
        } catch (Exception e) {
//            AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
//            dialog.setTitle("Message");
//            dialog.setMessage(e.getMessage());
//            dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface dialog, int which) {
//
//                }
//            });
//            dialog.show();
        }
        if (requestCode == SCAN_PARTID && resultCode == -1) {
            etPartId.setText(barcode);
            etPartId.requestFocus();
        }
        if (requestCode == SCAN_LOCATION && resultCode == -1) {
            etLocation.setText(barcode);
            etLocation.requestFocus();
        }
    }
}
