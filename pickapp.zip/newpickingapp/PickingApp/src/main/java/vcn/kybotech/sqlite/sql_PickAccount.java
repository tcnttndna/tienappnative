package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.model.PickAccount;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class sql_PickAccount {

    private sql_DataBase data;
    public static final String TABLE_PICK_ACCOUNT = "PickAccount";

    public static final String COLUMN0_PICK_NAME = "pname";
    public static final String COLUMN1_PICK_ID = "pid";
    public static final String COLUMN2_IS_ADMIN = "isadmin";
    public static final String COLUMN3_WARE_HOUSE_ID = "warehouseid";
    public static final String COLUMN4_IS_QA = "isqa";
    public static final String COLUMN5_IS_AGENCY = "isagency";
    public static final String COLUMN6_CAN_QC = "canqc";


    public static final String CREATE_TABLE_ACCOUNT = "CREATE TABLE "
            + TABLE_PICK_ACCOUNT + " ("
            + COLUMN0_PICK_NAME + " TEXT, "
            + COLUMN1_PICK_ID + " INTEGER PRIMARY KEY, "
            + COLUMN2_IS_ADMIN + " TEXT, "
            + COLUMN3_WARE_HOUSE_ID + " INTEGER, "
            + COLUMN4_IS_QA + " TEXT, "
            + COLUMN5_IS_AGENCY + " NUMERIC, "
            + COLUMN6_CAN_QC + " TEXT)";

    public sql_PickAccount(Context context) {
        data = new sql_DataBase(context);
    }

    /* Kiem tra su ton tai cua du lieu*/
    public boolean checkExistsData() {
        boolean output = false;
        String sqlSelect = "SELECT * FROM " + TABLE_PICK_ACCOUNT;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        if (cursor.getCount() > 0) {
            output = true;
        }
        cursor.close();
        db.close();
        return output;
    }

    /* Kiem tra xem co bao nhieu ban ghi*/
    public int getCountPickerAccount() {
        int c = 0;
        String sqlSelect = "SELECT * FROM " + TABLE_PICK_ACCOUNT;
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        c = cursor.getCount();
        cursor.close();
        db.close();
        return c;
    }


    /*Insert du lieu thong thuong*/
    public void insertPickAccount(JSONArray jsonArr) {
        SQLiteDatabase db = data.getWritableDatabase();
        Log.e("sql_PickAccount ", "so ban ghi PickAccount can duoc insert vao sqlite = " + jsonArr.length());
        for (int i = 0; i < jsonArr.length(); i++) {

            try {
                JSONObject jsonPickParts = jsonArr.getJSONObject(i);
                ContentValues values = new ContentValues();

                values.put(COLUMN0_PICK_NAME, jsonPickParts.getString("pname"));
                values.put(COLUMN1_PICK_ID, jsonPickParts.getInt("pid"));
                values.put(COLUMN2_IS_ADMIN, jsonPickParts.getString("isadmin"));
                values.put(COLUMN3_WARE_HOUSE_ID, jsonPickParts.getInt("warehouseid"));
                values.put(COLUMN4_IS_QA, jsonPickParts.getString("isqa"));

                db.insert(TABLE_PICK_ACCOUNT, null, values);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e("sql_PickAccount", " insert jsonParts to sqlite error ");
            }
            db.close();
            Log.e("sql_PickAccount", " so ban ghi duoc insert  =  " + getCountPickerAccount());
        }
    }


    public List<PickAccount> getAllPickAccount() {
        SQLiteDatabase db = data.getWritableDatabase();
        Cursor cursor = db.query(TABLE_PICK_ACCOUNT, null, null, null, null, null, null);
        List<PickAccount> list = new ArrayList<PickAccount>();
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                list.add(new PickAccount(
                                cursor.getString(cursor.getColumnIndex(COLUMN0_PICK_NAME)),
                                cursor.getInt(cursor.getColumnIndex(COLUMN1_PICK_ID)),
                                Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_ADMIN))),
                                cursor.getInt(cursor.getColumnIndex(COLUMN3_WARE_HOUSE_ID)),
                                Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN4_IS_QA))),
                                cursor.getString(cursor.getColumnIndex(COLUMN6_CAN_QC))
                        )
                );

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    /*Clear du lieu*/
    public void clearData() {
        SQLiteDatabase db = data.getWritableDatabase();
        db.delete(TABLE_PICK_ACCOUNT, null, null);
        db.close();
        if (getCountPickerAccount() == 0) {
            Log.e("sql_PickAccount", " Clear Data succes");
        } else Log.e("sql_PickAccount", " Clear Data fail");
    }

    /*Insert du lieu su dung transaction*/
    public void insertPickAccountTransaciton(JSONArray jsonArr) {
        /*Chuoi JSONArray truyen vao la mot mang cac doi tuong */
        String sql = "INSERT INTO " + TABLE_PICK_ACCOUNT + " ("
                + COLUMN0_PICK_NAME + ", "
                + COLUMN1_PICK_ID + ", "
                + COLUMN2_IS_ADMIN + ", "
                + COLUMN3_WARE_HOUSE_ID + ", "
                + COLUMN4_IS_QA + ", "
                + COLUMN5_IS_AGENCY + ", "
                + COLUMN6_CAN_QC + ") VALUES (?, ?, ?, ?, ?, ?, ?)";

		
		/*Clearn data*/
        clearData();

        SQLiteDatabase db = data.getWritableDatabase();
        db.beginTransactionNonExclusive();
        SQLiteStatement sqlSTMT = db.compileStatement(sql);
        Log.e("sql_PickAccount ", "so ban ghi PickAccount can duoc insert vao sqlite = " + jsonArr.length());
        try {
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject jsonPickAccount = jsonArr.getJSONObject(i);

				/*Tam thoi chi insert cac cot can su dung con cac cot khong su dung tam thoi comment*/
                sqlSTMT.bindString(1, jsonPickAccount.getString("pname"));
                sqlSTMT.bindLong(2, jsonPickAccount.getLong("pid"));
                sqlSTMT.bindString(3, jsonPickAccount.getString("isadmin"));
                sqlSTMT.bindLong(4, jsonPickAccount.getLong("warehouseid"));
                sqlSTMT.bindString(5, jsonPickAccount.getString("isqa"));
                sqlSTMT.bindString(6, jsonPickAccount.getString("isagency"));
                sqlSTMT.bindString(7, jsonPickAccount.getString("canqc"));


//				sqlSTMT.bindLong(1, jsonParts.getLong("PartID"));
//				sqlSTMT.bindString(2,jsonParts.getString("IsScanned"));
//				sqlSTMT.bindString(3, jsonParts.getString("IsQA"));
//				sqlSTMT.bindString(4, jsonParts.getString("PartName"));
//				sqlSTMT.bindLong(5, jsonParts.getLong("Quantity") );
//	
//				sqlSTMT.bindLong(6, jsonParts.getLong("Barcode"));
//				sqlSTMT.bindString(7, jsonParts.getString("OrderRef"));
//				sqlSTMT.bindLong(8, jsonParts.getLong("OrderItemID"));
//				sqlSTMT.bindLong(9, jsonParts.getLong("TotalPack") );
//				sqlSTMT.bindString(10, jsonParts.getString("DateScanned") );
//	   
//				sqlSTMT.bindString(11, jsonParts.getString("LocationName") );
//				sqlSTMT.bindString(12, jsonParts.getString("PickedBy") );
//				sqlSTMT.bindLong(13, jsonParts.getLong("PickTypeID") );
//				sqlSTMT.bindString(14, jsonParts.getString("PickType") );
//				sqlSTMT.bindString(15, jsonParts.getString("ProductName") );
//				
//				sqlSTMT.bindString(16, jsonParts.getString("ProductOption"));
//				sqlSTMT.bindLong(17, jsonParts.getLong("DropNumber"));
//				sqlSTMT.bindString(18, jsonParts.getString("LoadCode") );			
//				sqlSTMT.bindLong(19, jsonParts.getInt("Package"));
//				sqlSTMT.bindString(20, jsonParts.getString("SpecialInstructions"));

                sqlSTMT.execute();
                sqlSTMT.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.e("sql_PickAccount", " insertTransaction jsonParts to sqlite error ");
        }
        db.close();
        Log.e("sql_PickAccount", " so ban ghi duoc qickly insert  =  " + getCountPickerAccount());
    }


//	public List<PickAccount> getListPickAccount(String OrderRef) {
//		List<PickPart> list = new ArrayList<PickPart>();
//		String selectListParts = "SELECT * FROM " + TABLE_PARTS
//				+ " WHERE "  + COLUMN6_ORDER_REF + " = '"
//				+ OrderRef + "'";
//		
//		SQLiteDatabase db = data.getReadableDatabase();
//		Cursor cursor = db.rawQuery(selectListParts, null);
//		cursor.moveToFirst();
//		if (cursor.getCount() > 0) {
//			cursor.moveToFirst();
//			do {
//				list.add(new PickPart(

//						cursor.getInt(cursor.getColumnIndex(COLUMN0_PART_ID)),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN1_IS_SCANNED))),
//						Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex(COLUMN2_IS_QA))),
//						cursor.getString(cursor.getColumnIndex(COLUMN3_PART_NAME)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN4_QUANTITY)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN5_BAR_CODE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN6_ORDER_REF)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN7_ORDER_ITEM_ID)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN8_TOTAL_PACK)),
//						cursor.getString(cursor.getColumnIndex(COLUMN9_DATE_SCANNED)),
//						cursor.getString(cursor.getColumnIndex(COLUMN10_LOCATION_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN11_PICKED_BY)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN12_PICK_TYPE_ID)),
//						cursor.getString(cursor.getColumnIndex(COLUMN13_PICK_TYPE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN14_PRODUCT_NAME)),
//						cursor.getString(cursor.getColumnIndex(COLUMN15_PRODUCT_OPTION)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN16_DROP_NUMBER)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN17_LOAD_CODE)),
//						cursor.getInt(cursor.getColumnIndex(COLUMN18_PACKAGE)),
//						cursor.getString(cursor.getColumnIndex(COLUMN19_SPECIAL_INSTRUCTIONS))
//						)
//				);
//				
//			} while (cursor.moveToNext());
//		}
//		cursor.close();
//		db.close();
//		return list;
//	}

    public int getPickID(String namePicker) {
        int pID = -1;
        String sqlSelect = "SELECT  " + COLUMN1_PICK_ID + " FROM " + TABLE_PICK_ACCOUNT + " WHERE " + COLUMN0_PICK_NAME + " = '" + namePicker + "'  LIMIT 1";
        SQLiteDatabase db = data.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlSelect, null);
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++) {
            pID = cursor.getInt(0);
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        return pID;
    }

    public PickAccount getPickerCanQcById(String pickerId) {
        PickAccount pickAccount = new PickAccount();
        try {
            String sqlSelect = "SELECT  " + COLUMN1_PICK_ID + "," + COLUMN6_CAN_QC + " FROM " + TABLE_PICK_ACCOUNT + " WHERE " + COLUMN1_PICK_ID + " = '" + pickerId + "'";
            SQLiteDatabase db = data.getReadableDatabase();
            Cursor cursor = db.rawQuery(sqlSelect, null);
            cursor.moveToFirst();
            pickAccount.setpId(cursor.getInt(0));
            pickAccount.setCanQC(cursor.getString(1));
            cursor.close();
            db.close();
            return pickAccount;
        } catch (Exception ex) {
            return null;
        }
    }

//
//public int getCountSearch(String search) {
//	int count = 0;
//	String sqlSelect = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS;
//	SQLiteDatabase db = data.getReadableDatabase();
//	Cursor cursor = db.rawQuery(sqlSelect, null);
//	count = cursor.getCount();
//	cursor.close();
//	db.close();
//	return count;
//}

}
