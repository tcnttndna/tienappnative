package vcn.kybotech.adapter;

import java.util.ArrayList;

import vcn.kybotech.model.ImageItem;
import vcn.kybotech.mycustom.SquaredImageView;
import vcn.kybotech.pickingapp.R;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.squareup.picasso.Picasso;

public class PickImageGridViewAdapter extends BaseAdapter {

	private Context context;
	public static ArrayList<ImageItem> data = new ArrayList<ImageItem>();

	@SuppressWarnings("static-access")
	public PickImageGridViewAdapter(Context context, ArrayList<ImageItem> data) {
		this.context = context;
		this.data = data;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		final ViewHolder holder;
		LayoutInflater inflater;
		RelativeLayout relativeLayout = null;
		if (row == null) {
			inflater = ((Activity) context).getLayoutInflater();
			row = inflater.inflate(R.layout.item_girdview_image, parent, false);
			SquaredImageView imageView = (SquaredImageView) row
					.findViewById(R.id.imageInGirdView);
			imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
			row.setPadding(1, 1, 1, 1);

			holder = new ViewHolder();
			holder.image = imageView;
			holder.check = (ImageView) row.findViewById(R.id.checkImage);
			row.setTag(holder);
		} else {
			holder = (ViewHolder) row.getTag();
		}

		final ImageItem item = data.get(position);
		Picasso.with(context) //
				.load("file://" + item.getPathImage()) //
				.placeholder(R.drawable.ic_came) //
				.error(R.drawable.ic_search) //
				.fit() //
				.centerCrop().tag(context) //
				.into(holder.image);

		// Picasso.with(context)
		// .load("file://" + files[files.length - (position+1)])
		// .resize(100, 100)
		// .centerCrop()
		// .into(viewHolder.image);

		if (item.isChecked()) {
			// holder.image.setImageBitmap(item.getImage());
			holder.check.setVisibility(View.VISIBLE);
		} else {
			holder.check.setVisibility(View.INVISIBLE);
		}

		relativeLayout = (RelativeLayout) row
				.findViewById(R.id.grvSelectImages);
		relativeLayout.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (item.isChecked()) {
					holder.check.setVisibility(View.INVISIBLE);
					item.setChecked(false);
					// MainActivity.listImagesSelected.remove(item);
				} else {
					holder.check.setVisibility(View.VISIBLE);
					item.setChecked(true);
					// MainActivity.listImagesSelected.add(item);
				}

			}
		});

		return row;
	}

	public static class ViewHolder {
		SquaredImageView image;
		ImageView check;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return data.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}
}