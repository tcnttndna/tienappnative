package vcn.kybotech.parseapi.model;

/**
 * Created by Admin-PC on 1/17/2018.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datareturnfailoder {

    @SerializedName("OrderRef")
    @Expose
    private String orderRef;
    @SerializedName("LoadID")
    @Expose
    private Integer loadID;
    @SerializedName("OriginalLoadCode")
    @Expose
    private String originalLoadCode;
    @SerializedName("PlannedDeliveryDate")
    @Expose
    private String plannedDeliveryDate;

    public String getOrderRef() {
        return orderRef;
    }

    public void setOrderRef(String orderRef) {
        this.orderRef = orderRef;
    }

    public Integer getLoadID() {
        return loadID;
    }

    public void setLoadID(Integer loadID) {
        this.loadID = loadID;
    }

    public String getOriginalLoadCode() {
        return originalLoadCode;
    }

    public void setOriginalLoadCode(String originalLoadCode) {
        this.originalLoadCode = originalLoadCode;
    }

    public String getPlannedDeliveryDate() {
        return plannedDeliveryDate;
    }

    public void setPlannedDeliveryDate(String plannedDeliveryDate) {
        this.plannedDeliveryDate = plannedDeliveryDate;
    }

}