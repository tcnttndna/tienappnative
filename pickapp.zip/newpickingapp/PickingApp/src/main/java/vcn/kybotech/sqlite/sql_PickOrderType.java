package vcn.kybotech.sqlite;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.model.PickOrderType;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class sql_PickOrderType {

	private sql_DataBase dataBase;

	public sql_PickOrderType(Context context) {
		super();
		this.dataBase = new sql_DataBase(context);
	}

	public static final String TABLE_PICK_ORDERS_WITH_TYPE = "PickOrdersWithType";
	public static final String COLUMN_ORDER_REF = "OrderRef";
	public static final String COLUMN_ORDER_ITEM_ID = "OrderItemID";
	public static final String COLUMN_PRODUCT_NAME = "ProductName";
	public static final String COLUMN_PRODUCT_OPTION = "ProductOption";
	public static final String COLUMN_DROP_NUMBER = "DropNumber";
	public static final String COLUMN_PRODUCT_PICKTYPE = "PickType";
	public static final String COLUMN_SPECIAL_INSTRUCTIONS = "SpecialInstructions";

	public static final String CREATE_TABLE = "CREATE TABLE " + TABLE_PICK_ORDERS_WITH_TYPE
			+ "(" + 
			COLUMN_ORDER_REF + " TEXT, " + 
			COLUMN_ORDER_ITEM_ID + " INTEGER, " +
			COLUMN_PRODUCT_NAME	+ " TEXT, " + 
			COLUMN_PRODUCT_OPTION + " TEXT, " + 
			COLUMN_DROP_NUMBER + " INTEGER, " + 
			COLUMN_PRODUCT_PICKTYPE	+ " TEXT, " + 
			COLUMN_SPECIAL_INSTRUCTIONS + " TEXT " + ")";

	public void insertPickOrdersWithTypeTransaciton(JSONArray jsonArr) {
		String sql = "INSERT INTO " + TABLE_PICK_ORDERS_WITH_TYPE + " VALUES (?, ?, ?, ?, ?, ?, ?)";
		SQLiteDatabase db = dataBase.getWritableDatabase();

		db.beginTransactionNonExclusive();
		SQLiteStatement sqlSTMT = db.compileStatement(sql);
		try {
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject object = jsonArr.getJSONObject(i);
				sqlSTMT.bindString(1,object.getString("OrderRef"));
				sqlSTMT.bindLong(2,object.getInt("OrderItemID"));
				sqlSTMT.bindString(3, object.getString("ProductName"));
				sqlSTMT.bindString(4, object.getString("ProductOption"));
				sqlSTMT.bindLong(5, object.getInt("DropNumber"));
				sqlSTMT.bindString(6, object.getString("PickType"));
				sqlSTMT.bindString(7, object.getString("SpecialInstructions"));
				sqlSTMT.execute();
				sqlSTMT.clearBindings();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		db.setTransactionSuccessful();
		db.endTransaction();
		db.close();
	}
	
	
	/*Clear du lieu*/
	public void clearData() {
		SQLiteDatabase db = dataBase.getWritableDatabase();
		try {
			db.delete(TABLE_PICK_ORDERS_WITH_TYPE, null, null);
			db.close();
			Log.e("sql_PickOrdersWithType", " Clear Data succes");
		} catch (Exception e) {
			if (db!=null) {
				db.close();
			}
//			new LogCrashActivity().inserException(e);
		}
	}

	
	
	
	/*Neu o phan NormalPick ma remove OrderItem thi phai xoa ngay orderItem do trong bang nay*/
	
	/* NewPickingApp  PickByType - Dem xem co bao nhieu Order trong mot Load khong tinh cac Order da remove*/
	public int getCountOrdersWithType() {
		int c = 0;
		SQLiteDatabase db = dataBase.getReadableDatabase();
		String sqlSelect = "SELECT COUNT(*) FROM " + TABLE_PICK_ORDERS_WITH_TYPE;
		Cursor cursor = null;
		
		try {
			cursor = db.rawQuery(sqlSelect, null);
			if (cursor.getCount()>0) {
				cursor.moveToFirst();
				c = cursor.getInt(0);
			}
			cursor.close();
			db.close();
		} catch (Exception e) {
			e.printStackTrace();
			if (cursor!= null) {
				cursor.close();
			}
			if (db!= null) {
				db.close();
			}
//			new LogCrashActivity().inserException(e);
		}
		
		return c;
	}
	

	public List<PickOrderType> getOrderItemType(String type ) {
		
		List<PickOrderType> list = new ArrayList<PickOrderType>();
		String sql = "select * from" +
								"(select " +
								" PickOrdersWithType.OrderRef, " +
								" PickOrdersWithType.OrderItemID, " +
								" PickOrdersWithType.ProductName, " +
								" PickOrdersWithType.ProductOption, " +
								" PickOrdersWithType.DropNumber, " +
								" PickOrdersWithType.PickType, " +
								" PickOrdersWithType.SpecialInstructions, " +
								" PickOrders.Status " +
								" from  PickOrdersWithType   LEFT OUTER JOIN PickOrders " +
								" on (PickOrdersWithType.OrderItemID = PickOrders.OrderItemID)) as B " +
				" where  ( B.Status !='Remove' ) and ( B.PickType ='"+ type +"' )"+
				" order by DropNumber asc";
		
		
//		String sql = "select * from" +
//				"(select " +
//				" PickOrdersWithType.OrderRef, " +
//				" PickOrdersWithType.OrderItemID, " +
//				" PickOrdersWithType.ProductName, " +
//				" PickOrdersWithType.ProductOption, " +
//				" PickOrdersWithType.DropNumber, " +
//				" PickOrdersWithType.PickType, " +
//				" PickOrdersWithType.SpecialInstructions, " +
//				" PickOrders.Status " +
//				" from  PickOrdersWithType   LEFT OUTER JOIN PickOrders " +
//				" on (PickOrdersWithType.OrderItemID = PickOrders.OrderItemID)) as B " +
//				" where  ( B.Status ='None' ) and ( B.PickType ='"+ type +"' )"+
//				" order by DropNumber asc";
		
//		String selectSQL = "SELECT DISTINCT " 
//		+ COLUMN1_ORDER_REF + ", " 
//		+ COLUMN2_ORDER_ITEM_ID + ", "
//		+ COLUMN9_PRODUCT_NAME + ", " 
//		+ COLUMN10_PRODUCT_OPTION + ", " 
//		+ COLUMN11_DROP_NUMBER 
//		+ " FROM " + TABLE_PARTS_WITH_TYPE
//		+ " WHERE " + COLUMN8_PICK_TYPE_ID + " = " + type_id + " ORDER BY " + COLUMN11_DROP_NUMBER + " ASC ";
				
		
		SQLiteDatabase db = dataBase.getReadableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		cursor.moveToFirst();
		if (cursor.getCount() > 0) {
			cursor.moveToFirst();
			do {
				PickOrderType  orderType = new  PickOrderType();
				orderType.setOrderRef(cursor.getString(cursor.getColumnIndex("OrderRef")));
				orderType.setOrderItemID(cursor.getInt(cursor.getColumnIndex("OrderItemID")));
				orderType.setProductName(cursor.getString(cursor.getColumnIndex("ProductName")));
				orderType.setProductOption(cursor.getString(cursor.getColumnIndex("ProductOption")));
				orderType.setDropNumber(cursor.getInt(cursor.getColumnIndex("DropNumber")));
				orderType.setPickType(cursor.getString(cursor.getColumnIndex("PickType")));
				orderType.setSpecialInstructions(cursor.getString(cursor.getColumnIndex("SpecialInstructions")));
				list.add(orderType);
				
			} while (cursor.moveToNext());
		}
		cursor.close();
		db.close();
		return list;
	}
}
