package vcn.kybotech.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;
import android.content.Context;

public class TransferStockControl {
	private JSONParser jsonParser;
	private int userid;
	private String username;
	
	public TransferStockControl(Context context){
		jsonParser = new JSONParser();
		FileSave file = new FileSave(context, Constants.GET);
		userid = file.getPickerID();
		username = file.getPickerName();
		if(!file.getName().equals("")){
			username = username + " - " + file.getName();
		}
	}
	
	public JSONObject uploadTransferStock(int partid, String reason, int warehouseidFrom, int warehouseidTo, String quantity){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "transfer"));
		params.add(new BasicNameValuePair("PartID", String.valueOf(partid)));
		params.add(new BasicNameValuePair("Reason", reason));
		params.add(new BasicNameValuePair("FromWarehouseID", String.valueOf(warehouseidFrom)));
		params.add(new BasicNameValuePair("ToWarehouseID", String.valueOf(warehouseidTo)));
		params.add(new BasicNameValuePair("UserID", String.valueOf(userid)));
		params.add(new BasicNameValuePair("Quantity", quantity));
		params.add(new BasicNameValuePair("UserName", username));
		params.add(new BasicNameValuePair("appname", "Load Mobile New"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.link, params);
		return objJSON;
	}
}
