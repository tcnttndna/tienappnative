package vcn.kybotech.model;

public class SiteItem {
	private int WarehouseID;
	private String SiteName;
	public SiteItem() {
		super();
	}
	public SiteItem(int warehouseID, String siteName) {
		super();
		WarehouseID = warehouseID;
		SiteName = siteName;
	}
	public int getWarehouseID() {
		return WarehouseID;
	}
	public void setWarehouseID(int warehouseID) {
		WarehouseID = warehouseID;
	}
	public String getSiteName() {
		return SiteName;
	}
	public void setSiteName(String siteName) {
		SiteName = siteName;
	}
}
