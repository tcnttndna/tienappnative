package vcn.kybotech.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;

import vcn.kybotech.constants.Constants;
import vcn.kybotech.pickingapp.R;

public class PickingLoadEmptyFragment extends android.app.Fragment{

	
	String LoadID;
	TextView messageNotFoundOrder;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_picking_load_empty,container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
		
		messageNotFoundOrder = (TextView)rootView.findViewById(R.id.fragment_picking_load_completion_loadassigned_id);
		return rootView;
	}
	
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		LoadID = getArguments().getString(Constants.key_bundle_loadid);
		messageNotFoundOrder.setText(LoadID);
	}
	
}
