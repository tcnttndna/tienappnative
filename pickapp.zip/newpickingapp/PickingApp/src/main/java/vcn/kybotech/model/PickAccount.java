package vcn.kybotech.model;

public class PickAccount {

    private String pName;
    private int pId;
    private boolean isAdmin;
    private int wareHouseId;
    private boolean isQA;
    private boolean isAgency;
    private String canQC;

    public PickAccount() {
        super();
    }

    public PickAccount(String pName, int pId, boolean isAdmin, int wareHouseId,
                       boolean isQA, String canQC) {
        super();
        this.pName = pName;
        this.pId = pId;
        this.isAdmin = isAdmin;
        this.wareHouseId = wareHouseId;
        this.isQA = isQA;
        this.canQC = canQC;
    }

    public String isCanQC() {
        return canQC;
    }

    public void setCanQC(String canQC) {
        this.canQC = canQC;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getpId() {
        return pId;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public int getWareHouseId() {
        return wareHouseId;
    }

    public void setWareHouseId(int wareHouseId) {
        this.wareHouseId = wareHouseId;
    }

    public boolean isQA() {
        return isQA;
    }

    public void setQA(boolean isQA) {
        this.isQA = isQA;
    }

    public boolean isAgency() {
        return isAgency;
    }

    public void setAgency(boolean isAgency) {
        this.isAgency = isAgency;
    }
}
