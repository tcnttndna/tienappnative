package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.PickLoad;
import vcn.kybotech.model.PickOrder;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickLoads;
import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
@SuppressLint("SimpleDateFormat") 
public class OrderInPreviewAdapter extends ArrayAdapter<PickOrder> {
	private Context context;
	private int	ResID;
	List<PickOrder> listLoadAssigned;
	private String dropnumber = "";
	private String StrLoadID;
	private PickLoad pickLoadAssigned;
	public OrderInPreviewAdapter(Context context, int resource, List<PickOrder> objects, String StrLoadID) {
		super(context, resource, objects);
		this.context = context;
		this.ResID = resource;
		this.listLoadAssigned = objects;
		this.StrLoadID = StrLoadID;
		HamKhoiTao();
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		OrderHolder orderHolder;
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			orderHolder = new OrderHolder();
			convertView = inflater.inflate(this.ResID, parent, false);
			
			orderHolder.header = (LinearLayout)convertView.findViewById(R.id.info_load_in_preview);
			orderHolder.second = (LinearLayout)convertView.findViewById(R.id.info_message_in_preview);
			orderHolder.InforOrder = (TextView) convertView.findViewById(R.id.info_item_order_in_preview);
			orderHolder.ProductSubOptions = (TextView) convertView.findViewById(R.id.product_sub_options_in_preview);
			orderHolder.LoadID = (TextView)convertView.findViewById(R.id.fragment_preview_load_id);
			orderHolder.DropNumber = (TextView)convertView.findViewById(R.id.fragment_preview_drop_number);
			orderHolder.DateTime = (TextView)convertView.findViewById(R.id.fragment_preview_date_time);
			orderHolder.Driver = (TextView)convertView.findViewById(R.id.fragment_preview_driver);
			orderHolder.Weight = (TextView)convertView.findViewById(R.id.fragment_preview_weight);
			
			convertView.setTag(orderHolder);
		}else {
			orderHolder = (OrderHolder) convertView.getTag();
		}
		
		if (position == 0) {
			orderHolder.header.setVisibility(View.VISIBLE);
			orderHolder.second.setVisibility(View.GONE);
			
			orderHolder.LoadID.setText(StrLoadID);
			orderHolder.DropNumber.setText(dropnumber.substring(0, dropnumber.length()-2));
			orderHolder.DateTime.setText(pickLoadAssigned.getCreatedDate()); 
			orderHolder.Driver.setText(pickLoadAssigned.getDriverName());
			orderHolder.Weight.setText(String.valueOf(pickLoadAssigned.getWeight())); 
			
		}else {
			orderHolder.header.setVisibility(View.GONE);
			orderHolder.second.setVisibility(View.VISIBLE);
			
			PickOrder pickOrder = listLoadAssigned.get(position);
			String inforOrder = "<font color=\"#000000\">" + pickOrder.getDropNumber()+ "</font>. <font color=\"#46609C\">" + pickOrder.getProductName()+ " - QTY: " + pickOrder.getQuantity() + "</font>";
			String jsonObject = pickOrder.getProductSubOptions();
			String productSubOptions = "";
			if(!jsonObject.equals("null")){
				productSubOptions = "-> " + jsonObject.replace("null", "").replace('[', ' ').replace(']', ' ').replace(",","\n\n-> ");
			}
			orderHolder.InforOrder.setText(Html.fromHtml(inforOrder));
			orderHolder.ProductSubOptions.setText(productSubOptions);
		}
		return convertView;
	}
	
	public static class OrderHolder{
		LinearLayout header;
		LinearLayout second;
		TextView InforOrder;
		TextView ProductSubOptions;
		TextView LoadID;
		TextView DropNumber;
		TextView DateTime;
		TextView LoadGeneratedBy;
		TextView Driver;
		TextView Weight;
	}
	
	private void HamKhoiTao(){
		//DUNG LIST DE DOC & GHEP DROP NUMBER
		for (int i = 1; i < this.listLoadAssigned.size(); i++) {
			dropnumber += this.listLoadAssigned.get(i).getDropNumber()+ ", ";
		}
		//===================================
		sql_PickLoads loadAssigneds = new sql_PickLoads(this.context);
		//LAY RA THONG TIN LOAD
		pickLoadAssigned = loadAssigneds.getLoadWhereID(String.valueOf(StrLoadID));
	}
}
