package vcn.kybotech.fragment;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.adapter.SipnnerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.constants.ScalingUtilities;
import vcn.kybotech.constants.ScalingUtilities.ScalingLogic;
import vcn.kybotech.controller.ImageControl;
import vcn.kybotech.controller.UnpackControl;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.Image;
import vcn.kybotech.model.PackDetails;
import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.model.Unpack;
import vcn.kybotech.model.WareHouseItem;
import vcn.kybotech.mycustom.DatePickerFragment;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.pickingapp.WarehouseAndSite;
import vcn.kybotech.sqlite.sql_Image;
import vcn.kybotech.sqlite.sql_Site;
import vcn.kybotech.sqlite.sql_WareHouse;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class UnpackFragment extends Fragment{
	private RadioGroup radioGroup;
	private EditText etSearch;
	private ImageButton btnSearch;
	private Button btnUnpack;
	private LinearLayout layoutLinnear;
	private ProgressBar proLoad;
	private String imagePath = "";
	private boolean checkResult = false;
	private GPSTracker gps;
	private double LAT;
	private double LNG;
	private int GRNItemID;
	private WebView wvShowView;
	private Unpack unpack;
	private int warehouseId;
	private int warehouseIdChiSo;
	private String site;
	public static String dateused;
	private Button btnSave;
	final Calendar c = Calendar.getInstance();
	private int year = c.get(Calendar.YEAR);
	private int month = c.get(Calendar.MONTH);
	private int day = c.get(Calendar.DAY_OF_MONTH);
	public UnpackFragment callHamTao() {
		UnpackFragment mFragment = new UnpackFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_unpack,
				container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT));
		sql_WareHouse sqlWareHouse = new sql_WareHouse(UnpackFragment.this.getActivity());
		sql_Site sqlSite = new sql_Site(UnpackFragment.this.getActivity());
		if(!sqlWareHouse.checkData() || sqlSite.checkData()){
			new WarehouseAndSite(UnpackFragment.this.getActivity()).execute();
		}
		HamKhoiTao(rootView);
		BatSuKien();
		return rootView;
	}

	public void HamKhoiTao(View v){
		radioGroup = (RadioGroup) v.findViewById(R.id.fragment_unpack_radioGroup);
		etSearch = (EditText) v.findViewById(R.id.fragment_unpack_et_search);
		btnSearch = (ImageButton) v.findViewById(R.id.fragment_unpack_btn_search);
		btnUnpack = (Button) v.findViewById(R.id.fragment_unpack_btn_unpack);
		layoutLinnear = (LinearLayout) v.findViewById(R.id.fragment_unpack_linnear_layout);
		proLoad = (ProgressBar) v.findViewById(R.id.fragment_unpack_progressbar_load);
		wvShowView = (WebView) v.findViewById(R.id.fragment_unpack_wv_show_view);
		gps = new GPSTracker(UnpackFragment.this.getActivity());
		if (gps.canGetLocation()) {
			LAT = gps.getLatitude();
			LNG = gps.getLongitude();
		}
		gps.stopUsingGPS();
	}

	public void BatSuKien(){
		btnSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(etSearch.getText().toString().trim().length() == 0){
					etSearch.requestFocus();
					OpenKeyBoard(UnpackFragment.this.getActivity());
				}else{
					searchUnpack();
					CloseKeyBoard(UnpackFragment.this.getActivity());
				}
			}
		});

		btnUnpack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				DialogUnpack();
			}
		});
	}

	public void searchUnpack() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				View radioButton = radioGroup.findViewById(radioGroup.getCheckedRadioButtonId());
				UnpackControl ctrUnpack = new UnpackControl(UnpackFragment.this.getActivity());
				String packId = etSearch.getText().toString().trim();
				objJSON = ctrUnpack.searchPack(radioGroup.indexOfChild(radioButton), packId);
				return objJSON;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS)
									.equals(Constants.KEY_TRUE)) {

								JSONObject obj = objJSON.getJSONObject("data");
								if(obj.getInt("PackID") == 0){
									Toast.makeText(getActivity(),
											"Invalid packid, please input packid correctly.",
											Toast.LENGTH_SHORT).show();
									etSearch.requestFocus();
									setNullUnpack();
									layoutLinnear.setVisibility(View.GONE);
									OpenKeyBoard(UnpackFragment.this.getActivity());
								}else{
									if(obj.getString("UnpackStatus").equals("Packed")){
										List<PackDetails> list = null;
										try {
											JSONArray arrPackDetails = objJSON.getJSONArray("packdetails");
											if(arrPackDetails.length() > 0){
												list = new ArrayList<PackDetails>();
												for (int i = 0; i < arrPackDetails.length(); i++) {
													JSONObject objPackDetails = arrPackDetails.getJSONObject(i);
													PackDetails packDetails = new PackDetails(
															objPackDetails.getInt("PartID"),
															objPackDetails.getInt("Length"),
															objPackDetails.getInt("NumOfPieces"),
															objPackDetails.getString("DateCreated"),
															objPackDetails.getDouble("VolumeItem"));
													list.add(packDetails);
												}
											}
										} catch (JSONException e) {
											e.printStackTrace();
										}finally{
											unpack = new Unpack(
													obj.getInt("PackID"),
													obj.getInt("PartID"),
													obj.getInt("GRNID"),
													obj.getString("PartName"),
													obj.getDouble("Volume"),
													obj.getString("PackSupplierID"),
													obj.getInt("GRNItemID"),
													obj.getString("UnpackStatus"), list);
											GRNItemID = obj.getInt("GRNItemID");
											showData(unpack);
											layoutLinnear.setVisibility(View.VISIBLE);
										}
									}else{
										if(obj.getString("UnpackStatus").equals("UnPacked")){
											Toast.makeText(UnpackFragment.this.getActivity(), "PackId "+ etSearch.getText().toString() +" have been unpack, please choose another packId", Toast.LENGTH_LONG).show();
											etSearch.requestFocus();
											etSearch.setText(null);
											setNullUnpack();
											layoutLinnear.setVisibility(View.GONE);
											OpenKeyBoard(UnpackFragment.this.getActivity());
										}
									}
								}
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS)
										.equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(),
											objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_SHORT).show();
									etSearch.requestFocus();
									setNullUnpack();
									layoutLinnear.setVisibility(View.GONE);
									OpenKeyBoard(UnpackFragment.this.getActivity());
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}
	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}

	public void DialogDisconnectToServer(){
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new  AlertDialog.Builder(UnpackFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {

				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void DialogUnpack(){
		try {
			final List<WareHouseItem> listWareHouse;

			final Dialog dialog = new Dialog(UnpackFragment.this.getActivity());
			dialog.setContentView(R.layout.dialog_unpack);
			dialog.setTitle(R.string.unpack_Use_Pack);

			Spinner spinWareHouse = (Spinner) dialog.findViewById(R.id.dialog_unpack_spin_warehouse);
			final Spinner spinSite = (Spinner) dialog.findViewById(R.id.dialog_unpack_spin_site);
			LinearLayout linearDateUsed = (LinearLayout) dialog.findViewById(R.id.dialog_unpack_linear_date_use);
			Button btnTakePhoto = (Button) dialog.findViewById(R.id.dialog_unpack_btn_take_photo);
			btnSave = (Button) dialog.findViewById(R.id.dialog_unpack_btn_save);
			final TextView tvDateUse = (TextView) dialog.findViewById(R.id.dialog_unpack_tv_date_use);
			tvDateUse.setText(day + "/" + (month + 1) + "/" + year);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			dateused = dateFormat.format(c.getTime());
			sql_WareHouse sqlWareHouse = new sql_WareHouse(UnpackFragment.this.getActivity());
			listWareHouse = sqlWareHouse.select();
			List<SpinnerItem> itemSpinnerWareHouse = new ArrayList<SpinnerItem>();
			for (int i = 0; i < listWareHouse.size(); i++) {
				itemSpinnerWareHouse.add(new SpinnerItem(listWareHouse.get(i).getWarehouseName()));
			}
			SipnnerAdapter adapter = new SipnnerAdapter(
					UnpackFragment.this.getActivity(), R.layout.dialog_unpack_custom_spinner,
					itemSpinnerWareHouse);
			spinWareHouse.setAdapter(adapter);

			/**
			 *  THAY ĐỔI(1): set mặc định spinner Warehouse là worksop
			 */
			for (int i = 0; i < itemSpinnerWareHouse.size();i++){
				if(itemSpinnerWareHouse.get(i).getSpinner().equalsIgnoreCase("Worksop")){
					spinWareHouse.setSelection(i);
					break;
				}
			}

			spinWareHouse.setOnItemSelectedListener(new OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
										   int arg2, long arg3) {
					warehouseIdChiSo = arg2;
					warehouseId = listWareHouse.get(arg2).getWarehouseID();
					List<SpinnerItem> itemSite = new ArrayList<SpinnerItem>();
					for (int i = 0; i < listWareHouse.get(arg2).getSite().size(); i++) {
						itemSite.add(new SpinnerItem(listWareHouse.get(arg2).getSite().get(i).getSiteName()));
					}
					SipnnerAdapter adapter = new SipnnerAdapter(
							UnpackFragment.this.getActivity(), R.layout.dialog_unpack_custom_spinner,
							itemSite);
					spinSite.setAdapter(adapter);

					/**
					 *  THAY ĐỔI(2): set mặc định spinner Site là Assembly
					 */
					for(int i = 0;i<itemSite.size();i++){
						if (itemSite.get(i).getSpinner().contains("Assembly")){
							spinSite.setSelection(i);
							break;
						}
					}

				}
				@Override
				public void onNothingSelected(AdapterView<?> arg0) {

				}
			});

			spinSite.setOnItemSelectedListener(new OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
										   int arg2, long arg3) {
					site = listWareHouse.get(warehouseIdChiSo).getSite().get(arg2).getSiteName();
				}
				@Override
				public void onNothingSelected(AdapterView<?> arg0) {

				}
			});
			linearDateUsed.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					DialogFragment newFragment = new DatePickerFragment(tvDateUse);
					newFragment.show(getFragmentManager(), "datePicker");
				}
			});

			btnTakePhoto.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if(tvDateUse.getText().toString().length() > 0){
						callTakePicture();
					}else{
						Toast.makeText(UnpackFragment.this.getActivity(), R.string.YouHaveNotSelectedDateused, Toast.LENGTH_LONG).show();
					}
				}
			});

			btnSave.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					confirmUnpack();
					dialog.dismiss();
				}
			});

			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void callTakePicture(){
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent.resolveActivity(UnpackFragment.this.getActivity().getPackageManager()) != null) {
			File photoFile = null;
			try {
				photoFile = createFileImage();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			if (photoFile != null) {
				takePictureIntent.putExtra("imagePath", imagePath);
				takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,	Uri.fromFile(photoFile));
				startActivityForResult(takePictureIntent, Constants.TAKE_UNPACK_PHOTO);
			}
		}
	}

	@SuppressLint("SimpleDateFormat")
	private File createFileImage() throws IOException {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
		String fileImagename = "Unpack_" + timeStamp;
		File StorageDir = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME), Constants.FOLDER_NAME_UNPACK);

		if (!StorageDir.exists()) {
			StorageDir.mkdirs();
		}
		File image = new File(StorageDir, fileImagename + ".png");

		imagePath = image.getAbsolutePath();
		return image;
	}

	private boolean compressImage(String path, int width, int height) {
		boolean isCompress = false;
		Bitmap scaledBitmap = null;
		try {
			Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, width, height, ScalingLogic.FIT);
			scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap, width, height, ScalingLogic.FIT);
			FileOutputStream fos = null;
			try {
				File fichero = new File(imagePath);
				if (fichero.canWrite()) {
					fichero.createNewFile();
					fos = new FileOutputStream(fichero);
					isCompress =  scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, fos);
					fos.flush();
					fos.close();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			scaledBitmap.recycle();
		} catch (Throwable e) {
		}
		return isCompress;
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == Activity.RESULT_OK){
			switch (requestCode) {
				case Constants.TAKE_UNPACK_PHOTO:
					compressImage(imagePath, 800, 1400);
					checkResult = true;
					break;
				default:
					break;
			}
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		if (checkResult) {
			callUploadImage(imagePath);
		}
		checkResult = false;
	}

	private void callUploadImage(String path){
		Image obj = new Image();
		FileSave file = new FileSave(UnpackFragment.this.getActivity(), Constants.GET);
		obj.setImageType(Constants.TYPE_UNPACK_PHOTO);
		obj.setPickerId(file.getPickerID());
		obj.setPickerName(file.getPickerName());
		obj.setPackId(unpack.getPackId());
		obj.setPartId(unpack.getPartId());
		obj.setImageData(path);

		UploadImage(obj);
	}

	public void UploadImage(final Image image){
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;
			BufferedInputStream buffInputStream = null;
			File file;
			String path;
			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) UnpackFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
				try {
					/**MA HOA ANH*/
					byte byteAnh[] = null;
					path = image.getImageData();
					file = new File(path);
					FileInputStream inputStream = new FileInputStream(path);
					buffInputStream = new BufferedInputStream(inputStream);
					byteAnh = new byte[buffInputStream.available()];
					buffInputStream.read(byteAnh);
					String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
					image.setImageData(encodedString);

					/**GUI ANH VUA MA HOA LEN SERVICE*/
					ImageControl ctrImage = new ImageControl(UnpackFragment.this.getActivity());
					objJSON = ctrImage.uploadUnpackImage(image);
					return objJSON;
				} catch (Exception e) {
					return null;
				}
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals("true")) {
								buffInputStream.close();
								if(file.delete()){
									System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
								}
								btnSave.setVisibility(View.VISIBLE);
							}else{
								if (objJSON.getString(Constants.KEY_SUCCESS).equals("false")) {
//									Toast.makeText(UnpackFragment.this.getActivity(), Constants.ERR_SERVICE_NETWORK, Toast.LENGTH_LONG).show();
									DialogDisconnectToServer(image, path);
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
//					Toast.makeText(UnpackFragment.this.getActivity(), Constants.ERR_SERVICE_NETWORK, Toast.LENGTH_LONG).show();
					DialogDisconnectToServer(image, path);
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void confirmUnpack() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}
			@Override
			protected JSONObject doInBackground(String... params) {
//				ConnectivityManager cm = (ConnectivityManager) UnpackFragment.this.getActivity().
//						getSystemService(Context.CONNECTIVITY_SERVICE);
//				NetworkInfo netInfo = cm.getActiveNetworkInfo();
//				if (netInfo != null && netInfo.isConnected()) {
//					try {
//						URL url = new URL(Constants.GOOGLE_LINK);
//						HttpURLConnection httpUrlConn = (HttpURLConnection) url
//								.openConnection();
//						httpUrlConn.setConnectTimeout(Constants.TIME_OUT * 1000);
//						httpUrlConn.connect();
//						if (httpUrlConn.getResponseCode() == 200) {
				try {
					UnpackControl ctrUnpack = new UnpackControl(UnpackFragment.this.getActivity());
					int packId = unpack.getPackId();
					int partId = unpack.getPartId();
					objJSON = ctrUnpack.confirmUnpack(LAT, LNG, packId, partId, GRNItemID, warehouseId, site, dateused);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return objJSON;
//						}
//					} catch (MalformedURLException e) {
//						e.printStackTrace();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				return null;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS)
									.equals(Constants.KEY_TRUE)) {
								Toast.makeText(UnpackFragment.this.getActivity(), "PackID "+ String.valueOf(unpack.getPackId()) +" unpack success", Toast.LENGTH_LONG).show();
								setNullUnpack();
								etSearch.setText(null);
								etSearch.requestFocus();
								OpenKeyBoard(UnpackFragment.this.getActivity());
								layoutLinnear.setVisibility(View.GONE);
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS)
										.equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(),
											objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_SHORT).show();
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void showData(Unpack unpack){
		String test = null;
		if(unpack.getPackdetails() != null){
			test =
					"<head>" +
							"<style>" +
							"table, th, td {" +
							"border: 1px solid black;" +
							"border-collapse: collapse;" +
							"border-color:#46609C" +
							"}" +
							"th {" +
							"padding: 5px;" +
							"text-align: left;  " +
							"color:#46609C  " +
							"}" +
							"td{" +
							"padding: 5px;" +
							"text-align: center;" +
							"}" +
							"</style>" +
							"</head>" +
							"<body>" +

							"<table style=\"width:100%\">" +
							"<tr bgcolor=\"#DDDDDD\">" +
							"<th colspan=\"3\">Kybo PackId</th>" +
							"<th colspan=\"3\">Supplier PackId</th>" +
							"</tr>" +
							"<tr bgcolor=\"#DDDDDD\">" +
							"<td colspan=\"3\">"+ unpack.getPackId() +"</td>" +
							"<td colspan=\"3\">"+ unpack.getPackSupplierId() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th colspan=\"3\">PartId</th>" +
							"<td colspan=\"3\">"+ unpack.getPartId() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th colspan=\"3\">PartName</th>" +
							"<td colspan=\"3\">"+ unpack.getPartName() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th colspan=\"3\">Total Volume</th>" +
							"<td colspan=\"3\">"+ unpack.getVolume() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th colspan=\"6\">Pack Details</th>" +
							"</tr>" +
							"<tr>" +
							"<td colspan=\"2\">Length</td>" +
							"<td colspan=\"2\">NumOfPiece</td>" +
							"<td colspan=\"2\">VolumeItem</td>" +
							"</tr>";
			for (int i = 0; i < unpack.getPackdetails().size(); i++) {
				test = test +
						"<tr>" +
						"<td colspan=\"2\">"+ unpack.getPackdetails().get(i).getLength() +"</td>" +
						"<td colspan=\"2\">"+ unpack.getPackdetails().get(i).getNumOfPieces() +"</td>" +
						"<td colspan=\"2\">"+ unpack.getPackdetails().get(i).getVolumeItem() +"</td>" +
						"</tr>";
			}
			test = test +
					"</table>"+
					"</body>";
		}else{
			test =
					"<head>" +
							"<style>" +
							"table, th, td {" +
							"border: 1px solid black;" +
							"border-collapse: collapse;" +
							"border-color:#46609C" +
							"}" +
							"th {" +
							"padding: 5px;" +
							"text-align: left;  " +
							"color:#46609C  " +
							"}" +
							"td{" +
							"padding: 5px;" +
							"text-align: center;" +
							"}" +
							"</style>" +
							"</head>" +
							"<body>" +

							"<table style=\"width:100%\">" +
							"<tr bgcolor=\"#DDDDDD\">" +
							"<th>Kybotech PackId</th>" +
							"<th>Supplier PackId</th>" +
							"</tr>" +
							"<tr bgcolor=\"#DDDDDD\">" +
							"<td>"+ unpack.getPackId() +"</td>" +
							"<td>"+ unpack.getPackSupplierId() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th>PartId</th>" +
							"<td>"+ unpack.getPartId() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th>PartName</th>" +
							"<td>"+ unpack.getPartName() +"</td>" +
							"</tr>" +
							"<tr>" +
							"<th>Total Volume</th>" +
							"<td>"+ unpack.getVolume() +"</td>" +
							"</tr>" +
							"</table>"+
							"</body>";
		}
		String mime = "text/html";
		String encoding = "utf-8";
		wvShowView.loadDataWithBaseURL(null, test, mime, encoding, null);
	}

	public void setNullUnpack(){
		try {
			unpack = new Unpack(0, 0, 0, null, 0.0, null, 0, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void DialogDisconnectToServer(final Image image, final String path){
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new  AlertDialog.Builder(UnpackFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.UpImage_Message_no_response_form_server));
			//NEU OK SE LUU ANH DE UPLOAD SAU
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					sql_Image sqlImage = new sql_Image(UnpackFragment.this.getActivity());
					image.setImageData(path);
					sqlImage.insert(image);
					btnSave.setVisibility(View.VISIBLE);
				}
			});
			//NEU CANCEL SE XOA ANH TRONG SD CARD
			dialog.setNegativeButton("Cancel", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					File file = new File(path);
					if(file.delete()){
						System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
					}
				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
