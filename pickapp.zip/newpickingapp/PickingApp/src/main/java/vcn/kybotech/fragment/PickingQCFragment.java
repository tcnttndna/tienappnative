package vcn.kybotech.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vcn.kybotech.activity.PickingNormalUploadImagesActivity;
import vcn.kybotech.adapter.QCPartsPickerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickOrder;
import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.MainActivity;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickOrders;
import vcn.kybotech.sqlite.sql_PickParts;

@SuppressLint({"CutPasteId", "InflateParams"})
public class PickingQCFragment extends android.app.Fragment {

    public GPSTracker gpsTracker;
    private FileSave fileSave;
    private TextView OrdersDropNumber;
    private TextView OrderRef;
    private TextView TvOrderItemID;
    private TextView ProductName;
    private TextView TvLoadID;
    private TextView txtAllOrders_QCConfirmed;
    private ListView lvPartsInOrder;
    private RelativeLayout relative_qrcode;
    private LinearLayout layout_clear_skip;
    private LinearLayout layout_info_orderef;
    private QCPartsPickerAdapter adapter;
    private String LoadID;
    private String LoadCode;
    public static EditText textScanBarcode;
    private List<PickOrder> listOrder;
    private List<PickPart> listPart;
    private Button btnSkip;
    //    private Button btnSkipQC;
//    private Button btnConfirmQC;
    private Button btnConfirm;
    private Button btnClear;
    private Button btnGTIN;
    private ImageButton btnScanBarcode;
    private ImageButton btnSelecImageUpload;
    private ImageButton btnSpecialInstructions;
    private int iOrders;
    private ImageView logoTesCo;
    public static int countImageUpLoaded;
    private CommunicatingFragments communicatingFragments;
    RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
    private final static String Tag = "RequesConfirm";
    int intOrdersItemID;
    int intOrdersID;
    String strOrdersDropNumber;
    String strOrderRef;
    String strProductName;
    String strSpecialInstructions;
    private Button btnRemoveOderItem;
    public static Boolean IsManuallyScan = true;
    GestureDetector gestureDetector;
    View.OnTouchListener gestureListener;
    private static final int SWIPE_MIN_DISTANCE = 120;
    private static final int SWIPE_MAX_OFF_PATH = 250;
    private static final int SWIPE_THRESHOLD_VELOCITY = 100;

    @Override
    public void onAttach(Activity activity) {
        // TODO Auto-generated method stub
        super.onAttach(activity);
        try {
            communicatingFragments = (CommunicatingFragments) getActivity();
        } catch (Exception e) {
            throw new ClassCastException(activity.toString() + " must implement CommunicatingFragments");
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_picking_load_qc, container, false);
        rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

		/* Phan dang ky findViewByID */
        // layoutFrame =
        // (RelativeLayout)rootView.findViewById(R.id.fragment_picking_load_accept_xml);
        // layoutFrame.setOnClickListener(null);
        relative_qrcode = (RelativeLayout) rootView.findViewById(R.id.relative_qrcode);
        layout_clear_skip = (LinearLayout) rootView.findViewById(R.id.layout_clear_skip);
        layout_info_orderef = (LinearLayout) rootView.findViewById(R.id.layout_info_orderef);

        logoTesCo = (ImageView) rootView.findViewById(R.id.logoTesCo);
        // relative_NotFoundOrder =
        // (RelativeLayout)rootView.findViewById(R.id.relative_NotFoundOrder);
        OrdersDropNumber = (TextView) rootView.findViewById(R.id.tvOrdersDropNumber);
        txtAllOrders_QCConfirmed = (TextView) rootView.findViewById(R.id.txtAllOrders_QCConfirmed);
        TvOrderItemID = (TextView) rootView.findViewById(R.id.load_accept_OrderItemID);
        OrderRef = (TextView) rootView.findViewById(R.id.load_accept_OrderRef);
        ProductName = (TextView) rootView.findViewById(R.id.productname);
        lvPartsInOrder = (ListView) rootView.findViewById(R.id.lvPartsInOrder_FragmentPickingLoadAccept);
        textScanBarcode = (EditText) rootView.findViewById(R.id.textScanBarcode);
        TvLoadID = (TextView) rootView.findViewById(R.id.load_accept_LoadID);
        btnConfirm = (Button) rootView.findViewById(R.id.btnConfirm);
//        btnConfirmQC = (Button) rootView.findViewById(R.id.btnConfirmQC);
        btnSkip = (Button) rootView.findViewById(R.id.btnSkip);
//        btnSkipQC = (Button) rootView.findViewById(R.id.btnSkipQC);
        btnClear = (Button) rootView.findViewById(R.id.btnClearScan);
        btnGTIN = (Button) rootView.findViewById(R.id.btnGTIN);
        btnScanBarcode = (ImageButton) rootView.findViewById(R.id.btnBarcode);
        btnSelecImageUpload = (ImageButton) rootView.findViewById(R.id.btnSelectImageUpload);
        btnSpecialInstructions = (ImageButton) rootView.findViewById(R.id.note);
        btnRemoveOderItem = (Button) rootView.findViewById(R.id.btnRemoveOderItem);

        gestureDetector = new GestureDetector(new MyGestureDetector());
        gestureListener = new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            public boolean onTouch(View v, MotionEvent event) {
                gestureDetector.onTouchEvent(event);
                return false;
            }
        };

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
        try {
            this.LoadID = getArguments().getString(Constants.key_bundle_loadid);
            this.LoadCode = getArguments().getString(Constants.key_bundle_loadcode);
            countImageUpLoaded = 0;
            iOrders = 0;

            requestQueue = Volley.newRequestQueue(getActivity());

            gpsTracker = new GPSTracker(getActivity());
            // file = getActivity().getSharedPreferences(Constants.TEMP_PICKING_APP,
            // 0);
            fileSave = new FileSave(getActivity(), Constants.GET);

            sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
        /* Lay ra danh sach Order Chua Picked trong mot Load de lam viec */
            listOrder = sqlOrders.getListOrdersQC();
//        listOrder = sqlOrders.getListOrdersAccept(LoadID);
//            listOrder = sqlOrders.getListOrdersLoading(LoadID);
//            listOrder = sqlOrders.getListOrdersToQC(LoadID);
        /* Phan xu ly sau khi findViewByID */
            if (listOrder.size() > 0) {
                onProgressEvent(iOrders);
            } else {
                relative_qrcode.setVisibility(View.GONE);
                layout_clear_skip.setVisibility(View.GONE);
                layout_info_orderef.setVisibility(View.GONE);
                txtAllOrders_QCConfirmed.setVisibility(View.VISIBLE);
            }
            onClickButton();
//            onClickQC();
        } catch (Exception ex) {
            Log.d("Passing data QC", ex.getMessage());
        }


    }

    @Override
    public void onResume() {
        super.onResume();
        //focus on textScanBarcode
        textScanBarcode.requestFocus();
    }



    public void onContinueProcessScanPart(boolean checkExists, boolean isScanned, String s, String QR, final sql_PickParts sqlParts) {

        String PartID_Or_BarCode = "PartID: ";
        if (QR.equalsIgnoreCase("GTIN")) {
            PartID_Or_BarCode = "BarCode: ";
        }

        if (checkExists) {
            if (isScanned) {

                textScanBarcode.setText(null);

						/* Thong bao da scanned */
                Builder dialog = new Builder(getActivity());
                dialog.setTitle("Notification").setMessage(PartID_Or_BarCode + s.toString() + " scanned full")
                        .setPositiveButton("OK", null).show();
            } else {
                        /* Bat dau scan */
                PickPart pickPart = null;
                        /*
                         * pickPart khong the null vi ham o tren goi ham nay ra
						 * da check exists va iscan
						 */
                if (QR.equalsIgnoreCase("QR") || QR.equalsIgnoreCase("SWIPE")) {
                    pickPart = sqlParts.getPickPartNotScannedQC(String.valueOf(intOrdersItemID), s.toString());
                } else {
                    pickPart = sqlParts.getPickPartWhereBarCodeQC(String.valueOf(intOrdersItemID),
                            s.toString());
                }

                final int id = pickPart.getId();
                final int part_id = pickPart.getPartID();
                final int part_qty = pickPart.getQuantity();
                final String part_location = pickPart.getLocationName();
                final String part_name = pickPart.getPartName();
                final String order_ref = pickPart.getOrderRef();
                final int order_item_id = pickPart.getOrderItemID();
                final String lat = String.valueOf(gpsTracker.getLatitude());
                final String lng = String.valueOf(gpsTracker.getLongitude());
                // FileSave fileSave = new FileSave(getActivity(),
                // Constants.GET);
                // final int picker_id = fileSave.getPickerID();
                // final String picker_name = fileSave.getPickerName();

                if (sqlParts.checkSwipeConfirmQC(String.valueOf(intOrdersItemID),
                        String.valueOf(pickPart.getPartID()), pickPart.getId())) {
                    // Toast.makeText(getActivity(), "Cho nay can gui
                    // Log confirm part len ",
                    // Toast.LENGTH_SHORT).show();

                    final ProgressDialog progressDialog;
                    progressDialog = new ProgressDialog(getActivity());
                    progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                    progressDialog.setCancelable(false);
                    progressDialog.show();

                    Response.Listener<String> listener = new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONObject jsonObject = new JSONObject(response.toString());
                                if (jsonObject.getBoolean("success")) {
                                    // Check xem part nay co bat buoc
                                    // scan = camera hay ko
                                    if (jsonObject.getBoolean("needscan") && IsManuallyScan) {
                                        Builder dialog = new Builder(getActivity());
                                        dialog.setTitle("Notification")
                                                .setMessage(
                                                        "This part need scan by application, you can't manully input to scan this part.")
                                                .setPositiveButton("OK", null).show();
                                    } else {
//												/*
//												 * confirm len service truoc,
//												 * neu confirm thanh cong moi
//												 * cho ++swipe scan
//												 */
                                        textScanBarcode.setText(null);
                                        sqlParts.updateSwipeQC(intOrdersItemID, part_id, id);
                                        updateListView(String.valueOf(intOrdersItemID));
                                        updateButtonShowHide(String.valueOf(intOrdersItemID));
                                    }
                                } else {
                                    Toast.makeText(getActivity(), "success: false, Server is problem!",
                                            Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                DialogServerProblem();
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }

                            if (progressDialog != null) {
                                progressDialog.dismiss();
                            }
                            if (textScanBarcode != null) {
                                textScanBarcode.setText(null);
                            }

                        }

                    };

                    Response.ErrorListener errorListener = new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError volleyError) {
                            if (progressDialog != null) {
                                progressDialog.dismiss();
                            }
                            if (textScanBarcode != null) {
                                textScanBarcode.setText(null);
                            }
                            Toast.makeText(getActivity(), "Connection to your server disconnected!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    };

                    StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                            listener, errorListener) {
                        @Override
                        protected Map<String, String> getParams() {

                            Map<String, String> params = onCreateParams();

                            return params;
                        }

                        private Map<String, String> onCreateParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            String date = "";
                            String version = "";
                            SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                            try {
                                date = formatngay.format(new Date());
                                version = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE
                                        + " | " + getActivity().getPackageManager()
                                        .getPackageInfo(getActivity().getPackageName(), 0).versionCode;

                                Log.e("reques ConfirmOrderItem", "Toa Do: " + lat + " ; " + lng);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            params.put("type", "scanpart");
                            params.put("loadid", LoadID);

                            params.put("orderref", order_ref);
                            params.put("orderitemid", String.valueOf(order_item_id));
                            params.put("partid", String.valueOf(part_id));

                            params.put("partname", part_name);
                            params.put("qty", String.valueOf(part_qty));

                            params.put("locationname", part_location);
                            params.put("pickerid", String.valueOf(fileSave.getPickerID()));
                            params.put("pickername", fileSave.getPickerName());
                            params.put("isscanned", String.valueOf(true));

                            params.put("typepick", String.valueOf(Constants.type_pick_qc));

                            params.put("InApp", "NewPickingApp");
                            params.put("lat", lat);
                            params.put("lng", lng);
                            params.put("version", version);
                            params.put("phonedate", date);

                            return params;
                        }
                    };

                    // RequestQueue requestQueue =
                    // Volley.newRequestQueue(getActivity());
                    postRequest.setTag(Tag);
                    postRequest.setShouldCache(false);
                    requestQueue.add(postRequest);

                } else {

                    if (textScanBarcode != null) {
                        textScanBarcode.setText(null);
                    }
                    sqlParts.updateSwipeQC(intOrdersItemID, part_id, id);
                    updateListView(String.valueOf(intOrdersItemID));
                    updateButtonShowHide(String.valueOf(intOrdersItemID));
                }
            }

        } else {
            textScanBarcode.setText(null);

					/* Thong bao da scanned */
            Builder dialog = new Builder(getActivity());
            dialog.setTitle("Notification")
                    .setMessage(PartID_Or_BarCode + s.toString() + " you have entered is invalid")
                    .setPositiveButton("OK", null).show();
        }
        //focus on textScanBarcode
        textScanBarcode.requestFocus();
    }

    /* Tạm thời bỏ đoạn event (6/9/2017) */
    private void onClickButton() {

        btnRemoveOderItem.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                final Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.dialog_remove_order_item);

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(lp);
                // dialog.getWindow().setGravity(Gravity.TOP);
                final EditText edtPartId = (EditText) dialog.findViewById(R.id.removePartID);
                final TextView tvEnterText = (TextView) dialog.findViewById(R.id.tvEnterText);
                Button PositiveButton = (Button) dialog.findViewById(R.id.btnYes);
                Button NegativeButton = (Button) dialog.findViewById(R.id.btnNo);
                PositiveButton.setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        final String partID = edtPartId.getText().toString() + "";

                        if (partID.trim().length() > 0) {

                            final ProgressDialog progressDialog;
                            progressDialog = new ProgressDialog(getActivity());
                            progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                            progressDialog.setCancelable(false);
                            progressDialog.show();

                            Response.Listener<String> listener = new Response.Listener<String>() {

                                @Override
                                public void onResponse(String response) {
                                    try {

                                        JSONObject jsonObject = new JSONObject(response);
                                        if (jsonObject.getBoolean("success")) {
                                            /* Xoa bo so anh da duoc upload */
                                            countImageUpLoaded = 0;
                                            /*
                                             * Thay doi trang thai cua Order sau
											 * do check xem all OrderItem da
											 * confirm het chua neu confirm het
											 * thi bay sang giao dien Confirm
											 * Load
											 */
                                            /* OrderItem vua remove */
                                            sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                                            sqlOrders.updateRemoveOrderItem(String.valueOf(intOrdersItemID));
                                            if (listOrder != null && listOrder.size() > 0) {
                                                // int iOrders = flagOrders %
                                                // listOrder.size();
                                                listOrder.remove(iOrders);
                                                if (listOrder.size() == 0) {
                                                    android.app.Fragment fragment = getActivity().getFragmentManager()
                                                            .findFragmentById(R.id.container);
                                                    android.app.FragmentTransaction ft = getActivity().getFragmentManager()
                                                            .beginTransaction();
                                                    ft.remove(fragment);
                                                    ft.commit();
                                                    Log.e("remove", fragment.toString());
                                                    getActivity().getFragmentManager().popBackStack();
                                                    communicatingFragments.onNormalPickMoveConfirmLoad(LoadID);

                                                } else {

                                                    if (iOrders >= listOrder.size()) {
                                                        iOrders = 0;
                                                        onProgressEvent(iOrders);
                                                    } else {
                                                        onProgressEvent(iOrders);
                                                    }
                                                }
                                            }
                                        } else {

                                            Builder dialog = new Builder(getActivity());
                                            dialog.setTitle("Notification")
                                                    .setMessage("Error remove, server is problem! ")
                                                    .setPositiveButton("OK", null).show();
                                        }

                                    } catch (JSONException e) {
                                        DialogServerProblem();
                                        // Toast.makeText(getActivity(), "data:
                                        // false, server is problem!",
                                        // Toast.LENGTH_SHORT).show();
                                        e.printStackTrace();
                                    } catch (Exception e2) {

                                    }

                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                }

                            };

                            Response.ErrorListener errorListener = new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError arg0) {
                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                    Builder dialog = new Builder(getActivity());
                                    dialog.setTitle("Notification").setMessage("Connection to your server disconnected")
                                            .setPositiveButton("OK", null).show();
                                }
                            };

                            StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                                    listener, errorListener) {

                                @Override
                                protected Map<String, String> getParams() {
                                    String latitude = String.valueOf(gpsTracker.getLatitude());
                                    String longtitude = String.valueOf(gpsTracker.getLongitude());

                                    Map<String, String> params = new HashMap<String, String>();
                                    params = onCreateParams(latitude, longtitude);
                                    return params;
                                }

                                private Map<String, String> onCreateParams(String Lat, String Lng) {
                                    Map<String, String> params = new HashMap<String, String>();
                                    SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    Log.e("reques ConfirmOrderItem", "Toa Do: " + Lat + " ; " + Lng);
                                    String date = "";
                                    String version = "";

                                    try {
                                        date = formatngay.format(new Date());
                                        version = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE
                                                + " | " + getActivity().getPackageManager()
                                                .getPackageInfo(getActivity().getPackageName(), 0).versionCode;

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        // new
                                        // LogCrashActivity().inserException(e);
                                    }
                                    params.put("type", "newremoveitemorder");
                                    params.put("pickerid", String.valueOf(fileSave.getPickerID()));
                                    params.put("pickername", fileSave.getPickerName());
                                    params.put("orderid", String.valueOf(intOrdersID));
                                    params.put("orderitemid", String.valueOf(intOrdersItemID));
                                    params.put("loadid", LoadID);
                                    params.put("orderref", strOrderRef);
                                    params.put("partid", partID);

                                    params.put("lat", Lat);
                                    params.put("lng", Lng);
                                    params.put("version", version);
                                    params.put("phonedate", date);
                                    params.put("inapp", "NewPickingApp");

                                    return params;
                                }

                                ;
                            };

                            // RequestQueue requestQueue =
                            // Volley.newRequestQueue(getActivity());
                            postRequest.setTag(Tag);
                            postRequest.setShouldCache(false);
                            requestQueue.add(postRequest);

                            dialog.dismiss();
                        } else {
                            tvEnterText.setVisibility(View.VISIBLE);
                        }
                    }
                });

                NegativeButton.setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();

                    }
                });

                dialog.setCancelable(false);
                dialog.show();

            }
        });

        btnGTIN.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {
                    btnGTIN.setText("GTIN");
                } else {
                    btnGTIN.setText("QR");
                }

            }
        });

        final sql_PickParts sqlParts = new sql_PickParts(getActivity());

        textScanBarcode.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(final CharSequence sa, int start, int before, int count) {

                String scanText = textScanBarcode.getText().toString();
                sql_PickParts sqlParts = new sql_PickParts(getActivity());

                if (scanText.length() >= 1 && scanText.length() <= 3) {
                    Log.e("hehe", "scan text: " + scanText.length());
                    IsManuallyScan = true;
                }

                if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {

                    if (scanText.length() >= 5) {
                        try {
                            /*
                             * Check xem da scanned chua neu roi thi bao scanned
							 * full
							 */
                            boolean isScannedQC = sqlParts.checkPartScannedQC(intOrdersItemID,
                                    Integer.parseInt(scanText));
                            boolean checkExists = sqlParts.checkExistsData(String.valueOf(intOrdersItemID), scanText);

                            onContinueProcessScanPart(checkExists, isScannedQC, scanText, "QR", sqlParts);
                        } catch (NumberFormatException e) {
                            DialogInputPartIDInvalid();
                        }
                    }
                } else {
                    if (scanText.length() >= 13) {
                        /*
						 * Check xem da scanned chua neu roi thi bao scanned
						 * full
						 */
                        boolean isScanned = sqlParts.checkPartScannedWhereBarCodeQC(intOrdersItemID, scanText);
                        boolean checkExists = sqlParts.checkExistsBarCode(String.valueOf(intOrdersItemID), scanText);

                        onContinueProcessScanPart(checkExists, isScanned, scanText, "GTIN", sqlParts);
                    }
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        btnClear.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Builder dialog = new Builder(getActivity());
                dialog.setTitle(getResources().getString(R.string.fragment_accept_dialog_title));
                dialog.setMessage(getResources().getString(R.string.fragment_accept_dialog_message));
                dialog.setPositiveButton(R.string.fragment_accept_dialog_yes, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        onClearnPartInOrderItemQC(LoadID, String.valueOf(intOrdersItemID));
                        // onClearnPartInOrderItemQC(String.valueOf(intOrdersItemID));

                    }

                    private void onClearnPartInOrderItemQC(final String LoadId, final String OrderItemID) {

                        final ProgressDialog progressDialog;
                        progressDialog = new ProgressDialog(getActivity());
                        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                        progressDialog.setCancelable(false);
                        progressDialog.show();

                        Response.Listener<String> listener = new Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {

                                try {
                                    JSONObject jsonObject = new JSONObject(response.toString());
                                    if (jsonObject.getBoolean("success")) {
                                        try {
											/* Coi nhu chua upload anh */
                                            countImageUpLoaded = 0;
                                            sqlParts.clearScanQCPart(String.valueOf(OrderItemID));
                                            updateButtonShowHide(String.valueOf(OrderItemID));
                                            updateListView(String.valueOf(OrderItemID));
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    } else {
                                        Builder dialog = new Builder(getActivity());
                                        dialog.setTitle("Message")
                                                .setMessage("Clear scan Part fail. Server is problem!")
                                                .setPositiveButton("Cancel", null).show();
                                    }
                                } catch (JSONException e) {
                                    DialogServerProblem();
                                } catch (Exception e2) {
                                    e2.printStackTrace();
                                    Toast.makeText(getActivity(), "data:false\nServer is problem!", Toast.LENGTH_SHORT)
                                            .show();
                                }

                                if (progressDialog != null) {
                                    progressDialog.dismiss();
                                }
                            }

                        };

                        Response.ErrorListener errorListener = new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError volleyError) {
                                if (progressDialog != null) {
                                    progressDialog.dismiss();
                                }
                                Builder dialog = new Builder(getActivity());
                                dialog.setTitle("Message")
                                        .setMessage("Clear scan Part fail. Connect to server timeout!")
                                        .setPositiveButton("Cancel", null).show();
                            }
                        };

                        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                                listener, errorListener) {
                            @Override
                            protected Map<String, String> getParams() {
                                Map<String, String> params = new HashMap<String, String>();
                                params.put("type", "newclearpart");
                                params.put("loadid", LoadId);
                                params.put("typeclear", String.valueOf(Constants.type_pick_qc));
                                params.put("orderitemid", String.valueOf(OrderItemID));
                                return params;
                            }
                        };

                        // RequestQueue requestQueue =
                        // Volley.newRequestQueue(getActivity());
                        postRequest.setTag(Tag);
                        postRequest.setShouldCache(false);
                        requestQueue.add(postRequest);
                    }
                });

                dialog.setNegativeButton(R.string.fragment_accept_dialog_no, null);
                dialog.show();

            }
        });

        btnScanBarcode.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                ((MainActivity)getActivity()).onSCanBarCode(Constants.SCAN_PART_BY_QC);
                //focus on textScanBarcode
                textScanBarcode.requestFocus();
            }
        });

        btnSpecialInstructions.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                String message = strSpecialInstructions;
                if (strSpecialInstructions.equalsIgnoreCase("") || strSpecialInstructions.equalsIgnoreCase("null")) {
                    message = getString(R.string.fragment_accept_dialog_note_no_mesage);
                }
                Builder dialog = new Builder(getActivity());
                dialog.setTitle(R.string.fragment_accept_dialog_note_title).setMessage(message)
                        .setPositiveButton(R.string.fragment_accept_dialog_yes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                // TODO Auto-generated method stub

                            }
                        }).show();
            }
        });

        btnSkip.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                if (listOrder.size() > 1) {
					/* Xoa bo so anh da duoc upload */
                    countImageUpLoaded = 0;
                    ++iOrders;
                    if (iOrders >= listOrder.size()) {
                        iOrders = 0;
                        onProgressEvent(iOrders);
                    } else {
                        onProgressEvent(iOrders);
                    }
                } else {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                    dialog.setTitle("Message").setMessage("No skip, only one OrderItem in Load")
                            .setPositiveButton("OK", null).show();
                }

            }
        });

        btnConfirm.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                showDialogConfirm();
            }
        });


    }



    public void DialogServerProblem() {
        if (getActivity() == null) {
            return;
        }
        Builder dialog = new Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage("Server is problem");
        dialog.setPositiveButton("OK", null);
        dialog.show();
    }

    public void DialogInputPartIDInvalid() {
        if (getActivity() == null) {
            return;
        }
        Builder dialog = new Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage("Scan PartID invalid, PartID is format number 5 digit.");
        dialog.setPositiveButton("OK", null);
        dialog.show();
    }

    protected void showDialogConfirm() {
        Builder dialogRequesTakePhoto = new Builder(getActivity());
        dialogRequesTakePhoto.setTitle("Message").setMessage("You want to confirm OrderItem this?")
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        onProcessConfirm();
                    }
                }).setNegativeButton("Cancel", null).show();

    }


    protected void onProcessConfirm() {
        final PickOrder order = new PickOrder();
        order.setLoadID(Integer.parseInt(LoadID));
        order.setOrderRef(strOrderRef);
        order.setOrderID(intOrdersID);
        order.setOrderItemID(intOrdersItemID);

        final sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();
        try {
            Response.Listener<String> listener = new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    try {

                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            String s = jsonObject.getString("message");
                            if (s.equals("success")) {
                                if (sqlOrders.updateConfirmQCOrderItem(String.valueOf(intOrdersItemID)) > 0) {
                                    if (listOrder != null && listOrder.size() > 0) {
                                        listOrder.remove(iOrders);
                                        if (listOrder.size() == 0) {
                                        } else {
                                            if (iOrders >= listOrder.size()) {
                                                iOrders = 0;
                                                onProgressEvent(iOrders);
                                            } else {
                                                onProgressEvent(iOrders);
                                            }

                                        }
                                    }
                                    Toast.makeText(getActivity(), "OrderItemId: " + intOrdersItemID + " confirmed quality success", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), "Confirm error, server is problem!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        DialogServerProblem();
                        e.printStackTrace();
                    } catch (Exception e) {

                    }

                    if (progressDialog != null) {
                        progressDialog.dismiss();
                    }
                }

            };

            Response.ErrorListener errorListener = new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError arg0) {
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                    }
                    Toast.makeText(getActivity(), "Can not connect to server", Toast.LENGTH_SHORT).show();
                }
            };

            StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                    errorListener) {

                @Override
                protected Map<String, String> getParams() {

                    int countNotPicked = sqlOrders.getCountOrdersNotPicked(LoadID, String.valueOf(intOrdersID));
                    String latitude = String.valueOf(gpsTracker.getLatitude());
                    String longtitude = String.valueOf(gpsTracker.getLongitude());

                    Map<String, String> params = new HashMap<String, String>();

                    if (countNotPicked == 1) {
                    /* Confirm OrderItem cuoi cung trong OrderID */
                        params = onCreateParams("1", latitude, longtitude);
                    } else {
                    /* Khong phai Confirm OrderItem cuoi cung trong OrderID */
                        params = onCreateParams("0", latitude, longtitude);
                    }

                    return params;
                }

                private Map<String, String> onCreateParams(String isorderconfirmed, String Lat, String Lng) {
                    Map<String, String> params = new HashMap<String, String>();
                    SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                    String date = "";
                    String version = "";

                    try {
                        date = formatngay.format(new Date());
                        version = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE + " | " + getActivity()
                                .getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionCode;

                        Log.e("reques ConfirmOrderItem", "Toa Do: " + Lat + " ; " + Lng);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    params.put("type", "newconfirmorderqc");
                    params.put("pickerid", String.valueOf(fileSave.getPickerID()));
                    params.put("pickername", fileSave.getPickerName());
                    params.put("InApp", "NewPickingApp");
                    params.put("loadid", String.valueOf(order.getLoadID()));
                    params.put("orderref", order.getOrderRef());
                    params.put("orderitemid", String.valueOf(order.getOrderItemID()));
                    params.put("lat", Lat);
                    params.put("lng", Lng);
                    params.put("version", version);
                    params.put("phonedate", date);
                    params.put("isorderconfirmed", isorderconfirmed);
                    return params;
                }
            };

            postRequest.setTag(Tag);
            postRequest.setShouldCache(false);
            requestQueue.add(postRequest);
        } catch (Exception ex) {
            Log.d("Request Confirm QC", ex.getMessage());
        }
    }

    protected void showDialogRequesTakePhoto() {
        Builder dialogRequesTakePhoto = new Builder(getActivity());
        dialogRequesTakePhoto.setTitle("Message")
                .setMessage("Please take photo and select least 3 photos upload to confirm.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Take Photo", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        openTakePhoto();
                    }
                }).show();
    }

    private void onProgressEvent(int indexOrder) {

        intOrdersItemID = listOrder.get(indexOrder).getOrderItemID();
        intOrdersID = listOrder.get(indexOrder).getOrderID();
        strOrdersDropNumber = listOrder.get(indexOrder).getDropNumber() + "";
        strOrderRef = listOrder.get(indexOrder).getOrderRef();
        strProductName = listOrder.get(indexOrder).getProductName();
        strSpecialInstructions = "" + listOrder.get(indexOrder).getSpecialInstructions();// cong
        // chuoi
        // tranh
        // null;

        // final String strSpecialInstructions =
        // loadAssignAcceptanceJSONObj.getJSONArray("orders").getJSONObject(indexOrder).getString("SpecialInstructions");
        textScanBarcode.setText("");
        OrdersDropNumber.setText(strOrdersDropNumber);
        TvOrderItemID.setText(String.valueOf(intOrdersItemID));
        OrderRef.setText(strOrderRef);
        ProductName.setText(strProductName);
        TvLoadID.setText(LoadID);

        if (strOrderRef.indexOf("KTC") >= 0) {
            logoTesCo.setVisibility(View.VISIBLE);
        } else {
            logoTesCo.setVisibility(View.GONE);
        }


        final sql_PickParts sqlParts = new sql_PickParts(getActivity());
        listPart = sqlParts.getListParts(String.valueOf(intOrdersItemID));
        adapter = new QCPartsPickerAdapter(getActivity(), R.layout.item_part_swipe, listPart);
        lvPartsInOrder.setAdapter(adapter);

        lvPartsInOrder.setOnTouchListener(gestureListener);
        updateButtonShowHide(String.valueOf(intOrdersItemID));

    }

    protected void openTakePhoto() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(textScanBarcode.getWindowToken(), 0);

        Bundle bundle = new Bundle();

        bundle.putString("key_imagetype", Constants.image_QcOrderImage);
        bundle.putString("key_loadid", String.valueOf(listOrder.get(iOrders).getLoadID()));
        bundle.putString("key_loadcode", LoadCode);

        bundle.putString("key_pickerid", String.valueOf(fileSave.getPickerID()));
        bundle.putString("key_pickername", fileSave.getPickerName());
        // bundle.putString("key_imageurie", value);

        bundle.putString("key_orderid", String.valueOf(listOrder.get(iOrders).getOrderID()));
        bundle.putString("key_orderref", listOrder.get(iOrders).getOrderRef());
        bundle.putString("key_orderitemid", String.valueOf(listOrder.get(iOrders).getOrderItemID()));

        Intent intent = new Intent(getActivity(), PickingNormalUploadImagesActivity.class);
        intent.putExtra(Constants.key_bundle_upload_image, bundle);
        startActivityForResult(intent, Constants.REQUEST_NORMAL_UPLOAD_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.REQUEST_NORMAL_UPLOAD_IMAGE
                && resultCode == Constants.RESULT_NORMAL_UPLOAD_IMAGE) {
            showDialogConfirm();
        }
    }

    private void updateButtonShowHide(String OrderItemID) {
        sql_PickParts sqlParts = new sql_PickParts(getActivity());

        if (sqlParts.isAllPartScannedQC(OrderItemID)) {

            //showDialogRequesTakePhoto();

            btnConfirm.setVisibility(View.VISIBLE);
            btnSkip.setVisibility(View.GONE);
            btnSelecImageUpload.setVisibility(View.GONE);
            btnScanBarcode.setVisibility(View.GONE);
        } else {
            btnConfirm.setVisibility(View.GONE);
            btnSkip.setVisibility(View.VISIBLE);
            btnSelecImageUpload.setVisibility(View.GONE);
            btnScanBarcode.setVisibility(View.VISIBLE);
        }
//        sql_PickOrders sqlOrder = new sql_PickOrders(getActivity());
//        if (sqlOrder.checkOrderItemIdQC(OrderItemID)) {
//            btnConfirmQC.setVisibility(View.GONE);
//        } else {
//            btnConfirmQC.setVisibility(View.VISIBLE);
//        }


    }

    protected void updateListView(String OrderItemID) {
        sql_PickParts sqlParts = new sql_PickParts(getActivity());
        List<PickPart> listNew = sqlParts.getListPartsQC(OrderItemID);

        listPart.clear();
        listPart.addAll(listNew);
        adapter.notifyDataSetChanged();

    }

    @Override
    public void onDetach() {
        requestQueue.cancelAll(Tag);
        super.onDetach();
    }

    public void YourSlideLeftToRight(final int position) {
        sql_PickParts sqlParts = new sql_PickParts(getActivity());
        boolean isScannedQC = sqlParts.checkPartScannedQC(intOrdersItemID, listPart.get(position).getPartID());
        boolean checkExists = sqlParts.checkExistsData(String.valueOf(intOrdersItemID), String.valueOf(listPart.get(position).getPartID()));
        onContinueProcessScanPart(checkExists, isScannedQC, String.valueOf(listPart.get(position).getPartID()), "SWIPE", sqlParts);
    }

    class MyGestureDetector extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            try {
                float diffX = e2.getX() - e1.getX();
                float diffY = e2.getY() - e1.getY();
                if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
                    return false;
                if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
                        && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                    // left to right swipe
                    YourSlideLeftToRight(lvPartsInOrder.pointToPosition((int) e1.getX(), (int) e1.getY()));
                }
            } catch (Exception e) {
                // nothing
                return true;
            }

            return true;

        }
    }
}
