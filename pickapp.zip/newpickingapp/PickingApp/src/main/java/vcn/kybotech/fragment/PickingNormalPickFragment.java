package vcn.kybotech.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vcn.kybotech.activity.PickingNormalUploadImagesActivity;
import vcn.kybotech.adapter.PartsPickerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.controller.BarcodeSubString;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.PickLoad;
import vcn.kybotech.model.PickOrder;
import vcn.kybotech.model.PickPart;
import vcn.kybotech.pickingapp.CommunicatingFragments;
import vcn.kybotech.pickingapp.MainActivity;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.sqlite.sql_PickLoads;
import vcn.kybotech.sqlite.sql_PickOrders;
import vcn.kybotech.sqlite.sql_PickParts;

@SuppressLint({"CutPasteId", "InflateParams"})
public class PickingNormalPickFragment extends android.app.Fragment {

    public GPSTracker gpsTracker;
    private FileSave fileSave;
    private TextView OrdersDropNumber;
    private TextView OrderRef;
    private TextView TvOrderItemID;
    private TextView ProductName;
    private TextView TvLoadID;
    private ListView lvPartsInOrder;
    private PartsPickerAdapter adapter;
    private String LoadID;
    private String LoadCode;
    public static EditText textScanBarcode;
    private List<PickOrder> listOrder;
    private List<PickPart> listPart;
    private List<PickPart> listPartGroup;
    private Button btnSkip;
    private Button btnConfirm;
    private Button btnClear;
    private Button btnGTIN;
    private ImageButton btnScanBarcode;
    private ImageButton btnSelecImageUpload;
    private ImageButton btnSpecialInstructions;
    private Button btnRemoveOderItem;
    private int iOrders;
    private ImageView logoTesCo;
    public static int countImageUpLoaded;
    private CommunicatingFragments communicatingFragments;
    private final static String Tag = "RequesConfirm";
    RequestQueue requestQueue;// = Volley.newRequestQueue(getActivity());
    int intOrdersItemID;
    int intOrdersID;
    String strOrdersDropNumber;
    String strOrderRef;
    String strProductName;
    String strSpecialInstructions;
    int typedtime;
    public static Boolean istyped = false;
    public static Boolean IsManuallyScan = true;
    public int qtyGlazing = 0;
    public int qtyFeltRoll = 0;
    public static sql_PickParts sqlParts;
    private sql_PickLoads sqlPickLoads;
    List<Integer> listPIDGlazingFelt;
    List<Integer> listOrderItemIDGlazingFelt;
    String partGlazingFelt;
    private List<PickOrder> listAllOrder;
    private boolean isSkipDiaLogAnwer = false;

    @Override
    public void onAttach(Activity activity) {
        // TODO Auto-generated method stub
        super.onAttach(activity);
        try {
            communicatingFragments = (CommunicatingFragments) getActivity();
        } catch (Exception e) {
            throw new ClassCastException(activity.toString() + " must implement CommunicatingFragments");
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_picking_load_normal, container, false);
        rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        /* Phan dang ky findViewByID */
        // layoutFrame =
        // (RelativeLayout)rootView.findViewById(R.id.fragment_picking_load_accept_xml);
        // layoutFrame.setOnClickListener(null);
        logoTesCo = (ImageView) rootView.findViewById(R.id.logoTesCo);
        btnRemoveOderItem = (Button) rootView.findViewById(R.id.btnRemoveOderItem);
        // relative_NotFoundOrder =
        // (RelativeLayout)rootView.findViewById(R.id.relative_NotFoundOrder);
        OrdersDropNumber = (TextView) rootView.findViewById(R.id.tvOrdersDropNumber);
        TvOrderItemID = (TextView) rootView.findViewById(R.id.load_accept_OrderItemID);
        OrderRef = (TextView) rootView.findViewById(R.id.load_accept_OrderRef);
        ProductName = (TextView) rootView.findViewById(R.id.productname);
        lvPartsInOrder = (ListView) rootView.findViewById(R.id.lvPartsInOrder_FragmentPickingLoadAccept);
        textScanBarcode = (EditText) rootView.findViewById(R.id.textScanBarcode);
        TvLoadID = (TextView) rootView.findViewById(R.id.load_accept_LoadID);
        btnConfirm = (Button) rootView.findViewById(R.id.btnConfirm);
        btnSkip = (Button) rootView.findViewById(R.id.btnSkip);
        btnClear = (Button) rootView.findViewById(R.id.btnClearScan);
        btnGTIN = (Button) rootView.findViewById(R.id.btnGTIN);
        btnScanBarcode = (ImageButton) rootView.findViewById(R.id.btnBarcode);
        btnSelecImageUpload = (ImageButton) rootView.findViewById(R.id.btnSelectImageUpload);
        btnSpecialInstructions = (ImageButton) rootView.findViewById(R.id.note);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);
        this.LoadID = getArguments().getString(Constants.key_bundle_loadid);
        this.LoadCode = getArguments().getString(Constants.key_bundle_loadcode);

        requestQueue = Volley.newRequestQueue(getActivity());
        countImageUpLoaded = 0;
        iOrders = 0;
        gpsTracker = new GPSTracker(getActivity());
        fileSave = new FileSave(getActivity(), Constants.GET);

        sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
        /* Lay ra danh sach Order Chua Picked trong mot Load de lam viec */
        listOrder = sqlOrders.getListOrdersAccept(LoadID);
        listCheckGlazingFelt(LoadID);
        if (listOrder.size() > 0) {
            onProgressEvent(iOrders);
        }

        onClickButton();

        // Check permission remove item
        boolean isAdmin = fileSave.getIsAdmin();
        if (isAdmin) {
            btnRemoveOderItem.setVisibility(View.VISIBLE);
            Log.d("hehE", "hien hien");
        } else {
            btnRemoveOderItem.setVisibility(View.GONE);
            Log.d("hehe", "an an");
        }
    }

    public void listCheckGlazingFelt(String LoadId) {
        try {
            sqlPickLoads = new sql_PickLoads(getActivity());
            PickLoad pickLoad = new PickLoad();
            pickLoad = sqlPickLoads.getLoadWhereID(LoadId);
            if(pickLoad.getLoadCode().toLowerCase().startsWith("lcd")){
                isSkipDiaLogAnwer = true;
            }

            if (!isSkipDiaLogAnwer) {
                sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                listAllOrder = sqlOrders.getAllListOrders(LoadID);
                listPIDGlazingFelt = new ArrayList<>();
                listOrderItemIDGlazingFelt = new ArrayList<>();
                for (int j = 0; j < listAllOrder.size(); j++) {
                    final sql_PickParts sqlParts = new sql_PickParts(getActivity());
                    intOrdersItemID = listAllOrder.get(j).getOrderItemID();
                    listPartGroup = sqlParts.getListParts(String.valueOf(intOrdersItemID));

                    for (int i = 0; i < listPartGroup.size(); i++) {
                        if (listPartGroup.get(i).getOrderRef().toLowerCase().contains("rdm")) {
                            continue;
                        }
                        if (listPartGroup.get(i).getPartGroupID() == 176
                                || listPartGroup.get(i).getPartGroupID() == 222
                                || listPartGroup.get(i).getPartGroupID() == 249) {
                            qtyGlazing += listPartGroup.get(i).getQuantity();

                        }
                        if (listPartGroup.get(i).getPartGroupID() == 138) {
                            qtyFeltRoll += listPartGroup.get(i).getQuantity();

                        }

                        if (listPartGroup.get(i).getPartGroupID() == 176
                                || listPartGroup.get(i).getPartGroupID() == 222
                                || listPartGroup.get(i).getPartGroupID() == 249 || listPartGroup.get(i).getPartGroupID() == 138) {

                            listPIDGlazingFelt.add(listPartGroup.get(i).getPartID());
                            if (!listOrderItemIDGlazingFelt.contains(listPartGroup.get(i).getOrderItemID())) {

                                listOrderItemIDGlazingFelt.add(listPartGroup.get(i).getOrderItemID());
                            }
                        }
                    }
                }
                partGlazingFelt = TextUtils.join(",", listPIDGlazingFelt);
            }

            Log.d("", "");

        } catch (Exception ex) {
            Log.d("Glazing,Felt", ex.getMessage());
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        //focus on textScanBarcode
        textScanBarcode.requestFocus();
    }

    private void onClickButton() {
        sqlParts = new sql_PickParts(getActivity());

        btnRemoveOderItem.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                final Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.dialog_remove_order_item);

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setAttributes(lp);
                // dialog.getWindow().setGravity(Gravity.TOP);
                final EditText edtPartId = (EditText) dialog.findViewById(R.id.removePartID);
                final TextView tvEnterText = (TextView) dialog.findViewById(R.id.tvEnterText);
                Button PositiveButton = (Button) dialog.findViewById(R.id.btnYes);
                Button NegativeButton = (Button) dialog.findViewById(R.id.btnNo);
                PositiveButton.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        final String partID = edtPartId.getText().toString() + "";

                        if (partID.trim().length() > 0) {

                            final ProgressDialog progressDialog;
                            progressDialog = new ProgressDialog(getActivity());
                            progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                            progressDialog.setCancelable(false);
                            progressDialog.show();

                            Response.Listener<String> listener = new Response.Listener<String>() {

                                @Override
                                public void onResponse(String response) {
                                    try {

                                        JSONObject jsonObject = new JSONObject(response);
                                        if (jsonObject.getBoolean("success")) {
                                            /* Xoa bo so anh da duoc upload */
                                            countImageUpLoaded = 0;
                                            /*
                                             * Thay doi trang thai cua Order sau
											 * do check xem all OrderItem da
											 * confirm het chua neu confirm het
											 * thi bay sang giao dien Confirm
											 * Load
											 */
                                            /* OrderItem vua remove */
                                            sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                                            sqlOrders.updateRemoveOrderItem(String.valueOf(intOrdersItemID));
                                            if (listOrder != null && listOrder.size() > 0) {
                                                // int iOrders = flagOrders %
                                                // listOrder.size();
                                                listOrder.remove(iOrders);
                                                if (listOrder.size() == 0) {
                                                    android.app.Fragment fragment = getActivity().getFragmentManager()
                                                            .findFragmentById(R.id.container);
                                                    android.app.FragmentTransaction ft = getActivity().getFragmentManager()
                                                            .beginTransaction();
                                                    ft.remove(fragment);
                                                    ft.commit();
                                                    Log.e("remove", fragment.toString());
                                                    getActivity().getFragmentManager().popBackStack();
                                                    // communicatingFragments.onNormalPickMoveConfirmLoad(LoadID);
                                                    communicatingFragments.onQAConfirmLoad(LoadID);

                                                } else {

                                                    if (iOrders >= listOrder.size()) {
                                                        iOrders = 0;
                                                        onProgressEvent(iOrders);
                                                    } else {
                                                        onProgressEvent(iOrders);
                                                    }
                                                }
                                            }
                                        } else {

                                            AlertDialog.Builder dialog = new Builder(getActivity());
                                            dialog.setTitle("Notification")
                                                    .setMessage("Error remove, server is problem! ")
                                                    .setPositiveButton("OK", null).show();
                                        }

                                    } catch (JSONException e) {
                                        DialogServerProblem();
                                        // Toast.makeText(getActivity(), "data:
                                        // false, server is problem!",
                                        // Toast.LENGTH_SHORT).show();
                                        e.printStackTrace();
                                    } catch (Exception e2) {

                                    }

                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                }

                            };

                            Response.ErrorListener errorListener = new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError arg0) {
                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                    AlertDialog.Builder dialog = new Builder(getActivity());
                                    dialog.setTitle("Notification").setMessage("Connection to your server disconnected")
                                            .setPositiveButton("OK", null).show();
                                }
                            };

                            StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                                    listener, errorListener) {

                                @Override
                                protected Map<String, String> getParams() {
                                    String latitude = String.valueOf(gpsTracker.getLatitude());
                                    String longtitude = String.valueOf(gpsTracker.getLongitude());

                                    Map<String, String> params = new HashMap<String, String>();
                                    params = onCreateParams(latitude, longtitude);
                                    return params;
                                }

                                private Map<String, String> onCreateParams(String Lat, String Lng) {
                                    Map<String, String> params = new HashMap<String, String>();
                                    SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    Log.e("reques ConfirmOrderItem", "Toa Do: " + Lat + " ; " + Lng);
                                    String date = "";
                                    String version = "";

                                    try {
                                        date = formatngay.format(new Date());
                                        version = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE
                                                + " | " + getActivity().getPackageManager()
                                                .getPackageInfo(getActivity().getPackageName(), 0).versionCode;

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        // new
                                        // LogCrashActivity().inserException(e);
                                    }
                                    params.put("type", "newremoveitemorder");
                                    params.put("pickerid", String.valueOf(fileSave.getPickerID()));
                                    params.put("pickername", fileSave.getPickerName());
                                    params.put("orderid", String.valueOf(intOrdersID));
                                    params.put("orderitemid", String.valueOf(intOrdersItemID));
                                    params.put("loadid", LoadID);
                                    params.put("orderref", strOrderRef);
                                    params.put("partid", partID);

                                    params.put("lat", Lat);
                                    params.put("lng", Lng);
                                    params.put("version", version);
                                    params.put("phonedate", date);
                                    params.put("inapp", "NewPickingApp");

                                    return params;
                                }

                                ;
                            };

                            // RequestQueue requestQueue =
                            // Volley.newRequestQueue(getActivity());
                            postRequest.setTag(Tag);
                            postRequest.setShouldCache(false);
                            requestQueue.add(postRequest);

                            dialog.dismiss();
                        } else {
                            tvEnterText.setVisibility(View.VISIBLE);
                        }
                    }
                });

                NegativeButton.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();

                    }
                });

                dialog.setCancelable(false);
                dialog.show();

            }
        });

        textScanBarcode.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(final CharSequence sa, int start, int before, int count) {

                BarcodeSubString barcodeSubString = new BarcodeSubString();
                String scanText = barcodeSubString.CutBarcode(textScanBarcode.getText().toString().trim(), "");
                sql_PickParts sqlParts = new sql_PickParts(getActivity());

                String lat = String.valueOf(gpsTracker.getLatitude());
                String lng = String.valueOf(gpsTracker.getLongitude());

                if (scanText.length() >= 1 && scanText.length() <= 3) {
                    Log.e("hehe", "scan text: " + scanText.length());
                    IsManuallyScan = true;
                }
                if (scanText.length() == 1) {
                    istyped = true;
                    typedtime = (int) System.currentTimeMillis();
                }
                if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {

                    if (scanText.length() >= 5) {
                        try {
                            if (istyped) {
                                typedtime = (int) (System.currentTimeMillis() - typedtime);
                            } else {
                                typedtime = 0;
                            }
                            Log.e("hehe", "typed time: " + typedtime);

							/*
                             * Check xem da scanned chua neu roi thi bao scanned
							 * full
							 */

                            // split if code has ','
//							if (scanText.length() > 5) {
//								String[] s = scanText.split(",");
//								if (s.length > 1) {
//									scanText = s[0];
//									if (s[0].toLowerCase().contains("k")) {
//										scanText = s[1];
//									}
//								}
//							}
//							if (scanText.length() > 5) {
//								scanText = scanText.substring(0, 5);
//							}
                            boolean isScanned = sqlParts.checkPartScanned(intOrdersItemID, Integer.parseInt(scanText));
                            boolean checkExists = sqlParts.checkExistsData(String.valueOf(intOrdersItemID), scanText);
                            istyped = false;
                            onContinueProcessScanPart(checkExists, isScanned, scanText, "QR", lat, lng, typedtime);
                        } catch (NumberFormatException e) {
                            DialogInputPartIDInvalid();
                        }
                    }
                } else {
                    if (scanText.length() >= 13) {
                        if (istyped) {
                            typedtime = (int) (System.currentTimeMillis() - typedtime);
                        } else {
                            typedtime = 0;
                        }
                        Log.e("hehe", "typed time: " + typedtime);

						/*
                         * Check xem da scanned chua neu roi thi bao scanned
						 * full
						 */
                        boolean isScanned = sqlParts.checkPartScannedWhereBarCode(intOrdersItemID, scanText);
                        boolean checkExists = sqlParts.checkExistsBarCode(String.valueOf(intOrdersItemID), scanText);
                        istyped = false;
                        onContinueProcessScanPart(checkExists, isScanned, scanText, "GTIN", lat, lng, typedtime);
                    }
                }
            }

            private void onContinueProcessScanPart(boolean checkExists, boolean isScanned, final String s, String QR,
                                                   final String lat, final String lng, final int typetime) {

                String PartID_Or_BarCode = "PartID: ";
                if (QR.equalsIgnoreCase("GTIN")) {
                    PartID_Or_BarCode = "BarCode: ";
                }

                if (checkExists) {
                    if (isScanned) {

                        textScanBarcode.setText(null);

						/* Thong bao da scanned */
                        AlertDialog.Builder dialog = new Builder(getActivity());
                        dialog.setTitle("Notification").setMessage(PartID_Or_BarCode + s.toString() + " scanned full")
                                .setPositiveButton("OK", null).show();
                    } else {
                        /* Bat dau scan */
                        PickPart pickPart = null;
                        /*
                         * pickPart khong the null vi ham o tren goi ham nay ra
						 * da check exists va iscan
						 */
                        if (QR.equalsIgnoreCase("QR")) {
                            pickPart = sqlParts.getPickPartNotScanned(String.valueOf(intOrdersItemID), s.toString());
                        } else {
                            pickPart = sqlParts.getPickPartWhereBarCode(String.valueOf(intOrdersItemID), s.toString());

                        }

                        final int id = pickPart.getId();
                        final int part_id = pickPart.getPartID();
                        final int part_qty = pickPart.getQuantity();
                        final String part_location = pickPart.getLocationName();
                        final String part_name = pickPart.getPartName();
                        final String order_ref = pickPart.getOrderRef();
                        final int order_item_id = pickPart.getOrderItemID();

                        if (sqlParts.checkSwipeConfirm(String.valueOf(intOrdersItemID),
                                String.valueOf(pickPart.getPartID()), pickPart.getId())) {
                            /*
                             * request server neu thanh cong thi moi update neu
							 * khong thi bao loi
							 */

                            final ProgressDialog progressDialog;
                            progressDialog = new ProgressDialog(getActivity());
                            progressDialog.setMessage(getString(R.string.fragment_login_waiting));
                            progressDialog.setCancelable(false);
                            progressDialog.show();

                            Response.Listener<String> listener = new Response.Listener<String>() {

                                @Override
                                public void onResponse(String response) {

                                    try {
                                        JSONObject jsonObject = new JSONObject(response.toString());
                                        if (jsonObject.getBoolean("success")) {
                                            // Check xem part nay co bat buoc
                                            // scan = camera hay ko
                                            if (jsonObject.getBoolean("needscan") && IsManuallyScan) {
                                                AlertDialog.Builder dialog = new Builder(getActivity());
                                                dialog.setTitle("Notification")
                                                        .setMessage(
                                                                "This part need scan by application, you can't manully input to scan this part.")
                                                        .setPositiveButton("OK", null).show();
                                            } else {
                                                /*
                                                 * confirm len service truoc,
												 * neu confirm thanh cong moi
												 * cho ++swipe scan
												 */
                                                sqlParts.updateSwipe(intOrdersItemID, part_id, id,
                                                        fileSave.getPickerName());
                                                updateButtonShowHide(String.valueOf(intOrdersItemID));
                                                updateListView(String.valueOf(intOrdersItemID));
                                            }
                                        } else {
                                            Toast.makeText(getActivity(), "success: false, Server is problem!",
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        DialogServerProblem();
                                    } catch (Exception e2) {
                                        e2.printStackTrace();
                                    }

                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                    if (textScanBarcode != null) {
                                        textScanBarcode.setText(null);
                                    }

                                }

                            };

                            Response.ErrorListener errorListener = new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError volleyError) {
                                    if (progressDialog != null) {
                                        progressDialog.dismiss();
                                    }
                                    if (textScanBarcode != null) {
                                        textScanBarcode.setText(null);
                                    }
                                    Toast.makeText(getActivity(), "Connect to server timeout!", Toast.LENGTH_SHORT)
                                            .show();
                                }
                            };

                            StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                                    listener, errorListener) {
                                @Override
                                protected Map<String, String> getParams() {

                                    Map<String, String> params = onCreateParams();

                                    return params;
                                }

                                private Map<String, String> onCreateParams() {
                                    Map<String, String> params = new HashMap<String, String>();
                                    String date = "";
                                    String version = "";
                                    SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                                    try {
                                        date = formatngay.format(new Date());
                                        version = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE
                                                + " | " + getActivity().getPackageManager()
                                                .getPackageInfo(getActivity().getPackageName(), 0).versionCode;

                                        Log.e("reques ConfirmOrderItem", "Toa Do: " + lat + " ; " + lng);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    params.put("type", "scanpart");
                                    params.put("loadid", LoadID);

                                    params.put("orderref", order_ref);
                                    params.put("orderitemid", String.valueOf(order_item_id));
                                    params.put("partid", String.valueOf(part_id));

                                    params.put("partname", part_name);
                                    params.put("qty", String.valueOf(part_qty));

                                    params.put("locationname", part_location);
                                    params.put("pickerid", String.valueOf(fileSave.getPickerID()));

                                    params.put("pickername", fileSave.getPickerName());
                                    params.put("isscanned", String.valueOf(true));

                                    params.put("typepick", String.valueOf(Constants.type_pick_normalpick));
                                    params.put("typetime", String.valueOf(typetime));

                                    params.put("InApp", "NewPickingApp");
                                    params.put("lat", lat);
                                    params.put("lng", lng);
                                    params.put("version", version);
                                    params.put("phonedate", date);

                                    return params;
                                }
                            };

                            // RequestQueue requestQueue =
                            // Volley.newRequestQueue(getActivity());
                            postRequest.setTag(Tag);
                            postRequest.setShouldCache(false);
                            requestQueue.add(postRequest);

                        } else {
                            textScanBarcode.setText(null);
                            sqlParts.updateSwipe(intOrdersItemID, part_id, id, fileSave.getPickerName());
                            updateListView(String.valueOf(intOrdersItemID));
                        }

                    }

                } else {
                    textScanBarcode.setText(null);

					/* Thong bao da scanned */
                    AlertDialog.Builder dialog = new Builder(getActivity());
                    dialog.setTitle("Notification")
                            .setMessage(PartID_Or_BarCode + s.toString() + " you have entered is invalid")
                            .setPositiveButton("OK", null).show();
                }
                //focus on textScanBarcode
                textScanBarcode.requestFocus();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnClear.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Builder dialog = new AlertDialog.Builder(getActivity());
                dialog.setTitle(getResources().getString(R.string.fragment_accept_dialog_title));
                dialog.setMessage(getResources().getString(R.string.fragment_accept_dialog_message));
                dialog.setPositiveButton(R.string.fragment_accept_dialog_yes, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        String lat = String.valueOf(gpsTracker.getLatitude());
                        String lng = String.valueOf(gpsTracker.getLongitude());
                        onClearnAllPartInOrderItemToServer(LoadID, String.valueOf(intOrdersID),
                                String.valueOf(intOrdersItemID), lat, lng);

						/* Clear cac part chua scan full */
                        // sqlParts.clearScanPartNotScanned(String.valueOf(intOrdersItemID));

                    }


                });

                dialog.setNegativeButton(R.string.fragment_accept_dialog_no, null);
                dialog.show();

            }
        });



        btnScanBarcode.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                ((MainActivity)getActivity()).onSCanBarCode(Constants.SCAN_ACCEPT_LOAD_PICKING);
                //focus on textScanBarcode
                textScanBarcode.requestFocus();
            }
        });

        btnSpecialInstructions.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                String message = strSpecialInstructions;
                if (strSpecialInstructions.equalsIgnoreCase("") || strSpecialInstructions.equalsIgnoreCase("null")) {
                    message = getString(R.string.fragment_accept_dialog_note_no_mesage);
                }
                Builder dialog = new AlertDialog.Builder(getActivity());
                dialog.setTitle(R.string.fragment_accept_dialog_note_title).setMessage(message)
                        .setPositiveButton(R.string.fragment_accept_dialog_yes, new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                // TODO Auto-generated method stub

                            }
                        }).show();
            }
        });

        btnSkip.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                listOrder = sqlOrders.getListOrdersAccept(LoadID);
                if (listOrder.size() > 1) {
                    /* Xoa bo so anh da duoc upload */
                    countImageUpLoaded = 0;
                    ++iOrders;
                    if (iOrders >= listOrder.size()) {
                        iOrders = 0;
                        onProgressEvent(iOrders);
                    } else {
                        onProgressEvent(iOrders);
                    }
                } else {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                    dialog.setTitle("Message").setMessage("No skip, only one OrderItem in Load")
                            .setPositiveButton("OK", null).show();
                }
            }
        });

        btnSelecImageUpload.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                openTakePhoto();
            }
        });

        btnConfirm.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

				/*
                 * Check xem upload anh chua neu chua upload thi thong bao yeu
				 * cau chup anh de upload
				 */
                /*if (countImageUpLoaded == 0) {
                    showRequesTakePhoto();

				} else {
					showDialogConfirm();
				}*/
                sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());
                listOrder = sqlOrders.getListOrdersAccept(LoadID);
                if (listOrder.size() == 1) {
                    if (isSkipDiaLogAnwer) {
                        showDialogConfirm();
                    } else if (qtyGlazing == 0 && qtyFeltRoll == 0) {
                        showDialogConfirm();
                    } else {
                        dialogQuestion();
                    }
                } else {
                    showDialogConfirm();
                }
            }
        });

        btnGTIN.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (btnGTIN.getText().toString().equalsIgnoreCase("QR")) {
                    btnGTIN.setText("GTIN");
                } else {
                    btnGTIN.setText("QR");
                }

            }
        });

    }

    private void onClearnAllPartInOrderItemToServer(final String LoadId, final String OrderId,
                                                    final String OrderItemID, final String Lat, final String Lng) {
                        /*
                         * confirm len service truoc, neu confirm thanh cong moi
						 * cho clearn scan
						 */
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    if (jsonObject.getBoolean("success")) {
                                        /* Coi nhu chua upload anh */
                        countImageUpLoaded = 0;
//                        Log.e("PickingLoadAssignedPickByTypeFragment", response.toString());
                        sqlParts.clearAllScanPart(String.valueOf(OrderItemID));
                        updateButtonShowHide(String.valueOf(OrderItemID));
                        updateListView(String.valueOf(OrderItemID));

                    } else {
                        Toast.makeText(getActivity(), "message:false\nServer is problem!",
                                Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    DialogServerProblem();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }

                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
            }

        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
                AlertDialog.Builder dialog = new Builder(getActivity());
                dialog.setTitle("Message")
                        .setMessage("Clear scan Part fail. Connection to your server disconnected!!")
                        .setPositiveButton("Cancel", null).show();
            }
        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                listener, errorListener) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "newclearpart");
                params.put("loadid", LoadId);
                params.put("typeclear", String.valueOf(Constants.type_pick_normalpick));
                params.put("orderitemid", String.valueOf(OrderItemID));
                return params;
            }
        };

        // RequestQueue requestQueue =
        // Volley.newRequestQueue(getActivity());
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);

    }

    public void dialogQuestion() {
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
        View mview = getActivity().getLayoutInflater().inflate(R.layout.dialog_question, null);
        Button btnOK = (Button) mview.findViewById(R.id.btnOKQuestion);
        Button btnCancel = (Button) mview.findViewById(R.id.btnCancelQuestion);
        final EditText edGlazing = (EditText) mview.findViewById(R.id.edAnswerGlazing);
        final EditText edFeltRoll = (EditText) mview.findViewById(R.id.edAnswerFelt);

        mBuilder.setView(mview);
        mBuilder.setCancelable(false);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();
        btnCancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnOK.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (edGlazing.getText().toString().length() == 0 || edFeltRoll.getText().toString().length() == 0) {
                        Toast.makeText(getActivity(), "Please input all answers", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int glazing = Integer.parseInt(edGlazing.getText().toString());
                    int feltRoll = Integer.parseInt(edFeltRoll.getText().toString());
                    if (glazing == (qtyGlazing) && feltRoll == (qtyFeltRoll)) {

                        showDialogConfirm();
                        dialog.dismiss();

                    } else {
                        if (listOrderItemIDGlazingFelt.size() > 0) {
                            for (int i = 0; i < listOrderItemIDGlazingFelt.size(); i++) {
                                clearlitlepartid(LoadID, String.valueOf(listOrderItemIDGlazingFelt.get(i)), partGlazingFelt);
                            }

                            FileSave file = new FileSave(getActivity(), Constants.GET);
                            String picker = String.valueOf(file.getPickerID()) + " - " + file.getPickerName();
                            sendemail("vcn@kybotech.co.uk", "picking.problem@kybotech.co.uk",
                                    "Answer question not correct", "Load ID " + LoadID +
                                            " has had incorrect glazing or felt counted by picker " + picker
                                            +".\nPicker inputed  "+glazing+" glazings and "+ feltRoll+" felts."
                                            + "\n The correct answer is : "+qtyGlazing + " glazings and "+ qtyFeltRoll +" felts.");
                            Toast.makeText(getActivity(), "Please scan again!", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        } else dialog.dismiss();
                    }
                } catch (Exception ex) {
                    Log.d("DialogQuestion",ex.getMessage());
                }
            }
        });
    }

    protected void showDialogConfirm() {
        // hiện bảng câu hỏi check part group có phải là glazing hay felt rolls không

        AlertDialog.Builder dialogRequesTakePhoto = new Builder(getActivity());
        dialogRequesTakePhoto.setTitle("Message").setMessage("You want to confirm OrderItem this?")
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        onProcessConfirm();
                    }
                }).setNegativeButton("Cancel", null).show();

    }

    protected void onProcessConfirm() {
        final PickOrder order = new PickOrder();
        order.setLoadID(Integer.parseInt(LoadID));
        order.setOrderRef(strOrderRef);
        order.setOrderID(intOrdersID);
        order.setOrderItemID(intOrdersItemID);
        final sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());

        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getBoolean("success")) {
                        /* Xoa bo so anh da upload */
                        countImageUpLoaded = 0;

						/*
                         * Thay doi trang thai cua Order sau do check xem all
						 * OrderItem da confirm het chua neu confirm het thi bay
						 * sang giao dien Confirm Load
						 */
                        sqlOrders.updateConfirmSpickedOrder(String.valueOf(intOrdersItemID));
                        if (listOrder != null && listOrder.size() > 0) {
                            // int iOrders = flagOrders % listOrder.size();
                            listOrder.remove(iOrders);
                            if (listOrder.size() == 0) {
                                android.app.Fragment fragment = getActivity().getFragmentManager()
                                        .findFragmentById(R.id.container);
                                android.app.FragmentTransaction ft = getActivity().getFragmentManager().beginTransaction();
                                ft.remove(fragment);
                                ft.commit();
                                Log.e("remove", fragment.toString());
                                getActivity().getFragmentManager().popBackStack();
                                // communicatingFragments.onNormalPickMoveConfirmLoad(LoadID);
                                communicatingFragments.onQAConfirmLoad(LoadID);

                            } else {
                                if (iOrders >= listOrder.size()) {
                                    iOrders = 0;
                                    onProgressEvent(iOrders);
                                } else {
                                    onProgressEvent(iOrders);
                                }

                            }
                        }
                    } else {
                        Toast.makeText(getActivity(), "Confirm error, server is problem!", Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    DialogServerProblem();
                    e.printStackTrace();
                } catch (Exception e2) {
                    // TODO: handle exception
                }

                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
            }

        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError arg0) {
                if (progressDialog != null) {
                    progressDialog.dismiss();
                }
                Toast.makeText(getActivity(), "Can not connect to server", Toast.LENGTH_SHORT).show();

            }
        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS, listener,
                errorListener) {

            @Override
            protected Map<String, String> getParams() {
				/*
				 * CHECK XEM ORDER ITEM NAY CO PHAI LA ORDERITEM CUOI CUNG DUOC
				 * XU LY KHONG
				 */

                int countNotPicked = sqlOrders.getCountOrdersNotPicked(LoadID, String.valueOf(intOrdersID));
                String latitude = String.valueOf(gpsTracker.getLatitude());
                String longtitude = String.valueOf(gpsTracker.getLongitude());

                Map<String, String> params = new HashMap<String, String>();

				/*
				 * NEU LA ORDERITEM CUOI CUNG CUA MOT ORDER THI TRUYEN VAO THAM
				 * SO = 1 ELSE = 0
				 */
                if (countNotPicked == 1) {
					/* Confirm OrderItem cuoi cung trong OrderID */
                    params = onCreateParams("1", latitude, longtitude);
                } else {
					/* Khong phai Confirm OrderItem cuoi cung trong OrderID */
                    params = onCreateParams("0", latitude, longtitude);
                }
                return params;
            }

            private Map<String, String> onCreateParams(String isorderconfirmed, String latitude, String longtitude) {
                Map<String, String> params = new HashMap<String, String>();
                SimpleDateFormat formatngay = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                String date = "";
                String version = "";

                try {
                    date = formatngay.format(new Date());
                    version = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE + " | " + getActivity()
                            .getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionCode;

                    Log.e("reques ConfirmOrderItem", "Toa Do: " + latitude + " ; " + longtitude);
                } catch (Exception e) {
                    e.printStackTrace();
                    // new LogCrashActivity().inserException(e);
                }
                params.put("type", "confirmitempicked");
                params.put("pickerid", String.valueOf(fileSave.getPickerID()));
                params.put("pickername", fileSave.getPickerName());
                params.put("InApp", "NewPickingApp");
                params.put("loadid", String.valueOf(order.getLoadID()));
                params.put("orderref", order.getOrderRef());
                params.put("orderitemid", String.valueOf(order.getOrderItemID()));
                params.put("lat", latitude);
                params.put("lng", longtitude);
                params.put("version", version);
                params.put("phonedate", date);
                params.put("isorderconfirmed", isorderconfirmed);

                return params;
            }

            ;
        };

        // RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);

    }

    protected void showRequesTakePhoto() {
        AlertDialog.Builder dialogRequesTakePhoto = new Builder(getActivity());
        dialogRequesTakePhoto.setTitle("Message").setMessage("Please take photo and upload to confirm")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Take Photo", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        openTakePhoto();
                    }
                }).show();

    }

    private void onProgressEvent(int indexOrder) {

        intOrdersItemID = listOrder.get(indexOrder).getOrderItemID();
        intOrdersID = listOrder.get(indexOrder).getOrderID();
        strOrdersDropNumber = listOrder.get(indexOrder).getDropNumber() + "";
        strOrderRef = listOrder.get(indexOrder).getOrderRef();
        strProductName = listOrder.get(indexOrder).getProductName();
        strSpecialInstructions = "" + listOrder.get(indexOrder).getSpecialInstructions();// cong
        // chuoi
        // tranh
        // null;

        // final String strSpecialInstructions =
        // loadAssignAcceptanceJSONObj.getJSONArray("orders").getJSONObject(indexOrder).getString("SpecialInstructions");
        textScanBarcode.setText("");
        OrdersDropNumber.setText(strOrdersDropNumber);
        TvOrderItemID.setText(String.valueOf(intOrdersItemID));
        OrderRef.setText(strOrderRef);
        ProductName.setText(strProductName);
        TvLoadID.setText(LoadID);

        if (strOrderRef.indexOf("KTC") >= 0) {
            logoTesCo.setVisibility(View.VISIBLE);
        } else {
            logoTesCo.setVisibility(View.GONE);
        }

        final sql_PickParts sqlParts = new sql_PickParts(getActivity());
        listPart = sqlParts.getListPartsPickedASC(String.valueOf(intOrdersItemID));
        adapter = new PartsPickerAdapter(getActivity(), R.layout.item_part, listPart);
        lvPartsInOrder.setAdapter(adapter);
        updateButtonShowHide(String.valueOf(intOrdersItemID));

    }

    private void onProgressEventGlazingFelt(int indexOrder) {

        intOrdersItemID = listAllOrder.get(indexOrder).getOrderItemID();
        intOrdersID = listAllOrder.get(indexOrder).getOrderID();
        strOrdersDropNumber = listAllOrder.get(indexOrder).getDropNumber() + "";
        strOrderRef = listAllOrder.get(indexOrder).getOrderRef();
        strProductName = listAllOrder.get(indexOrder).getProductName();
        strSpecialInstructions = "" + listAllOrder.get(indexOrder).getSpecialInstructions();// cong
        // chuoi
        // tranh
        // null;

        // final String strSpecialInstructions =
        // loadAssignAcceptanceJSONObj.getJSONArray("orders").getJSONObject(indexOrder).getString("SpecialInstructions");
        textScanBarcode.setText("");
        OrdersDropNumber.setText("Loading: " + strOrdersDropNumber);
        TvOrderItemID.setText(String.valueOf(intOrdersItemID));
        OrderRef.setText(strOrderRef);
        ProductName.setText(strProductName);
        TvLoadID.setText(LoadID);

        if (strOrderRef.indexOf("KTC") >= 0) {
            logoTesCo.setVisibility(View.VISIBLE);
        } else {
            logoTesCo.setVisibility(View.GONE);
        }

        final sql_PickParts sqlParts = new sql_PickParts(getActivity());
        listPart = sqlParts.getListPartsPickedASC(String.valueOf(intOrdersItemID));
        adapter = new PartsPickerAdapter(getActivity(), R.layout.item_part, listPart);
        lvPartsInOrder.setAdapter(adapter);
        updateButtonShowHide(String.valueOf(intOrdersItemID));

    }

    public void sendemail(final String from, final String to, final String subject, final String body) {

        Response.Listener<String> listener = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

            }

        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        };

        StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                listener, errorListener) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", "sendemail");
                params.put("from", from);
                params.put("to", to);
                params.put("subject", subject);
                params.put("message", body);
                return params;
            }
        };

        postRequest.setTag(Tag);
        postRequest.setShouldCache(false);
        requestQueue.add(postRequest);
    }


    public void clearlitlepartid(final String LoadId, final String OrderItemID, final String partids) {

        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.fragment_login_waiting));
        progressDialog.setCancelable(false);
        progressDialog.show();

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Response.Listener<String> listener = new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response.toString());
                            if (jsonObject.getBoolean("success")) {

                                FileSave file = new FileSave(getActivity(), Constants.GET);
                                String picker = String.valueOf(file.getPickerID()) + " - " + file.getPickerName();
                                countImageUpLoaded = 0;
                                final sql_PickParts sqlParts = new sql_PickParts(getActivity());
                                final sql_PickOrders sqlOrders = new sql_PickOrders(getActivity());

                               // Log.e("PickingLoadAssignedPickByTypeFragment", response.toString());
//                        sqlParts.clearAllLoadedPart(String.valueOf(OrderItemID));
                                for (int i = 0; i < listPIDGlazingFelt.size(); i++) {
                                    sqlParts.clearScanPart(String.valueOf(OrderItemID), String.valueOf(listPIDGlazingFelt.get(i)));
                                }
                                sqlOrders.clearConfirmSpickedOrder(String.valueOf(OrderItemID));
                                for (int i = 0; i < listAllOrder.size(); i++) {
                                    if (String.valueOf(listAllOrder.get(i).getOrderItemID()).equals(OrderItemID)) {
                                        onProgressEventGlazingFelt(i);
                                    }
                                }
//                        updateButtonShowHide(String.valueOf(OrderItemID));
                                updateListView(String.valueOf(OrderItemID));

                                sendemail("vcn@kybotech.co.uk", "picking.problem@kybotech.co.uk", "Answer question not correct", "Load ID " + LoadId + " has had incorrect glazing or felt counted by picker " + picker);

                            } else {
                                Toast.makeText(getActivity(), "message:false\nServer is problem!",
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            DialogServerProblem();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }

                        if (progressDialog != null) {
                            progressDialog.dismiss();
                        }
                    }

                };

                Response.ErrorListener errorListener = new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (progressDialog != null) {
                            progressDialog.dismiss();
                        }
                        AlertDialog.Builder dialog = new Builder(getActivity());
                        dialog.setTitle("Message")
                                .setMessage("Clear scan Part fail. Connection to your server disconnected!!")
                                .setPositiveButton("Cancel", null).show();
                    }
                };

                StringRequest postRequest = new StringRequest(Request.Method.POST, Constants.LINK_PROCESS,
                        listener, errorListener) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("type", "newclearlittlepart");
                        params.put("loadid", LoadId);
                        params.put("typeclear", String.valueOf(Constants.type_pick_normalpick));
                        params.put("orderitemid", String.valueOf(OrderItemID));
                        params.put("partids", partids);

                        return params;
                    }
                };

                // RequestQueue requestQueue =
                // Volley.newRequestQueue(getActivity());
                postRequest.setTag(Tag);
                postRequest.setShouldCache(false);
                requestQueue.add(postRequest);
            }
        }, 2000);

    }

    protected void openTakePhoto() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(textScanBarcode.getWindowToken(), 0);

        Bundle bundle = new Bundle();

        bundle.putString("key_imagetype", Constants.image_PickingOrderImage);
        bundle.putString("key_loadid", String.valueOf(listOrder.get(iOrders).getLoadID()));
        bundle.putString("key_loadcode", LoadCode);

        bundle.putString("key_pickerid", String.valueOf(fileSave.getPickerID()));
        bundle.putString("key_pickername", fileSave.getPickerName());
        // bundle.putString("key_imageurie", value);

        bundle.putString("key_orderid", String.valueOf(listOrder.get(iOrders).getOrderID()));
        bundle.putString("key_orderref", listOrder.get(iOrders).getOrderRef());
        bundle.putString("key_orderitemid", String.valueOf(listOrder.get(iOrders).getOrderItemID()));

        Intent intent = new Intent(getActivity(), PickingNormalUploadImagesActivity.class);
        intent.putExtra(Constants.key_bundle_upload_image, bundle);
        startActivityForResult(intent, Constants.REQUEST_NORMAL_UPLOAD_IMAGE);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.REQUEST_NORMAL_UPLOAD_IMAGE
                && resultCode == Constants.RESULT_NORMAL_UPLOAD_IMAGE) {
            showDialogConfirm();
        }

    }

    public void DialogServerProblem() {
        if (getActivity() == null) {
            return;
        }
        Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage("Server is problem");
        dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        dialog.show();
    }

    public void DialogInputPartIDInvalid() {
        if (getActivity() == null) {
            return;
        }
        Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle("Message");
        dialog.setMessage("Scan PartID invalid, PartID is format number 5 digit.");
        dialog.setPositiveButton("OK", null);
        dialog.show();
    }

    private void updateButtonShowHide(String OrderItemID) {
        sql_PickParts sqlParts = new sql_PickParts(getActivity());
        if (sqlParts.isAllPartScanned(OrderItemID)) {
            //showRequesTakePhoto();
            btnConfirm.setVisibility(View.VISIBLE);
            btnSkip.setVisibility(View.GONE);
            btnSelecImageUpload.setVisibility(View.VISIBLE);
            btnScanBarcode.setVisibility(View.GONE);
        } else {
            btnConfirm.setVisibility(View.GONE);
            btnSkip.setVisibility(View.VISIBLE);
            btnSelecImageUpload.setVisibility(View.GONE);
            btnScanBarcode.setVisibility(View.VISIBLE);
        }

    }

    protected void updateListView(String OrderItemID) {
        sql_PickParts sqlParts = new sql_PickParts(getActivity());
        List<PickPart> listNew = sqlParts.getListPartsPickedASC(OrderItemID);

        listPart.clear();
        listPart.addAll(listNew);
        adapter.notifyDataSetChanged();

    }

    @Override
    public void onDetach() {
        requestQueue.cancelAll(Tag);
        super.onDetach();
    }
}
