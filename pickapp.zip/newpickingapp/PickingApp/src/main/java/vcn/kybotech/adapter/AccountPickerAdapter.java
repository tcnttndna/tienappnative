package vcn.kybotech.adapter;

import java.util.List;

import vcn.kybotech.model.PickAccount;
import vcn.kybotech.pickingapp.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class AccountPickerAdapter extends ArrayAdapter<PickAccount> {

	Context context;
	int	ResID;
	List<PickAccount> listPicker;
	public AccountPickerAdapter(Context context, int resource, List<PickAccount> objects) {
		super(context, resource, objects);
		this.context = context;
		this.ResID = resource;
		this.listPicker = objects;
		
	}

	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		AccountPickerHolder pickerNameHolder;
		
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			pickerNameHolder = new AccountPickerHolder();
			convertView = inflater.inflate(ResID, parent, false);
			pickerNameHolder.pickerName = (TextView) convertView.findViewById(R.id.picker_name_item);
			convertView.setTag(pickerNameHolder);
		}else {
			pickerNameHolder = (AccountPickerHolder) convertView.getTag();
		}
		
		pickerNameHolder.pickerName.setText(listPicker.get(position).getpName());
		return convertView;
	}
	
	
	public static class AccountPickerHolder{
		TextView pickerName;
	}
}
