package vcn.kybotech.fragment;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vcn.kybotech.adapter.SipnnerAdapter;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.GPSTracker;
import vcn.kybotech.constants.ScalingUtilities;
import vcn.kybotech.constants.ScalingUtilities.ScalingLogic;
import vcn.kybotech.controller.ImageControl;
import vcn.kybotech.controller.UnpackControl;
import vcn.kybotech.model.FileSave;
import vcn.kybotech.model.Image;
import vcn.kybotech.model.PackDetails;
import vcn.kybotech.model.SpinnerItem;
import vcn.kybotech.model.TimberPack;
import vcn.kybotech.model.Unpack;
import vcn.kybotech.model.WareHouseItem;
import vcn.kybotech.mycustom.DatePickerFragment;
import vcn.kybotech.pickingapp.R;
import vcn.kybotech.pickingapp.WarehouseAndSite;
import vcn.kybotech.sqlite.sql_Image;
import vcn.kybotech.sqlite.sql_Site;
import vcn.kybotech.sqlite.sql_WareHouse;
import android.R.color;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class TimberDeliveredFragment extends Fragment {
	private EditText etSearch;
	private ImageButton btnSearch;
	private Button btnUnpack;
	private LinearLayout layoutLinnear;
	private ProgressBar proLoad;
	private String imagePath = "";
	private boolean checkResult = false;
	private GPSTracker gps;
	private double LAT;
	private double LNG;
	private int GRNItemID;
	private WebView wvShowView;
	private Unpack unpack;
	private int warehouseId;
	private int warehouseIdChiSo;
	private String site;
	public static String dateused;
	private Button btnSave;
	final Calendar c = Calendar.getInstance();
	private int year = c.get(Calendar.YEAR);
	private int month = c.get(Calendar.MONTH);
	private int day = c.get(Calendar.DAY_OF_MONTH);
	private int PackID;
	
	public TimberDeliveredFragment callHamTao() {
		TimberDeliveredFragment mFragment = new TimberDeliveredFragment();
		Bundle mBundle = new Bundle();
		mFragment.setArguments(mBundle);
		return mFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_timber_delivered, container, false);
		rootView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		sql_WareHouse sqlWareHouse = new sql_WareHouse(TimberDeliveredFragment.this.getActivity());
		sql_Site sqlSite = new sql_Site(TimberDeliveredFragment.this.getActivity());
		if (!sqlWareHouse.checkData() || sqlSite.checkData()) {
			new WarehouseAndSite(TimberDeliveredFragment.this.getActivity()).execute();
		}
		HamKhoiTao(rootView);
		BatSuKien();
		return rootView;
	}

	public void HamKhoiTao(View v) {
		etSearch = (EditText) v.findViewById(R.id.fragment_unpack_et_search);
		btnSearch = (ImageButton) v.findViewById(R.id.fragment_unpack_btn_search);
		btnUnpack = (Button) v.findViewById(R.id.fragment_unpack_btn_unpack);
		layoutLinnear = (LinearLayout) v.findViewById(R.id.fragment_unpack_linnear_layout);
		proLoad = (ProgressBar) v.findViewById(R.id.fragment_unpack_progressbar_load);
		wvShowView = (WebView) v.findViewById(R.id.fragment_unpack_wv_show_view);
		gps = new GPSTracker(TimberDeliveredFragment.this.getActivity());
		if (gps.canGetLocation()) {
			LAT = gps.getLatitude();
			LNG = gps.getLongitude();
		}
		gps.stopUsingGPS();
	}

	public void BatSuKien() {
		btnSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (etSearch.getText().toString().trim().length() == 0) {
					etSearch.requestFocus();
					OpenKeyBoard(TimberDeliveredFragment.this.getActivity());
				} else {
					searchUnpack();
					CloseKeyBoard(TimberDeliveredFragment.this.getActivity());
				}
			}
		});

		btnUnpack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (PackID == 0) {
					Toast.makeText(getActivity(), "PackId not valid !", Toast.LENGTH_LONG).show();
				}
				else {
					DialogUnpack();
				}
				
			}
		});
	}

	public void searchUnpack() {
		PackID = 0;
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				UnpackControl ctrUnpack = new UnpackControl(TimberDeliveredFragment.this.getActivity());
				String packId = etSearch.getText().toString().trim();
				objJSON = ctrUnpack.timberPackDetail(packId);
				return objJSON;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {

								String obj = objJSON.getString("data");
								showData(obj);
								PackID = objJSON.getInt("packid");
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(), objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_SHORT).show();
									etSearch.requestFocus();
									showData("");
									//layoutLinnear.setVisibility(View.GONE);
									OpenKeyBoard(TimberDeliveredFragment.this.getActivity());
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	// For open keyboard
	public void OpenKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
	}

	// For close keyboard
	public void CloseKeyBoard(Context mContext) {
		InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
	}

	public void DialogDisconnectToServer() {
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new AlertDialog.Builder(TimberDeliveredFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.fragment_login_Message_no_response_form_server));
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {

				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void DialogUnpack() {
		try {
			final List<WareHouseItem> listWareHouse;

			final Dialog dialog = new Dialog(TimberDeliveredFragment.this.getActivity());
			dialog.setContentView(R.layout.dialog_timber_delivered);
			dialog.setTitle("Confirm Timber Delivered");
			
			Button btnTakePhoto = (Button) dialog.findViewById(R.id.dialog_timber_delivered_btn_take_photo);
			btnSave = (Button) dialog.findViewById(R.id.dialog_timber_delivered_btn_save);
			
			TextView tvPackid = (TextView) dialog.findViewById(R.id.dialog_packid);
			tvPackid.setText("PackID: " + PackID);
			tvPackid.setTextColor(Color.BLACK);
			
			btnTakePhoto.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					callTakePicture();
				}
			});

			btnSave.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					confirmUnpack();
					dialog.dismiss();
				}
			});

			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void callTakePicture() {
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent.resolveActivity(TimberDeliveredFragment.this.getActivity().getPackageManager()) != null) {
			File photoFile = null;
			try {
				photoFile = createFileImage();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			if (photoFile != null) {
				takePictureIntent.putExtra("imagePath", imagePath);
				takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
				startActivityForResult(takePictureIntent, Constants.TAKE_TIMBER_DELIVERED_PHOTO);
			}
		}
	}

	@SuppressLint("SimpleDateFormat")
	private File createFileImage() throws IOException {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String fileImagename = "Unpack_" + timeStamp;
		File StorageDir = new File(Environment.getExternalStoragePublicDirectory(Constants.FOLDER_NAME),
				Constants.FOLDER_NAME_UNPACK);

		if (!StorageDir.exists()) {
			StorageDir.mkdirs();
		}
		File image = new File(StorageDir, fileImagename + ".png");

		imagePath = image.getAbsolutePath();
		return image;
	}

	private boolean compressImage(String path, int width, int height) {
		boolean isCompress = false;
		Bitmap scaledBitmap = null;
		try {
			Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, width, height, ScalingLogic.FIT);
			scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap, width, height, ScalingLogic.FIT);
			FileOutputStream fos = null;
			try {
				File fichero = new File(imagePath);
				if (fichero.canWrite()) {
					fichero.createNewFile();
					fos = new FileOutputStream(fichero);
					isCompress = scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, fos);
					fos.flush();
					fos.close();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			scaledBitmap.recycle();
		} catch (Throwable e) {
		}
		return isCompress;
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			switch (requestCode) {
			case Constants.TAKE_TIMBER_DELIVERED_PHOTO:
				compressImage(imagePath, 800, 1400);
				checkResult = true;
				break;
			default:
				break;
			}
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		if (checkResult) {
			callUploadImage(imagePath);
		}
		checkResult = false;
	}

	private void callUploadImage(String path) {
		Image obj = new Image();
		FileSave file = new FileSave(TimberDeliveredFragment.this.getActivity(), Constants.GET);
		obj.setImageType(Constants.TAKE_TIMBER_DELIVERED_PHOTO);
		obj.setPickerId(file.getPickerID());
		obj.setPickerName(file.getPickerName());
		obj.setPackId(PackID);
		obj.setImageData(path);

		UploadImage(obj);
	}

	public void UploadImage(final Image image) {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;
			BufferedInputStream buffInputStream = null;
			File file;
			String path;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				try {
					/** MA HOA ANH */
					byte byteAnh[] = null;
					path = image.getImageData();
					file = new File(path);
					FileInputStream inputStream = new FileInputStream(path);
					buffInputStream = new BufferedInputStream(inputStream);
					byteAnh = new byte[buffInputStream.available()];
					buffInputStream.read(byteAnh);
					String encodedString = Base64.encodeToString(byteAnh, Base64.DEFAULT);
					image.setImageData(encodedString);

					/** GUI ANH VUA MA HOA LEN SERVICE */
					ImageControl ctrImage = new ImageControl(TimberDeliveredFragment.this.getActivity());
					objJSON = ctrImage.uploadTimberDeliveredImage(image);
					return objJSON;
				} catch (Exception e) {
					return null;
				}
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals("true")) {
								buffInputStream.close();
								if (file.delete()) {
									System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
								}
								btnSave.setVisibility(View.VISIBLE);
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals("false")) {
									// Toast.makeText(UnpackFragment.this.getActivity(),
									// Constants.ERR_SERVICE_NETWORK,
									// Toast.LENGTH_LONG).show();
									DialogDisconnectToServer(image, path);
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					// Toast.makeText(UnpackFragment.this.getActivity(),
					// Constants.ERR_SERVICE_NETWORK, Toast.LENGTH_LONG).show();
					DialogDisconnectToServer(image, path);
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void confirmUnpack() {
		new AsyncTask<String, String, JSONObject>() {
			JSONObject objJSON;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				proLoad.setVisibility(View.VISIBLE);
			}

			@Override
			protected JSONObject doInBackground(String... params) {
				try {
					UnpackControl ctrUnpack = new UnpackControl(TimberDeliveredFragment.this.getActivity());
					objJSON = ctrUnpack.confirmTimberDelivered(LAT, LNG, PackID);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return objJSON;
			}

			@Override
			protected void onPostExecute(JSONObject objJSON) {
				if (objJSON != null) {
					try {
						if (objJSON.getString(Constants.KEY_SUCCESS) != null) {
							if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_TRUE)) {
								Toast.makeText(TimberDeliveredFragment.this.getActivity(),
										"Confirm timber delivered success !",
										Toast.LENGTH_LONG).show();
								PackID = 0;
								showData("");
								etSearch.setText(null);
								etSearch.requestFocus();
								OpenKeyBoard(TimberDeliveredFragment.this.getActivity());
								//layoutLinnear.setVisibility(View.GONE);
							} else {
								if (objJSON.getString(Constants.KEY_SUCCESS).equals(Constants.KEY_FALSE)) {
									Toast.makeText(getActivity(), objJSON.getString(Constants.KEY_MESSAGE),
											Toast.LENGTH_SHORT).show();
								}
							}
						} else {
							Log.e("Error", Constants.ERR_SERVICE_NOT_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					Log.e("Error", Constants.ERR_SERVICE_NETWORK);
					DialogDisconnectToServer();
				}
				proLoad.setVisibility(View.GONE);
			}
		}.execute();
	}

	public void showData(String str) {
		String mime = "text/html";
		String encoding = "utf-8";
		
		wvShowView.loadDataWithBaseURL(null, str, mime, encoding, null);
	}

	public void setNullUnpack() {
		try {
			unpack = new Unpack(0, 0, 0, null, 0.0, null, 0, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void DialogDisconnectToServer(final Image image, final String path) {
		try {
			Log.e("LoginFramgment", "disconnect to server");
			Builder dialog = new AlertDialog.Builder(TimberDeliveredFragment.this.getActivity());
			dialog.setTitle("Message");
			dialog.setMessage(getString(R.string.UpImage_Message_no_response_form_server));
			// NEU OK SE LUU ANH DE UPLOAD SAU
			dialog.setPositiveButton("OK", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					sql_Image sqlImage = new sql_Image(TimberDeliveredFragment.this.getActivity());
					image.setImageData(path);
					sqlImage.insert(image);
					btnSave.setVisibility(View.VISIBLE);
				}
			});
			// NEU CANCEL SE XOA ANH TRONG SD CARD
			dialog.setNegativeButton("Cancel", new AlertDialog.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					File file = new File(path);
					if (file.delete()) {
						System.out.println(">>>>>>>>>>>>DELETE SD CARD: Done");
					}
				}
			});
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
