package vcn.kybotech.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import android.content.Context;
import vcn.kybotech.constants.Constants;
import vcn.kybotech.constants.JSONParser;
import vcn.kybotech.model.FileSave;

public class DespathchedControl {
	private JSONParser jsonParser;
	
	private int PICKER_ID;
	private String PICKER_NAME;
	private String DATE_TIME;
	private String VERSION;
	
	public DespathchedControl(Context context){
		jsonParser = new JSONParser();
		try {
			FileSave file = new FileSave(context, Constants.GET);
			PICKER_ID = file.getPickerID();
			PICKER_NAME = file.getPickerName();
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DATE_TIME = dateFormat.format(calendar.getTime());
			VERSION = android.os.Build.MODEL + " | " + android.os.Build.VERSION.RELEASE + " | " + String.valueOf(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public JSONObject getDriver(){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "listdrivers"));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
	
	public JSONObject checkUser(String type, String pickerid, String loadid){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "checkuser"));
		params.add(new BasicNameValuePair("action", type));
		params.add(new BasicNameValuePair("pickerid", pickerid));
		params.add(new BasicNameValuePair("loadid", loadid));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
	
	public JSONObject confirmDespatched(String loadId, int DriverId, Double LAT, Double LNG){
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("type", "NewDespatchedLoadOffline"));
		params.add(new BasicNameValuePair("pickerid", String.valueOf(PICKER_ID)));
		params.add(new BasicNameValuePair("loadid", loadId));
		params.add(new BasicNameValuePair("driverid", String.valueOf(DriverId)));
		params.add(new BasicNameValuePair("pickername", PICKER_NAME));
		params.add(new BasicNameValuePair("inapp", "NewPickingApp"));
		params.add(new BasicNameValuePair("lat", String.valueOf(LAT)));
		params.add(new BasicNameValuePair("lng", String.valueOf(LNG)));
		params.add(new BasicNameValuePair("version", VERSION));
		params.add(new BasicNameValuePair("phonedate", DATE_TIME));
		JSONObject objJSON = jsonParser.getJsonTuUrl(Constants.LINK_PROCESS, params);
		return objJSON;
	}
}
